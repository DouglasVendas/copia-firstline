import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()  # Carrega as variáveis do .env

class Config:
    SECRET_KEY = os.getenv("SECRET_TOKEN")
    ENV = os.getenv("FLASK_ENV", "development")
    RECALL_WEBHOOK_SECRET = os.getenv("RECALL_WEBHOOK_SECRET")
    RECALL_WEBHOOK_SECRET_UPDATE = os.getenv("RECALL_WEBHOOK_SECRET_UPDATE")
    GREENN_WEBHOOK_SECRET = os.getenv("GREENN_WEBHOOK_SECRET")
    # Configure maximum file upload size (200MB)
    MAX_CONTENT_LENGTH = 200 * 1024 * 1024  # 200MB
    # Configure timeout for requests
    SEND_FILE_MAX_AGE_DEFAULT = 500
    
    # JWT Configuration
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=5)   # Access token: 5 min
    JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)     # Refresh token: 30 dias
    
    # JWT Cookie Configuration
    JWT_TOKEN_LOCATION = ['cookies']
    JWT_ACCESS_COOKIE_NAME = 'access_token_cookie'
    JWT_REFRESH_COOKIE_NAME = 'refresh_token_cookie'
    JWT_COOKIE_SECURE = True if ENV == "production" else False  # Use secure cookies in production
    JWT_COOKIE_HTTPONLY = True  # Prevent XSS attacks
    JWT_COOKIE_SAMESITE = 'Strict' if ENV == "production" else 'Lax'  # CSRF protection
    JWT_COOKIE_CSRF_PROTECT = False  # We'll handle CSRF differently since we're using refresh tokens
    JWT_COOKIE_DOMAIN = '.firstlineai.com.br' if ENV == "production" else None  # Domain for cookies
    JWT_ACCESS_COOKIE_PATH = '/'
    JWT_REFRESH_COOKIE_PATH = '/'
    
    # Cookie Max-Age configuration (in seconds)
    JWT_ACCESS_COOKIE_MAX_AGE = int(JWT_ACCESS_TOKEN_EXPIRES.total_seconds())  # 5 minutes
    JWT_REFRESH_COOKIE_MAX_AGE = int(JWT_REFRESH_TOKEN_EXPIRES.total_seconds())  # 30 days
    
    # RSA Keys paths
    PRIVATE_KEY_PATH = os.path.join(os.path.dirname(__file__), 'keys', 'private.pem')
    PUBLIC_KEY_PATH = os.path.join(os.path.dirname(__file__), 'keys', 'public.pem')
