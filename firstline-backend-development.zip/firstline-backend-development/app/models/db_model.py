import os
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool
from sqlalchemy.orm import scoped_session, sessionmaker
import logging
from dotenv import load_dotenv

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Configuração de logging
logger = logging.getLogger(__name__)

# Dicionário para armazenar engines de banco de dados
ENGINE_CACHE = {}

def create_db_engine(db_name, pool_size=5, max_overflow=10, pool_timeout=30):
    """
    Creates or retrieves a cached SQLAlchemy engine with connection pooling
    """
    # Retornar engine se já estiver na cache
    if db_name in ENGINE_CACHE:
        return ENGINE_CACHE[db_name]

    # Extrair informações de conexão e criar URL
    connection_url = os.getenv(db_name)
    if not connection_url:
        return None
    
    # Criar engine com pooling
    try:
        engine = create_engine(
            connection_url,
            poolclass=QueuePool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_timeout=pool_timeout,
            pool_pre_ping=True,
            echo=False
        )
            
        ENGINE_CACHE[db_name] = engine
        logger.info(f"Database engine para {db_name} criado com sucesso.")
        return engine
        
    except Exception as e:
        logger.error(f"Erro ao criar engine para {db_name}: {e}")
        return None

def get_db_session(db_name):
    """
    Returns a scoped session for database operations
    """
    engine = create_db_engine(db_name)
    if not engine:
        return None
    Session = scoped_session(sessionmaker(bind=engine))
    return Session()

def dispose_all_engines():
    """
    Close all database connections - useful for application shutdown
    """
    # Dispor todos os engines
    for db_name, engine in ENGINE_CACHE.items():
        logger.info(f"Dispondo engine para {db_name}")
        engine.dispose()
    
    # Limpar cache
    ENGINE_CACHE.clear()

def get_cache_stats():
    """
    Returns statistics about the current state of the database connection caches
    """
    return {
        'engines': len(ENGINE_CACHE)
    }