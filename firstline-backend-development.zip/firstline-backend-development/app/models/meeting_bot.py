import os
import logging
import requests
import tempfile
import threading
from flask import jsonify
from sqlalchemy import text
from datetime import datetime
from dotenv import load_dotenv
from app.models.db_model import create_db_engine
from app.models.analyze_audio import AudioAnalyzer

# Load environment variables
load_dotenv()

class MeetingBot:
    def __init__(self):
        self.engine = create_db_engine("DB_URI")
        self.analyze_audio = AudioAnalyzer()
        self.logger = logging.getLogger(__name__)
        self.recall_ai_token = os.getenv("RECALL_AI_TOKEN")
        self.recall_url = "https://us-west-2.recall.ai/api/v1/"

    def create_bot(self, user_id, platform, meeting_url, context_id, vendedor_id, analysis_name):
        """Cria um bot de transcrição para uma reunião."""
        url = self.recall_url + "bot/"
        payload = {
            "bot_name": "FirstLineAI",
            "meeting_url": meeting_url,
            "recording_config": {
                "audio_mixed_mp3": {},
                "metadata": {
                    "user_id": user_id,
                    "context_id": context_id, 
                    "vendedor_id": vendedor_id,
                    "analysis_name": analysis_name
                }
            }
        }
        headers = {
            "accept": "application/json",
            "content-type": "application/json",
            "Authorization": self.recall_ai_token
        }
        try:
            response = requests.post(url, json=payload, headers=headers)
            response.raise_for_status()
            self.logger.info(f"Bot criado com sucesso: {response.json()}")
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao criar bot: {e}")
            return jsonify({"error": "Erro ao criar bot"}), 500
        
        # Salvar o bot no banco de dados
        with self.engine.connect() as connection:
            try:
                query = text("""
                    INSERT INTO meeting_bots (id, user_id, platform, bot_name, meeting_url, vendedor_id, created_at, updated_at, status)
                    VALUES (:id, :user_id, :platform, :bot_name, :meeting_url, :vendedor_id, :created_at, :updated_at, :status)
                """)
                connection.execute(query, {
                    "id": response.json().get("id"),
                    "user_id": user_id,
                    "platform": platform,
                    "bot_name": analysis_name,
                    "meeting_url": meeting_url,
                    "vendedor_id": vendedor_id,
                    "created_at": datetime.now(),
                    "updated_at": datetime.now(),
                    "status": "created"
                })
                connection.commit()
            except Exception as e:
                self.logger.error(f"Erro ao salvar bot no banco de dados: {e}")
                return jsonify({"error": "Erro ao salvar bot no banco de dados"}), 500
        return jsonify({"message": "Bot criado com sucesso"}), 202
    
    def get_bots(self, user_id):
        """Obtém todos os bots cadastrados para o usuário.
        
        Args:
            user_id (str): ID do usuário.
        
        Returns:
            200 OK: Se os bots foram obtidos com sucesso.
            {
                "success": true,
                "bots": [
                    {
                        "id": str(row.id),
                        "user_id": str(row.user_id),
                        "platform": row.platform,
                        "bot_name": row.bot_name,
                        "meeting_url": row.meeting_url,
                        "analysis_id": row.analysis_id,
                        "vendedor_id": row.vendedor_id,
                        "created_at": row.created_at,
                        "updated_at": row.updated_at,
                        "status": row.status,
                        "analysis_name": row.analysis_name
                    }
                ]
            }
        """
        with self.engine.connect() as connection:
            try:
                query = text("""
                    SELECT 
                        mb.id, 
                        mb.user_id, 
                        mb.platform, 
                        mb.bot_name, 
                        mb.meeting_url, 
                        mb.analysis_id, 
                        mb.vendedor_id, 
                        mb.created_at, 
                        mb.ended_at, 
                        mb.status, 
                        mb.updated_at,
                        COALESCE(a.analysis_name, mb.bot_name) AS analysis_name
                    FROM meeting_bots mb
                    LEFT JOIN analyses a ON mb.analysis_id IS NOT NULL AND mb.analysis_id::text = a.id::text
                    WHERE CAST(mb.user_id AS UUID) = CAST(:user_id AS UUID)
                    ORDER BY mb.created_at DESC
                """)
                result = connection.execute(query, {"user_id": user_id}).fetchall()
                
                bots_list = []
                for row in result:
                    bot_data = {
                        "id": str(row.id),
                        "user_id": str(row.user_id),
                        "platform": row.platform,
                        "bot_name": row.bot_name,
                        "meeting_url": row.meeting_url,
                        "analysis_id": row.analysis_id,
                        "vendedor_id": row.vendedor_id,
                        "created_at": row.created_at,
                        "ended_at": row.ended_at,
                        "status": row.status,
                        "updated_at": row.updated_at,
                        "analysis_name": row.analysis_name
                    }
                    bots_list.append(bot_data)

                return jsonify({"success": True, "bots": bots_list}), 200

            except Exception as e:
                self.logger.error(f"Erro ao obter bots: {e}")
                return jsonify({"error": "Erro ao obter bots"}), 500

    def delete_bot(self, bot_id):
        """Retira um bot de transcrição de uma reunião."""
        url = f"{self.recall_url}bot/{bot_id}/leave_call/"
        headers = {
            "Authorization": self.recall_ai_token
        }
        try:
            response = requests.post(url, headers=headers)
            response.raise_for_status()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao retirar bot: {e}")
            return jsonify({"error": "Erro ao retirar bot"}), 500
        return jsonify({"message": "Bot retirado com sucesso"}), 200
    
    def _get_number_of_participants(self, bot_id):
        """Obtém o número de participantes de uma reunião."""
        url = f"{self.recall_url}bot/{bot_id}"
        headers = {
            "Authorization": self.recall_ai_token
        }
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            participants_url = data.get("recordings", [{}])[0].get("media_shortcuts", {}).get("participant_events", {}).get("data", {}).get("participants_download_url", [])
            if not participants_url:
                self.logger.error("URL de participantes não encontrada")
                return None
            participants_response = requests.get(participants_url)
            participants_response.raise_for_status()
            return len(participants_response.json())
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter número de participantes: {e}")
            return None
        
    def _update_bot_status(self, bot_id, status, updated_at):
        """Atualiza o status e updated_at do bot no banco de dados."""
        with self.engine.connect() as connection:
            try:
                query = text("""
                    UPDATE meeting_bots 
                    SET status = :status, updated_at = :updated_at 
                    WHERE id = :bot_id
                """)
                connection.execute(query, {
                    "status": status,
                    "updated_at": updated_at,
                    "bot_id": bot_id
                })
                connection.commit()
                self.logger.info(f"Status do bot {bot_id} atualizado para {status} em {updated_at}")
            except Exception as e:
                self.logger.error(f"Erro ao atualizar status do bot no banco de dados: {e}")

    def _save_ended_at_in_db(self, bot_id):
        """Salva o tempo de término do bot no banco de dados."""
        with self.engine.connect() as connection:
            ended_at = datetime.now()
            try:
                query = text("""
                    UPDATE meeting_bots SET ended_at = :ended_at, updated_at = :updated_at, status = :status WHERE id = :bot_id
                """)
                connection.execute(query, {
                    "ended_at": ended_at,
                    "updated_at": ended_at,
                    "status": "done",
                    "bot_id": bot_id
                })
                connection.commit()
            except Exception as e:
                self.logger.error(f"Erro ao salvar ended_at no banco de dados: {e}")

    def webhook_bot_api(self, user_id, context_id, vendedor_id, audio_id, bot_id, analysis_name):
        """Recebe webhooks da Recall AI."""
        url = f"{self.recall_url}audio_mixed/{audio_id}/"
        headers = {
            "Authorization": self.recall_ai_token
        }
        try:
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            download_url = data.get("data", {}).get("download_url")

            if not download_url:
                self.logger.error("Download URL não encontrado nos dados do webhook")
                return jsonify({"error": "Download URL não encontrado"}), 400

            # Inicia o processamento assíncrono
            thread = threading.Thread(
                target=self._process_audio_async,
                args=(download_url, context_id, vendedor_id, user_id, bot_id, audio_id, analysis_name)
            )
            thread.daemon = True
            thread.start()

            # Salva o tempo de término do bot no banco de dados
            self._save_ended_at_in_db(bot_id)

            # Retorna 202 imediatamente
            return jsonify({"success": True, "message": "Processamento iniciado"}), 202

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao obter dados do webhook: {e}")
            return jsonify({"error": "Erro ao obter dados do webhook"}), 500

    def _process_audio_async(self, download_url, context_id, vendedor_id, user_id, bot_id, audio_id, analysis_name):
        """Processa o áudio de forma assíncrona."""
        try:
            # Baixa o áudio
            audio_response = requests.get(download_url)
            audio_response.raise_for_status()

            # Obtém o número de participantes
            speakers_expected = self._get_number_of_participants(bot_id)

            # Cria arquivo temporário com o conteúdo do áudio
            with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as temp_file:
                temp_file.write(audio_response.content)
                temp_file_path = temp_file.name

            # Cria um objeto similar ao FileStorage para compatibilidade
            class TempAudioFile:
                def __init__(self, file_path, content):
                    self.file_path = file_path
                    self.content = content
                    self.filename = f"meeting_audio_{audio_id}.mp3"
                    self.content_type = "audio/mpeg"
                    self.content_length = len(content)
                    
                def seek(self, pos, whence=0):
                    # Para compatibilidade, mas não precisa implementar de fato
                    pass
                    
                def tell(self):
                    return len(self.content)
                    
                def read(self, size=-1):
                    return self.content
                
                def save(self, path):
                    """Salva o conteúdo do áudio no caminho especificado."""
                    with open(path, 'wb') as f:
                        f.write(self.content)

            temp_audio = TempAudioFile(temp_file_path, audio_response.content)

            # Processa o áudio
            result, status_code = self.analyze_audio.analyze_audio(
                temp_audio, context_id, vendedor_id, user_id, speakers_expected, analysis_name
            )

            if status_code == 200:
                self.logger.info(f"Análise de áudio concluída com sucesso para bot {bot_id}")
                analysis_id = result.get("analysis").get("id") if result.get("analysis") else None
                if analysis_id:
                    with self.engine.connect() as connection:
                        try:
                            query = text("""
                                UPDATE meeting_bots SET analysis_id = :analysis_id WHERE id = :bot_id
                            """)
                            connection.execute(query, {
                                "analysis_id": analysis_id,
                                "bot_id": bot_id
                            })
                            connection.commit()
                        except Exception as e:
                            self.logger.error(f"Erro ao salvar analysis_id no banco de dados: {e}")
            else:
                self.logger.error(f"Erro na análise de áudio para bot {bot_id}: {result}")

        except Exception as e:
            self.logger.error(f"Erro no processamento assíncrono do áudio: {e}")
        finally:
            try:
                if 'temp_file_path' in locals():
                    os.unlink(temp_file_path)
            except Exception as e:
                self.logger.warning(f"Erro ao remover arquivo temporário: {e}")
