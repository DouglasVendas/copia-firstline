import logging
import uuid
import random
import string
from datetime import datetime, timedelta
from app.models.db_model import create_db_engine
from app.utils.email_service import EmailService
from sqlalchemy import text
import os

class TwoFAModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.email_service = EmailService()

    def _generate_code(self):
        """Gera um código de 6 dígitos"""
        return ''.join(random.choices(string.digits, k=6))

    def _generate_expiration(self, minutes=10):
        """Gera timestamp de expiração (padrão 10 minutos)"""
        return datetime.now() + timedelta(minutes=minutes)

    def _get_user_email(self, user_id):
        """Busca o email do usuário pelo ID"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return None
        
        try:
            query = text("SELECT email FROM users WHERE CAST(id AS UUID) = CAST(:user_id AS UUID)")
            result = conn.execute(query, {'user_id': user_id}).fetchone()
            
            if not result:
                self.logger.error(f"User not found: {user_id}")
                return None
            
            return result[0]
            
        except Exception as e:
            self.logger.error(f"Error getting user email: {e}")
            return None
        finally:
            conn.close()

    def create_code(self, user_id):
        """Cria um novo código 2FA para o usuário"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return None
        
        try:
            # Limpar códigos antigos não utilizados
            cleanup_query = text("""
                DELETE FROM two_fa_codes 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND expires_at < :current_time
            """)
            current_time = datetime.now()
            conn.execute(cleanup_query, {'user_id': user_id, 'current_time': current_time})
            
            # Verificar se já existe um código válido
            check_query = text("""
                SELECT id, expires_at FROM two_fa_codes 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND expires_at > :current_time
            """)
            existing_code = conn.execute(check_query, {'user_id': user_id, 'current_time': current_time}).fetchone()
            
            if existing_code:
                return {'success': True, 'message': 'Código já enviado. Verifique seu email.', 'expires_at': existing_code[1].isoformat() + 'Z'}
            
            # Gerar novo código
            code_id = str(uuid.uuid4())
            code = self._generate_code()
            expires_at = self._generate_expiration()
            
            # Inserir código no banco
            insert_query = text("""
                INSERT INTO two_fa_codes (id, user_id, code, expires_at, created_at)
                VALUES (:id, :user_id, :code, :expires_at, :created_at)
            """)
            
            conn.execute(insert_query, {
                'id': code_id,
                'user_id': user_id,
                'code': code,
                'expires_at': expires_at,
                'created_at': datetime.now()
            })
            
            conn.commit()
            
            # Enviar email com o código
            user_email = self._get_user_email(user_id)
            if user_email and self.email_service.send_2fa_code_email(user_email, code):
                return {
                    'success': True,
                    'message': 'Código enviado para o email',
                    'expires_at': expires_at.isoformat() + 'Z'
                }
            else:
                # Se falhou ao enviar email, deletar o código e retornar erro
                delete_query = text("DELETE FROM two_fa_codes WHERE id = :code_id")
                conn.execute(delete_query, {'code_id': code_id})
                conn.commit()
                
                return {
                    'error': 'Erro ao enviar código por email',
                    'code': 500
                }
            
        except Exception as e:
            self.logger.error(f"Error creating 2FA code: {e}")
            try:
                conn.rollback()
            except:
                pass
            return None
        finally:
            conn.close()

    def verify_code(self, email, code):
        """Verifica se o código 2FA está correto e não expirado"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return None
        
        try:
            # Primeiro buscar o user_id pelo email
            user_query = text("SELECT id FROM users WHERE email = :email")
            user_result = conn.execute(user_query, {'email': email}).fetchone()
            
            if not user_result:
                return {'valid': False, 'error': 'Usuário não encontrado'}
            
            user_id = user_result[0]
            
            # Buscar código válido
            query = text("""
                SELECT id, code, expires_at
                FROM two_fa_codes 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND expires_at > :current_time
                ORDER BY created_at DESC
                LIMIT 1
            """)
            
            current_time = datetime.now()
            result = conn.execute(query, {'user_id': user_id, 'current_time': current_time}).fetchone()
            
            if not result:
                return {'valid': False, 'error': 'Código não encontrado ou expirado'}
            
            code_id, stored_code, expires_at = result
            
            # Verificar se o código está correto
            if code != stored_code:
                return {'valid': False, 'error': 'Código inválido'}
            
            # Deletar código
            delete_query = text("""
                DELETE FROM two_fa_codes 
                WHERE id = :code_id
            """)
            
            conn.execute(delete_query, {'code_id': code_id})
            conn.commit()
            
            return {'valid': True, 'message': 'Código verificado com sucesso', 'user_id': user_id}
            
        except Exception as e:
            self.logger.error(f"Error verifying 2FA code: {e}")
            try:
                conn.rollback()
            except:
                pass
            return None
        finally:
            conn.close()

    def resend_code(self, email):
        """Reenvia um novo código 2FA"""
        # Primeiro, vamos buscar o user_id pelo email
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return None
        
        try:
            # Buscar user_id pelo email
            user_query = text("SELECT id FROM users WHERE email = :email")
            user_result = conn.execute(user_query, {'email': email}).fetchone()
            
            if not user_result:
                return {'error': 'Usuário não encontrado', 'code': 404}
            
            user_id = user_result[0]
            
            # Limpar códigos antigos
            cleanup_query = text("""
                DELETE FROM two_fa_codes 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            conn.execute(cleanup_query, {'user_id': user_id})
            
            # Verificar quantas tentativas recentes (últimas 24h)
            recent_attempts_query = text("""
                SELECT COUNT(*) 
                FROM two_fa_codes 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)
                AND created_at > :twenty_four_hours_ago
            """)
            
            twenty_four_hours_ago = datetime.now() - timedelta(hours=24)
            recent_count = conn.execute(recent_attempts_query, {
                'user_id': user_id,
                'twenty_four_hours_ago': twenty_four_hours_ago
            }).scalar()
            
            # Limite de 10 tentativas por dia
            if recent_count >= 10:
                return {'error': 'Limite de tentativas excedido. Tente novamente amanhã.', 'code': 429}
            
            conn.close()
            
            # Criar novo código
            return self.create_code(user_id)
            
        except Exception as e:
            self.logger.error(f"Error resending 2FA code: {e}")
            return None
        finally:
            conn.close() 