import logging
import uuid
import secrets
from datetime import datetime, timedelta
from app.models.db_model import create_db_engine
from app.utils.email_service import EmailService
from sqlalchemy import text

class PaymentModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.email_service = EmailService()

    def _generate_token(self):
        """Gera um token único de 43 caracteres"""
        return secrets.token_urlsafe(32)  # Gera 43 caracteres

    def _generate_expiration(self, hours=24):
        """Gera timestamp de expiração (padrão 24 horas)"""
        return datetime.now() + timedelta(hours=hours)
    
    def _get_plan_name_from_product_id(self, product_id):
        """
        Converte product ID para nome do plano usando a tabela relacao_id_produto
        
        Args:
            product_id (str): ID do produto
            
        Returns:
            str: Nome do plano ou o ID original se não encontrado
        """
        if not product_id:
            return None
            
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed for plan lookup")
            return product_id  # Retorna o ID original se não conseguir conectar
        
        try:
            query = text("""
                SELECT plan FROM relacao_id_produto 
                WHERE product_id = :product_id
            """)
            
            result = conn.execute(query, {'product_id': product_id}).fetchone()
            
            if result:
                plan_name = result[0]
                self.logger.info(f"Converted Product ID {product_id} to plan: {plan_name}")
                return plan_name
            else:
                self.logger.warning(f"Plan not found for Product ID: {product_id}")
                return product_id  # Retorna o ID original se não encontrar
                
        except Exception as e:
            self.logger.error(f"Error looking up plan for Product ID {product_id}: {e}")
            return product_id  # Retorna o ID original em caso de erro
        finally:
            conn.close()

    def create_registration_token(self, customer_email, subscription_plan=None, 
                                payment_intent_id=None, customer_id=None):
        """
        Cria um token de registro após pagamento bem-sucedido
        
        Args:
            customer_email (str): Email do cliente
            subscription_plan (str, optional): Product ID que será convertido para nome do plano
            payment_intent_id (str, optional): ID do payment intent
            customer_id (str, optional): ID do cliente na plataforma de pagamento
            
        Returns:
            dict: Dados do token criado ou erro
        """
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return {'error': 'Erro interno do servidor', 'code': 500}
        
        try:
            # Converter product ID para nome do plano
            plan_name = self._get_plan_name_from_product_id(subscription_plan)
            
            # Verificar se já existe um token válido para este email
            check_query = text("""
                SELECT token, expires_at FROM registration_tokens 
                WHERE customer_email = :email AND expires_at > :current_time AND used_at IS NULL
            """)
            current_time = datetime.now()
            existing_token = conn.execute(check_query, {
                'email': customer_email, 
                'current_time': current_time
            }).fetchone()
            
            if existing_token:
                # Se já existe um token válido, reenvia o email
                if self.email_service.send_registration_token_email(
                    customer_email, existing_token[0], plan_name
                ):
                    return {
                        'success': True,
                        'message': 'Token de registro reenviado',
                        'token': existing_token[0],
                        'expires_at': existing_token[1].isoformat() + 'Z'
                    }
                else:
                    return {'error': 'Erro ao enviar email', 'code': 500}
            
            # Gerar novo token
            token = self._generate_token()
            expires_at = self._generate_expiration()
            
            # Inserir token no banco
            insert_query = text("""
                INSERT INTO registration_tokens 
                (token, customer_email, subscription_plan, payment_intent_id, 
                 customer_id, created_at, expires_at)
                VALUES (:token, :email, :plan, :payment_intent_id, :customer_id, :created_at, :expires_at)
            """)
            
            conn.execute(insert_query, {
                'token': token,
                'email': customer_email,
                'plan': plan_name,
                'payment_intent_id': payment_intent_id,
                'customer_id': customer_id,
                'created_at': datetime.now(),
                'expires_at': expires_at
            })
            
            conn.commit()
            
            # Enviar email com o token
            if self.email_service.send_registration_token_email(
                customer_email, token, plan_name
            ):
                self.logger.info(f"Registration token created and sent to {customer_email}")
                return {
                    'success': True,
                    'message': 'Token de registro criado e enviado',
                    'token': token,
                    'expires_at': expires_at.isoformat() + 'Z'
                }
            else:
                # Se falhou ao enviar email, deletar o token
                delete_query = text("DELETE FROM registration_tokens WHERE token = :token")
                conn.execute(delete_query, {'token': token})
                conn.commit()
                
                return {'error': 'Erro ao enviar email de registro', 'code': 500}
            
        except Exception as e:
            self.logger.error(f"Error creating registration token: {e}")
            try:
                conn.rollback()
            except:
                pass
            return {'error': 'Erro interno do servidor', 'code': 500}
        finally:
            conn.close()

    def validate_registration_token(self, token):
        """
        Valida se o token de registro é válido
        
        Args:
            token (str): Token a ser validado
            
        Returns:
            dict: Resultado da validação
        """
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return {'valid': False, 'error': 'Erro interno do servidor'}
        
        try:
            query = text("""
                SELECT customer_email, subscription_plan, payment_intent_id, 
                       customer_id, expires_at, used_at, created_at
                FROM registration_tokens 
                WHERE token = :token
            """)
            
            result = conn.execute(query, {'token': token}).fetchone()
            
            if not result:
                return {'valid': False, 'error': 'Token inválido'}
            
            customer_email, subscription_plan, payment_intent_id, customer_id, expires_at, used_at, created_at = result
            
            # Verificar se o token já foi usado
            if used_at:
                return {'valid': False, 'error': 'Token já utilizado'}
            
            # Verificar se o token expirou
            if expires_at < datetime.now():
                return {'valid': False, 'error': 'Token expirado'}
            
            return {
                'valid': True,
                'data': {
                    'customer_email': customer_email,
                    'subscription_plan': subscription_plan,
                    'payment_intent_id': payment_intent_id,
                    'customer_id': customer_id,
                    'expires_at': expires_at.isoformat() + 'Z',
                    'created_at': created_at.isoformat() + 'Z'
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error validating registration token: {e}")
            return {'valid': False, 'error': 'Erro interno do servidor'}
        finally:
            conn.close()

    def mark_token_as_used(self, token):
        """
        Marca um token como usado após o registro ser concluído
        
        Args:
            token (str): Token a ser marcado como usado
            
        Returns:
            bool: True se marcado com sucesso, False caso contrário
        """
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return False
        
        try:
            # Verificar se o token existe e não foi usado
            check_query = text("""
                SELECT customer_email FROM registration_tokens 
                WHERE token = :token AND used_at IS NULL AND expires_at > :current_time
            """)
            
            result = conn.execute(check_query, {
                'token': token,
                'current_time': datetime.now()
            }).fetchone()
            
            if not result:
                self.logger.warning(f"Attempt to mark invalid/expired token as used: {token}")
                return False
            
            # Marcar como usado
            update_query = text("""
                UPDATE registration_tokens 
                SET used_at = :used_at
                WHERE token = :token
            """)
            
            conn.execute(update_query, {
                'token': token,
                'used_at': datetime.now()
            })
            
            conn.commit()
            
            self.logger.info(f"Registration token marked as used: {token}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error marking token as used: {e}")
            try:
                conn.rollback()
            except:
                pass
            return False
        finally:
            conn.close()

    def cleanup_expired_tokens(self):
        """
        Remove tokens expirados do banco de dados
        
        Returns:
            int: Número de tokens removidos
        """
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return 0
        
        try:
            # Deletar tokens expirados
            delete_query = text("""
                DELETE FROM registration_tokens 
                WHERE expires_at < :current_time
            """)
            
            result = conn.execute(delete_query, {'current_time': datetime.now()})
            deleted_count = result.rowcount
            
            conn.commit()
            
            if deleted_count > 0:
                self.logger.info(f"Cleaned up {deleted_count} expired registration tokens")
            
            return deleted_count
            
        except Exception as e:
            self.logger.error(f"Error cleaning up expired tokens: {e}")
            try:
                conn.rollback()
            except:
                pass
            return 0
        finally:
            conn.close()
