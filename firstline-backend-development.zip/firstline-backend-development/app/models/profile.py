import logging
from datetime import datetime
from app.models.db_model import create_db_engine
from sqlalchemy import text
from PIL import Image
import io, os, magic

class ProfileModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.UPLOAD_DIR = '/var/www/profile/picture/'
        # Caminho interno para X-Accel-Redirect (deve corresponder à configuração do Nginx)
        self.INTERNAL_PATH = '/profile-pictures/'

    def get_profile(self, user_id):
        """Get user profile by user_id"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            query = text("""
                SELECT 
                    id,
                    user_id,
                    company_name,
                    responsible_name,
                    phone,
                    cnpj,
                    contact_email,
                    current_plan,
                    plan_renewal_date,
                    created_at,
                    updated_at,
                    google_connected,
                    google_email,
                    google_name,
                    google_picture
                FROM profiles 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            
            result = conn.execute(query, {'user_id': user_id})
            row = result.fetchone()
            
            if not row:
                return None
            
            # Converter para dicionário
            profile = {
                'id': str(row[0]),
                'user_id': str(row[1]),
                'company_name': row[2],
                'responsible_name': row[3],
                'phone': row[4],
                'cnpj': row[5],
                'contact_email': row[6],
                'current_plan': row[7],
                'plan_renewal_date': row[8].isoformat() if row[8] else None,
                'created_at': row[9].isoformat() if row[9] else None,
                'updated_at': row[10].isoformat() if row[10] else None,
                'google_connected': row[11] if row[11] is not None else False,
                'google_email': row[12],
                'google_name': row[13],
                'google_picture': row[14]
            }
            
            self.logger.info(f"Profile retrieved for user_id: {user_id}")
            return profile
            
        except Exception as e:
            self.logger.error(f"Error getting profile for user_id {user_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def put_profile(self, user_id, data):
        """Update user profile"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Primeiro verificar se o perfil existe
            check_query = text("SELECT id FROM profiles WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            result = conn.execute(check_query, {'user_id': user_id})
            if not result.fetchone():
                return None
            
            # Construir query de update dinamicamente
            update_fields = []
            params = {'user_id': user_id, 'updated_at': datetime.utcnow()}
            
            for field in ['company_name', 'responsible_name', 'phone', 'cnpj', 'contact_email']:
                if field in data:
                    update_fields.append(f"{field} = :{field}")
                    params[field] = data[field]
            
            if not update_fields:
                # Se não há campos para atualizar, retornar o perfil atual
                return self.get_profile(user_id)
            
            update_query = text(f"""
                UPDATE profiles 
                SET {', '.join(update_fields)}, updated_at = :updated_at
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            
            conn.execute(update_query, params)
            conn.commit()
            
            # Retornar o perfil atualizado
            updated_profile = self.get_profile(user_id)
            self.logger.info(f"Profile updated for user_id: {user_id}")
            return updated_profile
            
        except Exception as e:
            self.logger.error(f"Error updating profile for user_id {user_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def upload_profile_picture(self, user_id, file, extensao):
        """Upload profile picture"""
        try:
            img = Image.open(file)

            # Limites: 800x800 pixels, 500KB
            max_size = (800, 800)
            max_size_kb = 500

            if img.width > max_size[0] or img.height > max_size[1]:
                img.thumbnail(max_size)
            
            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=85, optimize=True)
            size_kb = len(buffer.getvalue()) / 1024

            # Faz segunda compressão se necessário
            if size_kb > max_size_kb:
                buffer = io.BytesIO()
                img.save(buffer, format='JPEG', quality=75, optimize=True)
                size_kb = len(buffer.getvalue()) / 1024

            # Salvar arquivo
            buffer.seek(0)
            nome_arquivo = f"{user_id}.jpg"
            caminho = os.path.join(self.UPLOAD_DIR, nome_arquivo)

            with open(caminho, 'wb') as f:
                f.write(buffer.read())

            self.logger.info(f"Profile picture uploaded for user_id: {user_id}")
            
            return True

        except Exception as e:
            self.logger.error(f"Error uploading profile picture for user_id {user_id}: {e}")
            return False

    def get_profile_picture_path(self, user_id):
        """Get the internal path for X-Accel-Redirect"""
        try:
            # Verificar se o arquivo existe no sistema
            nome_arquivo = f"{user_id}.jpg"
            caminho_completo = os.path.join(self.UPLOAD_DIR, nome_arquivo)
            
            if not os.path.exists(caminho_completo):
                self.logger.warning(f"Profile picture file not found for user_id: {user_id}")
                return None
            
            # Retornar o caminho interno que o Nginx vai mapear
            # O Nginx precisa ter:
            # location /profile-pictures/ { -> location para acessar o nginx
            #     internal;
            #     alias /var/www/profile/picture/; -> caminho real do arquivo
            # }
            internal_path = f"{self.INTERNAL_PATH}{nome_arquivo}"
            
            self.logger.info(f"Profile picture path retrieved for user_id: {user_id}")
            return internal_path
            
        except Exception as e:
            self.logger.error(f"Error getting profile picture path for user_id {user_id}: {e}")
            return None