import logging
import json
import uuid
import re
from datetime import datetime, timedelta
from sqlalchemy import text
from app.models.db_model import create_db_engine
from app.utils.disc_profiles import get_disc_profile_by_id

class AnalyzeManager:
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def get_analyzes(self, user_id, limit=50, offset=0, vendedor=None, context_id=None, upload_type=None, sort='created_at'):
        """Get all analyzes for a user with filtering and pagination"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Build WHERE clause with filters
            where_conditions = ["CAST(a.user_id AS UUID) = CAST(:user_id AS UUID)"]
            params = {'user_id': user_id, 'limit': limit, 'offset': offset}
            
            if vendedor:
                where_conditions.append("a.vendedor = :vendedor")
                params['vendedor'] = vendedor
            
            if context_id:
                where_conditions.append("a.context_uuid = :context_id")
                params['context_id'] = context_id
            
            if upload_type:
                where_conditions.append("a.upload_type = :upload_type")
                params['upload_type'] = upload_type
            
            where_clause = " AND ".join(where_conditions)
            
            # Build ORDER BY clause
            order_direction = 'DESC' if sort == 'created_at' else 'ASC'
            order_clause = f"ORDER BY a.{sort} {order_direction}"
            
            # Get total count for pagination
            count_query = text(f"SELECT COUNT(*) FROM analyses a WHERE {where_clause}")
            total_result = conn.execute(count_query, params)
            total = total_result.fetchone()[0]
            
            # Get paginated results
            query = text(f"""
                SELECT 
                    a.id, a.created_at, a.client_name, a.score_geral, a.upload_type, a.resumo,
                    a.pontos_positivos, a.pontos_atencao, a.objecoes_identificadas, 
                    a.sugestoes_melhoria, a.proximos_passos, a.context_uuid, a.transcription,
                    a.vendedor, a.analysis_name, a.framework_analysis, a.coaching_insights,
                    a.performance_analysis, a.mental_triggers, a.reformulacoes_pnl, a.plano_fechamento,
                    a.ia_preditiva, a.user_id, a.audio_duration_seconds, a.desempenho_geral, a.tempo_de_fala,
                    s.name as vendedor_nome, s.tipo as vendedor_tipo, c.name as context_name, a.disc_profile_id
                FROM analyses a
                LEFT JOIN sellers s ON CAST(a.vendedor AS UUID) = s.id
                LEFT JOIN contexts c ON CAST(a.context_uuid AS UUID) = c.id
                WHERE {where_clause}
                {order_clause}
                LIMIT :limit OFFSET :offset
            """)
            
            result = conn.execute(query, params)
            rows = result.fetchall()

            analyzes = []
            for row in rows:
                analyze = self._format_analyze_data(row)
                analyzes.append(analyze)
            
            # Calculate pagination info
            has_more = (offset + limit) < total
            
            return {
                'analyzes': analyzes,
                'pagination': {
                    'total': total,
                    'limit': limit,
                    'offset': offset,
                    'has_more': has_more
                }
            }

        except Exception as e:
            self.logger.error(f"Error getting analyzes: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def get_analyze(self, analyze_id, user_id=None):
        """Get a specific analyze by ID"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Validate UUID format
            if not self._is_valid_uuid(analyze_id):
                return None
            
            where_clause = "a.id = :id"
            params = {'id': analyze_id}
            
            # Add user_id filter if provided for authorization
            if user_id:
                where_clause += " AND CAST(a.user_id AS UUID) = CAST(:user_id AS UUID)"
                params['user_id'] = user_id
            
            query = text(f"""
                SELECT 
                    a.id, a.created_at, a.client_name, a.score_geral, a.upload_type, a.resumo,
                    a.pontos_positivos, a.pontos_atencao, a.objecoes_identificadas, 
                    a.sugestoes_melhoria, a.proximos_passos, a.context_uuid, a.transcription,
                    a.vendedor, a.analysis_name, a.framework_analysis, a.coaching_insights,
                    a.performance_analysis, a.mental_triggers, a.reformulacoes_pnl, a.plano_fechamento,
                    a.ia_preditiva, a.user_id, a.audio_duration_seconds, a.desempenho_geral, a.tempo_de_fala,
                    s.name as vendedor_nome, s.tipo as vendedor_tipo, c.name as context_name, a.disc_profile_id
                FROM analyses a
                LEFT JOIN sellers s ON CAST(a.vendedor AS UUID) = s.id
                LEFT JOIN contexts c ON CAST(a.context_uuid AS UUID) = c.id
                WHERE {where_clause}
            """)
            
            result = conn.execute(query, params)
            row = result.fetchone()
            
            if not row:
                return None
            
            return self._format_analyze_data(row)
            
        except Exception as e:
            self.logger.error(f"Error getting analyze {analyze_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def delete_analyze(self, analyze_id, user_id=None):
        """Delete an analyze by ID"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return False
            
            # Validate UUID format
            if not self._is_valid_uuid(analyze_id):
                return False
            
            # Check if analyze exists and belongs to user
            if user_id:
                check_query = text("SELECT id FROM analyses WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
                check_result = conn.execute(check_query, {'id': analyze_id, 'user_id': user_id})
                if not check_result.fetchone():
                    return False
            
            # Delete the analyze
            delete_query = text("DELETE FROM analyses WHERE id = :id")
            if user_id:
                delete_query = text("DELETE FROM analyses WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
                params = {'id': analyze_id, 'user_id': user_id}
            else:
                params = {'id': analyze_id}
            
            result = conn.execute(delete_query, params)
            conn.commit()
            
            return result.rowcount > 0
            
        except Exception as e:
            self.logger.error(f"Error deleting analyze {analyze_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return False
        finally:
            if conn:
                conn.close()

    def update_analyze(self, analyze_id, user_id, updates):
        """Update an analyze by ID"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Validate UUID format
            if not self._is_valid_uuid(analyze_id):
                return None
            
            # Check if analyze exists and belongs to user
            check_query = text("SELECT id FROM analyses WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            check_result = conn.execute(check_query, {'id': analyze_id, 'user_id': user_id})
            if not check_result.fetchone():
                return None
            
            # Build update query dynamically based on provided fields
            allowed_fields = {
                'client_name', 'vendedor', 'resumo', 'score_geral',
                'pontos_positivos', 'pontos_atencao', 'objecoes_identificadas',
                'sugestoes_melhoria', 'proximos_passos', 'framework_analysis',
                'coaching_insights', 'performance_analysis', 'mental_triggers',
                'reformulacoes_pnl', 'plano_fechamento', 'ia_preditiva',
                'analysis_name', 'desempenho_geral', 'tempo_de_fala'
            }
            
            update_fields = []
            params = {'id': analyze_id, 'user_id': user_id}
            
            for field, value in updates.items():
                if field in allowed_fields:
                    update_fields.append(f"{field} = :{field}")
                    # Convert lists/dicts to JSON strings for storage
                    if isinstance(value, (list, dict)):
                        params[field] = json.dumps(value, ensure_ascii=False)
                    else:
                        params[field] = value
            
            if not update_fields:
                self.logger.warning("No valid fields to update")
                return None
            
            # Execute update query
            update_query = text(f"""
                UPDATE analyses 
                SET {', '.join(update_fields)}
                WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            
            result = conn.execute(update_query, params)
            conn.commit()
            
            if result.rowcount == 0:
                return None
            
            # Return updated analyze
            return self.get_analyze(analyze_id, user_id)
            
        except Exception as e:
            self.logger.error(f"Error updating analyze {analyze_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def get_analyze_stats(self, user_id=None):
        """Get statistics about analyzes"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Base query parameters
            params = {}
            where_clause = ""
            
            # Add user filter if provided
            if user_id:
                where_clause = "WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)"
                params['user_id'] = user_id
            
            # Get total count
            total_query = text(f"SELECT COUNT(*) FROM analyses {where_clause}")
            total_result = conn.execute(total_query, params)
            total_count = total_result.fetchone()[0]
            
            # Get recent count (last 7 days)
            seven_days_ago = datetime.now() - timedelta(days=7)
            recent_query = text(f"""
                SELECT COUNT(*) FROM analyses 
                {where_clause + ' AND ' if where_clause else 'WHERE '}
                created_at >= :seven_days_ago
            """)
            params_recent = {**params, 'seven_days_ago': seven_days_ago}
            recent_result = conn.execute(recent_query, params_recent)
            recent_count = recent_result.fetchone()[0]

            return {
                'total_count': total_count,
                'recent_count': recent_count
            }
            
        except Exception as e:
            self.logger.error(f"Error getting analyze stats: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def cleanup_old_analyzes(self, older_than_date, user_id=None):
        """Delete analyzes older than specified date"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Base query parameters
            params = {'older_than': older_than_date}
            where_clause = "created_at < :older_than"
            
            # Add user filter if provided
            if user_id:
                where_clause += " AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)"
                params['user_id'] = user_id
            
            # Delete old analyzes
            delete_query = text(f"DELETE FROM analyses WHERE {where_clause}")
            result = conn.execute(delete_query, params)
            conn.commit()
            
            return {
                'deleted_count': result.rowcount
            }
            
        except Exception as e:
            self.logger.error(f"Error cleaning up old analyzes: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()
        
    def get_dashboard_view(self, user_id):
        """Get dashboard view data:
        Retorna:
        - totalAnalises: Total de análises feitas.
        - mediaPontuacao: Média da pontuação geral das análises.
        - taxaConversao: Média da probabilidade de fechamento
        - pipelineTotal: Soma dos valores de negócio estimados.
        """
        try:
            with create_db_engine('DB_URI').connect() as conn:
                # Query for dashboard summary data
                summary_query = text("""
                    SELECT 
                        COUNT(*) as totalAnalises,
                        AVG(score_geral) * 10 as mediaPontuacao,
                        AVG((ia_preditiva::json ->> 'probabilidade_fechamento')::float) AS taxaConversao
                    FROM analyses 
                    WHERE user_id = :user_id
                """)
                summary_result = conn.execute(summary_query, {'user_id': user_id})
                summary_row = summary_result.fetchone()

                # Query for pipeline total #TODO: criar campo com valor float
                pipeline_query = text("""
                    SELECT (ia_preditiva::json ->> 'valor_negocio_estimado')::TEXT AS valor_estimado 
                    FROM analyses 
                    WHERE user_id = :user_id
                """)
                pipeline_result = conn.execute(pipeline_query, {'user_id': user_id})

                pipelineTotal = 0
                for row in pipeline_result:
                    valor_texto = row[0]
                    valor_numerico = self._extract_valor_reais(valor_texto)
                    if valor_numerico:
                        pipelineTotal += valor_numerico

                if not summary_row:
                    return {
                        'totalAnalises': 0,
                        'mediaPontuacao': 0.0,
                        'taxaConversao': 0.0,
                        'pipelineTotal': pipelineTotal
                    }
                
                return {
                    'totalAnalises': summary_row[0] if summary_row[0] is not None else 0,
                    'mediaPontuacao': float(summary_row[1]) if summary_row[1] is not None else 0.0,
                    'taxaConversao': float(summary_row[2]) if summary_row[2] is not None else 0.0,
                    'pipelineTotal': pipelineTotal
                }

        except Exception as e:
            self.logger.error(f"Error getting dashboard view: {e}")
            return None
        
    def get_ranking(self, user_id):
        """Get ranking data
        Retorna:
        - objecoes: Dicionário com as principais objeções identificadas nas análises.
        - coaching: Dicionário com scores médios de coaching insights para o usuário.
        """
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None

            # Query para objeções
            query_objecoes = text("""
                SELECT
                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%medo%', '%cautela%', '%receio%', '%incerteza%'
                        ]) THEN 1 ELSE 0 END) AS medo,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%ansiedade%', '%impaciência%'
                        ]) THEN 1 ELSE 0 END) AS ansiedade,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%dúvida%', '%incerteza%', '%questionamento%'
                        ]) THEN 1 ELSE 0 END) AS duvida,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%resistência%', '%relutância%', '%objeção%'
                        ]) THEN 1 ELSE 0 END) AS resistencia,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%insegurança%', '%necessidade de segurança%', '%incerteza%'
                        ]) THEN 1 ELSE 0 END) AS inseguranca,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%conforto%'
                        ]) THEN 1 ELSE 0 END) AS conforto,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%frustração%', '%desapontamento%', '%constrangimento%'
                        ]) THEN 1 ELSE 0 END) AS frustracao,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%orgulho%'
                        ]) THEN 1 ELSE 0 END) AS orgulho,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%controle%'
                        ]) THEN 1 ELSE 0 END) AS controle,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%desinteresse%', '%sem tempo%', '%falta de tempo%'
                        ]) THEN 1 ELSE 0 END) AS desinteresse,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%desconfiança%', '%ceticismo%'
                        ]) THEN 1 ELSE 0 END) AS desconfianca,

                    SUM(CASE 
                        WHEN objecoes_identificadas::text ILIKE ANY (ARRAY[
                            '%financeira%', '%preço%', '%dinheiro%'
                        ]) THEN 1 ELSE 0 END) AS preco
                FROM analyses
                WHERE user_id = :user_id
            """)
            
            result_objecoes = conn.execute(query_objecoes, {'user_id': user_id})
            row_objecoes = result_objecoes.fetchone()
            columns_objecoes = result_objecoes.keys()
            
            # Converte resultado em dicionário dinamicamente
            objecoes = dict(zip(columns_objecoes, row_objecoes)) if row_objecoes else {}

            # Query para coaching
            query_coaching = text("""
                SELECT
                    AVG((performance_analysis::json -> 'Rapport' ->> 'score')::numeric) AS rapport,
                    AVG((performance_analysis::json -> 'Urgência' ->> 'score')::numeric) AS urgencia,
                    AVG((performance_analysis::json -> 'Estratégia Followup' ->> 'score')::numeric) AS estrategia_followup,
                    AVG((performance_analysis::json -> 'Apresentação Oferta' ->> 'score')::numeric) AS apresentacao_oferta,
                    AVG((performance_analysis::json -> 'Tratamento Objeções' ->> 'score')::numeric) AS tratamento_objecoes
                FROM analyses
                WHERE user_id = :user_id
            """)
            
            result_coaching = conn.execute(query_coaching, {'user_id': user_id})
            row_coaching = result_coaching.fetchone()
            columns_coaching = result_coaching.keys()
            
            # Converte resultado em dicionário dinamicamente
            coaching = dict(zip(columns_coaching, row_coaching)) if row_coaching else {}
            
            # Converte valores Decimal para float para serialização JSON
            coaching = {k: float(v) if v is not None else None for k, v in coaching.items()}

            return {
                'objecoes': objecoes,
                'coaching': coaching
            }

        except Exception as e:
            self.logger.error(f"Error getting ranking data: {e}")
            return None
        finally:
            if conn:
                conn.close()


    def get_latest(self, user_id):
        """Get the latest analyse and/or context"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                raise ValueError("Failed to get database connection")

            # Get latest analyse
            latest_query = text("""
                SELECT id, created_at FROM analyses 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)
                ORDER BY created_at DESC 
                LIMIT 1
            """)
            latest_result = conn.execute(latest_query, {'user_id': user_id})
            latest_row = latest_result.fetchone()

            # Get context
            context_query = text("""
                SELECT id, updated_at FROM contexts 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)
                ORDER BY updated_at DESC 
                LIMIT 1
            """)
            context_result = conn.execute(context_query, {'user_id': user_id})
            context_row = context_result.fetchone()

            # Monta o retorno conforme o que foi encontrado
            result = {}
            if latest_row:
                result['analyse'] = {
                    'id': str(latest_row[0]),
                    'created_at': latest_row[1].isoformat() + 'Z' if latest_row[1] else None
                }
            if context_row:
                result['context'] = {
                    'id': str(context_row[0]),
                    'updated_at': context_row[1].isoformat() + 'Z' if context_row[1] else None
                }
            if not result:
                return None
            return result

        except Exception as e:
            self.logger.error(f"Error getting latest analyse and context: {e}")
            raise ValueError("Internal server error")
        finally:
            if conn:
                conn.close()

    def _format_analyze_data(self, row):
        """Format database row into analyze data structure"""
        try:
            vendedor_id = row[13]
            # Os novos campos estão nos índices 26, 27, 28 e 29
            vendedor_nome = row[26]  # Nome do vendedor do JOIN
            vendedor_tipo = row[27]  # Tipo do vendedor do JOIN
            context_name = row[28]   # Nome do contexto do JOIN
            disc_profile_id = row[29] if len(row) > 29 else None  # ID do perfil DISC
            
            # Buscar dados completos do perfil DISC
            disc_profile = None
            if disc_profile_id:
                disc_profile = get_disc_profile_by_id(disc_profile_id)
            
            analyze = {
                'id': str(row[0]),
                'created_at': row[1].isoformat() + 'Z' if row[1] else None,
                'client_name': row[2],
                'score_geral': float(row[3]) if row[3] else None,
                'upload_type': row[4],
                'resumo': row[5],
                'pontos_positivos': self._parse_json_field(row[6]),
                'pontos_atencao': self._parse_json_field(row[7]),
                'objecoes_identificadas': self._parse_json_field(row[8]),
                'sugestoes_melhoria': self._parse_json_field(row[9]),
                'proximos_passos': self._parse_json_field(row[10]),
                'context_uuid': str(row[11]) if row[11] else None,
                'context_name': context_name,
                'transcription': row[12],
                'vendedor': vendedor_nome,
                'vendedor_id': vendedor_id,
                'vendedor_tipo': vendedor_tipo,
                'analysis_name': row[14],
                'framework_analysis': self._parse_json_field(row[15]),
                'coaching_insights': self._parse_json_field(row[16]),
                'performance_analysis': self._parse_json_field(row[17]),
                'mental_triggers': self._parse_json_field(row[18]),
                'reformulacoes_pnl': self._parse_json_field(row[19]),
                'plano_fechamento': self._parse_json_field(row[20]),
                'ia_preditiva': self._parse_json_field(row[21]),
                'user_id': str(row[22]),
                'audio_duration_seconds': float(row[23]) if row[23] is not None else None,
                'desempenho_geral': self._parse_json_field(row[24]) if row[24] is not None else None,
                'tempo_de_fala': self._parse_json_field(row[25]) if row[25] is not None else None,
                'disc_profile': disc_profile
            }
            return analyze
        except Exception as e:
            self.logger.error(f"Error formatting analyze data: {e}")
            return None

    def get_credits_remaining(self, user_id):
        """Get the remaining credits for a user"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None

            # Buscar limite e total de análises do mês em uma única query
            query = text("""
                SELECT 
                    p.monthly_analysis_limit,
                    (
                        SELECT COUNT(*) 
                        FROM analyses a 
                        WHERE CAST(a.user_id AS UUID) = CAST(p.user_id AS UUID)
                          AND EXTRACT(YEAR FROM a.created_at) = EXTRACT(YEAR FROM :current_date)
                          AND EXTRACT(MONTH FROM a.created_at) = EXTRACT(MONTH FROM :current_date)
                    ) as analyses_this_month
                FROM profiles p
                WHERE CAST(p.user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            current_date = datetime.now()
            result = conn.execute(query, {'user_id': user_id, 'current_date': current_date})
            row = result.fetchone()
            if row:
                user_credits = row[0] if row[0] is not None else 0
                analyses_this_month = row[1] if row[1] is not None else 0
            else:
                user_credits = 0
                analyses_this_month = 0

            return {
                'user_credits': user_credits,
                'analyses_this_month': analyses_this_month
            }
        except Exception as e:
            self.logger.error(f"Error getting credits remaining: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def _parse_json_field(self, field):
        """Parse JSON field safely"""
        if field is None:
            return None
        
        if isinstance(field, str):
            try:
                return json.loads(field)
            except json.JSONDecodeError:
                return field
        
        return field

    def _is_valid_uuid(self, uuid_string):
        """Validate UUID format"""
        try:
            uuid.UUID(uuid_string)
            return True
        except ValueError:
            return False

    def get_scores_by_seller(self, user_id):
        """Get scores grouped by seller with interpolated daily averages"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            query = text("""
                SELECT 
                    s.id as seller_id,
                    s.name as seller_name,
                    s.tipo as seller_type,
                    a.score_geral,
                    a.created_at
                FROM analyses a
                INNER JOIN sellers s ON CAST(a.vendedor AS UUID) = s.id
                WHERE CAST(a.user_id AS UUID) = CAST(:user_id AS UUID)
                AND a.score_geral IS NOT NULL
                ORDER BY s.name, a.created_at
            """)
            
            result = conn.execute(query, {'user_id': user_id})
            rows = result.fetchall()
            
            # Agrupar análises por vendedor
            sellers_data = {}
            for row in rows:
                seller_id = str(row[0])
                seller_name = row[1]
                seller_type = row[2]
                score = float(row[3]) if row[3] else None
                created_at = row[4]

                if seller_id not in sellers_data:
                    sellers_data[seller_id] = {
                        'nome': seller_name,
                        'id': seller_id,
                        'tipo': seller_type,
                        'analyses': []
                    }
                
                if score is not None and created_at:
                    sellers_data[seller_id]['analyses'].append({
                        'date': created_at.date(),
                        'score': score
                    })
            
            # Processar cada vendedor para criar série temporal com médias diárias
            sellers_scores = []
            today = datetime.now().date()
            
            for seller_id, seller_info in sellers_data.items():
                analyses = seller_info['analyses']
                
                if not analyses:
                    continue
                
                # Ordenar análises por data
                analyses.sort(key=lambda x: x['date'])
                
                # Primeira data de análise do vendedor
                first_date = analyses[0]['date']
                
                # Criar dicionário de scores por dia
                daily_scores = {}
                cumulative_sum = 0
                cumulative_count = 0
                
                # Processar cada dia desde a primeira análise até hoje
                current_date = first_date
                analysis_index = 0
                
                while current_date <= today:
                    # Verificar se há análises neste dia
                    day_scores = []
                    while analysis_index < len(analyses) and analyses[analysis_index]['date'] == current_date:
                        day_scores.append(analyses[analysis_index]['score'])
                        analysis_index += 1
                    
                    # Se houver análises neste dia, atualizar a média acumulada
                    if day_scores:
                        for score in day_scores:
                            cumulative_sum += score
                            cumulative_count += 1
                    
                    # Calcular média atual (só adiciona se já tiver pelo menos uma análise)
                    if cumulative_count > 0:
                        current_average = cumulative_sum / cumulative_count
                        date_str = current_date.strftime('%Y-%m-%d')
                        daily_scores[date_str] = round(current_average, 2)
                    
                    # Avançar para o próximo dia
                    current_date += timedelta(days=1)
                
                # Montar o resultado final para este vendedor
                scores_list = [{date: score} for date, score in daily_scores.items()]
                
                sellers_scores.append({
                    'nome': seller_info['nome'],
                    'id': seller_info['id'],
                    'tipo': seller_info['tipo'],
                    'scores': scores_list
                })
            
            return sellers_scores
            
        except Exception as e:
            self.logger.error(f"Error getting scores by seller: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def get_users_with_low_credits(self):
        """
        Retorna lista de usuários que já usaram 85% ou mais de seus créditos mensais.
        Usuários com limite NULL (ilimitado) não aparecem.
        """
        try:
            engine = create_db_engine('DB_URI')
            with engine.connect() as conn:
                current_date = datetime.now()
                query = text('''
                    SELECT 
                        p.responsible_name as Nome,
                        p.phone as Telefone,
                        u.email,
                        p.monthly_analysis_limit as "Limite de Análises",
                        COUNT(a.id) AS "Análises esse Mês",
                        p.monthly_analysis_limit - COUNT(a.id) as "Análises Restantes",
                        ROUND(COUNT(a.id)::numeric / p.monthly_analysis_limit * 100, 2) AS Percentual_Usado
                    FROM profiles p
                    JOIN analyses a ON a.user_i = p.user_id
                    JOIN users u ON u.id = p.user_id
                    WHERE 
                        p.monthly_analysis_limit IS NOT NULL
                        AND EXTRACT(YEAR FROM a.created_at) = EXTRACT(YEAR FROM :current_date)
                        AND EXTRACT(MONTH FROM a.created_at) = EXTRACT(MONTH FROM :current_date)
                    GROUP BY p.user_id, p.monthly_analysis_limit, p.responsible_name, p.phone, u.email
                    HAVING ROUND(COUNT(a.id)::numeric / p.monthly_analysis_limit * 100, 2) >= 85
                ''')
                result = conn.execute(query, {'current_date': current_date})
                rows = result.fetchall()
                if not rows:
                    return []
                columns = result.keys()
                return [dict(zip(columns, row)) for row in rows]
        except Exception as e:
            self.logger.error(f"Erro ao buscar usuários com créditos baixos: {e}")
            return None

    @staticmethod
    def _extract_valor_reais(text): # TODO: após criar campo float, remover essa função
        """Extrai valor em reais de um texto não estruturado."""
        if not text or not isinstance(text, str):
            return None

        # normaliza o texto
        t = text.lower().replace(' ', '')

        # regex para pegar valores tipo "r$4.000", "r$6.200,00", "r$15000", "r$15mil"
        matches = re.findall(r'r\$[\d\.\,]+(?:mil)?', t)
        if not matches:
            return None

        valores = []
        for m in matches:
            # remove "r$"
            num = m.replace('r$', '')

            # detecta "mil"
            multiplicador = 1000 if 'mil' in num else 1
            num = num.replace('mil', '')

            # troca vírgula por ponto e remove pontos de milhar
            num = num.replace('.', '').replace(',', '.')

            try:
                valor = float(num) * multiplicador
                valores.append(valor)
            except ValueError:
                continue

        if not valores:
            return None

        # se houver faixas ou múltiplos, pega o MAIOR valor
        return max(valores)