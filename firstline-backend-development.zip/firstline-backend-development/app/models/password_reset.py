import logging
import uuid
from datetime import datetime, timedelta
from app.models.db_model import create_db_engine
from app.utils.email_service import EmailService
from sqlalchemy import text
import os
import bcrypt

class PasswordResetModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.email_service = EmailService()

    def _hash_password(self, password):
        """Hash a password using bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def request_reset(self, email):
        """Create password reset token and send email"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return False
        
        try:
            # Check if user exists but don't reveal this information
            user_query = text("SELECT id FROM users WHERE email = :email")
            user = conn.execute(user_query, {'email': email}).fetchone()
            
            if not user:
                # Return True even if user doesn't exist for security
                return True
            
            # Generate token and expiration
            token = str(uuid.uuid4())
            expires_at = datetime.now() + timedelta(hours=1)
            
            # Save token
            token_query = text("""
                INSERT INTO password_reset_tokens 
                (id, user_id, token, expires_at, used)
                VALUES (:id, :user_id, :token, :expires_at, :used)
            """)
            
            conn.execute(token_query, {
                'id': str(uuid.uuid4()),
                'user_id': user[0],
                'token': token,
                'expires_at': expires_at,
                'used': False
            })
            
            conn.commit()
            
            # Send email
            if self.email_service.send_password_reset_email(email, token):
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error requesting password reset: {e}")
            try:
                conn.rollback()
            except:
                pass
            return False
        finally:
            conn.close()

    def validate_token(self, token):
        """Validate if token exists, is not expired and not used"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return False
        
        try:
            query = text("""
                SELECT expires_at, used 
                FROM password_reset_tokens 
                WHERE token = :token
            """)
            
            result = conn.execute(query, {'token': token}).fetchone()
            
            if not result:
                return {
                    'valid': False,
                    'reason': 'Token inválido'
                }
            
            if result[1]:  # used
                return {
                    'valid': False,
                    'reason': 'Token já utilizado'
                }
            
            if result[0] < datetime.now():  # expired
                return {
                    'valid': False,
                    'reason': 'Token expirado'
                }
            
            return {
                'valid': True
            }
            
        except Exception as e:
            self.logger.error(f"Error validating token: {e}")
            return {
                'valid': False,
                'reason': 'Erro ao validar token'
            }
        finally:
            conn.close() 

    def confirm_reset(self, token, new_password):
        """Confirm password reset and update user password"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return {
                'success': False,
                'error': 'Erro interno do servidor'
            }
        
        try:
            # First validate token and get user_id
            query = text("""
                SELECT t.user_id, t.expires_at, t.used, u.email
                FROM password_reset_tokens t
                JOIN users u ON t.user_id = u.id
                WHERE t.token = :token
            """)
            
            result = conn.execute(query, {'token': token}).fetchone()
            
            if not result:
                return {
                    'success': False,
                    'error': 'Token inválido'
                }
            
            user_id, expires_at, used, email = result
            
            # Check if token is expired
            if expires_at < datetime.now():
                return {
                    'success': False,
                    'error': 'Token expirado'
                }
            
            # Check if token was already used
            if used:
                return {
                    'success': False,
                    'error': 'Token já utilizado'
                }
            
            # Hash new password
            hashed_password = self._hash_password(new_password)
            
            # Update user password
            update_password_query = text("""
                UPDATE users 
                SET password_hash = :password_hash,
                    updated_at = :updated_at,
                    token_version = token_version + 1
                WHERE id = :user_id
            """)
            
            conn.execute(update_password_query, {
                'password_hash': hashed_password,
                'updated_at': datetime.now(),
                'user_id': user_id
            })
            
            # Mark token as used
            mark_used_query = text("""
                UPDATE password_reset_tokens
                SET used = :used,
                    updated_at = :updated_at
                WHERE token = :token
            """)
            
            conn.execute(mark_used_query, {
                'token': token,
                'used': True,
                'updated_at': datetime.now()
            })
            
            conn.commit()
            
            return {
                'success': True,
                'message': 'Senha redefinida com sucesso'
            }
            
        except Exception as e:
            self.logger.error(f"Error confirming password reset: {e}")
            try:
                conn.rollback()
            except:
                pass
            return {
                'success': False,
                'error': 'Erro interno do servidor'
            }
        finally:
            conn.close() 