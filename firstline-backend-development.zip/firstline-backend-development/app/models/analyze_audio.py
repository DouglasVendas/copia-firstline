import os
import json
import logging
import time
import uuid
import tempfile
from datetime import datetime
from typing import Dict
import assemblyai as aai
from anthropic import Anthropic
from flask import request
from dotenv import load_dotenv
from sqlalchemy import text
from app.models.db_model import create_db_engine, ENGINE_CACHE
from app.models.analyze_manager import AnalyzeManager
from app.utils.disc_profiles import get_disc_profile_by_name
from mutagen._file import File
import re
from fuzzywuzzy import fuzz

# Custom handler to force immediate log writing
class ImmediateFileHandler(logging.FileHandler):
    def emit(self, record):
        super().emit(record)
        self.flush()

SECURITY_LIMITS = {
    "MAX_FILE_SIZE": 200 * 1024 * 1024, # 200MB
    "ALLOWED_MIME_TYPES": [
        # Formatos de áudio principais
        'audio/mpeg', 'audio/mp3', 'audio/mpga', 'audio/mp2',
        'audio/wav', 'audio/wave',
        'audio/ogg', 'audio/oga', 'audio/mogg',
        'audio/opus',
        'audio/aac',
        'audio/ac3',
        'audio/aiff', 'audio/aif',
        'audio/alac',
        'audio/amr',
        'audio/ape',
        'audio/au', 'audio/basic',
        'audio/dss',
        'audio/flac',
        'audio/tta',
        'audio/voc',
        'audio/webm', 'audio/webma',
        'audio/wma',
        'audio/x-m4a', 'audio/x-m4b', 'audio/x-m4p', 'audio/x-m4r',
        'audio/x-3ga',
        'audio/x-8svx',
        'audio/x-flv',
        'audio/x-qcp',
        # Formatos de vídeo (que contêm áudio)
        'video/mp4', 'video/x-m4v',
        'video/webm',
        'video/ogg',
        'video/quicktime', 'video/x-quicktime',
        'video/mp2t', 'video/mp2ts', 'video/mts',
        'video/mxf',
        'video/flv',
        # Formatos específicos
        'application/ogg'
    ],
    "MAX_PROCESSING_TIME": 480000, # 8 minutes
}

# Load environment variables from .env file
load_dotenv()

def get_audio_duration(filepath):
    """
    Retorna a duração do áudio em segundos usando mutagen.
    Suporta a maioria dos formatos populares (mp3, wav, ogg, etc).
    """
    audio = File(filepath)
    if audio is None or not hasattr(audio, 'info') or not hasattr(audio.info, 'length'):
        raise ValueError("Não foi possível extrair a duração do áudio com mutagen.")
    return audio.info.length

class AudioAnalyzer:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        # Add immediate file handler if not already present
        if not any(isinstance(h, ImmediateFileHandler) for h in self.logger.handlers):
            handler = ImmediateFileHandler('app.log', mode='a')
            handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
            
        self.db_engine = create_db_engine("DB_URI")
        if not self.db_engine:
            self.logger.error("Failed to create database engine with DB_URI")
            raise Exception("Database connection failed")
        
        # Initialize Anthropic and AssemblyAI clients
        try:
            anthropic_api_key = os.getenv('ANTHROPIC_API_KEY')
            assembly_api_key = os.getenv('ASSEMBLY_API_KEY')
            if not anthropic_api_key or not assembly_api_key:
                self.logger.error("API KEYS not found in environment variables")
                raise Exception("API keys not configured")
            
            # Create Anthropic client
            self.client = Anthropic(api_key=anthropic_api_key)
            aai.settings.api_key = assembly_api_key
            
            # Load prompt from file
            try:
                with open('prompt.txt', 'r', encoding='utf-8') as f:
                    self.prompt = f.read()
            except Exception as e:
                self.logger.error(f"Failed to load prompt from prompt.txt: {str(e)}")
                self.prompt = None
        except Exception as e:
            self.logger.error(f"Failed to initialize Anthropic client: {str(e)}")
            self.client = None

    def _build_context_prompt(self, context: dict) -> str:
        """Constrói o prompt de contexto baseado nos campos do contexto"""
        if not context:
            return ""
        
        context_parts = []
        
        if context.get('product_info'):
            context_parts.append(f"INFORMAÇÕES DO PRODUTO/SERVIÇO:\n{context['product_info']}")
        
        if context.get('target_audience'):
            context_parts.append(f"PÚBLICO-ALVO:\n{context['target_audience']}")
        
        if context.get('common_objections'):
            objections = context['common_objections']
            if isinstance(objections, list) and len(objections) > 0:
                objections_text = ""
                for i, obj in enumerate(objections, 1):
                    if isinstance(obj, dict):
                        objection = obj.get('objection', '')
                        response = obj.get('response', '')
                        objections_text += f"{i}. OBJEÇÃO: {objection}\n   RESPOSTA: {response}\n\n"
                    else:
                        objections_text += f"{i}. {obj}\n"
                context_parts.append(f"OBJEÇÕES COMUNS:\n{objections_text.strip()}")
            elif isinstance(objections, str) and objections:
                context_parts.append(f"OBJEÇÕES COMUNS:\n{objections}")
        
        if context.get('pricing_structure'):
            context_parts.append(f"ESTRUTURA DE PREÇOS:\n{context['pricing_structure']}")
        
        if context.get('playbook'):
            context_parts.append(f"PLAYBOOK DE VENDAS:\n{context['playbook']}")
        
        if context.get('mental_triggers'):
            context_parts.append(f"GATILHOS MENTAIS:\n{context['mental_triggers']}")
        
        if context.get('competitors'):
            competitors = context['competitors']
            if isinstance(competitors, list) and len(competitors) > 0:
                competitors_text = ", ".join(competitors)
                context_parts.append(f"CONCORRENTES:\n{competitors_text}")
            elif isinstance(competitors, str) and competitors:
                context_parts.append(f"CONCORRENTES:\n{competitors}")
        
        if context_parts:
            return "\n\n".join(context_parts)
        
        return ""

    def _validate_context(self, context_id, user_id):
        """
        Validate that the context exists and belongs to the user
        """
        try:
            with self.db_engine.connect() as conn:
                # Convert IDs to strings to avoid type mismatch
                context_id_str = str(context_id) if context_id else None
                user_id_str = str(user_id) if user_id else None
                
                result = conn.execute(text(
                    "SELECT * FROM contexts WHERE id = :context_id AND user_id = :user_id"
                ), {"context_id": context_id_str, "user_id": user_id_str})
                
                context = result.fetchone()
                if not context:
                    self.logger.error(f"Context not found: {context_id} for user {user_id}")
                    return None
                
                return context._asdict()
        except Exception as e:
            self.logger.error(f"Database error validating context: {str(e)}")
            return None

    def _sanitize_array(self, arr):
        """
        Sanitize array items and limit their size
        """
        if not isinstance(arr, list):
            return []
        return [str(item)[:500] for item in arr][:20]  # Max 20 items, 500 chars each
    
    def _format_transcription(self, api_response: Dict) -> str:
        """
        Formata a resposta da API AssemblyAI para um formato de diálogo legível.
        
        Args:
            api_response: Dicionário com a resposta da API AssemblyAI
            
        Returns:
            String formatada com o diálogo
        """
        words = api_response.get('words', [])
        
        if not words:
            return "Nenhuma palavra encontrada na transcrição."
        
        # Dicionário para mapear speakers para números
        speaker_map = {}
        speaker_counter = 1
        
        # Variáveis para controlar o agrupamento
        current_speaker = None
        current_text = []
        formatted_lines = []
        
        for word in words:
            speaker = word.get('speaker', 'Unknown')
            text = word.get('text', '')
            
            # Mapear speaker para número se ainda não existe
            if speaker not in speaker_map:
                speaker_map[speaker] = f"PESSOA {speaker_counter}"
                speaker_counter += 1
            
            # Se mudou de speaker, finalizar a fala anterior
            if current_speaker != speaker:
                if current_speaker is not None and current_text:
                    # Juntar as palavras e adicionar à lista
                    sentence = ' '.join(current_text).strip()
                    if sentence:
                        formatted_lines.append(f"{speaker_map[current_speaker]}")
                        formatted_lines.append(sentence)
                        formatted_lines.append("")  # Linha em branco
                
                # Iniciar nova fala
                current_speaker = speaker
                current_text = [text]
            else:
                # Continuar a fala atual
                current_text.append(text)
        
        # Adicionar a última fala
        if current_speaker is not None and current_text:
            sentence = ' '.join(current_text).strip()
            if sentence:
                formatted_lines.append(f"{speaker_map[current_speaker]}")
                formatted_lines.append(sentence)
        
        return '\n'.join(formatted_lines)

    def _replace_speaker_names(self, transcription: str, participants: list) -> str:
        """
        Substitui os identificadores PESSOA 1, PESSOA 2, etc., pelos nomes reais dos participantes na transcrição.
        Se não houver nome identificado, mantém o identificador original.
        """
        if not participants or not isinstance(participants, list):
            return transcription
        result = transcription
        for participante in participants:
            identificador = participante.get("identificador")
            nome = participante.get("nome")
            if identificador and nome:
                # Substitui apenas quando o identificador está sozinho na linha
                result = result.replace(f"{identificador}\n", f"{nome}\n")
                result = result.replace(f"{identificador}\r\n", f"{nome}\r\n")
                result = result.replace(f"{identificador}\r", f"{nome}\r")
        return result

    def _get_vendedor_nome(self, vendedor_id: str) -> str:
        """Busca o nome do vendedor pelo id na tabela sellers."""
        if not vendedor_id:
            return None
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute(text("SELECT name FROM sellers WHERE id = :id"), {"id": vendedor_id})
                row = result.fetchone()
                if row:
                    return row[0]
        except Exception as e:
            self.logger.error(f"Erro ao buscar nome do vendedor: {str(e)}")
        return None

    def _get_vendedor_info(self, vendedor_id: str) -> tuple:
        """Busca o nome e tipo do vendedor pelo id na tabela sellers."""
        if not vendedor_id:
            return None, None
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute(text("SELECT name, tipo FROM sellers WHERE id = :id"), {"id": vendedor_id})
                row = result.fetchone()
                if row:
                    return row[0], row[1]
        except Exception as e:
            self.logger.error(f"Erro ao buscar informações do vendedor: {str(e)}")
        return None, None

    def _check_monthly_limit(self, user_id):
        """Valida o limite mensal de análises do usuário."""
        try:
            with self.db_engine.connect() as conn:
                # Convert user_id to string to avoid type mismatch
                user_id_str = str(user_id) if user_id else None
                
                limit_query = text("SELECT monthly_analysis_limit FROM profiles WHERE user_id = :user_id")
                limit_result = conn.execute(limit_query, {"user_id": user_id_str})
                limit_row = limit_result.fetchone()
                monthly_limit = limit_row[0] if limit_row else None

                # PostgreSQL compatible query using EXTRACT for year/month comparison
                current_date = datetime.now()
                count_query = text("""
                    SELECT COUNT(*) FROM analyses 
                    WHERE user_id = :user_id 
                    AND EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM :current_date)
                    AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM :current_date)
                """)
                count_result = conn.execute(count_query, {"user_id": user_id_str, "current_date": current_date})
                monthly_count = count_result.fetchone()[0]

                if monthly_limit is not None and monthly_count >= monthly_limit:
                    self.logger.error(f"Limite mensal de análises atingido para user_id {user_id}")
                    return False, {"error": "Limite mensal de análises atingido. Faça upgrade do seu plano para criar mais análises."}, 429
                return True, None, None
        except Exception as e:
            self.logger.error(f"Erro ao validar limite de análises: {str(e)}")
            return False, {"error": "Erro ao validar limite de análises."}, 500

    def _save_temp_audio_file(self, audio_file):
        """Valida e salva o arquivo de áudio temporariamente, retornando o caminho."""
        temp_dir = tempfile.gettempdir()
        file_extension = audio_file.filename.split('.')[-1] if '.' in audio_file.filename else 'wav'
        temp_file_path = os.path.join(temp_dir, f"{uuid.uuid4()}.{file_extension}")
        try:
            audio_file.save(temp_file_path)
            if not os.path.exists(temp_file_path):
                raise Exception(f"Failed to save temporary file: {temp_file_path}")
            saved_file_size = os.path.getsize(temp_file_path)
            if saved_file_size == 0:
                raise Exception("Saved temporary file is empty")
            return temp_file_path, saved_file_size, None
        except Exception as e:
            self.logger.error(f"Error saving file: {str(e)}")
            return None, 0, {"error": f"Erro ao salvar arquivo de áudio: {str(e)}"}

    def _transcribe_audio(self, temp_file_path, speakers_expected):
        """Transcreve o áudio usando AssemblyAI e retorna a transcrição formatada."""
        try:
            config = aai.TranscriptionConfig(
                speaker_labels=True,
                format_text=True,
                punctuate=True,
                speech_model=aai.SpeechModel.best,
                language_code=aai.LanguageCode.pt,
                speakers_expected=speakers_expected if speakers_expected else None)
            transcript = aai.Transcriber(config=config).transcribe(temp_file_path)
            if transcript.status == "error":
                raise Exception(f"Transcription error: {transcript.error}")
            return self._format_transcription(transcript.json_response), None
        except Exception as e:
            self.logger.error(f"Erro na transcrição do áudio: {str(e)}")
            return None, ({"error": f"Erro na transcrição do áudio: {str(e)}"}, 500)

    def _analyze_transcription(self, transcription, context, max_retries=3):
        """Analisa a transcrição usando Anthropic Claude e retorna o JSON de análise."""
        try:
            # Check if prompt is available
            if not self.prompt:
                self.logger.error("Prompt not loaded")
                return None, {"error": "Service not available. Please, contact support."}, 500
            
            # Create system prompt from context
            context_prompt = self._build_context_prompt(context)
            system_prompt = f"{context_prompt}\n\n{self.prompt}" if context_prompt else self.prompt
            
            # Função para extrair JSON do texto
            def extract_json(text):
                import re
                match = re.search(r'\{.*\}', text, re.DOTALL)
                if match:
                    return match.group(0)
                return None
            
            # Tentar análise com retry
            messages = [
                {
                    "role": "user",
                    "content": f"TRANSCRIÇÃO DE ÁUDIO PARA ANÁLISE:\n\n{transcription}\n\nAnalise esta conversa específica e retorne o JSON estruturado conforme solicitado."
                }
            ]
            
            self.logger.info("Iniciando análise da transcrição com Anthropic Claude")
            for attempt in range(max_retries):
                try:
                    self.logger.info(f"Tentativa {attempt + 1} de {max_retries} para análise")
                    
                    # Analyze with Anthropic Claude
                    analysis_response = self.client.messages.create(
                        model="claude-3-7-sonnet-20250219",
                        max_tokens=8000,
                        temperature=0.4,
                        system=system_prompt,
                        messages=messages
                    )
                    
                    analysis = analysis_response.content[0].text
                    self.logger.info(f"Claude analysis response received, length: {len(analysis) if analysis else 0} characters")
                    
                    if not analysis or not analysis.strip():
                        error_msg = "Claude retornou resposta vazia."
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry
                            messages.append({"role": "assistant", "content": analysis if analysis else ""})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO: {error_msg}\n\nPor favor, retorne o JSON estruturado conforme solicitado no formato correto."
                            })
                            continue
                        else:
                            return None, ({"error": "Claude retornou resposta vazia após múltiplas tentativas"}, 500)
                    
                    json_str = extract_json(analysis)
                    if not json_str:
                        error_msg = "Não foi possível extrair JSON válido da resposta."
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry com a resposta anterior
                            messages.append({"role": "assistant", "content": analysis})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO: {error_msg}\n\nVocê retornou:\n{analysis}\n\nPor favor, retorne APENAS o JSON estruturado no formato correto, sem texto adicional antes ou depois."
                            })
                            continue
                        else:
                            return None, ({"error": "Formato da análise inválido após múltiplas tentativas"}, 500)
                    
                    # Tentar fazer parse do JSON
                    try:
                        parsed_analysis = json.loads(json_str)
                        self.logger.info(f"Analysis successful na tentativa {attempt + 1}")
                        return parsed_analysis, None
                    except Exception as parse_error:
                        error_msg = f"Erro ao fazer parse do JSON: {str(parse_error)}"
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry com o erro específico e JSON problemático
                            messages.append({"role": "assistant", "content": analysis})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO DE PARSE JSON: {str(parse_error)}\n\nPor favor, corrija os erros no JSON e retorne o JSON válido e bem formatado."
                            })
                            continue
                        else:
                            self.logger.error(f"Failed to parse analysis JSON after {max_retries} attempts: {str(parse_error)}")
                            return None, ({"error": "Analysis format error após múltiplas tentativas"}, 500)
                
                except Exception as attempt_error:
                    self.logger.error(f"Erro na tentativa {attempt + 1}: {str(attempt_error)}")
                    if attempt < max_retries - 1:
                        continue
                    else:
                        raise attempt_error
            
            # Se chegou aqui, todas as tentativas falharam
            return None, ({"error": "Falha na análise após múltiplas tentativas"}, 500)
            
        except Exception as e:
            self.logger.error(f"Erro ao analisar transcrição: {str(e)}")
            return None, ({"error": f"Erro ao analisar transcrição: {str(e)}"}, 500)

    def _save_analysis_to_db(self, analysis_data):
        """Salva a análise no banco de dados."""
        try:
            with self.db_engine.connect() as conn:
                # Convert list/dict fields to JSON strings for database storage
                # PostgreSQL will handle JSON conversion automatically if columns are JSON type
                for key, value in analysis_data.items():
                    if isinstance(value, (list, dict)):
                        analysis_data[key] = json.dumps(value, ensure_ascii=False)
                
                query = """
                    INSERT INTO analyses (
                        id, client_name, analysis_name, transcription, score_geral,
                        pontos_positivos, pontos_atencao, objecoes_identificadas,
                        sugestoes_melhoria, proximos_passos, resumo, disc_profile_id, context_uuid,
                        upload_type, vendedor, user_id, framework_analysis,
                        coaching_insights, performance_analysis, mental_triggers,
                        reformulacoes_pnl, plano_fechamento, ia_preditiva, created_at, 
                        audio_duration_seconds, desempenho_geral, tempo_de_fala
                    ) VALUES (
                        :id, :client_name, :analysis_name, :transcription, :score_geral,
                        :pontos_positivos, :pontos_atencao, :objecoes_identificadas,
                        :sugestoes_melhoria, :proximos_passos, :resumo, :disc_profile_id, :context_uuid,
                        :upload_type, :vendedor, :user_id, :framework_analysis,
                        :coaching_insights, :performance_analysis, :mental_triggers,
                        :reformulacoes_pnl, :plano_fechamento, :ia_preditiva, :created_at,
                        :audio_duration_seconds, :desempenho_geral, :tempo_de_fala
                    )
                """
                conn.execute(text(query), analysis_data)
                conn.commit()
                return analysis_data["id"], None
        except Exception as e:
            self.logger.error(f"Erro ao salvar análise no banco: {str(e)}")
            return None, ({"error": f"Erro ao salvar análise no banco: {str(e)}"}, 500)

    def analyze_audio(self, audio_file, context_id, vendedor, user_id, speakers_expected, analysis_name):
        start_time = time.time()
        # 1. Validação de limite
        ok, error, status = self._check_monthly_limit(user_id)
        if not ok:
            return error, status
        # 2. Validação do arquivo
        if not audio_file or not audio_file.filename:
            return {"error": "Audio file is required"}, 400
        file_size = 0
        try:
            audio_file.seek(0, 2)
            file_size = audio_file.tell()
            audio_file.seek(0)
        except Exception:
            file_size = getattr(audio_file, 'content_length', 0) or 0
        if file_size == 0:
            return {"error": "Audio file is empty"}, 400
        if file_size > SECURITY_LIMITS["MAX_FILE_SIZE"]:
            return {"error": "File size exceeds limit"}, 400
        content_type = getattr(audio_file, 'content_type', None)
        if content_type not in SECURITY_LIMITS["ALLOWED_MIME_TYPES"]:
            return {"error": "Invalid file type"}, 400
        # 3. Salvar arquivo temporário
        temp_file_path, saved_file_size, error = self._save_temp_audio_file(audio_file)
        if error:
            return error, 500
        # 4. Calcular duração do áudio
        try:
            audio_duration_seconds = get_audio_duration(temp_file_path)
        except Exception as e:
            self.logger.warning(f"Não foi possível calcular a duração do áudio: {str(e)}")
            return {"error": "Não foi possível calcular a duração do áudio"}, 500
        if audio_duration_seconds <= 10:
            self.logger.warning("A duração do áudio deve ser maior que 10 segundos")
            return {"error": "A duração do áudio deve ser maior que 10 segundos"}, 400
        # 5. Validar contexto
        context = self._validate_context(context_id, user_id)
        if not context:
            return {"error": "Context not found"}, 403
        # 6. Transcrever áudio
        transcription, error = self._transcribe_audio(temp_file_path, speakers_expected)
        if error:
            return error[0], error[1]
        # 7. Analisar transcrição
        parsed_analysis, error = self._analyze_transcription(transcription, context)
        if error:
            return error[0], error[1]
        # 8. Substituir nomes
        participants = parsed_analysis.get("participants")
        transcription_with_names = self._replace_speaker_names(transcription, participants)
        # 9. Obter informações do vendedor e contexto
        vendedor_nome, vendedor_tipo = self._get_vendedor_info(vendedor)
        context_name = context.get('name') if context else None

        # Processar perfil DISC
        disc_profile_name = parsed_analysis.get("DISC", "").upper()
        disc_profile_data = get_disc_profile_by_name(disc_profile_name)
        disc_profile_id = disc_profile_data.get("id")
        
        # 10. Preparar dados para banco
        analysis_data = {
            "id": str(uuid.uuid4()),
            "client_name": parsed_analysis.get("client_name") if parsed_analysis.get("client_name") else None,
            "seller_name": parsed_analysis.get("seller_name") if parsed_analysis.get("seller_name") else None,
            "analysis_name": analysis_name[:255],
            "transcription": transcription_with_names,
            "score_geral": max(0, min(10, int(parsed_analysis.get("score_geral", 0)))),
            "pontos_positivos": self._sanitize_array(parsed_analysis.get("pontos_positivos", [])),
            "pontos_atencao": self._sanitize_array(parsed_analysis.get("pontos_atencao", [])),
            "objecoes_identificadas": self._sanitize_array(parsed_analysis.get("objecoes_identificadas", [])),
            "sugestoes_melhoria": self._sanitize_array(parsed_analysis.get("sugestoes_melhoria", [])),
            "proximos_passos": self._sanitize_array(parsed_analysis.get("proximos_passos", [])),
            "resumo": str(parsed_analysis.get("resumo", ""))[:1000],
            "disc_profile_id": disc_profile_id,
            "disc_profile": disc_profile_data if disc_profile_data else None,
            "context_uuid": context_id,
            "context_name": context_name,
            "upload_type": "audio",
            "vendedor": vendedor[:100] if vendedor else None,
            "vendedor_nome": vendedor_nome,
            "vendedor_tipo": vendedor_tipo,
            "user_id": str(user_id) if user_id else None,
            "framework_analysis": parsed_analysis.get("framework_analysis"),
            "coaching_insights": self._sanitize_array(parsed_analysis.get("coaching_insights", [])),
            "performance_analysis": parsed_analysis.get("performance_analysis"),
            "mental_triggers": parsed_analysis.get("mental_triggers"),
            "reformulacoes_pnl": parsed_analysis.get("reformulacoes_pnl"),
            "plano_fechamento": self._sanitize_array(parsed_analysis.get("plano_fechamento", [])),
            "ia_preditiva": parsed_analysis.get("ia_preditiva"),
            "desempenho_geral": parsed_analysis.get("desempenho_geral"),
            "tempo_de_fala": parsed_analysis.get("tempo_de_fala"),
            "created_at": time.strftime('%Y-%m-%d %H:%M:%S'),
            "audio_duration_seconds": audio_duration_seconds
        }
        # 11. Salvar no banco
        analysis_id, error = self._save_analysis_to_db(analysis_data)
        if error:
            return error[0], error[1]
        processing_time = time.time() - start_time
        
        # 12. Limpar arquivo temporário
        try:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
                self.logger.info(f"Temporary file cleaned up: {temp_file_path}")
        except Exception as cleanup_error:
            self.logger.warning(f"Failed to clean up temporary file: {cleanup_error}")
        
        # Get scores by seller
        analyze_manager = AnalyzeManager()
        scores = analyze_manager.get_scores_by_seller(user_id)
        if scores is None:
            scores = []
        
        return {
            "success": True,
            "analysis": {**analysis_data, "id": analysis_id},
            "transcription": transcription,
            "contextUsed": context['name'],
            "processing_time": processing_time,
            "scores": scores
        }, 200

    def _get_user_id_by_email(self, email):
        """Busca o user_id pelo email na tabela de usuários."""
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute(text("SELECT id FROM users WHERE email = :email"), {"email": email})
                row = result.fetchone()
                if row:
                    return row[0]
        except Exception as e:
            self.logger.error(f"Erro ao buscar user_id por email: {str(e)}")
        return None

    def _get_active_context(self, user_id):
        """Busca o contexto ativo para o usuário."""
        try:
            with self.db_engine.connect() as conn:
                # Convert user_id to string to avoid type mismatch
                user_id_str = str(user_id) if user_id else None
                # PostgreSQL compatible boolean comparison
                result = conn.execute(text("SELECT * FROM contexts WHERE user_id = :user_id AND is_active = true"), {"user_id": user_id_str})
                row = result.fetchone()
                if row:
                    return row._asdict()
        except Exception as e:
            self.logger.error(f"Erro ao buscar contexto ativo: {str(e)}")
        return None

    def _get_active_sellers(self, user_id):
        """Busca os vendedores ativos para o usuário, retornando id e nome."""
        try:
            with self.db_engine.connect() as conn:
                # Convert user_id to string to avoid type mismatch
                user_id_str = str(user_id) if user_id else None
                # PostgreSQL compatible boolean comparison
                result = conn.execute(text("SELECT id, name FROM sellers WHERE user_id = :user_id AND ativo = true"), {"user_id": user_id_str})
                return [{"id": row[0], "name": row[1]} for row in result.fetchall()]
        except Exception as e:
            self.logger.error(f"Erro ao buscar vendedores ativos: {str(e)}")
        return []

    def _get_first_name(self, full_name):
        """Extrai o primeiro nome de um nome completo."""
        if not full_name:
            return ""
        return full_name.strip().split()[0].lower()

    def _find_seller_by_fuzzy_match(self, seller_name, active_sellers, threshold=85):
        """
        Encontra um vendedor ativo usando comparação fuzzy do primeiro nome.
        
        Args:
            seller_name: Nome do vendedor identificado na análise
            active_sellers: Lista de vendedores ativos com id e nome
            threshold: Limite mínimo de similaridade (padrão: 85%)
            
        Returns:
            seller_id se encontrou match, None caso contrário
        """
        if not seller_name or not active_sellers:
            return None
            
        seller_first_name = self._get_first_name(seller_name)
        if not seller_first_name:
            return None
            
        best_match_score = 0
        best_match_id = None
        
        for seller in active_sellers:
            active_seller_first_name = self._get_first_name(seller['name'])
            if not active_seller_first_name:
                continue
                
            similarity = fuzz.ratio(seller_first_name, active_seller_first_name)
            
            if similarity >= threshold and similarity > best_match_score:
                best_match_score = similarity
                best_match_id = seller['id']
                
        self.logger.info(f"Fuzzy match result: '{seller_first_name}' -> best match score: {best_match_score}%, seller_id: {best_match_id}")
        return best_match_id

    def call_integration(self, audio_file, user_email, speakers_expected=None, analysis_name=None, context_id=None, vendedor_id=None, client_number=None):
        """
        Recebe o email do usuário e um áudio, busca user_id, contexto ativo, vendedores ativos e processa o áudio.
        Se o vendedor identificado não for ativo, grava como null.
        Parâmetros opcionais:
        - speakers_expected: número de speakers esperado
        - analysis_name: nome da análise
        """
        try:
            # 1. Buscar user_id pelo email
            user_id = self._get_user_id_by_email(user_email)
            if not user_id:
                return {"error": "Usuário não encontrado para o e-mail fornecido."}, 404

            # 2. Buscar contexto ativo
            if not context_id:
                context = self._get_active_context(user_id)
                context_id = context['id']
                if not context:
                    return {"error": "Nenhum contexto ativo encontrado para o usuário."}, 404

            # 3. Processar o áudio normalmente (sem vendedor definido ainda)
            if not analysis_name:
                analysis_name = f"Ligação api4com {client_number}"

            result, status_code = self.analyze_audio(audio_file, context_id=context_id, vendedor=vendedor_id, user_id=user_id, speakers_expected=speakers_expected, analysis_name=analysis_name)

            # Ajustar vendedor se necessário
            if not vendedor_id:
                active_sellers = self._get_active_sellers(user_id)
                if result.get('success') and result.get('analysis'):
                    seller_name = result['analysis'].get('seller_name')
                    seller_id = None
                    
                    # Usar comparação fuzzy do primeiro nome para encontrar o vendedor
                    if seller_name:
                        seller_id = self._find_seller_by_fuzzy_match(seller_name, active_sellers)
                    
                    if seller_id:
                        # Atualizar o registro no banco para o vendedor correto (id) e obter informações
                        try:
                            vendedor_nome, vendedor_tipo = self._get_vendedor_info(seller_id)
                            with self.db_engine.connect() as conn:
                                update_query = text("UPDATE analyses SET vendedor = :vendedor WHERE id = :id")
                                conn.execute(update_query, {"vendedor": seller_id, "id": result['analysis']['id']})
                                conn.commit()
                            result['analysis']['vendedor'] = seller_id
                            result['analysis']['vendedor_nome'] = vendedor_nome
                            result['analysis']['vendedor_tipo'] = vendedor_tipo
                        except Exception as e:
                            self.logger.error(f"Erro ao atualizar vendedor na análise: {str(e)}")
                    else:
                        # Se não for vendedor ativo, garantir que está como null
                        try:
                            with self.db_engine.connect() as conn:
                                update_query = text("UPDATE analyses SET vendedor = NULL WHERE id = :id")
                                conn.execute(update_query, {"id": result['analysis']['id']})
                                conn.commit()
                            result['analysis']['vendedor'] = None
                            result['analysis']['vendedor_nome'] = None
                            result['analysis']['vendedor_tipo'] = None
                        except Exception as e:
                            self.logger.error(f"Erro ao atualizar vendedor para null: {str(e)}")
            return {"success": result.get('success')}, status_code
        except Exception as e:
            self.logger.error(f"Erro no call_integration: {str(e)}")
            return {"error": "Erro interno na integração"}, 500