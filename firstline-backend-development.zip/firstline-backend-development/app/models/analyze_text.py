import os
import json
import logging
import time
import re
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from anthropic import Anthropic
from dotenv import load_dotenv
from sqlalchemy import text
from app.models.db_model import create_db_engine, ENGINE_CACHE
from app.models.analyze_manager import AnalyzeManager
from app.utils.disc_profiles import get_disc_profile_by_name
import uuid

# Security constants - Enhanced for large text processing
SECURITY_LIMITS = {
    "MAX_TEXT_LENGTH": 100000,
    "MAX_PROCESSING_TIME": 600,  # 10 minutes (in seconds)
    "CLAUDE_TIMEOUT": 480,  # 8 minutes timeout for Claude API (in seconds)
    "MAX_RETRIES": 3,  # Number of retry attempts
}

# Load environment variables from .env file
load_dotenv()

class TextAnalyzer:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.db_engine = create_db_engine("DB_URI")
        if not self.db_engine:
            self.logger.error("Failed to create database engine with DB_URI")
            raise Exception("Database connection failed")
        
        # Initialize Anthropic client
        try:
            api_key = os.getenv('ANTHROPIC_API_KEY')
            if not api_key:
                self.logger.error("ANTHROPIC_API_KEY not found in environment variables")
                self.client = None
            else:
                self.client = Anthropic(api_key=api_key)
                
            # Load prompt from file
            try:
                with open('prompt.txt', 'r', encoding='utf-8') as f:
                    self.prompt = f.read()
            except Exception as e:
                self.logger.error(f"Failed to load prompt from prompt.txt: {str(e)}")
                self.prompt = None
                
        except Exception as e:
            self.logger.error(f"Failed to initialize Anthropic client: {str(e)}")
            self.client = None

    def _build_context_prompt(self, context: Dict) -> str:
        """Constrói o prompt de contexto baseado nos campos do contexto"""
        if not context:
            return ""
        
        context_parts = []
        
        if context.get('product_info'):
            context_parts.append(f"INFORMAÇÕES DO PRODUTO/SERVIÇO:\n{context['product_info']}")
        
        if context.get('target_audience'):
            context_parts.append(f"PÚBLICO-ALVO:\n{context['target_audience']}")
        
        if context.get('common_objections'):
            objections = context['common_objections']
            if isinstance(objections, list) and len(objections) > 0:
                objections_text = ""
                for i, obj in enumerate(objections, 1):
                    if isinstance(obj, dict):
                        objection = obj.get('objection', '')
                        response = obj.get('response', '')
                        objections_text += f"{i}. OBJEÇÃO: {objection}\n   RESPOSTA: {response}\n\n"
                    else:
                        objections_text += f"{i}. {obj}\n"
                context_parts.append(f"OBJEÇÕES COMUNS:\n{objections_text.strip()}")
            elif isinstance(objections, str) and objections:
                context_parts.append(f"OBJEÇÕES COMUNS:\n{objections}")
        
        if context.get('pricing_structure'):
            context_parts.append(f"ESTRUTURA DE PREÇOS:\n{context['pricing_structure']}")
        
        if context.get('playbook'):
            context_parts.append(f"PLAYBOOK DE VENDAS:\n{context['playbook']}")
        
        if context.get('mental_triggers'):
            context_parts.append(f"GATILHOS MENTAIS:\n{context['mental_triggers']}")
        
        if context.get('competitors'):
            competitors = context['competitors']
            if isinstance(competitors, list) and len(competitors) > 0:
                competitors_text = ", ".join(competitors)
                context_parts.append(f"CONCORRENTES:\n{competitors_text}")
            elif isinstance(competitors, str) and competitors:
                context_parts.append(f"CONCORRENTES:\n{competitors}")
        
        if context_parts:
            return "\n\n".join(context_parts)
        
        return ""

    def _validate_context(self, context_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """
        Validate that the context exists and belongs to the user
        
        Args:
            context_id: The ID of the context
            user_id: The ID of the user
            
        Returns:
            Dict with context data or None if not found
        """
        try:
            with self.db_engine.connect() as conn:
                # Convert IDs to strings to avoid type mismatch
                context_id_str = str(context_id) if context_id else None
                user_id_str = str(user_id) if user_id else None
                
                result = conn.execute(text(
                    "SELECT * FROM contexts WHERE id = :context_id AND user_id = :user_id"
                ), {"context_id": context_id_str, "user_id": user_id_str})
                
                context = result.fetchone()
                if not context:
                    self.logger.error(f"Context not found: {context_id} for user {user_id}")
                    return None
                
                return context._asdict()
        except Exception as e:
            self.logger.error(f"Database error validating context: {str(e)}")
            return None
    
    def _sanitize_text(self, text: str) -> str:
        """
        Sanitize text input to remove potentially harmful content
        
        Args:
            text: The input text
            
        Returns:
            Sanitized text
        """
        # Remove HTML tags
        sanitized = re.sub(r'<[^>]*>', '', text)
        # Remove javascript: URLs
        sanitized = re.sub(r'javascript:', '', sanitized, flags=re.IGNORECASE)
        # Truncate to maximum length
        return sanitized[:SECURITY_LIMITS["MAX_TEXT_LENGTH"]]
    
    def _sanitize_array(self, arr: Any) -> List[str]:
        """
        Sanitize array items and limit their size
        
        Args:
            arr: Input array or other value
            
        Returns:
            Sanitized array of strings
        """
        if not isinstance(arr, list):
            return []
        return [str(item)[:500] for item in arr][:20]  # Max 20 items, 500 chars each
    
    def _retry_operation(self, operation_func, max_retries: int, delay_seconds: int = 2) -> Any:
        """
        Retry an operation multiple times with increasing delays
        
        Args:
            operation_func: Function to execute
            max_retries: Maximum number of retry attempts
            delay_seconds: Base delay between retries (will be multiplied by attempt number)
            
        Returns:
            Result of the operation
            
        Raises:
            Exception: The last error encountered after all retries fail
        """
        last_error = None
        
        for attempt in range(1, max_retries + 1):
            try:
                self.logger.info(f"Claude Analysis attempt {attempt}/{max_retries}")
                return operation_func()
            except Exception as e:
                last_error = e
                self.logger.error(f"Claude Analysis attempt {attempt} failed: {str(e)}")
                
                if attempt < max_retries:
                    wait_time = delay_seconds * attempt
                    self.logger.info(f"Waiting {wait_time}s before retry...")
                    time.sleep(wait_time)
        
        if last_error:
            raise last_error
    
    def _get_vendedor_nome(self, vendedor_id: str) -> str:
        """Busca o nome do vendedor pelo id na tabela sellers."""
        if not vendedor_id:
            return None
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute(text("SELECT name FROM sellers WHERE id = :id"), {"id": vendedor_id})
                row = result.fetchone()
                if row:
                    return row[0]
        except Exception as e:
            self.logger.error(f"Erro ao buscar nome do vendedor: {str(e)}")
        return None

    def _get_vendedor_info(self, vendedor_id: str) -> tuple:
        """Busca o nome e tipo do vendedor pelo id na tabela sellers."""
        if not vendedor_id:
            return None, None
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute(text("SELECT name, tipo FROM sellers WHERE id = :id"), {"id": vendedor_id})
                row = result.fetchone()
                if row:
                    return row[0], row[1]
        except Exception as e:
            self.logger.error(f"Erro ao buscar informações do vendedor: {str(e)}")
        return None, None

    def analyze_text(self, text_content: str, context_id: Optional[str], user_id: str, analysis_name: Optional[str] = None, vendedor: Optional[str] = None) -> Tuple[Dict[str, Any], int]:
        start_time = time.time()

        # Validação de limite de análises mensais
        try:
            with self.db_engine.connect() as conn:
                # Convert user_id to string to avoid type mismatch
                user_id_str = str(user_id) if user_id else None
                
                # Busca o limite do usuário
                limit_query = text("SELECT monthly_analysis_limit FROM profiles WHERE user_id = :user_id")
                limit_result = conn.execute(limit_query, {"user_id": user_id_str})
                limit_row = limit_result.fetchone()
                monthly_limit = limit_row[0] if limit_row else None

                # Conta quantas análises o usuário já fez neste mês
                current_date = datetime.now()
                count_query = text("""
                    SELECT COUNT(*) FROM analyses 
                    WHERE user_id = :user_id 
                    AND EXTRACT(YEAR FROM created_at) = EXTRACT(YEAR FROM :current_date)
                    AND EXTRACT(MONTH FROM created_at) = EXTRACT(MONTH FROM :current_date)
                """)
                count_result = conn.execute(count_query, {"user_id": user_id_str, "current_date": current_date})
                monthly_count = count_result.fetchone()[0]

                if monthly_limit is not None and monthly_count >= monthly_limit:
                    self.logger.error(f"Limite mensal de análises atingido para user_id {user_id}")
                    return {"error": "Limite mensal de análises atingido. Faça upgrade do seu plano para criar mais análises."}, 429
        except Exception as e:
            self.logger.error(f"Erro ao validar limite de análises: {str(e)}")
            return {"error": "Erro ao validar limite de análises."}, 500
        
        # Check if Anthropic client is available
        if not self.client:
            self.logger.error("Anthropic client not initialized")
            return {"error": "Service not available. Please, contact support."}, 500
        
        # Check if prompt is available
        if not self.prompt:
            self.logger.error("Prompt not loaded")
            return {"error": "Service not available. Please, contact support."}, 500
        
        # Validate inputs
        if not text_content:
            return {"error": "Text content is required"}, 400
        
        # Validate text length
        if len(text_content) > SECURITY_LIMITS["MAX_TEXT_LENGTH"]:
            return {"error": "Text content exceeds maximum length"}, 400
        
        # Sanitize text
        sanitized_text = self._sanitize_text(text_content)
        
        # Validate context (optional)
        context = None
        if context_id:
            context = self._validate_context(context_id, user_id)
            if not context:
                return {"error": "Invalid context ID"}, 400
            self.logger.info(f"Context validated: {context['name']}")
        else:
            self.logger.info("No context provided - using default analysis")
        
        try:
            # Set a timeout for the entire operation
            operation_start = time.time()
            
            # Create system prompt from context
            context_prompt = self._build_context_prompt(context)
            system_prompt = f"{context_prompt}\n\n{self.prompt}" if context_prompt else self.prompt
            
            self.logger.info("Starting Claude analysis with retry mechanism...")
            
            # Função para extrair JSON do texto
            def extract_json(text):
                import re
                match = re.search(r'\{.*\}', text, re.DOTALL)
                if match:
                    return match.group(0)
                return None
            
            # Tentar análise com retry
            messages = [
                {
                    "role": "user",
                    "content": f"CONVERSA DE VENDAS PARA ANÁLISE:\n\n{sanitized_text}\n\nAnalise esta conversa específica e retorne o JSON estruturado conforme solicitado."
                }
            ]
            
            max_retries = SECURITY_LIMITS["MAX_RETRIES"]
            parsed_analysis = None
            
            for attempt in range(max_retries):
                try:
                    # Check for timeout
                    if time.time() - operation_start > SECURITY_LIMITS["MAX_PROCESSING_TIME"]:
                        raise TimeoutError("Analysis operation timed out")
                    
                    self.logger.info(f"Tentativa {attempt + 1} de {max_retries} para análise")
                    
                    # Analyze with Anthropic Claude
                    analysis_response = self.client.messages.create(
                        model="claude-3-7-sonnet-20250219",
                        system=system_prompt,
                        messages=messages,
                        temperature=0.4,
                        max_tokens=8000
                    )
                    
                    analysis = analysis_response.content[0].text
                    self.logger.info(f"Claude analysis response received, length: {len(analysis) if analysis else 0} characters")
                    
                    if not analysis or not analysis.strip():
                        error_msg = "Claude retornou resposta vazia."
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry
                            messages.append({"role": "assistant", "content": analysis if analysis else ""})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO: {error_msg}\n\nPor favor, retorne o JSON estruturado conforme solicitado no formato correto."
                            })
                            continue
                        else:
                            return {"error": "Claude retornou resposta vazia após múltiplas tentativas"}, 500
                    
                    json_str = extract_json(analysis)
                    if not json_str:
                        error_msg = "Não foi possível extrair JSON válido da resposta."
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}. Resposta: {analysis[:500]}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry com a resposta anterior
                            messages.append({"role": "assistant", "content": analysis})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO: {error_msg}\n\nVocê retornou:\n{analysis}\n\nPor favor, retorne APENAS o JSON estruturado no formato correto, sem texto adicional antes ou depois."
                            })
                            continue
                        else:
                            return {"error": "Formato da análise inválido após múltiplas tentativas"}, 500
                    
                    # Tentar fazer parse do JSON
                    try:
                        parsed_analysis = json.loads(json_str)
                        self.logger.info(f"Analysis successful na tentativa {attempt + 1}")
                        break  # Sucesso, sair do loop
                    except Exception as parse_error:
                        error_msg = f"Erro ao fazer parse do JSON: {str(parse_error)}"
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry com o erro específico e JSON problemático
                            messages.append({"role": "assistant", "content": analysis})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO DE PARSE JSON: {str(parse_error)}\n\nJSON problemático:\n{json_str[:1000]}\n\nPor favor, corrija os erros no JSON e retorne o JSON válido e bem formatado."
                            })
                            continue
                        else:
                            self.logger.error(f"Failed to parse analysis JSON after {max_retries} attempts: {str(parse_error)}")
                            return {"error": "Analysis format error após múltiplas tentativas"}, 500
                
                except TimeoutError:
                    raise  # Re-raise timeout errors
                except Exception as attempt_error:
                    self.logger.error(f"Erro na tentativa {attempt + 1}: {str(attempt_error)}")
                    if attempt < max_retries - 1:
                        continue
                    else:
                        raise attempt_error
            
            # Se chegou aqui sem parsed_analysis, todas as tentativas falharam
            if not parsed_analysis:
                return {"error": "Falha na análise após múltiplas tentativas"}, 500
            
            self.logger.info("Claude analysis completed successfully")
            
            # Determinar client_name
            client_name = parsed_analysis.get("client_name")
            if not client_name:
                client_name = "Não Identificado"
            
            # Obter informações do vendedor e contexto
            vendedor_nome, vendedor_tipo = self._get_vendedor_info(vendedor)
            context_name = context.get('name') if context else None

            # Processar perfil DISC
            disc_profile_name = parsed_analysis.get("DISC", "").upper()
            disc_profile_data = get_disc_profile_by_name(disc_profile_name)
            disc_profile_id = disc_profile_data.get("id")
            
            # Prepare data for database
            analysis_data = {
                "id": str(uuid.uuid4()),
                "client_name": client_name,
                "analysis_name": analysis_name if analysis_name else "Análise de Texto",
                "transcription": sanitized_text[:50000],
                "score_geral": max(0, min(10, int(parsed_analysis.get("score_geral", 0)))),
                "pontos_positivos": self._sanitize_array(parsed_analysis.get("pontos_positivos", [])),
                "pontos_atencao": self._sanitize_array(parsed_analysis.get("pontos_atencao", [])),
                "objecoes_identificadas": self._sanitize_array(parsed_analysis.get("objecoes_identificadas", [])),
                "sugestoes_melhoria": self._sanitize_array(parsed_analysis.get("sugestoes_melhoria", [])),
                "proximos_passos": self._sanitize_array(parsed_analysis.get("proximos_passos", [])),
                "resumo": str(parsed_analysis.get("resumo", ""))[:1000],
                "disc_profile_id": disc_profile_id,
                "disc_profile": disc_profile_data if disc_profile_data else None,
                "context_uuid": context_id if context_id else None,
                "context_name": context_name,
                "upload_type": "text",
                "vendedor": vendedor,
                "vendedor_nome": vendedor_nome,
                "vendedor_tipo": vendedor_tipo,
                "user_id": str(user_id) if user_id else None,
                "framework_analysis": parsed_analysis.get("framework_analysis"),
                "coaching_insights": self._sanitize_array(parsed_analysis.get("coaching_insights", [])),
                "performance_analysis": parsed_analysis.get("performance_analysis"),
                "mental_triggers": parsed_analysis.get("mental_triggers"),
                "reformulacoes_pnl": parsed_analysis.get("reformulacoes_pnl"),
                "plano_fechamento": self._sanitize_array(parsed_analysis.get("plano_fechamento", [])),
                "ia_preditiva": parsed_analysis.get("ia_preditiva"),
                "desempenho_geral": parsed_analysis.get("desempenho_geral"),
                "tempo_de_fala": parsed_analysis.get("tempo_de_fala"),
                "created_at": time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Save to database
            self.logger.info("Saving to database...")
            with self.db_engine.connect() as conn:
                # Convert arrays and objects to JSON strings for database storage
                # PostgreSQL will handle JSON conversion automatically if columns are JSON type
                for key, value in analysis_data.items():
                    if isinstance(value, (list, dict)):
                        analysis_data[key] = json.dumps(value, ensure_ascii=False)
                
                query = """
                    INSERT INTO analyses (
                        id, client_name, analysis_name, transcription, score_geral,
                        pontos_positivos, pontos_atencao, objecoes_identificadas,
                        sugestoes_melhoria, proximos_passos, resumo, disc_profile_id, context_uuid,
                        upload_type, vendedor, user_id, framework_analysis,
                        coaching_insights, performance_analysis, mental_triggers,
                        reformulacoes_pnl, plano_fechamento, ia_preditiva, created_at,
                        desempenho_geral, tempo_de_fala
                    ) VALUES (
                        :id, :client_name, :analysis_name, :transcription, :score_geral,
                        :pontos_positivos, :pontos_atencao, :objecoes_identificadas,
                        :sugestoes_melhoria, :proximos_passos, :resumo, :disc_profile_id, :context_uuid,
                        :upload_type, :vendedor, :user_id, :framework_analysis,
                        :coaching_insights, :performance_analysis, :mental_triggers,
                        :reformulacoes_pnl, :plano_fechamento, :ia_preditiva, :created_at,
                        :desempenho_geral, :tempo_de_fala
                    )
                """
                
                conn.execute(text(query), analysis_data)
                conn.commit()
                analysis_id = analysis_data["id"]
            
            self.logger.info(f"=== SUCCESS: Analysis saved === {analysis_id}")
            processing_time = time.time() - start_time
            
            # Get scores by seller
            analyze_manager = AnalyzeManager()
            scores = analyze_manager.get_scores_by_seller(user_id)
            if scores is None:
                scores = []
            
            return {
                "success": True,
                "analysis": {**analysis_data, "id": analysis_id},
                "transcription": sanitized_text,
                "contextUsed": context['name'] if context else None,
                "processing_time": processing_time,
                "scores": scores
            }, 200
        
        except TimeoutError:
            processing_time = time.time() - start_time
            self.logger.error("=== ERROR === Processing timeout")
            return {"error": "Processing timeout - content may be too large"}, 500
        
        except Exception as e:
            processing_time = time.time() - start_time
            self.logger.error(f"=== ERROR === {str(e)}")
            
            error_message = "Processing failed"
            if "api" in str(e).lower():
                error_message = "Service temporarily unavailable"
            elif "analysis" in str(e).lower():
                error_message = "Analysis generation failed"
            
            return {"error": error_message}, 500