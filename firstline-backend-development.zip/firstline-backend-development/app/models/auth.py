import logging
import bcrypt
import uuid
from datetime import datetime
from app.models.db_model import create_db_engine
from app.models.payment import PaymentModel
from app.utils.email_service import EmailService
from sqlalchemy import text

class AuthModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.payment_model = PaymentModel()
        self.email_service = EmailService()

    def _hash_password(self, password):
        """Hash a password using bcrypt"""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def _verify_password(self, password, hashed_password):
        """Verify a password against its hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))

    def login(self, email, password) -> tuple[dict, int]:
        """Authenticate user with email and password"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return {'error': 'Database connection failed'}, 500
        
        try:
            # Get user by email
            query = text("""
                SELECT u.id, u.email, u.password_hash, p.token_version, p."2fa_enabled", p.current_plan plan, u.ativo
                FROM users u
                LEFT JOIN profiles p ON u.id = p.user_id
                WHERE u.email = :email
            """)
            
            result = conn.execute(query, {'email': email}).fetchone()
            
            if not result:
                self.logger.info(f"User not found: {email}")
                return {'error': 'Usuário não encontrado, entre em contato com o time de vendas para criar uma conta'}, 404

            # Verify if user is active
            if result[6] is False:
                self.logger.info(f"Inactive user attempted login: {email}")
                return {'error': 'Sua conta está inativa, entre em contato com o suporte'}, 403

            # Verify password
            if not self._verify_password(password, result[2]):
                self.logger.info(f"Invalid password for user: {email}")
                return {'error': 'Senha inválida, verifique suas credenciais e tente novamente'}, 401

            # Return user data
            return {
                'id': result[0],
                'email': result[1],
                'token_version': int(result[3]),
                '2fa_enabled': result[4],
                'plan': result[5]
            }, 200

        except Exception as e:
            self.logger.error(f"Error during login: {e}")
            return {'error': 'Erro interno do servidor'}, 500
        finally:
            conn.close()

    def register(self, email, token, password, company_name, responsible_name, phone, cnpj=None):
        """
        Registra um novo usuário usando token de registro válido (obrigatório)
        
        Args:
            email (str): Email do usuário
            token (str): Token de registro válido
            password (str): Senha do usuário
            company_name (str): Nome da empresa
            responsible_name (str): Nome do responsável
            phone (str): Telefone
            cnpj (str, optional): CNPJ da empresa
            
        Returns:
            dict: Dados do usuário criado ou erro
        """
        # Primeiro validar o token
        token_validation = self.validate_registration_token(token)
        
        if not token_validation.get('valid'):
            return {
                'error': token_validation.get('error', 'Token inválido'),
                'code': 400
            }
        
        token_data = token_validation['data']
        subscription_plan = token_data.get('subscription_plan')
        
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return {'error': 'Erro interno do servidor', 'code': 500}
        
        try:
            # Verificar se já existe usuário com este email
            check_query = text("SELECT id FROM users WHERE email = :email")
            existing_user = conn.execute(check_query, {'email': email}).fetchone()
            
            if existing_user:
                return {'error': 'E-mail já cadastrado', 'code': 400}
            
            # Hash da senha
            hashed_password = self._hash_password(password)
            
            # Gerar UUIDs
            user_id = str(uuid.uuid4())
            profile_id = str(uuid.uuid4())
            created_at = datetime.now()
            
            # Criar usuário
            user_query = text("""
                INSERT INTO users (id, email, password_hash, created_at)
                VALUES (:id, :email, :password_hash, :created_at)
            """)
            
            conn.execute(user_query, {
                'id': user_id,
                'email': email,
                'password_hash': hashed_password,
                'created_at': created_at
            })
            
            # Criar perfil com plano da assinatura
            profile_query = text("""
                INSERT INTO profiles (id, user_id, company_name, responsible_name, phone, cnpj, 
                                    contact_email, current_plan, created_at)
                VALUES (:id, :user_id, :company_name, :responsible_name, :phone, :cnpj, 
                        :contact_email, :current_plan, :created_at)
            """)
            
            conn.execute(profile_query, {
                'id': profile_id,
                'user_id': user_id,
                'company_name': company_name,
                'responsible_name': responsible_name,
                'phone': phone,
                'cnpj': cnpj,
                'contact_email': email,
                'current_plan': subscription_plan,
                'created_at': created_at
            })
            
            # Marcar token como usado
            token_marked = self.payment_model.mark_token_as_used(token)
            
            if not token_marked:
                # Se falhou ao marcar token, fazer rollback
                conn.rollback()
                return {'error': 'Erro ao processar token', 'code': 500}
            
            conn.commit()
            
            # Enviar email de boas-vindas
            try:
                self.email_service.send_welcome_email(email, responsible_name)
            except Exception as e:
                self.logger.warning(f"Failed to send welcome email to {email}: {e}")
            
            self.logger.info(f"User registered successfully with token: {email}")
            
            return {
                'user': {
                    'id': user_id,
                    'email': email,
                    'created_at': created_at.isoformat() + 'Z'
                },
                'profile': {
                    'id': profile_id,
                    'company_name': company_name,
                    'responsible_name': responsible_name,
                    'phone': phone,
                    'cnpj': cnpj,
                    'contact_email': email,
                    'current_plan': subscription_plan
                },
                'contract_data': {
                    'customer_id': token_data.get('customer_id'),
                    'payment_intent_id': token_data.get('payment_intent_id')
                }
            }
                
        except Exception as e:
            self.logger.error(f"Error during token registration: {e}")
            try:
                conn.rollback()
            except:
                pass
            return {'error': 'Erro interno do servidor', 'code': 500}
        finally:
            conn.close()
    
    def me(self, user_id):
        """Get user profile information"""
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return None
        
        try:
            query = text("""
                SELECT u.id, u.email, u.created_at, u.updated_at, p.token_version,
                       p.id as profile_id, p.company_name, p.responsible_name, 
                       p.phone, p.cnpj, p.contact_email, p.current_plan plan, 
                       p.plan_renewal_date, p.created_at as profile_created_at, 
                       p.updated_at as profile_updated_at, p.google_connected,
                       p.google_email, p.google_name, p.google_picture, u.ativo
                FROM users u
                LEFT JOIN profiles p ON u.id = p.user_id
                WHERE u.id = :user_id
            """)
            
            result = conn.execute(query, {'user_id': user_id}).fetchone()
            
            if not result:
                self.logger.info(f"User not found: {user_id}")
                return None
            
            return {
                'user': {
                    'id': result[0],
                    'email': result[1],
                    'created_at': result[2].isoformat() + 'Z' if result[2] else None,
                    'updated_at': result[3].isoformat() + 'Z' if result[3] else None,
                    'token_version': int(result[4]) if result[4] is not None else None,
                    'ativo': result[19] if result[19] is not None else False
                },
                'profile': {
                    'id': result[5],
                    'company_name': result[6],
                    'responsible_name': result[7],
                    'phone': result[8],
                    'cnpj': result[9],
                    'contact_email': result[10],
                    'plan': result[11],
                    'plan_renewal_date': result[12].isoformat() + 'Z' if result[12] else None,
                    'created_at': result[13].isoformat() + 'Z' if result[13] else None,
                    'updated_at': result[14].isoformat() + 'Z' if result[14] else None,
                    'google_connected': result[15] if result[15] is not None else False,
                    'google_email': result[16],
                    'google_name': result[17],
                    'google_picture': result[18]
                } if result[5] else None
            }
            
        except Exception as e:
            self.logger.error(f"Error getting user profile: {e}")
            return None
        finally:
            conn.close()

    def validate_registration_token(self, token):
        """
        Valida token de registro enviado por email após pagamento
        
        Args:
            token (str): Token de registro
            
        Returns:
            dict: Resultado da validação com dados do token
        """
        return self.payment_model.validate_registration_token(token)

    def connect_google_account(self, user_id, google_id, google_email, google_name, google_picture):
        """
        Conecta uma conta Google ao perfil do usuário
        
        Args:
            user_id (str): ID do usuário
            google_id (str): Google ID do usuário
            google_email (str): Email da conta Google
            google_name (str): Nome da conta Google
            google_picture (str): URL da foto do perfil Google
            
        Returns:
            bool: True se sucesso, False caso contrário
        """
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return False
        
        try:
            # Verificar se o perfil existe
            check_query = text("SELECT id FROM profiles WHERE user_id = :user_id")
            profile = conn.execute(check_query, {'user_id': user_id}).fetchone()
            
            if not profile:
                self.logger.error(f"Profile not found for user: {user_id}")
                return False
            
            # Atualizar perfil com dados do Google
            update_query = text("""
                UPDATE profiles 
                SET google_id = :google_id,
                    google_email = :google_email, 
                    google_name = :google_name,
                    google_picture = :google_picture,
                    google_connected = true,
                    updated_at = :updated_at
                WHERE user_id = :user_id
            """)
            
            conn.execute(update_query, {
                'user_id': user_id,
                'google_id': google_id,
                'google_email': google_email,
                'google_name': google_name,
                'google_picture': google_picture,
                'updated_at': datetime.now()
            })
            
            conn.commit()
            self.logger.info(f"Google account connected successfully for user: {user_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error connecting Google account: {e}")
            try:
                conn.rollback()
            except:
                pass
            return False
        finally:
            conn.close()

    def disconnect_google_account(self, user_id):
        """
        Desconecta a conta Google do perfil do usuário
        
        Args:
            user_id (str): ID do usuário
            
        Returns:
            bool: True se sucesso, False caso contrário
        """
        engine = create_db_engine('DB_URI')
        conn = engine.connect()
        if not conn:
            self.logger.error("Database connection failed")
            return False
        
        try:
            # Verificar se o perfil existe
            check_query = text("SELECT id FROM profiles WHERE user_id = :user_id")
            profile = conn.execute(check_query, {'user_id': user_id}).fetchone()
            
            if not profile:
                self.logger.error(f"Profile not found for user: {user_id}")
                return False
            
            # Remover dados do Google do perfil
            update_query = text("""
                UPDATE profiles 
                SET google_id = NULL,
                    google_email = NULL,
                    google_name = NULL,
                    google_picture = NULL,
                    google_connected = false,
                    updated_at = :updated_at
                WHERE user_id = :user_id
            """)
            
            conn.execute(update_query, {
                'user_id': user_id,
                'updated_at': datetime.now()
            })
            
            conn.commit()
            self.logger.info(f"Google account disconnected successfully for user: {user_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error disconnecting Google account: {e}")
            try:
                conn.rollback()
            except:
                pass
            return False
        finally:
            conn.close()