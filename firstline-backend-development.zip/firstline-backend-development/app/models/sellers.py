import logging
import uuid
from datetime import datetime
from enum import Enum
from app.models.db_model import create_db_engine
from sqlalchemy import text

class SellerType(Enum):
    """Enum para tipos de vendedores"""
    SDR = "SDR"
    CLOSER = "CLOSER"
    GERAL = "Geral"
    
    @classmethod
    def get_all_values(cls):
        """Retorna todos os valores válidos do enum"""
        return [member.value for member in cls]
    
    @classmethod
    def is_valid(cls, value):
        """Verifica se um valor é válido para o enum"""
        return value in cls.get_all_values()

class SellerModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def get_seller_types(self):
        """Retorna todos os tipos de vendedores disponíveis"""
        return SellerType.get_all_values()

    def get_sellers(self, user_id):
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return []
            query = text("SELECT id, name, tipo, email, telefone FROM sellers WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND ativo = true ORDER BY name")
            result = conn.execute(query, {'user_id': user_id})
            sellers = [ {'id': str(row[0]), 'name': row[1], 'tipo': row[2], 'email': row[3], 'telefone': row[4]} for row in result.fetchall() ]
            return sellers
        except Exception as e:
            self.logger.error(f"Error getting sellers for user_id {user_id}: {e}")
            return []
        finally:
            if conn:
                conn.close()

    def get_sellers_all(self, user_id):
        """Get all sellers including inactive ones - used for analyze_manager"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return []
            query = text("SELECT id, name, tipo, email, telefone FROM sellers WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) ORDER BY name")
            result = conn.execute(query, {'user_id': user_id})
            sellers = [ {'id': str(row[0]), 'name': row[1], 'tipo': row[2], 'email': row[3], 'telefone': row[4]} for row in result.fetchall() ]
            return sellers
        except Exception as e:
            self.logger.error(f"Error getting all sellers for user_id {user_id}: {e}")
            return []
        finally:
            if conn:
                conn.close()

    def get_seller_by_id(self, seller_id, user_id):
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            query = text("SELECT id, name, tipo, email, telefone FROM sellers WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND ativo = true")
            result = conn.execute(query, {'id': seller_id, 'user_id': user_id})
            row = result.fetchone()
            if not row:
                return None
            return {'id': str(row[0]), 'name': row[1], 'tipo': row[2], 'email': row[3], 'telefone': row[4]}
        except Exception as e:
            self.logger.error(f"Error getting seller {seller_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def create_seller(self, user_id, data):
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None

            # Buscar limite de vendedores do usuário
            #limit_query = text("SELECT seller_limit FROM profiles WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            #limit_result = conn.execute(limit_query, {'user_id': user_id})
            #limit_row = limit_result.fetchone()
            #seller_limit = limit_row[0] if limit_row else None

            # Contar vendedores ativos
            #count_query = text("SELECT COUNT(*) FROM sellers WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND ativo = true")
            #count_result = conn.execute(count_query, {'user_id': user_id})
            #active_count = count_result.fetchone()[0]

            # Se seller_limit não for None e limite atingido, retorna erro
            #if seller_limit is not None and active_count >= seller_limit:
            #    self.logger.error(f"Limite de vendedores atingido para user_id {user_id}")
            #    return {"error": "Limite de criação de vendedores excedido. Faça upgrade do seu plano para criar mais vendedores."}

            seller_id = str(uuid.uuid4())
            name = data.get('name')
            tipo = data.get('tipo')
            email = data.get('email')
            telefone = data.get('telefone')

            if not name:
                return None
            
            # Validar tipo do vendedor
            if tipo and not SellerType.is_valid(tipo):
                self.logger.error(f"Tipo de vendedor inválido: {tipo}. Tipos válidos: {SellerType.get_all_values()}")
                return {"error": f"Tipo de vendedor inválido. Tipos válidos: {SellerType.get_all_values()}"}
            
            # Se tipo não foi fornecido, usar GERAL como padrão
            if not tipo:
                tipo = SellerType.GERAL.value
            # UPSERT: se já existir (user_id, name), reativa e atualiza o nome
            query = text("""
                INSERT INTO sellers (id, user_id, name, tipo, email, telefone, ativo)
                VALUES (:id, :user_id, :name, :tipo, :email, :telefone, true)
                ON CONFLICT (user_id, name) DO UPDATE SET 
                    ativo = true, 
                    name = EXCLUDED.name,
                    tipo = EXCLUDED.tipo,
                    email = EXCLUDED.email,
                    telefone = EXCLUDED.telefone
            """)
            conn.execute(query, {'id': seller_id, 'user_id': user_id, 'name': name, 'tipo': tipo, 'email': email, 'telefone': telefone})
            conn.commit()
            # Buscar o vendedor criado/reativado
            query_get = text("SELECT id, name, tipo, email, telefone FROM sellers WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND name = :name")
            result = conn.execute(query_get, {'user_id': user_id, 'name': name})
            row = result.fetchone()
            if not row:
                return None
            return {'id': str(row[0]), 'name': row[1], 'tipo': row[2], 'email': row[3], 'telefone': row[4]}
        except Exception as e:
            self.logger.error(f"Error creating seller: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def update_seller(self, seller_id, user_id, data):
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            name = data.get('name')
            tipo = data.get('tipo')
            email = data.get('email')
            telefone = data.get('telefone')

            if not name:
                return None
            
            if not tipo:
                tipo = SellerType.GERAL.value
            
            # Validar tipo do vendedor
            if tipo and not SellerType.is_valid(tipo):
                self.logger.error(f"Tipo de vendedor inválido: {tipo}. Tipos válidos: {SellerType.get_all_values()}")
                return {"error": f"Tipo de vendedor inválido. Tipos válidos: {SellerType.get_all_values()}", "code": 400}
            
            # Verifica se já existe vendedor ATIVO com esse nome (e id diferente)
            query_active = text("SELECT id FROM sellers WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND name = :name AND ativo = true AND id != :id")
            result_active = conn.execute(query_active, {'user_id': user_id, 'name': name, 'id': seller_id})
            row_active = result_active.fetchone()
            if row_active:
                return {'error': 'Já existe um vendedor ativo com esse nome', 'code': 409}
            
            # Atualiza o vendedor
            query = text("UPDATE sellers SET name = :name, tipo = :tipo, email = :email, telefone = :telefone WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND ativo = true")
            result = conn.execute(query, {'id': seller_id, 'user_id': user_id, 'name': name, 'tipo': tipo, 'email': email, 'telefone': telefone})
            conn.commit()
            if result.rowcount == 0:
                return None
            return {'id': seller_id, 'name': name, 'tipo': tipo, 'email': email, 'telefone': telefone}
        except Exception as e:
            self.logger.error(f"Error updating seller {seller_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def delete_seller(self, seller_id, user_id):
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return False
            # Limpar vendedor_ativo dos contextos que usam esse vendedor
            clear_query = text("UPDATE contexts SET vendedor_ativo = NULL WHERE vendedor_ativo = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            conn.execute(clear_query, {'id': seller_id, 'user_id': user_id})
            # Soft delete - set ativo = false
            query = text("UPDATE sellers SET ativo = false WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            result = conn.execute(query, {'id': seller_id, 'user_id': user_id})
            conn.commit()
            return result.rowcount > 0
        except Exception as e:
            self.logger.error(f"Error deleting seller {seller_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return False 
        finally:
            if conn:
                conn.close() 