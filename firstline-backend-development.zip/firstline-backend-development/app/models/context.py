import logging
import uuid
import json
from datetime import datetime
from app.models.db_model import create_db_engine
from app.utils.document_extractor import DocumentExtractor
from sqlalchemy import text

class ContextModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def get_contexts(self, user_id):
        """Get all contexts for a user"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            # Buscar todos os vendedores ativos do usuário
#            sellers_query = text("SELECT id, name, tipo FROM sellers WHERE user_id = CAST(:user_id AS UUID) AND ativo = true")
#            sellers_result = conn.execute(sellers_query, {'user_id': user_id})
#            sellers = [ {'vendedor_id': str(row[0]), 'vendedor': row[1], 'tipo': row[2]} for row in sellers_result.fetchall() ]
#            sellers_dict = {str(row['vendedor_id']): row['vendedor'] for row in sellers}
            # JOIN para trazer o nome do vendedor ativo
            query = text("""
                SELECT 
                    c.id,
                    c.user_id,
                    c.name,
                    c.description,
                    c.product_info,
                    c.target_audience,
                    c.common_objections,
                    c.pricing_structure,
                    c.playbook,
                    c.mental_triggers,
                    c.competitors,
                    c.is_active,
                    c.vendedor_ativo,
                    s.name as vendedor_ativo_nome,
                    s.tipo as vendedor_ativo_tipo,
                    c.created_at,
                    c.updated_at
                FROM contexts c
                LEFT JOIN sellers s ON c.vendedor_ativo = s.id
                WHERE c.user_id = CAST(:user_id AS UUID)
                ORDER BY c.created_at DESC
            """)
            result = conn.execute(query, {'user_id': user_id})
            rows = result.fetchall()
            contexts = []
            for row in rows:
                vendedor_ativo_id = row[12]
                vendedor_ativo_nome = row[13]
                vendedor_ativo_tipo = row[14]
                
                # Parsear common_objections de JSONB para array
                objections_data = row[6]
                if isinstance(objections_data, str):
                    try:
                        objections_array = json.loads(objections_data)
                    except:
                        objections_array = []
                elif isinstance(objections_data, list):
                    objections_array = objections_data
                else:
                    objections_array = []
                
                # Parsear competitors de JSONB para array
                competitors_data = row[10]
                if isinstance(competitors_data, str):
                    try:
                        competitors_array = json.loads(competitors_data)
                    except:
                        competitors_array = []
                elif isinstance(competitors_data, list):
                    competitors_array = competitors_data
                else:
                    competitors_array = []
                
                context = {
                    'id': str(row[0]),
                    'user_id': str(row[1]),
                    'name': row[2],
                    'description': row[3],
                    'productInfo': row[4],
                    'targetAudience': row[5],
                    'commonObjections': objections_array,
                    'pricingStructure': row[7],
                    'playbook': row[8],
                    'mentalTriggers': row[9],
                    'competitors': competitors_array,
                    'is_active': bool(row[11]),
                    'vendedor_ativo': vendedor_ativo_nome,
                    'vendedor_ativo_id': vendedor_ativo_id,
                    'vendedor_ativo_tipo': vendedor_ativo_tipo,
                    'created_at': row[15].isoformat() + 'Z' if row[15] else None,
                    'updated_at': row[16].isoformat() + 'Z' if row[16] else None
                }
                contexts.append(context)
            self.logger.info(f"Retrieved {len(contexts)} contexts for user_id: {user_id}")
            return contexts
        except Exception as e:
            self.logger.error(f"Error getting contexts for user_id {user_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def get_active_context(self, user_id):
        """Get the active context for a user"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            query = text("""
                SELECT 
                    c.id,
                    c.user_id,
                    c.name,
                    c.description,
                    c.product_info,
                    c.target_audience,
                    c.common_objections,
                    c.pricing_structure,
                    c.playbook,
                    c.mental_triggers,
                    c.competitors,
                    c.is_active,
                    c.vendedor_ativo,
                    s.name as vendedor_ativo_nome,
                    s.tipo as vendedor_ativo_tipo,
                    c.created_at,
                    c.updated_at
                FROM contexts c
                LEFT JOIN sellers s ON c.vendedor_ativo = s.id
                WHERE c.user_id = CAST(:user_id AS UUID) AND c.is_active = true
                LIMIT 1
            """)
            result = conn.execute(query, {'user_id': user_id})
            row = result.fetchone()
            if not row:
                return None
            
            # Parsear common_objections de JSONB para array
            objections_data = row[6]
            if isinstance(objections_data, str):
                try:
                    objections_array = json.loads(objections_data)
                except:
                    objections_array = []
            elif isinstance(objections_data, list):
                objections_array = objections_data
            else:
                objections_array = []
            
            # Parsear competitors de JSONB para array
            competitors_data = row[10]
            if isinstance(competitors_data, str):
                try:
                    competitors_array = json.loads(competitors_data)
                except:
                    competitors_array = []
            elif isinstance(competitors_data, list):
                competitors_array = competitors_data
            else:
                competitors_array = []
            
            context = {
                'id': str(row[0]),
                'user_id': str(row[1]),
                'name': row[2],
                'description': row[3],
                'productInfo': row[4],
                'targetAudience': row[5],
                'commonObjections': objections_array,
                'pricingStructure': row[7],
                'playbook': row[8],
                'mentalTriggers': row[9],
                'competitors': competitors_array,
                'is_active': bool(row[11]),
                'vendedor_ativo_id': row[12],
                'vendedor_ativo_nome': row[13],
                'vendedor_ativo_tipo': row[14],
                'created_at': row[15].isoformat() + 'Z' if row[15] else None,
                'updated_at': row[16].isoformat() + 'Z' if row[16] else None
            }
            return context
        except Exception as e:
            self.logger.error(f"Error getting active context for user_id {user_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def create_context(self, user_id, data):
        """Create a new context"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            context_id = str(uuid.uuid4())
            created_at = datetime.utcnow()
            vendedor_ativo_id = data.get('vendedor_ativo_id')
            
            query = text("""
                INSERT INTO contexts (
                    id, user_id, name, description, product_info, target_audience,
                    common_objections, pricing_structure, playbook, mental_triggers,
                    competitors, is_active, vendedor_ativo, created_at, updated_at
                ) VALUES (
                    :id, :user_id, :name, :description, :product_info, :target_audience,
                    :common_objections, :pricing_structure, :playbook, :mental_triggers,
                    :competitors, :is_active, :vendedor_ativo, :created_at, :updated_at
                )
            """)
            # Converter competitors para JSON se for array
            competitors_value = data.get('competitors', [])
            if isinstance(competitors_value, list):
                competitors_json = json.dumps(competitors_value)
            else:
                competitors_json = json.dumps([])
            
            # Converter common_objections para JSON se for array
            objections_value = data.get('commonObjections', [])
            if isinstance(objections_value, list):
                objections_json = json.dumps(objections_value)
            else:
                objections_json = json.dumps([])
            
            conn.execute(query, {
                'id': context_id,
                'user_id': user_id,
                'name': data['name'],
                'description': data.get('description', ''),
                'product_info': data.get('productInfo', ''),
                'target_audience': data.get('targetAudience', ''),
                'common_objections': objections_json,
                'pricing_structure': data.get('pricingStructure', ''),
                'playbook': data.get('playbook', ''),
                'mental_triggers': data.get('mentalTriggers', ''),
                'competitors': competitors_json,
                'is_active': False,
                'vendedor_ativo': vendedor_ativo_id,
                'created_at': created_at,
                'updated_at': created_at
            })
            conn.commit()
            return self.get_context_by_id(context_id, user_id)
        except Exception as e:
            self.logger.error(f"Error creating context: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def update_context(self, context_id, user_id, data):
        """Update an existing context"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            check_query = text("SELECT id FROM contexts WHERE id = CAST(:id AS UUID) AND user_id = CAST(:user_id AS UUID)")
            result = conn.execute(check_query, {'id': context_id, 'user_id': user_id})
            if not result.fetchone():
                return None
            update_fields = []
            params = {'id': context_id, 'user_id': user_id, 'updated_at': datetime.utcnow()}
            
            if 'name' in data:
                update_fields.append("name = :name")
                params['name'] = data['name']
            if 'description' in data:
                update_fields.append("description = :description")
                params['description'] = data['description']
            if 'productInfo' in data:
                update_fields.append("product_info = :product_info")
                params['product_info'] = data['productInfo']
            if 'targetAudience' in data:
                update_fields.append("target_audience = :target_audience")
                params['target_audience'] = data['targetAudience']
            if 'commonObjections' in data:
                update_fields.append("common_objections = :common_objections")
                # Converter common_objections para JSON se for array
                objections_value = data['commonObjections']
                if isinstance(objections_value, list):
                    params['common_objections'] = json.dumps(objections_value)
                else:
                    params['common_objections'] = json.dumps([])
            if 'pricingStructure' in data:
                update_fields.append("pricing_structure = :pricing_structure")
                params['pricing_structure'] = data['pricingStructure']
            if 'playbook' in data:
                update_fields.append("playbook = :playbook")
                params['playbook'] = data['playbook']
            if 'mentalTriggers' in data:
                update_fields.append("mental_triggers = :mental_triggers")
                params['mental_triggers'] = data['mentalTriggers']
            if 'competitors' in data:
                update_fields.append("competitors = :competitors")
                # Converter competitors para JSON se for array
                competitors_value = data['competitors']
                if isinstance(competitors_value, list):
                    params['competitors'] = json.dumps(competitors_value)
                else:
                    params['competitors'] = json.dumps([])
            if 'vendedor_ativo_id' in data:
                update_fields.append("vendedor_ativo = :vendedor_ativo")
                params['vendedor_ativo'] = data['vendedor_ativo_id']
            
            if not update_fields:
                return self.get_context_by_id(context_id, user_id)
            update_query = text(f"""
                UPDATE contexts 
                SET {', '.join(update_fields)}, updated_at = :updated_at
                WHERE id = CAST(:id AS UUID) AND user_id = CAST(:user_id AS UUID)
            """)
            conn.execute(update_query, params)
            conn.commit()
            return self.get_context_by_id(context_id, user_id)
        except Exception as e:
            self.logger.error(f"Error updating context {context_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def delete_context(self, context_id, user_id):
        """Delete a context"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return False
            
            # Debug: log dos valores recebidos
            self.logger.info(f"Attempting to delete context: {context_id} (type: {type(context_id)}) for user: {user_id} (type: {type(user_id)})")
            
            # Check if context exists and belongs to user - com cast explícito para UUID
            check_query = text("SELECT id FROM contexts WHERE id = CAST(:id AS UUID) AND user_id = CAST(:user_id AS UUID)")
            result = conn.execute(check_query, {'id': context_id, 'user_id': user_id})
            found = result.fetchone()
            
            self.logger.info(f"Context found in check: {found}")
            
            if not found:
                self.logger.warning(f"Context {context_id} not found for user {user_id}")
                return False
            
            # Delete the context - com cast explícito para UUID
            delete_query = text("DELETE FROM contexts WHERE id = CAST(:id AS UUID) AND user_id = CAST(:user_id AS UUID)")
            delete_result = conn.execute(delete_query, {'id': context_id, 'user_id': user_id})
            self.logger.info(f"Rows affected by DELETE: {delete_result.rowcount}")
            
            conn.commit()
            
            self.logger.info(f"Context deleted: {context_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error deleting context {context_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return False
        finally:
            if conn:
                conn.close()

    def activate_context(self, context_id, user_id):
        """Activate a context and deactivate all others"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Check if context exists and belongs to user
            check_query = text("SELECT id FROM contexts WHERE id = CAST(:id AS UUID) AND user_id = CAST(:user_id AS UUID)")
            result = conn.execute(check_query, {'id': context_id, 'user_id': user_id})
            if not result.fetchone():
                return None
            
            # Deactivate all contexts for this user
            deactivate_query = text("UPDATE contexts SET is_active = false WHERE user_id = CAST(:user_id AS UUID)")
            conn.execute(deactivate_query, {'user_id': user_id})
            
            # Activate the selected context
            activate_query = text("""
                UPDATE contexts 
                SET is_active = true, updated_at = :updated_at 
                WHERE id = CAST(:id AS UUID) AND user_id = CAST(:user_id AS UUID)
            """)
            conn.execute(activate_query, {
                'id': context_id, 
                'user_id': user_id, 
                'updated_at': datetime.utcnow()
            })
            
            conn.commit()
            
            # Return activated context
            activated_context = self.get_context_by_id(context_id, user_id)
            self.logger.info(f"Context activated: {context_id}")
            return activated_context
            
        except Exception as e:
            self.logger.error(f"Error activating context {context_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def get_context_by_id(self, context_id, user_id):
        """Get a specific context by ID"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            # JOIN para trazer o nome do vendedor ativo
            query = text("""
                SELECT 
                    c.id,
                    c.user_id,
                    c.name,
                    c.description,
                    c.product_info,
                    c.target_audience,
                    c.common_objections,
                    c.pricing_structure,
                    c.playbook,
                    c.mental_triggers,
                    c.competitors,
                    c.is_active,
                    c.vendedor_ativo,
                    s.name as vendedor_ativo_nome,
                    s.tipo as vendedor_ativo_tipo,
                    c.created_at,
                    c.updated_at
                FROM contexts c
                LEFT JOIN sellers s ON c.vendedor_ativo = s.id
                WHERE c.id = CAST(:id AS UUID) AND c.user_id = CAST(:user_id AS UUID)
            """)
            result = conn.execute(query, {'id': context_id, 'user_id': user_id})
            row = result.fetchone()
            if not row:
                return None
            
            vendedor_ativo_id = row[12]
            vendedor_ativo_nome = row[13]
            vendedor_ativo_tipo = row[14]
            
            # Parsear common_objections de JSONB para array
            objections_data = row[6]
            if isinstance(objections_data, str):
                try:
                    objections_array = json.loads(objections_data)
                except:
                    objections_array = []
            elif isinstance(objections_data, list):
                objections_array = objections_data
            else:
                objections_array = []
            
            # Parsear competitors de JSONB para array
            competitors_data = row[10]
            if isinstance(competitors_data, str):
                try:
                    competitors_array = json.loads(competitors_data)
                except:
                    competitors_array = []
            elif isinstance(competitors_data, list):
                competitors_array = competitors_data
            else:
                competitors_array = []
            
            context = {
                'id': str(row[0]),
                'user_id': str(row[1]),
                'name': row[2],
                'description': row[3],
                'productInfo': row[4],
                'targetAudience': row[5],
                'commonObjections': objections_array,
                'pricingStructure': row[7],
                'playbook': row[8],
                'mentalTriggers': row[9],
                'competitors': competitors_array,
                'is_active': bool(row[11]),
                'vendedor_ativo': vendedor_ativo_nome,
                'vendedor_ativo_id': vendedor_ativo_id,
                'vendedor_ativo_tipo': vendedor_ativo_tipo,
                'created_at': row[15].isoformat() + 'Z' if row[15] else None,
                'updated_at': row[16].isoformat() + 'Z' if row[16] else None
            }
            return context
        except Exception as e:
            self.logger.error(f"Error getting context {context_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def create_context_from_file(self, user_id, file, context_name, context_description):
        """Create a new context from uploaded file"""
        try:
            # Initialize document extractor
            extractor = DocumentExtractor()
            
            # Extract context data from file using AI
            extracted_data = extractor.extract_context_from_file(file)
            if not extracted_data:
                self.logger.error("Failed to extract context data from file")
                return None
            
            # Prepare context data for creation
            context_data = {
                'name': context_name,
                'description': context_description,
                'productInfo': extracted_data.get('productInfo', ''),
                'targetAudience': extracted_data.get('targetAudience', ''),
                'commonObjections': extracted_data.get('commonObjections', []),
                'pricingStructure': extracted_data.get('pricingStructure', ''),
                'playbook': extracted_data.get('playbook', ''),
                'mentalTriggers': extracted_data.get('mentalTriggers', ''),
                'competitors': extracted_data.get('competitors', [])
            }
            
            # Use existing create_context method to save to database
            self.logger.info(f"Creating context with extracted data: {context_name}")
            return self.create_context(user_id, context_data)
            
        except Exception as e:
            self.logger.error(f"Error creating context from file: {e}")
            return None