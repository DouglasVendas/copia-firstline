import logging
from datetime import datetime, timedelta
from app.models.db_model import create_db_engine
from sqlalchemy import text
import json

class ReportModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def get_stats(self, user_id):
        """Get statistics for reports/stats endpoint"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Calculate date for recent analyses (last 30 days)
            thirty_days_ago = datetime.utcnow() - timedelta(days=30)
            
            # Get total analyses
            total_query = text("SELECT COUNT(*) FROM analyses WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            total_result = conn.execute(total_query, {'user_id': user_id})
            total_analyses = total_result.fetchone()[0]
            
            # Get average score
            avg_query = text("""
                SELECT AVG(score_geral) FROM analyses 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND score_geral IS NOT NULL
            """)
            avg_result = conn.execute(avg_query, {'user_id': user_id})
            avg_score = avg_result.fetchone()[0]
            avg_score = round(float(avg_score), 1) if avg_score else 0.0
            
            # Get recent analyses (last 30 days)
            recent_query = text("""
                SELECT COUNT(*) FROM analyses 
                WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID) AND created_at >= :date_limit
            """)
            recent_result = conn.execute(recent_query, {
                'user_id': user_id,
                'date_limit': thirty_days_ago
            })
            recent_analyses = recent_result.fetchone()[0]
            
            # Get active vendors and vendor list
            sellers_query = text("SELECT id, name FROM sellers WHERE CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            sellers_result = conn.execute(sellers_query, {'user_id': user_id})
            sellers = [ {'vendedor_id': str(row[0]), 'vendedor': row[1]} for row in sellers_result.fetchall() ]
            vendedores_ativos = len(sellers)
            
            stats = {
                'totalAnalyses': total_analyses,
                'averageScore': avg_score,
                'recentAnalyses': recent_analyses,
                'vendedoresAtivos': vendedores_ativos,
                'vendedores': sellers
            }
            
            self.logger.info(f"Stats retrieved for user_id: {user_id}")
            return stats
            
        except Exception as e:
            self.logger.error(f"Error getting stats for user_id {user_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def get_analyses_report(self, user_id, search=None, vendedor=None, page=1, limit=10):
        """Get analyses for reports/analyses endpoint with filtering and pagination"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Calculate offset
            offset = (page - 1) * limit
            
            # Build WHERE clause with filters
            where_conditions = ["CAST(a.user_id AS UUID) = CAST(:user_id AS UUID)"]
            params = {'user_id': user_id, 'limit': limit, 'offset': offset}
            
            if search:
                where_conditions.append("(client_name ILIKE :search OR resumo ILIKE :search)")
                params['search'] = f"%{search}%"
            
            if vendedor:
                where_conditions.append("vendedor = :vendedor")
                params['vendedor'] = vendedor
            
            where_clause = " AND ".join(where_conditions)
            
            # Get total count for pagination
            count_query = text(f"SELECT COUNT(*) FROM analyses a LEFT JOIN sellers s ON CAST(a.vendedor AS UUID) = s.id WHERE {where_clause}")
            total_result = conn.execute(count_query, params)
            total = total_result.fetchone()[0]
            
            # Get analyses with all fields
            query = text(f"""
                SELECT 
                    a.id, a.created_at, a.client_name, a.score_geral, a.upload_type, a.resumo,
                    a.pontos_positivos, a.pontos_atencao, a.objecoes_identificadas, 
                    a.sugestoes_melhoria, a.proximos_passos, a.context_uuid, a.transcription,
                    a.vendedor, s.name as vendedor_nome, a.framework_analysis, a.coaching_insights, a.performance_analysis,
                    a.mental_triggers, a.reformulacoes_pnl, a.plano_fechamento, a.ia_preditiva
                FROM analyses a
                LEFT JOIN sellers s ON CAST(a.vendedor AS UUID) = s.id
                WHERE {where_clause}
                ORDER BY a.created_at DESC
                LIMIT :limit OFFSET :offset
            """)
            
            result = conn.execute(query, params)
            rows = result.fetchall()
            
            analyses = []
            for row in rows:
                analyze = self._format_analyze_data(row)
                analyses.append(analyze)
            
            # Calculate pagination info
            total_pages = (total + limit - 1) // limit
            
            report_data = {
                'analyses': analyses,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total': total,
                    'pages': total_pages
                }
            }
            
            self.logger.info(f"Analyses report retrieved for user_id: {user_id}")
            return report_data
            
        except Exception as e:
            self.logger.error(f"Error getting analyses report for user_id {user_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def _format_analyze_data(self, row):
        """Format database row into analyze data structure"""
        try:
            vendedor_id = row[13]
            vendedor_nome = row[14]
            analyze = {
                'id': str(row[0]),
                'created_at': row[1].isoformat() + 'Z' if row[1] else None,
                'client_name': row[2],
                'score_geral': float(row[3]) if row[3] else None,
                'upload_type': row[4],
                'resumo': row[5],
                'pontos_positivos': self._parse_json_field(row[6]),
                'pontos_atencao': self._parse_json_field(row[7]),
                'objecoes_identificadas': self._parse_json_field(row[8]),
                'sugestoes_melhoria': self._parse_json_field(row[9]),
                'proximos_passos': self._parse_json_field(row[10]),
                'context_uuid': str(row[11]) if row[11] else None,
                'transcription': row[12],
                'vendedor': vendedor_nome,
                'vendedor_id': vendedor_id,
                'framework_analysis': self._parse_json_field(row[15]),
                'coaching_insights': self._parse_json_field(row[16]),
                'performance_analysis': self._parse_json_field(row[17]),
                'mental_triggers': self._parse_json_field(row[18]),
                'reformulacoes_pnl': self._parse_json_field(row[19]),
                'plano_fechamento': self._parse_json_field(row[20]),
                'ia_preditiva': self._parse_json_field(row[21])
            }
            return analyze
        except Exception as e:
            self.logger.error(f"Error formatting analyze data: {e}")
            return None

    def _parse_json_field(self, field):
        """Parse JSON field safely"""
        if field is None:
            return None
        
        if isinstance(field, str):
            try:
                return json.loads(field)
            except json.JSONDecodeError:
                return field
        
        return field
