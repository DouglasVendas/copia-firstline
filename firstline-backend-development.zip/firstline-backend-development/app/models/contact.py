import logging
import uuid
from datetime import datetime
from app.models.db_model import create_db_engine
from sqlalchemy import text
import re

class ContactModel:
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def get_contacts(self, user_id, page=1, limit=20, contact_type=None, search=None):
        """Get contacts with filtering and pagination"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Calculate offset
            offset = (page - 1) * limit
            
            # Build WHERE clause
            where_conditions = ["CAST(user_id AS UUID) = CAST(:user_id AS UUID)"]
            params = {'user_id': user_id, 'limit': limit, 'offset': offset}
            
            if contact_type:
                where_conditions.append("contact_type = :contact_type")
                params['contact_type'] = contact_type
            
            if search:
                where_conditions.append("(name ILIKE :search OR email ILIKE :search)")
                params['search'] = f"%{search}%"
            
            where_clause = " AND ".join(where_conditions)
            
            # Get total count
            count_query = text(f"SELECT COUNT(*) FROM contacts WHERE {where_clause}")
            total_result = conn.execute(count_query, params)
            total = total_result.fetchone()[0]
            
            # Get contacts
            query = text(f"""
                SELECT id, name, email, whatsapp, contact_type, created_at
                FROM contacts 
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT :limit OFFSET :offset
            """)
            
            result = conn.execute(query, params)
            rows = result.fetchall()
            
            contacts = []
            for row in rows:
                contact = {
                    'id': str(row[0]),
                    'name': row[1],
                    'email': row[2],
                    'whatsapp': row[3],
                    'contact_type': row[4],
                    'created_at': row[5].isoformat() + 'Z' if row[5] else None
                }
                contacts.append(contact)
            
            # Calculate pagination
            total_pages = (total + limit - 1) // limit
            
            return {
                'contacts': contacts,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total': total,
                    'totalPages': total_pages
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error getting contacts: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def create_contact(self, user_id, data):
        """Create a new contact"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            contact_id = str(uuid.uuid4())
            created_at = datetime.now()
            
            query = text("""
                INSERT INTO contacts (id, user_id, name, email, whatsapp, contact_type, created_at)
                VALUES (:id, :user_id, :name, :email, :whatsapp, :contact_type, :created_at)
            """)
            
            conn.execute(query, {
                'id': contact_id,
                'user_id': user_id,
                'name': data['name'],
                'email': data.get('email'),
                'whatsapp': data.get('whatsapp'),
                'contact_type': data['contact_type'],
                'created_at': created_at
            })
            
            conn.commit()
            
            # Return created contact
            contact = {
                'id': contact_id,
                'name': data['name'],
                'email': data.get('email'),
                'whatsapp': data.get('whatsapp'),
                'contact_type': data['contact_type'],
                'created_at': created_at.isoformat() + 'Z'
            }
            
            self.logger.info(f"Contact created with id: {contact_id}")
            return contact
            
        except Exception as e:
            self.logger.error(f"Error creating contact: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def get_contact_by_id(self, contact_id, user_id):
        """Get a specific contact by ID"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            query = text("""
                SELECT id, name, email, whatsapp, contact_type, created_at
                FROM contacts 
                WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            
            result = conn.execute(query, {'id': contact_id, 'user_id': user_id})
            row = result.fetchone()
            
            if not row:
                return None
            
            contact = {
                'id': str(row[0]),
                'name': row[1],
                'email': row[2],
                'whatsapp': row[3],
                'contact_type': row[4],
                'created_at': row[5].isoformat() + 'Z' if row[5] else None
            }
            
            return contact
            
        except Exception as e:
            self.logger.error(f"Error getting contact {contact_id}: {e}")
            return None
        finally:
            if conn:
                conn.close()

    def update_contact(self, contact_id, user_id, data):
        """Update an existing contact"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return None
            
            # Check if contact exists and belongs to user
            check_query = text("SELECT id FROM contacts WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            result = conn.execute(check_query, {'id': contact_id, 'user_id': user_id})
            if not result.fetchone():
                return None
            
            # Build dynamic update query
            update_fields = []
            params = {'id': contact_id, 'user_id': user_id}
            
            if 'name' in data:
                update_fields.append("name = :name")
                params['name'] = data['name']
            
            if 'email' in data:
                update_fields.append("email = :email")
                params['email'] = data['email']
            
            if 'whatsapp' in data:
                update_fields.append("whatsapp = :whatsapp")
                params['whatsapp'] = data['whatsapp']
            
            if 'contact_type' in data:
                update_fields.append("contact_type = :contact_type")
                params['contact_type'] = data['contact_type']
            
            if not update_fields:
                # No fields to update, return current contact
                return self.get_contact_by_id(contact_id, user_id)
            
            update_query = text(f"""
                UPDATE contacts 
                SET {', '.join(update_fields)}
                WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)
            """)
            
            conn.execute(update_query, params)
            conn.commit()
            
            # Return updated contact
            updated_contact = self.get_contact_by_id(contact_id, user_id)
            self.logger.info(f"Contact updated: {contact_id}")
            return updated_contact
            
        except Exception as e:
            self.logger.error(f"Error updating contact {contact_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return None
        finally:
            if conn:
                conn.close()

    def delete_contact(self, contact_id, user_id):
        """Delete a contact"""
        conn = None
        try:
            engine = create_db_engine('DB_URI')
            conn = engine.connect()
            if not conn:
                self.logger.error("Failed to get database connection")
                return False
            
            # Check if contact exists and belongs to user
            check_query = text("SELECT id FROM contacts WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            result = conn.execute(check_query, {'id': contact_id, 'user_id': user_id})
            if not result.fetchone():
                return False
            
            delete_query = text("DELETE FROM contacts WHERE id = :id AND CAST(user_id AS UUID) = CAST(:user_id AS UUID)")
            conn.execute(delete_query, {'id': contact_id, 'user_id': user_id})
            conn.commit()
            
            self.logger.info(f"Contact deleted: {contact_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error deleting contact {contact_id}: {e}")
            try:
                if conn:
                    conn.rollback()
            except:
                pass
            return False
        finally:
            if conn:
                conn.close()

    def validate_contact_data(self, data, is_update=False):
        """Validate contact data"""
        errors = {}
        
        # Name validation
        if not is_update or 'name' in data:
            name = data.get('name', '').strip()
            if not name:
                errors['name'] = ["Nome é obrigatório"]
            elif len(name) > 255:
                errors['name'] = ["Nome deve ter no máximo 255 caracteres"]
        
        # Contact type validation
        if not is_update or 'contact_type' in data:
            contact_type = data.get('contact_type', '').strip()
            valid_types = ['lead', 'cliente', 'prospect']
            if not contact_type:
                errors['contact_type'] = ["Tipo de contato é obrigatório"]
            elif contact_type not in valid_types:
                errors['contact_type'] = [f"Tipo de contato deve ser um dos seguintes: {', '.join(valid_types)}"]
        
        # Email validation (optional)
        if 'email' in data and data['email']:
            email = data['email'].strip()
            if not self._is_valid_email(email):
                errors['email'] = ["Formato de email inválido"]
        
        # WhatsApp validation (optional)
        if 'whatsapp' in data and data['whatsapp']:
            whatsapp = data['whatsapp'].strip()
            if not self._is_valid_phone(whatsapp):
                errors['whatsapp'] = ["Formato de telefone inválido"]
        
        return errors

    def _is_valid_email(self, email):
        """Validate email format"""
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(email_pattern, email) is not None

    def _is_valid_phone(self, phone):
        """Validate Brazilian phone format"""
        # Remove all non-digits
        phone_clean = re.sub(r'[^\d]', '', phone)
        
        # Check if has 10 or 11 digits
        if len(phone_clean) not in [10, 11]:
            return False
        
        # Check Brazilian phone pattern
        phone_pattern = r'^\(\d{2}\)\s\d{4,5}-\d{4}$'
        return re.match(phone_pattern, phone) is not None
