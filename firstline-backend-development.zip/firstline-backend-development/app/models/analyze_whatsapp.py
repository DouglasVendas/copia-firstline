import os
import json
import logging
import time
import uuid
import tempfile
import base64
import re
import unicodedata
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import assemblyai as aai
from anthropic import Anthropic
from flask import request
from dotenv import load_dotenv
from sqlalchemy import text
from app.models.db_model import create_db_engine, ENGINE_CACHE
from app.models.analyze_manager import AnalyzeManager
from app.utils.disc_profiles import get_disc_profile_by_name
from mutagen._file import File
from PIL import Image

# Custom handler to force immediate log writing
class ImmediateFileHandler(logging.FileHandler):
    def emit(self, record):
        super().emit(record)
        self.flush()

SECURITY_LIMITS = {
    "MAX_FILE_SIZE": 200 * 1024 * 1024, # 200MB
    "MAX_TEXT_LENGTH": 500000,  # 500KB para texto do WhatsApp
    "MAX_FILES": 50,  # Máximo de arquivos por análise
    "ALLOWED_AUDIO_TYPES": [
        'audio/mpeg', 'audio/mp3', 'audio/mpga', 'audio/mp2',
        'audio/wav', 'audio/wave',
        'audio/ogg', 'audio/oga', 'audio/mogg',
        'audio/opus',
        'audio/aac',
        'audio/ac3',
        'audio/aiff', 'audio/aif',
        'audio/alac',
        'audio/amr',
        'audio/ape',
        'audio/au', 'audio/basic',
        'audio/dss',
        'audio/flac',
        'audio/tta',
        'audio/voc',
        'audio/webm', 'audio/webma',
        'audio/wma',
        'audio/x-m4a', 'audio/x-m4b', 'audio/x-m4p', 'audio/x-m4r',
        'audio/x-3ga',
        'audio/x-8svx',
        'audio/x-flv',
        'audio/x-qcp',
        # Formatos de vídeo (que contêm áudio)
        'video/mp4', 'video/x-m4v',
        'video/webm',
        'video/ogg',
        'video/quicktime', 'video/x-quicktime',
        'video/mp2t', 'video/mp2ts', 'video/mts',
        'video/mxf',
        'video/flv',
        # Formatos específicos
        'application/ogg',
        'application/octet-stream'  # Para arquivos .opus do WhatsApp
    ],
    "ALLOWED_IMAGE_TYPES": [
        'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 
        'image/bmp', 'image/webp', 'image/tiff', 'image/svg+xml'
    ],
    "MAX_IMAGE_SIZE": 20 * 1024 * 1024,  # 20MB para imagens
    "MAX_PROCESSING_TIME": 480000, # 8 minutes
}

# Load environment variables from .env file
load_dotenv()

def get_audio_duration(filepath):
    """
    Retorna a duração do áudio em segundos usando mutagen.
    Suporta a maioria dos formatos populares (mp3, wav, ogg, etc).
    """
    audio = File(filepath)
    if audio is None or not hasattr(audio, 'info') or not hasattr(audio.info, 'length'):
        raise ValueError("Não foi possível extrair a duração do áudio com mutagen.")
    return audio.info.length

class AnalyzeWhatsapp:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        # Add immediate file handler if not already present
        if not any(isinstance(h, ImmediateFileHandler) for h in self.logger.handlers):
            handler = ImmediateFileHandler('app.log', mode='a')
            handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
        
        self.db_engine = create_db_engine("DB_URI")
        if not self.db_engine:
            self.logger.error("Failed to create database engine with DB_URI")
            raise Exception("Database connection failed")
        
        # Initialize Anthropic and AssemblyAI clients
        try:
            anthropic_api_key = os.getenv('ANTHROPIC_API_KEY')
            assembly_api_key = os.getenv('ASSEMBLY_API_KEY')
            if not anthropic_api_key or not assembly_api_key:
                self.logger.error("API KEYS not found in environment variables")
                raise Exception("API keys not configured")

            # Create clients
            self.client = Anthropic(api_key=anthropic_api_key)
            aai.settings.api_key = assembly_api_key
            
            # Load prompt from file
            try:
                with open('prompt.txt', 'r', encoding='utf-8') as f:
                    self.prompt = f.read()
            except Exception as e:
                self.logger.error(f"Failed to load prompt from prompt.txt: {str(e)}")
                self.prompt = None
                
        except Exception as e:
            self.logger.error(f"Failed to initialize clients: {str(e)}")
            self.client = None

    def _build_context_prompt(self, context: Dict) -> str:
        """Constrói o prompt de contexto baseado nos campos do contexto"""
        if not context:
            return ""
        
        context_parts = []
        
        if context.get('product_info'):
            context_parts.append(f"INFORMAÇÕES DO PRODUTO/SERVIÇO:\n{context['product_info']}")
        
        if context.get('target_audience'):
            context_parts.append(f"PÚBLICO-ALVO:\n{context['target_audience']}")
        
        if context.get('common_objections'):
            objections = context['common_objections']
            if isinstance(objections, list) and len(objections) > 0:
                objections_text = ""
                for i, obj in enumerate(objections, 1):
                    if isinstance(obj, dict):
                        objection = obj.get('objection', '')
                        response = obj.get('response', '')
                        objections_text += f"{i}. OBJEÇÃO: {objection}\n   RESPOSTA: {response}\n\n"
                    else:
                        objections_text += f"{i}. {obj}\n"
                context_parts.append(f"OBJEÇÕES COMUNS:\n{objections_text.strip()}")
            elif isinstance(objections, str) and objections:
                context_parts.append(f"OBJEÇÕES COMUNS:\n{objections}")
        
        if context.get('pricing_structure'):
            context_parts.append(f"ESTRUTURA DE PREÇOS:\n{context['pricing_structure']}")
        
        if context.get('playbook'):
            context_parts.append(f"PLAYBOOK DE VENDAS:\n{context['playbook']}")
        
        if context.get('mental_triggers'):
            context_parts.append(f"GATILHOS MENTAIS:\n{context['mental_triggers']}")
        
        if context.get('competitors'):
            competitors = context['competitors']
            if isinstance(competitors, list) and len(competitors) > 0:
                competitors_text = ", ".join(competitors)
                context_parts.append(f"CONCORRENTES:\n{competitors_text}")
            elif isinstance(competitors, str) and competitors:
                context_parts.append(f"CONCORRENTES:\n{competitors}")
        
        if context_parts:
            return "\n\n".join(context_parts)
        
        return ""

    def _transcribe_audio(self, audio_files):
        """Transcreve o áudio usando AssemblyAI e retorna a transcrição formatada."""
        try:
            config = aai.TranscriptionConfig(
                format_text=True,
                punctuate=True,
                speech_model=aai.SpeechModel.best,
                language_code=aai.LanguageCode.pt)
            transcript = aai.Transcriber(config=config).transcribe(audio_files)
            if transcript.status == "error":
                raise Exception(f"Transcription error: {transcript.error}")
            return transcript.json_response, None
        except Exception as e:
            self.logger.error(f"Erro na transcrição do áudio: {str(e)}")
            return None, ({"error": f"Erro na transcrição do áudio: {str(e)}"}, 500)

    def _validate_context(self, context_id: str, user_id: str) -> Optional[Dict[str, Any]]:
        """Validate that the context exists and belongs to the user"""
        try:
            with self.db_engine.connect() as conn:
                # Convert IDs to strings to avoid type mismatch
                context_id_str = str(context_id) if context_id else None
                user_id_str = str(user_id) if user_id else None
                
                result = conn.execute(text(
                    "SELECT * FROM contexts WHERE id = :context_id AND user_id = :user_id"
                ), {"context_id": context_id_str, "user_id": user_id_str})
                
                context = result.fetchone()
                if not context:
                    self.logger.error(f"Context not found: {context_id} for user {user_id}")
                    return None
                
                return context._asdict()
        except Exception as e:
            self.logger.error(f"Database error validating context: {str(e)}")
            return None

    def _sanitize_text(self, text: str) -> str:
        """Sanitize and limit text input"""
        if not text:
            return ""
        
        # Remover textos padrão do WhatsApp sobre criptografia (com mais variações)
        whatsapp_patterns = [
            # Mensagem completa de criptografia
            r'As mensagens e ligações são protegidas com a criptografia de ponta a ponta\. Somente as pessoas que fazem parte da conversa podem ler, ouvir e compartilhar esse conteúdo\. Saiba mais',
            # Com data/hora no início
            r'\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s+-\s+As mensagens e ligações são protegidas.*?Saiba mais',
            # Qualquer variação da mensagem
            r'.*?As mensagens e ligações são protegidas.*?Saiba mais.*?',
            # Linhas que só contêm data/hora e hífen (restos da mensagem de criptografia)
            r'\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s+-\s*$'
        ]
        
        cleaned_text = text
        for pattern in whatsapp_patterns:
            cleaned_text = re.sub(pattern, '', cleaned_text, flags=re.IGNORECASE | re.DOTALL | re.MULTILINE)
        
        # Dividir em linhas para limpeza mais precisa
        lines = cleaned_text.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Remover linhas que só contêm data/hora e hífen (sem conteúdo)
            if re.match(r'^\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s+-\s*$', line.strip()):
                continue
            # Remover linhas vazias ou só com espaços
            if line.strip():
                cleaned_lines.append(line)
        
        # Juntar novamente
        cleaned_text = '\n'.join(cleaned_lines)
        
        # Limpar múltiplas quebras de linha consecutivas (caso ainda existam)
        cleaned_text = re.sub(r'\n\s*\n', '\n', cleaned_text)
        cleaned_text = re.sub(r'\r\n\s*\r\n', '\r\n', cleaned_text)
        
        # Remover espaços em branco no início e fim
        cleaned_text = cleaned_text.strip()
        
        # Truncate to maximum length
        return cleaned_text[:SECURITY_LIMITS["MAX_TEXT_LENGTH"]]

    def _normalize_filename(self, filename: str) -> str:
        """Remove caracteres invisíveis Unicode de nomes de arquivos"""
        if not filename:
            return ""
        
        # Remover caracteres de controle Unicode (como LEFT-TO-RIGHT MARK)
        normalized = ''.join(char for char in filename if unicodedata.category(char)[0] != 'C')
        
        # Normalizar Unicode (NFD -> NFC)
        normalized = unicodedata.normalize('NFC', normalized)
        
        return normalized.strip()

    def _remove_missing_images_from_text(self, text: str, available_image_files: List[str]) -> str:
        """Remove referências a imagens que não foram enviadas/encontradas para evitar confusão na IA"""
        if not text:
            return ""
        
        # Extrair todas as imagens mencionadas no texto
        mentioned_images = self._extract_image_files_from_text(text)
        
        # Normalizar nomes de arquivos para comparação
        normalized_available = [self._normalize_filename(img) for img in available_image_files]
        
        # Identificar imagens que estão mencionadas mas não foram enviadas
        missing_images = []
        for mentioned_img in mentioned_images:
            normalized_mentioned = self._normalize_filename(mentioned_img)
            
            # Verificar se a imagem mencionada está na lista de arquivos disponíveis
            found = False
            for normalized_available_img in normalized_available:
                if normalized_mentioned == normalized_available_img:
                    found = True
                    break
            
            if not found:
                missing_images.append(mentioned_img)  # Manter o nome original para remoção
        
        if not missing_images:
            return text  # Nenhuma imagem faltando
        
        self.logger.info(f"Removendo {len(missing_images)} imagens não encontradas: {missing_images}")
        self.logger.info(f"Imagens disponíveis normalizadas: {normalized_available}")
        
        # Dividir texto em linhas para remoção precisa
        lines = text.split('\n')
        cleaned_lines = []
        
        for line in lines:
            line_should_be_removed = False
            
            # Verificar se a linha contém alguma das imagens faltando
            for missing_img in missing_images:
                if missing_img in line:
                    line_should_be_removed = True
                    self.logger.debug(f"Removendo linha com imagem faltando: {line[:100]}...")
                    break
            
            # Se a linha não deve ser removida, manter
            if not line_should_be_removed:
                cleaned_lines.append(line)
        
        # Juntar novamente
        cleaned_text = '\n'.join(cleaned_lines)
        
        # Limpar linhas vazias que podem ter sobrado
        cleaned_text = re.sub(r'\n\s*\n', '\n', cleaned_text)
        cleaned_text = cleaned_text.strip()
        
        return cleaned_text

    def _sanitize_array(self, arr):
        """Sanitize array items and limit their size"""
        if not isinstance(arr, list):
            return []
        return [str(item)[:500] for item in arr][:20]  # Max 20 items, 500 chars each

    def _get_vendedor_info(self, vendedor_id: str) -> tuple:
        """Busca o nome e tipo do vendedor pelo id na tabela sellers."""
        if not vendedor_id:
            return None, None
        try:
            with self.db_engine.connect() as conn:
                result = conn.execute(text("SELECT name, tipo FROM sellers WHERE id = :id"), {"id": vendedor_id})
                row = result.fetchone()
                if row:
                    return row[0], row[1]
        except Exception as e:
            self.logger.error(f"Erro ao buscar informações do vendedor: {str(e)}")
        return None, None

    def _check_monthly_limit(self, user_id):
        """Valida o limite mensal de análises do usuário."""
        try:
            with self.db_engine.connect() as conn:
                # Convert user_id to string to avoid type mismatch
                user_id_str = str(user_id) if user_id else None
                
                # Get current date and calculate start of month
                current_date = datetime.now()
                start_of_month = current_date.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
                
                # Count analyses this month
                result = conn.execute(text("""
                    SELECT COUNT(*) as count FROM analyses 
                    WHERE user_id = :user_id AND created_at >= :start_of_month
                """), {"user_id": user_id_str, "start_of_month": start_of_month})
                
                count = result.fetchone()[0]
                
                # Check user's plan limit (default to 50 for now)
                max_analyses = 50  # This could come from user's plan
                
                if count >= max_analyses:
                    self.logger.warning(f"User {user_id} exceeded monthly limit: {count}/{max_analyses}")
                    return False, {"error": "Monthly analysis limit exceeded"}, 429
                
                return True, None, None
        except Exception as e:
            self.logger.error(f"Erro ao validar limite de análises: {str(e)}")
            return True, None, None  # Allow on error

    def _extract_audio_files_from_text(self, text_content: str) -> List[str]:
        """Extrai nomes de arquivos de áudio mencionados no texto do WhatsApp"""
        # Padrões para arquivos de áudio no WhatsApp
        audio_patterns = [
            r'‎PTT-\d{8}-WA\d{4}\.opus',  # Áudios de voz (Voice messages)
            r'‎AUD-\d{8}-WA\d{4}\.(mp3|m4a|aac|opus|ogg|wav)',  # Arquivos de áudio
            r'‎VID-\d{8}-WA\d{4}\.(mp4|3gp|mov|avi)',  # Vídeos (podem ter áudio)
        ]
        
        audio_files = []
        for pattern in audio_patterns:
            matches = re.findall(pattern, text_content, re.IGNORECASE)
            if isinstance(matches[0], tuple) if matches else False:
                # Para padrões com grupos, pega o match completo
                audio_files.extend([match[0] if isinstance(match, tuple) else match for match in re.finditer(pattern, text_content, re.IGNORECASE)])
            else:
                audio_files.extend(matches)
        
        return audio_files

    def _extract_image_files_from_text(self, text_content: str) -> List[str]:
        """Extrai nomes de arquivos de imagem mencionados no texto do WhatsApp"""
        # Padrões para arquivos de imagem no WhatsApp
        image_patterns = [
            r'‎IMG-\d{8}-WA\d{4}\.(jpg|jpeg|png|gif|bmp|webp)',  # Imagens
            r'‎PHOTO-\d{8}-WA\d{4}\.(jpg|jpeg|png|gif|bmp|webp)',  # Fotos
        ]
        
        image_files = []
        for pattern in image_patterns:
            matches = re.finditer(pattern, text_content, re.IGNORECASE)
            image_files.extend([match.group() for match in matches])
        
        return image_files

    def _save_temp_file(self, file_obj, extension: str = None) -> Tuple[str, Optional[str]]:
        """Salva arquivo temporariamente e retorna o caminho"""
        try:
            temp_dir = tempfile.gettempdir()
            if extension:
                temp_file_path = os.path.join(temp_dir, f"{uuid.uuid4()}.{extension}")
            else:
                file_extension = file_obj.filename.split('.')[-1] if '.' in file_obj.filename else 'tmp'
                temp_file_path = os.path.join(temp_dir, f"{uuid.uuid4()}.{file_extension}")
            
            file_obj.save(temp_file_path)
            
            if not os.path.exists(temp_file_path):
                return None, "Erro ao salvar arquivo temporário"
            
            saved_file_size = os.path.getsize(temp_file_path)
            if saved_file_size == 0:
                os.remove(temp_file_path)
                return None, "Arquivo está vazio"
            
            return temp_file_path, None
        except Exception as e:
            self.logger.error(f"Error saving temp file: {str(e)}")
            return None, f"Erro ao salvar arquivo: {str(e)}"

    def _is_audio_file(self, filename: str, content_type: str) -> bool:
        """Verifica se um arquivo é de áudio baseado na extensão e content_type"""
        if not filename:
            return False
        
        # Verificar por content_type primeiro
        if content_type in SECURITY_LIMITS["ALLOWED_AUDIO_TYPES"]:
            return True
        
        # Se content_type for application/octet-stream, verificar por extensão
        if content_type == 'application/octet-stream':
            audio_extensions = [
                '.opus', '.mp3', '.wav', '.ogg', '.aac', '.m4a', 
                '.mp2', '.aiff', '.aif', '.alac', '.amr', '.ape', 
                '.au', '.dss', '.flac', '.tta', '.voc', '.wma'
            ]
            file_extension = '.' + filename.split('.')[-1].lower() if '.' in filename else ''
            return file_extension in audio_extensions
        
        return False

    def _is_image_file(self, filename: str, content_type: str) -> bool:
        """Verifica se um arquivo é de imagem baseado na extensão e content_type"""
        if not filename:
            return False
        
        # Verificar por content_type primeiro
        if content_type in SECURITY_LIMITS["ALLOWED_IMAGE_TYPES"]:
            return True
        
        # Verificar por extensão como fallback
        image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.svg']
        file_extension = '.' + filename.split('.')[-1].lower() if '.' in filename else ''
        return file_extension in image_extensions

    def _process_audio_file(self, file_obj, filename: str) -> Tuple[Optional[str], Optional[str]]:
        """Processa um arquivo de áudio e retorna a transcrição"""
        try:
            # Validar tipo de arquivo usando nova função
            if not self._is_audio_file(filename, file_obj.content_type):
                return None, f"Tipo de arquivo não suportado: {file_obj.content_type} (arquivo: {filename})"
            
            # Validar tamanho
            file_obj.seek(0, 2)
            file_size = file_obj.tell()
            file_obj.seek(0)
            
            if file_size > SECURITY_LIMITS["MAX_FILE_SIZE"]:
                return None, f"Arquivo muito grande: {file_size} bytes"
            
            # Salvar temporariamente
            temp_path, error = self._save_temp_file(file_obj)
            if error:
                return None, error
            
            try:
                # Transcrever áudio
                config = aai.TranscriptionConfig(
                    format_text=True,
                    punctuate=True,
                    speech_model=aai.SpeechModel.best,
                    language_code=aai.LanguageCode.pt
                )
                transcript = aai.Transcriber(config=config).transcribe(temp_path)
                
                if transcript.status == "error":
                    return None, f"Erro na transcrição: {transcript.error}"
                
                transcription = transcript.text
                self.logger.info(f"Áudio {filename} transcrito com sucesso: {len(transcription)} caracteres")
                
                return transcription, None
                
            finally:
                # Limpar arquivo temporário
                try:
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                except Exception as cleanup_error:
                    self.logger.warning(f"Failed to clean up temp file: {cleanup_error}")
                
        except Exception as e:
            self.logger.error(f"Erro ao processar áudio {filename}: {str(e)}")
            return None, str(e)

    def _process_image_file(self, file_obj, filename: str) -> Tuple[Optional[str], Optional[str]]:
        """Processa um arquivo de imagem e retorna dados base64 para o Claude"""
        try:
            # Validar tipo de arquivo usando nova função
            if not self._is_image_file(filename, file_obj.content_type):
                return None, f"Tipo de imagem não suportado: {file_obj.content_type} (arquivo: {filename})"
            
            # Validar tamanho
            file_obj.seek(0, 2)
            file_size = file_obj.tell()
            file_obj.seek(0)
            
            if file_size > SECURITY_LIMITS["MAX_IMAGE_SIZE"]:
                return None, f"Imagem muito grande: {file_size} bytes"
            
            # Ler dados da imagem
            image_data = file_obj.read()
            file_obj.seek(0)  # Reset para outros usos
            
            # Converter para base64
            base64_data = base64.b64encode(image_data).decode('utf-8')
            
            # Determinar tipo MIME correto
            media_type = file_obj.content_type
            if media_type == 'image/jpg':
                media_type = 'image/jpeg'
            
            self.logger.info(f"Imagem {filename} processada com sucesso: {len(base64_data)} caracteres base64")
            
            return f"data:{media_type};base64,{base64_data}", None
            
        except Exception as e:
            self.logger.error(f"Erro ao processar imagem {filename}: {str(e)}")
            return None, str(e)

    def analyze_whatsapp(self, text_content: str, files: List, context_id: str, vendedor: str, user_id: str, analysis_name: str) -> Tuple[Dict, int]:
        """
        Analisa uma conversa do WhatsApp com texto e arquivos de mídia
        
        Args:
            text_content: Texto da conversa do WhatsApp
            files: Lista de arquivos (áudios e imagens)
            context_id: ID do contexto para análise
            vendedor: ID do vendedor
            user_id: ID do usuário
            analysis_name: Nome da análise
            
        Returns:
            Tupla (resultado, status_code)
        """
        start_time = time.time()
        
        try:
            # 1. Validar limite mensal
            ok, error, status = self._check_monthly_limit(user_id)
            if not ok:
                return error, status
            
            # 2. Validar contexto
            context = self._validate_context(context_id, user_id)
            if not context:
                return {"error": "Context not found or access denied"}, 404
            
            # 3. Sanitizar texto base (remover textos padrão do WhatsApp)
            self.logger.info(f"Texto original length: {len(text_content)}")
            self.logger.debug(f"Primeiras 200 chars do texto original: {text_content[:200]}")
            
            sanitized_text = self._sanitize_text(text_content)
            
            self.logger.info(f"Texto sanitizado length: {len(sanitized_text)}")
            self.logger.debug(f"Primeiras 200 chars do texto sanitizado: {sanitized_text[:200]}")
            
            if len(sanitized_text) < 50:
                return {"error": "Texto muito curto para análise"}, 400
            
            # 4. Identificar arquivos mencionados no texto
            mentioned_audio_files = self._extract_audio_files_from_text(sanitized_text)
            mentioned_image_files = self._extract_image_files_from_text(sanitized_text)
            
            self.logger.info(f"Arquivos mencionados no texto - Áudios: {len(mentioned_audio_files)}, Imagens: {len(mentioned_image_files)}")
            
            # 5. Processar arquivos enviados
            processed_files = {}
            audio_transcriptions = {}
            image_data_list = []
            
            if files:
                self.logger.info(f"Processando {len(files)} arquivos enviados")
                
                for file_obj in files:
                    if not file_obj.filename:
                        continue
                    
                    filename = file_obj.filename
                    content_type = file_obj.content_type or ""
                    
                    self.logger.info(f"Processando arquivo: {filename}, tipo: {content_type}")
                    
                    # Processar áudios usando nova função de detecção
                    if self._is_audio_file(filename, content_type):
                        self.logger.info(f"Arquivo {filename} identificado como áudio")
                        transcription, error = self._process_audio_file(file_obj, filename)
                        if error:
                            self.logger.warning(f"Erro ao processar áudio {filename}: {error}")
                            processed_files[filename] = {
                                "type": "audio",
                                "status": "error",
                                "error": error
                            }
                            continue
                        
                        audio_transcriptions[filename] = transcription
                        processed_files[filename] = {
                            "type": "audio",
                            "transcription": transcription,
                            "status": "success"
                        }
                    
                    # Processar imagens usando nova função de detecção
                    elif self._is_image_file(filename, content_type):
                        self.logger.info(f"Arquivo {filename} identificado como imagem")
                        image_data, error = self._process_image_file(file_obj, filename)
                        if error:
                            self.logger.warning(f"Erro ao processar imagem {filename}: {error}")
                            processed_files[filename] = {
                                "type": "image",
                                "status": "error",
                                "error": error
                            }
                            continue
                        
                        image_data_list.append({
                            "filename": filename,
                            "data": image_data
                        })
                        processed_files[filename] = {
                            "type": "image",
                            "status": "success"
                        }
                    
                    else:
                        self.logger.warning(f"Tipo de arquivo não suportado: {filename} ({content_type})")
                        processed_files[filename] = {
                            "type": "unknown",
                            "status": "unsupported",
                            "error": f"Tipo não suportado: {content_type}"
                        }
            
            # 6. Remover imagens não encontradas do texto
            available_image_files = [img["filename"] for img in image_data_list]
            self.logger.info(f"Imagens disponíveis: {len(available_image_files)} - {available_image_files}")
            
            final_text = self._remove_missing_images_from_text(sanitized_text, available_image_files)
            
            # 7. Substituir áudios transcritos no texto
            for filename, transcription in audio_transcriptions.items():
                # Procurar padrão do arquivo no texto e substituir
                pattern = re.escape(filename)
                replacement = f"{filename}\n[TRANSCRIÇÃO DO ÁUDIO]: {transcription}"
                final_text = re.sub(pattern, replacement, final_text, flags=re.IGNORECASE)
            
            # 8. Preparar mensagens para o Claude
            messages = []
            
            # Mensagem principal com o texto
            main_content = f"""CONVERSA DO WHATSAPP PARA ANÁLISE:
{final_text}
Analise esta conversa do WhatsApp e retorne o JSON estruturado conforme solicitado."""
            
            # Se há imagens, adicionar contexto sobre elas
            if image_data_list:
                main_content += f"\n\nAs {len(image_data_list)} imagens anexadas aparecem na mesma ordem que foram enviadas na conversa."
                
                # Adicionar imagens à mensagem
                content_parts = [{"type": "text", "text": main_content}]
                
                for img in image_data_list:
                    content_parts.append({
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": img["data"].split(";")[0].split(":")[1],
                            "data": img["data"].split(",")[1]
                        }
                    })
                
                messages.append({
                    "role": "user",
                    "content": content_parts
                })
            else:
                # Apenas texto
                messages.append({
                    "role": "user",
                    "content": main_content
                })
            
            # 9. Analisar com Claude
            result, error = self._analyze_with_claude(messages, context)
            if error:
                return error, 500
            
            # 10. Obter informações do vendedor e contexto
            vendedor_nome, vendedor_tipo = self._get_vendedor_info(vendedor)
            context_name = context.get('name') if context else None

            # Processar perfil DISC
            disc_profile_name = result.get("DISC", "").upper()
            disc_profile_data = get_disc_profile_by_name(disc_profile_name)
            disc_profile_id = disc_profile_data.get("id")
            
            # 11. Salvar no banco de dados
            analysis_data = {
                "id": str(uuid.uuid4()),
                "client_name": result.get("client_name"),
                "analysis_name": analysis_name[:255],
                "transcription": final_text,
                "score_geral": max(0, min(10, int(result.get("score_geral", 0)))),
                "pontos_positivos": self._sanitize_array(result.get("pontos_positivos", [])),
                "pontos_atencao": self._sanitize_array(result.get("pontos_atencao", [])),
                "objecoes_identificadas": self._sanitize_array(result.get("objecoes_identificadas", [])),
                "sugestoes_melhoria": self._sanitize_array(result.get("sugestoes_melhoria", [])),
                "proximos_passos": self._sanitize_array(result.get("proximos_passos", [])),
                "resumo": str(result.get("resumo", ""))[:1000],
                "disc_profile_id": disc_profile_id,
                "disc_profile": disc_profile_data if disc_profile_data else None,
                "context_uuid": context_id,
                "context_name": context_name,
                "upload_type": "whatsapp",
                "vendedor": vendedor[:100] if vendedor else None,
                "vendedor_nome": vendedor_nome,
                "vendedor_tipo": vendedor_tipo,
                "user_id": str(user_id) if user_id else None,
                "framework_analysis": result.get("framework_analysis"),
                "coaching_insights": self._sanitize_array(result.get("coaching_insights", [])),
                "performance_analysis": result.get("performance_analysis"),
                "mental_triggers": result.get("mental_triggers"),
                "reformulacoes_pnl": result.get("reformulacoes_pnl"),
                "plano_fechamento": self._sanitize_array(result.get("plano_fechamento", [])),
                "ia_preditiva": result.get("ia_preditiva"),
                "desempenho_geral": result.get("desempenho_geral"),
                "tempo_de_fala": result.get("tempo_de_fala"),
                "created_at": time.strftime('%Y-%m-%d %H:%M:%S'),
            }
            
            analysis_id, error = self._save_analysis_to_db(analysis_data)
            if error:
                return error, 500
            
            processing_time = time.time() - start_time
            
            # Get scores by seller
            analyze_manager = AnalyzeManager()
            scores = analyze_manager.get_scores_by_seller(user_id)
            if scores is None:
                scores = []
            
            return {
                "success": True,
                "analysis": {**analysis_data, "id": analysis_id},
                "transcription": final_text,
                "contextUsed": context['name'],
                "processing_time": processing_time,
                "scores": scores,
                "whatsapp_files_info": {
                    "total_files": len(files) if files else 0,
                    "audio_files": len(audio_transcriptions),
                    "image_files": len(image_data_list),
                    "successful": len([f for f in processed_files.values() if f.get("status") == "success"]),
                    "failed": len([f for f in processed_files.values() if f.get("status") != "success"]),
                    "processed_files": processed_files
                }
            }, 200
            
        except Exception as e:
            self.logger.error(f"Erro na análise do WhatsApp: {str(e)}")
            import traceback
            self.logger.error(traceback.format_exc())
            return {"error": "Erro interno do servidor"}, 500

    def _analyze_with_claude(self, messages: List[Dict], context: Dict, max_retries: int = 3) -> Tuple[Optional[Dict], Optional[Dict]]:
        """Analisa o conteúdo usando Anthropic Claude com sistema de retry"""
        try:
            if not self.client:
                return None, {"error": "Claude client not initialized"}
            
            if not self.prompt:
                return None, {"error": "Analysis prompt not loaded"}
            
            # Preparar prompt do sistema
            context_prompt = self._build_context_prompt(context)
            system_prompt = f"{self.prompt}\n\n{context_prompt}" if context_prompt else self.prompt
            
            # Tentar análise com retry
            for attempt in range(max_retries):
                try:
                    self.logger.info(f"Tentativa {attempt + 1} de {max_retries} para análise")
                    
                    # Fazer a análise
                    response = self.client.messages.create(
                        model="claude-3-7-sonnet-20250219",
                        max_tokens=8000,
                        temperature=0.4,
                        system=system_prompt,
                        messages=messages
                    )
                    
                    analysis = response.content[0].text
                    self.logger.info(f"Claude analysis response received, length: {len(analysis) if analysis else 0} characters")
                    
                    if not analysis or not analysis.strip():
                        error_msg = "Claude retornou resposta vazia."
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry
                            messages.append({"role": "assistant", "content": analysis if analysis else ""})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO: {error_msg}\n\nPor favor, retorne o JSON estruturado conforme solicitado no formato correto."
                            })
                            continue
                        else:
                            return None, {"error": "Claude retornou resposta vazia após múltiplas tentativas"}
                    
                    # Extrair JSON da resposta
                    json_str = self._extract_json_from_text(analysis)
                    if not json_str:
                        error_msg = "Não foi possível extrair JSON válido da resposta."
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}. Resposta: {analysis[:500]}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry com a resposta anterior
                            messages.append({"role": "assistant", "content": analysis})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO: {error_msg}\n\nVocê retornou:\n{analysis}\n\nPor favor, retorne APENAS o JSON estruturado no formato correto, sem texto adicional antes ou depois."
                            })
                            continue
                        else:
                            return None, {"error": "Formato da análise inválido após múltiplas tentativas"}
                    
                    # Tentar fazer parse do JSON
                    try:
                        parsed_analysis = json.loads(json_str)
                        self.logger.info(f"Analysis successful na tentativa {attempt + 1}")
                        return parsed_analysis, None
                    except json.JSONDecodeError as parse_error:
                        error_msg = f"Erro ao fazer parse do JSON: {str(parse_error)}"
                        self.logger.warning(f"{error_msg} Tentativa {attempt + 1}")
                        
                        if attempt < max_retries - 1:
                            # Adicionar mensagem de retry com o erro específico e JSON problemático
                            messages.append({"role": "assistant", "content": analysis})
                            messages.append({
                                "role": "user",
                                "content": f"ERRO DE PARSE JSON: {str(parse_error)}\n\nJSON problemático:\n{json_str[:1000]}\n\nPor favor, corrija os erros no JSON e retorne o JSON válido e bem formatado."
                            })
                            continue
                        else:
                            self.logger.error(f"Failed to parse analysis JSON after {max_retries} attempts: {str(parse_error)}")
                            return None, {"error": "Analysis format error após múltiplas tentativas"}
                
                except Exception as attempt_error:
                    self.logger.error(f"Erro na tentativa {attempt + 1}: {str(attempt_error)}")
                    if attempt < max_retries - 1:
                        continue
                    else:
                        raise attempt_error
            
            # Se chegou aqui, todas as tentativas falharam
            return None, {"error": "Falha na análise após múltiplas tentativas"}
                
        except Exception as e:
            self.logger.error(f"Erro na análise com Claude: {str(e)}")
            return None, {"error": f"Claude analysis error: {str(e)}"}

    def _extract_json_from_text(self, text: str) -> Optional[str]:
        """Extrai JSON válido de um texto"""
        try:
            # Procurar por blocos JSON (entre {})
            json_pattern = r'\{.*\}'
            matches = re.findall(json_pattern, text, re.DOTALL)
            
            for match in matches:
                try:
                    # Testar se é JSON válido
                    json.loads(match)
                    return match
                except json.JSONDecodeError:
                    continue
            
            return None
        except Exception as e:
            self.logger.error(f"Error extracting JSON: {str(e)}")
            return None

    def _save_analysis_to_db(self, analysis_data: Dict) -> Tuple[Optional[str], Optional[Dict]]:
        """Salva a análise no banco de dados"""
        try:
            with self.db_engine.connect() as conn:
                # Convert arrays and objects to JSON strings for database storage
                # PostgreSQL will handle JSON conversion automatically if columns are JSON type
                for key, value in analysis_data.items():
                    if isinstance(value, (list, dict)):
                        analysis_data[key] = json.dumps(value, ensure_ascii=False)
                
                query = """
                    INSERT INTO analyses (
                        id, client_name, analysis_name, transcription, score_geral,
                        pontos_positivos, pontos_atencao, objecoes_identificadas,
                        sugestoes_melhoria, proximos_passos, resumo, disc_profile_id, context_uuid,
                        upload_type, vendedor, user_id, framework_analysis,
                        coaching_insights, performance_analysis, mental_triggers,
                        reformulacoes_pnl, plano_fechamento, ia_preditiva, created_at,
                        desempenho_geral, tempo_de_fala
                    ) VALUES (
                        :id, :client_name, :analysis_name, :transcription, :score_geral,
                        :pontos_positivos, :pontos_atencao, :objecoes_identificadas,
                        :sugestoes_melhoria, :proximos_passos, :resumo, :disc_profile_id, :context_uuid,
                        :upload_type, :vendedor, :user_id, :framework_analysis,
                        :coaching_insights, :performance_analysis, :mental_triggers,
                        :reformulacoes_pnl, :plano_fechamento, :ia_preditiva, :created_at,
                        :desempenho_geral, :tempo_de_fala
                    )
                """
                
                conn.execute(text(query), analysis_data)
                conn.commit()
                
                self.logger.info(f"Analysis saved to database with ID: {analysis_data['id']}")
                return analysis_data['id'], None
                
        except Exception as e:
            self.logger.error(f"Erro ao salvar análise no banco: {str(e)}")
            return None, {"error": f"Database error: {str(e)}"}