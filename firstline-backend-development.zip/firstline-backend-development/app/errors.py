from flask import jsonify

class ValidationError(Exception):
    """Exception for validation errors"""
    def __init__(self, message, details=None):
        self.message = message
        self.details = details or []
        super().__init__(self.message)

class NotFoundError(Exception):
    """Exception for resource not found errors"""
    def __init__(self, message="Resource not found"):
        self.message = message
        super().__init__(self.message)

class AuthenticationError(Exception):
    """Exception for authentication errors"""
    def __init__(self, message="Authentication required"):
        self.message = message
        super().__init__(self.message)

def handle_404(error):
    return jsonify({"error": "Resource not found"}), 404

def handle_500(error):
    return jsonify({"error": "Internal server error"}), 500

def handle_413(error):
    return jsonify({
        "error": "Arquivo muito grande",
        "message": "O arquivo enviado excede o tamanho máximo permitido de 200MB"
    }), 413
