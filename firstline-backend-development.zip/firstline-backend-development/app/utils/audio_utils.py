import logging
import os
import time
import requests
import tempfile
import base64
from .whatsapp_decoder import download_and_decode_whatsapp_audio, is_whatsapp_encrypted_url


def download_audio_from_url(audio_url, filename_prefix="audio_from_url", media_key=None, mimetype=None):
    """
    Download audio file from URL and create a FileStorage-like object
    Supports regular URLs and WhatsApp encrypted media URLs
    
    Args:
        audio_url: URL to download audio from
        filename_prefix: Prefix for the generated filename
        media_key: Media key for WhatsApp encrypted files (optional)
        mimetype: MIME type for WhatsApp files (e.g., "audio/mpeg", "audio/ogg")
        
    Returns:
        tuple: (audio_file_object, error_response)
        If successful: (TempAudioFile, None)
        If error: (None, (error_dict, status_code))
    """
    logger = logging.getLogger(__name__)
    
    try:
        # Check if it's a WhatsApp encrypted URL
        logger.info(f"Checking if URL is WhatsApp encrypted: {audio_url}")
        is_whatsapp = is_whatsapp_encrypted_url(audio_url)
        logger.info(f"Is WhatsApp URL: {is_whatsapp}")
        
        if is_whatsapp:
            if not media_key:
                logger.error("Media key is required for WhatsApp encrypted audio")
                return None, ({"error": "Media key is required for WhatsApp encrypted audio"}, 400)
            
            logger.info(f"Downloading WhatsApp encrypted audio from URL: {audio_url}")
            
            # Use WhatsApp decoder with specified mimetype or default
            whatsapp_mimetype = mimetype or "audio/ogg; codecs=opus"
            decoded_file_path, error_message = download_and_decode_whatsapp_audio(
                url=audio_url,
                media_key=media_key,
                mimetype=whatsapp_mimetype,
                filename_prefix=filename_prefix
            )
            
            if error_message:
                logger.error(f"WhatsApp decoding error: {error_message}")
                return None, ({"error": error_message}, 400)
            
            # Get file size and extension
            file_size = os.path.getsize(decoded_file_path)
            file_extension = os.path.splitext(decoded_file_path)[1]
            
            # Determine content type based on file extension or provided mimetype
            if mimetype:
                content_type = mimetype.split(';')[0]  # Remove codec info if present
            else:
                content_type_map = {
                    '.ogg': 'audio/ogg',
                    '.oga': 'audio/ogg',
                    '.mp3': 'audio/mpeg',
                    '.m4a': 'audio/mp4',
                    '.wav': 'audio/wav'
                }
                content_type = content_type_map.get(file_extension.lower(), 'audio/ogg')
            
            # Create a FileStorage-like object for compatibility
            class TempAudioFile:
                def __init__(self, file_path, filename_prefix, file_size, content_type, file_extension):
                    self.file_path = file_path
                    self.filename = f"{filename_prefix}_{int(time.time())}{file_extension}"
                    self.content_length = file_size
                    self.content_type = content_type
                    self._file_size = file_size
                    self.is_whatsapp_decoded = True
                
                def read(self):
                    with open(self.file_path, 'rb') as f:
                        return f.read()
                
                def seek(self, offset, whence=0):
                    # Simulate seek behavior for size validation
                    if whence == 2 and offset == 0:  # seek(0, 2) - go to end
                        return self._file_size
                    return 0
                
                def tell(self):
                    # Return file size when called after seek(0, 2)
                    return self._file_size
                
                def save(self, path):
                    """Save file to specified path"""
                    import shutil
                    shutil.copy2(self.file_path, path)
                
                def close(self):
                    try:
                        os.unlink(self.file_path)
                    except:
                        pass
            
            audio_file_from_whatsapp = TempAudioFile(decoded_file_path, filename_prefix, file_size, content_type, file_extension)
            
            # Validate decoded file size
            if audio_file_from_whatsapp._file_size == 0:
                logger.error("Decoded WhatsApp audio file is empty")
                try:
                    audio_file_from_whatsapp.close()
                except:
                    pass
                return None, ({"error": "Decoded WhatsApp audio file is empty"}, 400)
            
            logger.info(f"WhatsApp TempAudioFile created: filename={audio_file_from_whatsapp.filename}, content_length={audio_file_from_whatsapp.content_length}, file_size={audio_file_from_whatsapp._file_size}")
            
            return audio_file_from_whatsapp, None
        
        else:
            # Regular URL download
            logger.info(f"Downloading audio from URL: {audio_url}")
            response = requests.get(audio_url, timeout=30)
            response.raise_for_status()
            
            # Create temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as temp_file:
                temp_file.write(response.content)
                temp_file_path = temp_file.name
            
            logger.info(f"Audio downloaded successfully to: {temp_file_path}")
            
            # Create a FileStorage-like object for compatibility
            class TempAudioFile:
                def __init__(self, file_path, original_url, filename_prefix):
                    self.file_path = file_path
                    self.filename = f"{filename_prefix}_{int(time.time())}.mp3"
                    self.content_length = len(response.content)
                    self.content_type = response.headers.get('content-type', 'audio/mpeg')
                    self._file_size = len(response.content)
                    self.original_url = original_url
                    self.is_whatsapp_decoded = False
                
                def read(self):
                    with open(self.file_path, 'rb') as f:
                        return f.read()
                
                def seek(self, offset, whence=0):
                    # Simulate seek behavior for size validation
                    if whence == 2 and offset == 0:  # seek(0, 2) - go to end
                        return self._file_size
                    return 0
                
                def tell(self):
                    # Return file size when called after seek(0, 2)
                    return self._file_size
                
                def save(self, path):
                    """Save file to specified path"""
                    import shutil
                    shutil.copy2(self.file_path, path)
                
                def close(self):
                    try:
                        os.unlink(self.file_path)
                    except:
                        pass
            
            audio_file_from_url = TempAudioFile(temp_file_path, audio_url, filename_prefix)
            
            # Validate downloaded file size
            if audio_file_from_url._file_size == 0:
                logger.error(f"Downloaded audio file is empty from URL: {audio_url}")
                try:
                    audio_file_from_url.close()
                except:
                    pass
                return None, ({"error": "Downloaded audio file is empty"}, 400)
            
            logger.info(f"TempAudioFile created: filename={audio_file_from_url.filename}, content_length={audio_file_from_url.content_length}, file_size={audio_file_from_url._file_size}")
            
            return audio_file_from_url, None
                    
    except requests.RequestException as e:
        logger.error(f"Error downloading audio from URL: {str(e)}")
        return None, ({"error": f"Failed to download audio from URL: {str(e)}"}, 400)
    except Exception as e:
        logger.error(f"Error processing audio from URL: {str(e)}")
        return None, ({"error": f"Failed to process audio from URL: {str(e)}"}, 500)


def process_base64_audio(base64_data, filename_prefix="audio_from_base64"):
    """
    Process base64 audio data and create a FileStorage-like object
    
    Args:
        base64_data: Base64 encoded audio data
        filename_prefix: Prefix for the generated filename
        
    Returns:
        tuple: (audio_file_object, error_response)
        If successful: (TempAudioFile, None)
        If error: (None, (error_dict, status_code))
    """
    logger = logging.getLogger(__name__)
    
    try:
        logger.info("Processing base64 audio data")
        
        # Remove data URL prefix if present (e.g., "data:audio/mp3;base64,")
        if ',' in base64_data:
            base64_data = base64_data.split(',', 1)[1]
        
        # Decode base64 data
        try:
            audio_bytes = base64.b64decode(base64_data)
        except Exception as e:
            logger.error(f"Invalid base64 data: {str(e)}")
            return None, ({"error": "Invalid base64 audio data"}, 400)
        
        # Validate decoded data size
        if len(audio_bytes) == 0:
            logger.error("Decoded base64 audio data is empty")
            return None, ({"error": "Decoded audio data is empty"}, 400)
        
        # Create temporary file
        with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as temp_file:
            temp_file.write(audio_bytes)
            temp_file_path = temp_file.name
        
        logger.info(f"Base64 audio processed successfully to: {temp_file_path}")
        
        # Create a FileStorage-like object for compatibility
        class TempAudioFile:
            def __init__(self, file_path, filename_prefix, audio_bytes_len):
                self.file_path = file_path
                self.filename = f"{filename_prefix}_{int(time.time())}.mp3"
                self.content_length = audio_bytes_len
                self.content_type = 'audio/mpeg'
                self._file_size = audio_bytes_len
            
            def read(self):
                with open(self.file_path, 'rb') as f:
                    return f.read()
            
            def seek(self, offset, whence=0):
                # Simulate seek behavior for size validation
                if whence == 2 and offset == 0:  # seek(0, 2) - go to end
                    return self._file_size
                return 0
            
            def tell(self):
                # Return file size when called after seek(0, 2)
                return self._file_size
            
            def save(self, path):
                """Save file to specified path"""
                import shutil
                shutil.copy2(self.file_path, path)
            
            def close(self):
                try:
                    os.unlink(self.file_path)
                except:
                    pass
        
        audio_file_from_base64 = TempAudioFile(temp_file_path, filename_prefix, len(audio_bytes))
        
        logger.info(f"TempAudioFile created from base64: filename={audio_file_from_base64.filename}, content_length={audio_file_from_base64.content_length}, file_size={audio_file_from_base64._file_size}")
        
        return audio_file_from_base64, None
                    
    except Exception as e:
        logger.error(f"Error processing base64 audio: {str(e)}")
        return None, ({"error": f"Failed to process base64 audio: {str(e)}"}, 500)
