import logging
import hashlib
import hmac
import base64
import requests
import mimetypes
import random
import os
import tempfile
from Crypto.Cipher import AES

try:
    from mutagen import File as MutagenFile
    MUTAGEN_AVAILABLE = True
except ImportError:
    MUTAGEN_AVAILABLE = False


def download_and_decode_whatsapp_audio(url, media_key, mimetype="audio/ogg; codecs=opus", filename_prefix="whatsapp_audio"):
    """
    Download and decode WhatsApp encrypted audio file
    
    Args:
        url: WhatsApp .enc file URL
        media_key: Base64 encoded media key for decryption
        mimetype: MIME type of the audio file
        filename_prefix: Prefix for the generated filename
        
    Returns:
        tuple: (decoded_file_path, error_message)
        If successful: (file_path, None)
        If error: (None, error_message)
    """
    logger = logging.getLogger(__name__)
    
    try:
        logger.info(f"Downloading and decoding WhatsApp audio from: {url}")
        
        # Generate filename
        filename = f"{filename_prefix}_{random.getrandbits(64)}"
        file_extension = mimetypes.guess_extension(mimetype.split(';')[0]) or '.ogg'
        
        # Create temporary directories
        temp_dir = tempfile.mkdtemp()
        enc_file_path = os.path.join(temp_dir, f"{filename}.enc")
        decoded_file_path = os.path.join(temp_dir, f"{filename}{file_extension}")
        
        # Download .enc file
        response = requests.get(url, allow_redirects=True, timeout=30)
        response.raise_for_status()
        
        with open(enc_file_path, 'wb') as f:
            f.write(response.content)
        
        logger.info(f"Downloaded encrypted file to: {enc_file_path}")
        
        # Try to decode with Audio Keys first, then fallback to Document Keys
        decode_strategies = [
            ("WhatsApp Audio Keys", "audioMessage"),
            ("WhatsApp Document Keys", "documentMessage")
        ]
        
        decoded_success = False
        for message_type, strategy_name in decode_strategies:
            logger.info(f"Attempting to decode with: {message_type}")
            
            decoded_success = _decode_whatsapp_media(
                enc_file_path=enc_file_path,
                output_file_path=decoded_file_path,
                media_key=media_key,
                message_type=message_type
            )
            
            if decoded_success:
                # Validate the decoded audio file
                if _validate_audio_file(decoded_file_path):
                    logger.info(f"Successfully decoded and validated with: {message_type}")
                    break
                else:
                    logger.warning(f"Decoded file is invalid with {message_type}, trying next strategy")
                    decoded_success = False
                    # Remove invalid file
                    try:
                        os.unlink(decoded_file_path)
                    except:
                        pass
        
        if not decoded_success:
            return None, "Failed to decode WhatsApp audio file with any strategy"
        
        logger.info(f"Successfully decoded WhatsApp audio to: {decoded_file_path}")
        
        # Clean up encrypted file
        try:
            os.unlink(enc_file_path)
        except:
            pass
            
        return decoded_file_path, None
        
    except requests.RequestException as e:
        logger.error(f"Error downloading WhatsApp audio: {str(e)}")
        return None, f"Failed to download WhatsApp audio: {str(e)}"
    except Exception as e:
        logger.error(f"Error processing WhatsApp audio: {str(e)}")
        return None, f"Failed to process WhatsApp audio: {str(e)}"


def _decode_whatsapp_media(enc_file_path, output_file_path, media_key, message_type):
    """
    Internal function to decode WhatsApp encrypted media
    
    Args:
        enc_file_path: Path to the encrypted file
        output_file_path: Path where decoded file should be saved
        media_key: Base64 encoded media key
        message_type: Type of WhatsApp message for key derivation
        
    Returns:
        bool: True if successful, False otherwise
    """
    logger = logging.getLogger(__name__)
    
    try:
        def HKDF(key, length, app_info=b""):
            """HMAC-based Key Derivation Function"""
            key = hmac.new(b"\0" * 32, key, hashlib.sha256).digest()
            key_stream = b""
            key_block = b""
            block_index = 1
            while len(key_stream) < length:
                key_block = hmac.new(
                    key, 
                    msg=key_block + app_info + (chr(block_index).encode("utf-8")), 
                    digestmod=hashlib.sha256
                ).digest()
                block_index += 1
                key_stream += key_block
            return key_stream[:length]

        def aes_unpad(s):
            """Remove PKCS7 padding"""
            return s[:-ord(s[len(s)-1:])]

        def aes_decrypt(key, ciphertext, iv):
            """Decrypt using AES CBC mode"""
            cipher = AES.new(key, AES.MODE_CBC, iv)
            plaintext = cipher.decrypt(ciphertext)
            return aes_unpad(plaintext)

        # Expand the media key
        media_key_expanded = HKDF(
            base64.b64decode(media_key), 
            112, 
            bytes(message_type, encoding='utf-8')
        )

        # Read encrypted data
        with open(enc_file_path, "rb") as f:
            media_data = f.read()

        # Remove the last 10 bytes (MAC)
        file_data = media_data[:-10]

        # Decrypt the file
        file_data_decoded = aes_decrypt(
            media_key_expanded[16:48],  # AES key
            file_data, 
            media_key_expanded[:16]     # IV
        )

        # Write decoded data
        with open(output_file_path, 'wb') as f:
            f.write(file_data_decoded)

        logger.info(f"Successfully decoded media file: {output_file_path}")
        return True

    except Exception as e:
        logger.error(f"Error decoding WhatsApp media: {str(e)}")
        return False


def _validate_audio_file(file_path):
    """
    Validate if the decoded file is a valid audio file
    
    Args:
        file_path: Path to the file to validate
        
    Returns:
        bool: True if file is valid audio, False otherwise
    """
    logger = logging.getLogger(__name__)
    
    try:
        # Check if file exists and has content
        if not os.path.exists(file_path) or os.path.getsize(file_path) == 0:
            logger.warning(f"File does not exist or is empty: {file_path}")
            return False
        
        # If mutagen is available, use it for validation
        if MUTAGEN_AVAILABLE:
            try:
                audio_file = MutagenFile(file_path)
                if audio_file is not None:
                    logger.info(f"File validated as valid audio: {type(audio_file).__name__}")
                    return True
                else:
                    logger.warning(f"Mutagen could not identify file as audio: {file_path}")
                    return False
            except Exception as e:
                logger.warning(f"Mutagen validation failed: {str(e)}")
                return False
        else:
            # Basic validation - check file size and some basic audio signatures
            file_size = os.path.getsize(file_path)
            if file_size < 100:  # Too small to be a valid audio file
                logger.warning(f"File too small to be valid audio: {file_size} bytes")
                return False
            
            # Check for common audio file signatures
            with open(file_path, 'rb') as f:
                header = f.read(12)
                
            # Check for common audio signatures
            audio_signatures = [
                b'OggS',  # OGG
                b'ID3',   # MP3 with ID3
                b'\xff\xfb',  # MP3
                b'\xff\xfa',  # MP3
                b'\xff\xf3',  # MP3
                b'\xff\xf2',  # MP3
                b'fLaC',  # FLAC
                b'RIFF',  # WAV/WAVE
            ]
            
            for signature in audio_signatures:
                if header.startswith(signature):
                    logger.info(f"File appears to be valid audio based on signature: {signature}")
                    return True
            
            # If no signature matches, still consider it potentially valid
            logger.info("No audio signature detected but file has reasonable size")
            return True
            
    except Exception as e:
        logger.error(f"Error validating audio file: {str(e)}")
        return False


def is_whatsapp_encrypted_url(url):
    """
    Check if URL is a WhatsApp encrypted media URL
    
    Args:
        url: URL to check
        
    Returns:
        bool: True if it's a WhatsApp .enc URL
    """
    if not url:
        return False
    
    # Check for WhatsApp domain and .enc extension
    whatsapp_domains = [
        'mmg.whatsapp.net',
        'pps.whatsapp.net',
        'media.whatsapp.net'
    ]
    
    # Remove query parameters to check the actual file extension
    url_without_params = url.split('?')[0].lower()
    
    return (
        any(domain in url.lower() for domain in whatsapp_domains) and 
        url_without_params.endswith('.enc')
    )