"""
DISC Profiles Enum and Utilities
Módulo centralizado para gerenciar os perfis comportamentais DISC
"""

# DISC Profiles Enum
DISC_PROFILES = {
    "DOMINANCIA": {
        "id": 1,
        "name": "D - DOMINÂNCIA",
        "description": "Perfil executor. Pessoas orientadas à ação que querem ver o produto do trabalho. São ativas, objetivas e diretas."
    },
    "INFLUENCIA": {
        "id": 2,
        "name": "I - INFLUÊNCIA",
        "description": "Perfil comunicador. Pessoas confiantes e influentes, voltadas para relações interpessoais, com boa argumentação e persuasão."
    },
    "ESTABILIDADE": {
        "id": 3,
        "name": "E - ESTABILIDADE",
        "description": "Perfil planejador. Prezam pelo equilíbrio e harmonia, são prudentes, com pensamento estratégico e ótimos para planos de ação."
    },
    "CONFORMIDADE": {
        "id": 4,
        "name": "C - CONFORMIDADE",
        "description": "Perfil analista. Perfeccionistas, habilidosos e cautelosos. Ideais para analisar detalhes e fazer análises de risco."
    }
}


def get_disc_profiles():
    """
    Retorna o dicionário completo de perfis DISC
    
    Returns:
        dict: Dicionário com todos os perfis DISC disponíveis
    """
    return DISC_PROFILES


def get_disc_profile_by_name(profile_name: str):
    """
    Busca um perfil DISC pelo nome
    
    Args:
        profile_name: Nome do perfil (ex: "DOMINÂNCIA", "INFLUÊNCIA")
        
    Returns:
        dict: Dados do perfil ou dicionário vazio se não encontrado
    """
    if not profile_name:
        return {}
    
    # Normalizar para uppercase
    normalized_name = profile_name.upper().strip()
    return DISC_PROFILES.get(normalized_name, {})


def get_disc_profile_by_id(profile_id: int):
    """
    Busca um perfil DISC pelo ID
    
    Args:
        profile_id: ID do perfil (1-4)
        
    Returns:
        dict: Dados do perfil ou dicionário vazio se não encontrado
    """
    if not profile_id:
        return {}
    
    for profile_data in DISC_PROFILES.values():
        if profile_data.get("id") == profile_id:
            return profile_data
    
    return {}
