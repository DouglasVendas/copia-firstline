import os
import re
import json
import base64
import logging
from anthropic import Anthropic
from dotenv import load_dotenv

class DocumentExtractor:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        load_dotenv()
        
        # Initialize Anthropic client
        api_key = os.getenv('ANTHROPIC_API_KEY')
        if not api_key:
            self.logger.error("ANTHROPIC_API_KEY not found in environment variables")
            self.client = None
        else:
            self.client = Anthropic(api_key=api_key)
        
        # Load extraction prompt
        self.extraction_prompt = self._load_extraction_prompt()
    
    def _load_extraction_prompt(self):
        """Load the context extraction prompt from file"""
        try:
            with open('context_extraction_prompt.txt', 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            self.logger.error(f"Failed to load context_extraction_prompt.txt: {str(e)}")
            return None
    
    def _extract_json_from_response(self, text):
        """Extract JSON from AI response text"""
        json_match = re.search(r'\{.*\}', text, re.DOTALL)
        if json_match:
            return json_match.group(0)
        return None
    
    def extract_context_from_file(self, file):
        """
        Extract context information from uploaded file using AI
        
        Args:
            file: Uploaded file object
            
        Returns:
            dict: Extracted context data or None if extraction fails
        """
        try:
            # Check if client and prompt are available
            if not self.client:
                self.logger.error("Anthropic client not initialized")
                return None
            
            if not self.extraction_prompt:
                self.logger.error("Extraction prompt not loaded")
                return None
            
            # Get file extension
            file_extension = file.filename.lower().split('.')[-1] if '.' in file.filename else ''
            
            # Read file content
            file_content = file.read()
            file.seek(0)  # Reset file pointer
            
            # Handle different file types
            if file_extension == 'pdf':
                # PDF files - send as document
                base64_content = base64.b64encode(file_content).decode('utf-8')
                
                messages = [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "document",
                                "source": {
                                    "type": "base64",
                                    "media_type": "application/pdf",
                                    "data": base64_content
                                }
                            },
                            {
                                "type": "text",
                                "text": self.extraction_prompt
                            }
                        ]
                    }
                ]
                
                self.logger.info(f"Processing PDF file: {file.filename}")
                
            elif file_extension == 'txt':
                # Text files - send as text content
                try:
                    text_content = file_content.decode('utf-8')
                except UnicodeDecodeError:
                    try:
                        text_content = file_content.decode('latin-1')
                    except:
                        self.logger.error("Failed to decode text file")
                        return None
                
                messages = [
                    {
                        "role": "user",
                        "content": f"{self.extraction_prompt}\n\n=== CONTEÚDO DO ARQUIVO {file.filename.upper()} ===\n\n{text_content}"
                    }
                ]
                
                self.logger.info(f"Processing text file: {file.filename}")
                
            else:
                self.logger.error(f"Unsupported file type: {file_extension}")
                return None
            
            # Call Anthropic API
            response = self.client.messages.create(
                model="claude-3-7-sonnet-20250219",
                system="Você é um especialista em análise de documentos comerciais. Analise o documento e extraia as informações solicitadas retornando apenas o JSON estruturado.",
                messages=messages,
                temperature=0.3,
                max_tokens=4000
            )
            
            extraction_result = response.content[0].text
            self.logger.info(f"AI extraction completed, response length: {len(extraction_result)}")
            
            # Extract JSON from response
            json_str = self._extract_json_from_response(extraction_result)
            if not json_str:
                self.logger.error("No valid JSON found in AI response")
                return None
            
            # Parse extracted JSON
            try:
                extracted_data = json.loads(json_str)
                self.logger.info("Successfully extracted context data from file")
                return extracted_data
            except json.JSONDecodeError as e:
                self.logger.error(f"Failed to parse extracted JSON: {e}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error extracting context from file: {e}")
            return None