import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os

class EmailService:
    """Serviço centralizado para envio de emails"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.smtp_server = os.getenv('SMTP_SERVER')
        self.smtp_port = int(os.getenv('SMTP_PORT', 587))
        self.smtp_user = os.getenv('SMTP_USER')
        self.smtp_password = os.getenv('SMTP_PASSWORD')
        
    def _send_email(self, to_email, subject, body_html, body_text=None):
        """
        Método base para envio de emails
        
        Args:
            to_email (str): Email do destinatário
            subject (str): Assunto do email
            body_html (str): Corpo do email em HTML
            body_text (str, optional): Corpo do email em texto plano
            
        Returns:
            bool: True se enviado com sucesso, False caso contrário
        """
        try:
            msg = MIMEMultipart('alternative')
            msg['From'] = self.smtp_user
            msg['To'] = to_email
            msg['Subject'] = subject
            
            # Adicionar versão em texto plano se fornecida
            if body_text:
                msg.attach(MIMEText(body_text, 'plain'))
            
            # Adicionar versão HTML
            msg.attach(MIMEText(body_html, 'html'))
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_password)
                server.send_message(msg)
            
            self.logger.info(f"Email sent successfully to {to_email}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error sending email to {to_email}: {e}")
            return False
    
    def send_password_reset_email(self, email, token):
        """
        Envia email de redefinição de senha
        
        Args:
            email (str): Email do usuário
            token (str): Token de redefinição
            
        Returns:
            bool: True se enviado com sucesso, False caso contrário
        """
        reset_link = f"https://app.firstlineai.com.br/redefinir-senha?token={token}"
        
        subject = "Redefinição de Senha - FirstLine AI"
        
        body_html = f"""
        <html>
          <body>
            <p>Olá,</p>
            <p>Recebemos uma solicitação para redefinir sua senha.</p>
            <p>Para continuar com a redefinição, clique no link abaixo:</p>
            <p><a href="{reset_link}">Redefinir minha senha</a></p>
            <p>Se você não solicitou a redefinição de senha, ignore este e-mail.</p>
            <p>O link expirará em 1 hora.</p>
            <br>
            <p>Atenciosamente,</p>
            <p>Equipe FirstLine AI</p>
          </body>
        </html>
        """
        
        body_text = f"""
        Olá,
        
        Recebemos uma solicitação para redefinir sua senha.
        
        Para continuar com a redefinição, acesse o link abaixo:
        {reset_link}
        
        Se você não solicitou a redefinição de senha, ignore este e-mail.
        O link expirará em 1 hora.
        
        Atenciosamente,
        Equipe FirstLine AI
        """
        
        return self._send_email(email, subject, body_html, body_text)
    
    def send_2fa_code_email(self, email, code):
        """
        Envia email com código 2FA
        
        Args:
            email (str): Email do usuário
            code (str): Código de 6 dígitos
            
        Returns:
            bool: True se enviado com sucesso, False caso contrário
        """
        # Adicionar espaço no meio do código para facilitar a leitura
        code_with_space = f"{code[:3]} {code[3:]}"
        
        subject = "Código de Verificação - FirstLine AI"
        
        body_html = f"""
        <html>
          <body>
            <p>Olá,</p>
            <p>Seu código de verificação para login é:</p>
            <h2 style="font-size: 32px; color: #007bff; text-align: center; padding: 20px; background-color: #f8f9fa; border-radius: 8px; margin: 20px 0;">{code_with_space}</h2>
            <p>Este código expira em 10 minutos.</p>
            <p>Se você não solicitou este código, ignore este e-mail.</p>
            <br>
            <p>Atenciosamente,</p>
            <p>Equipe FirstLine AI</p>
          </body>
        </html>
        """
        
        body_text = f"""
        Olá,
        
        Seu código de verificação para login é: {code_with_space}
        
        Este código expira em 10 minutos.
        Se você não solicitou este código, ignore este e-mail.
        
        Atenciosamente,
        Equipe FirstLine AI
        """
        
        return self._send_email(email, subject, body_html, body_text)
    
    def send_registration_token_email(self, email, token, subscription_plan=None):
        """
        Envia email com token de registro após pagamento
        
        Args:
            email (str): Email do cliente
            token (str): Token de registro único
            subscription_plan (str, optional): Plano de assinatura escolhido
            
        Returns:
            bool: True se enviado com sucesso, False caso contrário
        """
        registration_link = f"https://app.firstlineai.com.br/register?token={token}"
        
        plan_text = f" para o plano {subscription_plan}" if subscription_plan else ""
        
        subject = "Complete seu Registro - FirstLine AI"
        
        body_html = f"""
        <html>
          <body>
            <p>Olá,</p>
            <p>Obrigado por sua compra{plan_text}!</p>
            <p>Para concluir seu registro e acessar nossa plataforma, clique no link abaixo:</p>
            <p><a href="{registration_link}" style="background-color: #007bff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">Completar Registro</a></p>
            <p>Este link é válido por 24 horas e pode ser usado apenas uma vez.</p>
            <p>Se você não realizou esta compra, entre em contato conosco imediatamente.</p>
            <br>
            <p>Bem-vindo à FirstLine AI!</p>
            <p>Equipe FirstLine AI</p>
          </body>
        </html>
        """
        
        body_text = f"""
        Olá,
        
        Obrigado por sua compra{plan_text}!
        
        Para concluir seu registro e acessar nossa plataforma, acesse o link abaixo:
        {registration_link}
        
        Este link é válido por 24 horas e pode ser usado apenas uma vez.
        Se você não realizou esta compra, entre em contato conosco imediatamente.
        
        Bem-vindo à FirstLine AI!
        Equipe FirstLine AI
        """
        
        return self._send_email(email, subject, body_html, body_text)
    
    def send_welcome_email(self, email, user_name):
        """
        Envia email de boas-vindas após registro completo
        
        Args:
            email (str): Email do usuário
            user_name (str): Nome do usuário
            
        Returns:
            bool: True se enviado com sucesso, False caso contrário
        """
        subject = "Bem-vindo à FirstLine AI!"
        
        body_html = f"""
        <html>
          <body>
            <p>Olá {user_name},</p>
            <p>Seu registro foi concluído com sucesso!</p>
            <p>Agora você pode acessar todos os recursos da nossa plataforma:</p>
            <ul>
              <li>Análise de conversas</li>
              <li>Relatórios detalhados</li>
              <li>Gerenciamento de vendedores</li>
              <li>E muito mais!</li>
            </ul>
            <p><a href="https://app.firstlineai.com.br/auth" style="background-color: #28a745; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">Acessar Plataforma</a></p>
            <p>Se precisar de ajuda, nossa equipe de suporte está sempre disponível.</p>
            <br>
            <p>Mais uma vez, bem-vindo!</p>
            <p>Equipe FirstLine AI</p>
          </body>
        </html>
        """
        
        body_text = f"""
        Olá {user_name},
        
        Seu registro foi concluído com sucesso!
        
        Agora você pode acessar todos os recursos da nossa plataforma:
        - Análise de conversas
        - Relatórios detalhados
        - Gerenciamento de vendedores
        - E muito mais!
        
        Acesse a plataforma em: https://app.firstlineai.com.br/auth
        
        Se precisar de ajuda, nossa equipe de suporte está sempre disponível.
        
        Mais uma vez, bem-vindo!
        Equipe FirstLine AI
        """
        
        return self._send_email(email, subject, body_html, body_text)
