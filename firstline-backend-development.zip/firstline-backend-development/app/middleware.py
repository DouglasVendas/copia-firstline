from flask import request, jsonify
import logging
import traceback
import os
import json
from functools import wraps
from flask_jwt_extended import verify_jwt_in_request, get_jwt, get_jwt_identity
from app.models.auth import AuthModel
from app.config import Config

def error_handler(app):
    """
    Global error handler middleware to catch unhandled exceptions
    """
    logger = logging.getLogger(__name__)
    
    @app.errorhandler(Exception)
    def handle_exception(e):
        logger.error(f"Unhandled exception: {str(e)}")
        logger.error(f"Exception type: {type(e).__name__}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        
        # Return JSON response instead of letting Flask crash
        return jsonify({
            "error": "Internal server error",
            "message": str(e),
            "type": type(e).__name__
        }), 500
    
    @app.errorhandler(500)
    def handle_500(e):
        logger.error(f"500 error: {str(e)}")
        return jsonify({"error": "Internal server error"}), 500
    
    @app.errorhandler(413)
    def handle_413(e):
        logger.error(f"413 error - File too large: {str(e)}")
        return jsonify({"error": "File too large"}), 413
    
    @app.errorhandler(MemoryError)
    def handle_memory_error(e):
        logger.error(f"Memory error: {str(e)}")
        return jsonify({"error": "Memory error - file too large"}), 413

def token_version_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        claims = get_jwt()
        user_id = get_jwt_identity()
        token_version = claims.get('token_version')
        auth_model = AuthModel()
        user_data = auth_model.me(user_id)
        if not user_data or not user_data['user'] or user_data['user'].get('token_version') != token_version:
            return jsonify({'success': False, 'error': 'Token inválido'}), 401
        return fn(*args, **kwargs)
    return wrapper

def refresh_token_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request(refresh=True)
        claims = get_jwt()
        user_id = get_jwt_identity()
        token_version = claims.get('token_version')
        auth_model = AuthModel()
        user_data = auth_model.me(user_id)
        if not user_data or not user_data['user'] or user_data['user'].get('token_version') != token_version:
            return jsonify({'success': False, 'error': 'Token inválido'}), 401
        
        # TODO: Quando Redis estiver disponível, verificar blacklist
        # jti = claims.get('jti')
        # if jti and is_token_blacklisted(jti):
        #     return jsonify({'success': False, 'error': 'Token inválido'}), 401
        
        return fn(*args, **kwargs)
    return wrapper

def role_required(required_roles: list):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            claims = get_jwt()
            user_plan = claims.get('plan')
            if user_plan not in required_roles:
                return jsonify({'success': False, 'error': 'Access denied. Insufficient permissions.'}), 403
            return fn(*args, **kwargs)
    return decorator
