import logging
from flask import request, jsonify, abort, send_file
from app.models.analyze_manager import AnalyzeManager
import uuid
from flask_jwt_extended import get_jwt_identity
from app.config import Config
import pandas as pd
import io
from datetime import datetime
from sqlalchemy import text
from app.models.db_model import create_db_engine

class AnalyzeManagerController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.analyze_manager = AnalyzeManager()

    def get_analyzes(self):
        """GET /analyses - Get all analyzes with filtering and pagination"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            # Get query parameters
            limit = request.args.get('limit', 50, type=int)
            offset = request.args.get('offset', 0, type=int)
            vendedor = request.args.get('vendedor')
            context_id = request.args.get('context_id')
            upload_type = request.args.get('upload_type')
            sort = request.args.get('sort', 'created_at')
            
            # Validate parameters
            if limit > 100:
                limit = 100
            if limit < 1:
                limit = 1
            if offset < 0:
                offset = 0
            
            if upload_type and upload_type not in ['audio', 'text']:
                return jsonify({
                    "success": False,
                    "error": "Invalid upload_type. Must be 'audio' or 'text'"
                }), 400
            
            if context_id and not self._is_valid_uuid(context_id):
                return jsonify({
                    "success": False,
                    "error": "Invalid context_id format"
                }), 400
            
            # Get analyzes from model
            result = self.analyze_manager.get_analyzes(
                user_id=user_id,
                limit=limit,
                offset=offset,
                vendedor=vendedor,
                context_id=context_id,
                upload_type=upload_type,
                sort=sort
            )
            
            if result is None:
                return jsonify({
                    "success": False,
                    "error": "Internal server error"
                }), 500
            
            # Get scores by seller
            scores = self.analyze_manager.get_scores_by_seller(user_id)
            if scores is None:
                scores = []
            
            return jsonify({
                "success": True,
                "data": result['analyzes'],
                "pagination": result['pagination'],
                "scores": scores
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_analyzes: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def get_analyze(self, analyze_id):
        """GET /analyses/:id - Get specific analysis"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            if not self._is_valid_uuid(analyze_id):
                return jsonify({
                    "success": False,
                    "error": "Invalid analyze_id format"
                }), 400
            
            # Get analyze from model
            analyze = self.analyze_manager.get_analyze(analyze_id, user_id)
            
            if analyze is None:
                # Check if analyze exists but doesn't belong to user
                analyze_exists = self.analyze_manager.get_analyze(analyze_id)
                if analyze_exists:
                    return jsonify({
                        "success": False,
                        "error": "Access denied - not your analysis"
                    }), 403
                else:
                    return jsonify({
                        "success": False,
                        "error": "Analysis not found"
                    }), 404
            
            # Get scores by seller
            scores = self.analyze_manager.get_scores_by_seller(user_id)
            if scores is None:
                scores = []
            
            return jsonify({
                "success": True,
                "data": analyze,
                "scores": scores
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_analyze: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def delete_analyze(self, analyze_id):
        """DELETE /analyses/:id - Delete specific analysis"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            if not self._is_valid_uuid(analyze_id):
                return jsonify({
                    "success": False,
                    "error": "Invalid analyze_id format"
                }), 400
            
            # Check if analyze exists and belongs to user
            analyze = self.analyze_manager.get_analyze(analyze_id, user_id)
            
            if analyze is None:
                # Check if analyze exists but doesn't belong to user
                analyze_exists = self.analyze_manager.get_analyze(analyze_id)
                if analyze_exists:
                    return jsonify({
                        "success": False,
                        "error": "Access denied - not your analysis"
                    }), 403
                else:
                    return jsonify({
                        "success": False,
                        "error": "Analysis not found"
                    }), 404
            
            # Delete analyze
            deleted = self.analyze_manager.delete_analyze(analyze_id, user_id)
            
            if not deleted:
                return jsonify({
                    "success": False,
                    "error": "Failed to delete analysis"
                }), 500
            
            return jsonify({
                "success": True,
                "message": "Analysis deleted successfully",
                "deleted_id": analyze_id
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in delete_analyze: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def update_analyze(self, analyze_id):
        """PUT /analyses/:id - Update specific analysis"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            if not self._is_valid_uuid(analyze_id):
                return jsonify({
                    "success": False,
                    "error": "Invalid analyze_id format"
                }), 400
            
            # Parse request body
            data = request.get_json()
            if not data:
                return jsonify({
                    "success": False,
                    "error": "Request body is required"
                }), 400
            
            # Validate at least one field is provided
            allowed_fields = {
                'client_name', 'vendedor', 'resumo', 'score_geral',
                'pontos_positivos', 'pontos_atencao', 'objecoes_identificadas',
                'sugestoes_melhoria', 'proximos_passos', 'framework_analysis',
                'coaching_insights', 'performance_analysis', 'mental_triggers',
                'reformulacoes_pnl', 'plano_fechamento', 'ia_preditiva',
                'analysis_name'
            }
            
            updates = {k: v for k, v in data.items() if k in allowed_fields}
            
            if not updates:
                return jsonify({
                    "success": False,
                    "error": "No valid fields provided for update"
                }), 400
            
            # Validate specific field types
            if 'score_geral' in updates:
                try:
                    score = float(updates['score_geral'])
                    if score < 0 or score > 10:
                        return jsonify({
                            "success": False,
                            "error": "score_geral must be between 0 and 10"
                        }), 400
                    updates['score_geral'] = score
                except (ValueError, TypeError):
                    return jsonify({
                        "success": False,
                        "error": "score_geral must be a valid number"
                    }), 400
            
            # Update analyze
            updated_analyze = self.analyze_manager.update_analyze(analyze_id, user_id, updates)
            
            if updated_analyze is None:
                # Check if analyze exists but doesn't belong to user
                analyze_exists = self.analyze_manager.get_analyze(analyze_id)
                if analyze_exists:
                    return jsonify({
                        "success": False,
                        "error": "Access denied - not your analysis"
                    }), 403
                else:
                    return jsonify({
                        "success": False,
                        "error": "Analysis not found"
                    }), 404
            
            return jsonify({
                "success": True,
                "message": "Analysis updated successfully",
                "data": updated_analyze
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in update_analyze: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def get_analyze_stats(self):
        """GET /analyses/stats - Get statistics about analyzes"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            # Get stats from model
            stats = self.analyze_manager.get_analyze_stats(user_id)
            
            if stats is None:
                return jsonify({
                    "success": False,
                    "error": "Internal server error"
                }), 500
            
            return jsonify(stats), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_analyze_stats: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def cleanup_old_analyzes(self):
        """DELETE /analyses/cleanup - Delete old analyzes"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            # Parse request body
            data = request.get_json()
            if not data or 'older_than' not in data:
                return jsonify({
                    "success": False,
                    "error": "older_than date is required"
                }), 400
            
            older_than_date = data['older_than']
            
            # Validate date format (ISO format expected)
            try:
                datetime.fromisoformat(older_than_date.replace('Z', '+00:00'))
            except ValueError:
                return jsonify({
                    "success": False,
                    "error": "Invalid date format. Use ISO format (YYYY-MM-DDTHH:MM:SS.sssZ)"
                }), 400
            
            # Cleanup old analyzes
            result = self.analyze_manager.cleanup_old_analyzes(older_than_date, user_id)
            
            if result is None:
                return jsonify({
                    "success": False,
                    "error": "Internal server error"
                }), 500
            
            return jsonify({
                "success": True,
                "message": "Cleanup successful",
                "deleted_count": result['deleted_count']
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in cleanup_old_analyzes: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500
        
    def get_dashboard_view(self):
        """GET /analyses/dashboard-view - Get dashboard view data"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            # Get dashboard data from model
            dashboard_data = self.analyze_manager.get_dashboard_view(user_id)
            
            if dashboard_data is None:
                return jsonify({
                    "success": False,
                    "error": "Internal server error"
                }), 500
            
            return jsonify({
                "success": True,
                "data": dashboard_data
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_dashboard_view: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500
        
    def get_ranking(self):
        """GET /analyses/ranking - Get user ranking based on analyze scores"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            # Get ranking data from model
            ranking_data = self.analyze_manager.get_ranking(user_id)
            
            if ranking_data is None:
                return jsonify({
                    "success": False,
                    "error": "Internal server error"
                }), 500
            
            return jsonify({
                "success": True,
                "data": ranking_data
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_ranking: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def get_latest(self):
        """GET /analyses/latest/ - Get the latest analyze and context"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401

            latest_data = self.analyze_manager.get_latest(user_id)

            if latest_data is None:
                return jsonify({
                    "success": False,
                    "error": "Nenhuma análise ou contexto encontrado"
                }), 404

            return jsonify({
                "success": True,
                "data": latest_data
            }), 200

        except Exception as e:
            self.logger.error(f"Error in get_latest: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def get_credits_remaining(self):
        """GET /analyses/credits-remaining/ - Get the remaining credits"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401

            credits_remaining = self.analyze_manager.get_credits_remaining(user_id)

            return jsonify({
                "success": True,
                "data": credits_remaining
            }), 200

        except Exception as e:
            self.logger.error(f"Error in get_credits_remaining: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def export_low_credit_users(self):
        """
        Retorna lista de usuários com 85%+ dos créditos usados no mês (ou [] se nenhum).
        """
        try:
            users = self.analyze_manager.get_users_with_low_credits()
            if users is None:
                return None
            return users
        except Exception as e:
            self.logger.error(f"Erro ao exportar usuários com créditos baixos: {e}")
            return None

    def export_low_credit_users_to_view(self):
        """
        Endpoint: /analyses/low-credit-users?token=SEU_TOKEN
        Valida token, gera Excel, retorna resposta HTTP.
        """
        token = request.args.get('token')
        secret_token = Config.SECRET_KEY
        if token != secret_token:
            return jsonify({"success": False, "message": "Token invalido"}), 401

        users = self.export_low_credit_users()
        if users is None:
            return jsonify({"success": False, "message": "Erro ao buscar dados."}), 500
        if not users:
            return jsonify({"success": False, "message": "Nenhum dado disponivel para exportacao."}), 404

        df = pd.DataFrame(users)
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Usuários com poucos créditos')
        output.seek(0)

        data_str = datetime.now().strftime('%Y-%m-%d')
        filename = f'usuarios_com_poucos_creditos_{data_str}.xlsx'

        return send_file(
            output,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            as_attachment=True,
            download_name=filename
        )

    def admin_get_user_analyzes(self, user_email):
        """GET /analyses/admin/<user_email> - Get all analyzes for a specific user. Available only for admin users."""
        try:
            admin_user_id = get_jwt_identity()
            if not admin_user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            # Buscar user_id pelo email
            target_user_id = self._get_user_id_by_email(user_email)
            if not target_user_id:
                return jsonify({
                    "success": False,
                    "error": "User not found"
                }), 404
            
            # Buscar análises do usuário usando a função existente
            result = self.analyze_manager.get_analyzes(
                user_id=target_user_id,
                limit=1000,  # Limite alto para pegar todas as análises
                offset=0
            )
            
            if result is None:
                return jsonify({
                    "success": False,
                    "error": "Internal server error"
                }), 500
            
            return jsonify({
                "success": True,
                "data": result['analyzes'],
                "pagination": result['pagination']
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in admin_get_user_analyzes: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def _get_user_id_by_email(self, email):
        """Busca o user_id pelo email na tabela de usuários"""
        try:
            engine = create_db_engine('DB_URI')
            with engine.connect() as conn:
                result = conn.execute(text("SELECT id FROM users WHERE email = :email"), {"email": email})
                row = result.fetchone()
                if row:
                    return row[0]
        except Exception as e:
            self.logger.error(f"Error getting user_id by email: {e}")
        return None

    def get_scores_by_seller(self):
        """GET /analyses/scores - Get scores grouped by seller"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    "success": False,
                    "error": "User ID required"
                }), 401
            
            result = self.analyze_manager.get_scores_by_seller(user_id)
            
            if result is None:
                return jsonify({
                    "success": False,
                    "error": "Failed to get scores"
                }), 500
            
            return jsonify(result), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_scores_by_seller: {e}")
            return jsonify({
                "success": False,
                "error": "Internal server error"
            }), 500

    def _is_valid_uuid(self, uuid_string):
        """Validate UUID format"""
        try:
            uuid.UUID(uuid_string)
            return True
        except ValueError:
            return False