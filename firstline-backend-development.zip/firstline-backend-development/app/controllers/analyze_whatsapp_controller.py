import logging
import traceback
from flask import request, jsonify
from app.errors import ValidationError, NotFoundError
from app.models.analyze_whatsapp import AnalyzeWhatsapp
from flask_jwt_extended import get_jwt_identity

class AnalyzeWhatsappController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.whatsapp_analyzer = AnalyzeWhatsapp()

    def analyze_whatsapp(self):
        """
        Process WhatsApp content with text and media files
        
        Required form parameters:
        - text_content: Extracted text content from .txt files
        - context_id: ID of the context for analysis
        - vendedor_id: UUID of the sales representative
        - analysis_name: Name for the analysis

        Optional form parameters:
        - files: Array of media files (mp3, jpg, png, etc.) with original names
        
        Returns:
        - JSON with analysis results or error message
        """
        try:
            # Log request info
            self.logger.info(f"Request form data: {request.form.to_dict()}")
            self.logger.info(f"Request files: {list(request.files.keys())}")

            # Extract form data
            text_content = request.form.get('text_content')
            context_id = request.form.get('context_id')
            vendedor_id = request.form.get('vendedor_id')
            analysis_name = request.form.get('analysis_name')
            user_id = get_jwt_identity()
            
            # Extract files
            files = request.files.getlist('files')
            
            # Validate required fields
            if not text_content:
                self.logger.warning("Missing text_content parameter")
                return jsonify({"error": "Text content is required"}), 400
                
            if not context_id:
                self.logger.warning("Missing context_id parameter")
                return jsonify({"error": "Context ID is required"}), 400
                
            if not vendedor_id:
                self.logger.warning("Missing vendedor_id parameter")
                return jsonify({"error": "Vendedor UUID is required"}), 400
                
            if not analysis_name:
                self.logger.warning("Missing analysis_name parameter")
                return jsonify({"error": "Analysis name is required"}), 400
                
            if not user_id:
                self.logger.warning("Missing user_id parameter (from JWT)")
                return jsonify({"error": "User ID is required"}), 400
            
            # Log request info
            files_info = []
            for file in files:
                if file.filename:
                    try:
                        # Get file size
                        file.seek(0, 2)
                        file_size = file.tell()
                        file.seek(0)
                        files_info.append({
                            "name": file.filename,
                            "size": file_size,
                            "content_type": file.content_type
                        })
                    except:
                        files_info.append({
                            "name": file.filename,
                            "size": "unknown",
                            "content_type": file.content_type
                        })
            
            self.logger.info(f"Processing WhatsApp analysis request: "
                           f"text_length={len(text_content)}, "
                           f"context={context_id}, "
                           f"user={user_id}, "
                           f"vendedor={vendedor_id}, "
                           f"analysis_name={analysis_name}, "
                           f"files_count={len(files)}, "
                           f"files_info={files_info}")
            
            # Process with the model
            result, status_code = self.whatsapp_analyzer.analyze_whatsapp(
                text_content, files, context_id, vendedor_id, user_id, analysis_name
            )
            
            return jsonify(result), status_code
            
        except ValidationError as e:
            self.logger.warning(f"Validation error: {str(e)}")
            return jsonify({"error": str(e)}), 400
            
        except NotFoundError as e:
            self.logger.warning(f"Not found error: {str(e)}")
            return jsonify({"error": str(e)}), 404
            
        except Exception as e:
            self.logger.error(f"Error in analyze_whatsapp endpoint: {str(e)}")
            self.logger.error(traceback.format_exc())
            return jsonify({"error": "Server error processing request"}), 500
