import logging
from flask import request, jsonify, Response
from app.models.profile import ProfileModel
from app.errors import ValidationError, NotFoundError
import magic
import re
import os
from flask_jwt_extended import get_jwt_identity

class ProfileController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.profile_model = ProfileModel()

    def get_profile(self) -> tuple[Response, int]:
        """GET /profile/<user_id> - Get user profile"""
        try:
            user_id = get_jwt_identity()
            
            profile = self.profile_model.get_profile(user_id)
            
            if not profile:
                self.logger.warning(f"Perfil não encontrado para user_id: {user_id}")
                return jsonify({"error": "Perfil não encontrado"}), 404

            return jsonify(profile), 200
            
        except Exception as e:
            self.logger.error(f"Erro ao obter perfil para user_id {user_id}: {e}")
            return jsonify({"error": "Internal server error"}), 500

    def update_profile(self) -> tuple[Response, int]:
        """PUT /profile/<user_id> - Update user profile"""
        try:
            user_id = get_jwt_identity()

            data = request.get_json()
            if not data:
                return jsonify({"error": "Dados não fornecidos"}), 400
            
            # Validar dados
            validation_errors = self._validate_profile_data(data)
            if validation_errors:
                return jsonify({
                    "error": "Falha na validação",
                    "details": validation_errors
                }), 400
            
            # Atualizar perfil
            updated_profile = self.profile_model.put_profile(user_id, data)
            
            if not updated_profile:
                self.logger.warning(f"Perfil não encontrado para user_id: {user_id}")
                return jsonify({"error": "Perfil não encontrado"}), 404

            return jsonify(updated_profile), 200
            
        except Exception as e:
            self.logger.error(f"Erro ao atualizar perfil para user_id {user_id}: {e}")
            return jsonify({"error": "Internal server error"}), 500
        
    def upload_picture(self) -> tuple[Response, int]:
        """POST /profile/upload/picture - Upload profile picture"""
        try:
            user_id = get_jwt_identity()
            
            if 'file' not in request.files:
                return jsonify({"error": "Nenhum arquivo fornecido"}), 400

            file = request.files['file']
            mime = magic.from_buffer(file.read(2048), mime=True)
            file.seek(0)

            extensao = os.path.splitext(file.filename)[1].lower()
            tipos_permitidos = {
                '.png': 'image/png',
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.svg': 'image/svg+xml',
                '.ico': 'image/x-icon',
                '.webp': 'image/webp'
            }

            if extensao not in tipos_permitidos or tipos_permitidos[extensao] != mime:
                return jsonify({"error": "extensão e MIME não correspondem"}), 400

            # Salvar a imagem e atualizar o perfil
            success = self.profile_model.upload_profile_picture(user_id, file, extensao)
            
            if not success:
                self.logger.warning(f"Erro ao salvar foto de perfil para user_id: {user_id}")
                return jsonify({"error": "Erro ao salvar foto de perfil"}), 500
  
            return self.get_picture()
                        
        except Exception as e:
            self.logger.error(f"Erro ao atualizar perfil para user_id {user_id}: {e}")
            return jsonify({"error": "Internal server error"}), 500

    def get_picture(self) -> tuple[Response, int]:
        """GET /profile/picture - Get profile picture using X-Accel-Redirect"""
        try:
            user_id = get_jwt_identity()
            
            # Verificar se o usuário tem foto de perfil
            file_path = self.profile_model.get_profile_picture_path(user_id)
            
            if not file_path:
                self.logger.warning(f"Foto de perfil não encontrada para user_id: {user_id}")
                return jsonify({"error": "Foto de perfil não encontrada"}), 404
            
            # Usar X-Accel-Redirect para que o Nginx sirva o arquivo
            # O Nginx precisa ter uma localização interna configurada
            response = jsonify({})
            response.headers['X-Accel-Redirect'] = file_path
            response.headers['Content-Type'] = 'image/jpeg'
            
            return response, 200
            
        except Exception as e:
            self.logger.error(f"Erro ao obter foto de perfil para user_id {user_id}: {e}")
            return jsonify({"error": "Internal server error"}), 500

    def _validate_profile_data(self, data):
        """Validate profile data fields"""
        errors = []
        
        # Validar CNPJ
        if 'cnpj' in data:
            if not self._validate_cnpj(data['cnpj']):
                errors.append({
                    "field": "cnpj",
                    "message": "CNPJ format is invalid"
                })
        
        # Validar email
        if 'contact_email' in data:
            if not self._validate_email(data['contact_email']):
                errors.append({
                    "field": "contact_email",
                    "message": "Email format is invalid"
                })
        
        # Validar telefone (opcional - formato brasileiro)
        if 'phone' in data:
            if not self._validate_phone(data['phone']):
                errors.append({
                    "field": "phone",
                    "message": "Phone format is invalid"
                })
        
        return errors

    def _validate_cnpj(self, cnpj) -> bool:
        """Validate CNPJ format"""
        if not cnpj:
            return True # CNPJ não é obrigatório
        
        # Remove formatação
        cnpj = re.sub(r'[^\d]', '', cnpj)
        
        # Verificar se tem 14 dígitos
        if len(cnpj) != 14:
            return False
        
        # Verificar se todos os dígitos são iguais
        if cnpj == cnpj[0] * 14:
            return False
        
        # Validar dígitos verificadores
        def calculate_digit(cnpj, weights):
            total = sum(int(digit) * weight for digit, weight in zip(cnpj, weights))
            remainder = total % 11
            return 0 if remainder < 2 else 11 - remainder
        
        weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
        
        first_digit = calculate_digit(cnpj[:12], weights1)
        second_digit = calculate_digit(cnpj[:13], weights2)
        
        return cnpj[12] == str(first_digit) and cnpj[13] == str(second_digit)

    def _validate_email(self, email) -> bool:
        """Validate email format"""
        if not email:
            return False
        
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(email_pattern, email) is not None

    def _validate_phone(self, phone) -> bool:
        """Validate phone format - more permissive"""
        if not phone:
            return True # Telefone não é obrigatório
        
        # Remove formatação
        phone_clean = re.sub(r'[^\d]', '', phone)
        
        # Verificar se tem pelo menos 8 dígitos e no máximo 15 (padrão internacional)
        if len(phone_clean) < 8 or len(phone_clean) > 15:
            return False
        
        # Aceitar qualquer formato que contenha apenas números, espaços, parênteses, hífens e o sinal +
        phone_pattern = r'^[\d\s\(\)\-\+]+$'
        return re.match(phone_pattern, phone) is not None