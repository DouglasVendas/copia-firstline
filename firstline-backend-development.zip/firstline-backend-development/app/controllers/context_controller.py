import logging
from flask import request, jsonify
from app.models.context import ContextModel
from flask_jwt_extended import get_jwt_identity

class ContextController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.context_model = ContextModel()

    def get_contexts(self):
        """GET /contexts - Get all contexts for user"""
        try:
            user_id = get_jwt_identity()
            self.logger.info(f"Getting contexts for user_id: {user_id}")
            
            contexts = self.context_model.get_contexts(user_id)
            
            if contexts is None:
                return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500
            
            return jsonify({
                "data": contexts,
                "total": len(contexts)
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error getting contexts for user_id {user_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500
        
    def get_active_context(self):
        """GET /contexts/active - Get active context for user"""
        try:
            user_id = get_jwt_identity()
            
            context = self.context_model.get_active_context(user_id)

            if context is None:
                return jsonify({
                    "error": "Nenhum contexto ativo",
                    "message": "Nenhum contexto ativo encontrado para o usuário"
                }), 404
            
            return jsonify({
                "data": context
            }), 200
        
        except Exception as e:
            self.logger.error(f"Error getting active context for user_id {user_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500

    def create_context(self):
        """POST /contexts - Create new context"""
        try:
            user_id = get_jwt_identity()
            self.logger.info(f"Creating context for user_id: {user_id}")
            
            data = request.get_json()
            if not data:
                return jsonify({
                    "error": "Campos obrigatórios",
                    "message": "Dados não fornecidos",
                    "details": {"missing_fields": ["data"]}
                }), 400
            
            if not data.get('name'):
                return jsonify({
                    "error": "Campos obrigatórios",
                    "message": "Nome é obrigatório",
                    "details": {"missing_fields": ["name"]}
                }), 400
            
            # Criar contexto
            context = self.context_model.create_context(user_id, data)
            
            if not context:
                return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500
            
            return jsonify({
                "data": context,
                "message": "Contexto criado com sucesso"
            }), 201
            
        except Exception as e:
            self.logger.error(f"Error creating context for user_id {user_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500

    def update_context(self, context_id):
        """PUT /contexts/:id - Update context"""
        try:
            user_id = get_jwt_identity()
            self.logger.info(f"Updating context {context_id} for user_id: {user_id}")
            
            data = request.get_json()
            if not data:
                return jsonify({
                    "error": "Campos obrigatórios",
                    "message": "Dados não fornecidos"
                }), 400
            
            if 'name' in data and not data['name']:
                return jsonify({
                    "error": "Campos obrigatórios",
                    "message": "Nome é obrigatório",
                    "details": {"missing_fields": ["name"]}
                }), 400
            
            # Atualizar contexto
            context = self.context_model.update_context(context_id, user_id, data)
            
            if not context:
                return jsonify({
                    "error": "Contexto não encontrado",
                    "message": "O contexto solicitado não existe"
                }), 404
            
            return jsonify({
                "data": context,
                "message": "Contexto atualizado com sucesso"
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error updating context {context_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500

    def delete_context(self, context_id):
        """DELETE /contexts/:id - Delete context"""
        try:
            user_id = get_jwt_identity()
            self.logger.info(f"Deleting context {context_id} for user_id: {user_id}")
            
            success = self.context_model.delete_context(context_id, user_id)
            
            if not success:
                return jsonify({
                    "error": "Contexto não encontrado",
                    "message": "O contexto solicitado não existe"
                }), 404
            
            return jsonify({
                "message": "Contexto removido com sucesso"
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error deleting context {context_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500

    def activate_context(self, context_id):
        """PUT /contexts/:id/activate - Activate context"""
        try:
            user_id = get_jwt_identity()
            self.logger.info(f"Activating context {context_id} for user_id: {user_id}")
            
            context = self.context_model.activate_context(context_id, user_id)
            
            if not context:
                return jsonify({
                    "error": "Contexto não encontrado",
                    "message": "O contexto solicitado não existe"
                }), 404
            
            return jsonify({
                "data": context,
                "message": "Contexto ativado com sucesso"
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error activating context {context_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500
        
    def create_context_from_file(self):
        """POST /contexts/create/from_file - Create context from uploaded file"""
        try:
            user_id = get_jwt_identity()
            self.logger.info(f"Creating context from file for user_id: {user_id}")

            context_name = request.form.get('name')
            context_description = request.form.get('description', '')
            if not context_name:
                return jsonify({
                    "error": "Campos obrigatórios",
                    "message": "Nome do contexto é obrigatório",
                    "details": {"missing_fields": ["name"]}
                }), 400
            
            if 'file' not in request.files:
                return jsonify({
                    "error": "Arquivo não fornecido",
                    "message": "Nenhum arquivo foi enviado"
                }), 400
            
            file = request.files['file']
            
            if file.filename == '':
                return jsonify({
                    "error": "Arquivo inválido",
                    "message": "Nenhum arquivo selecionado"
                }), 400
            
            # Validar tipos de arquivo permitidos
            allowed_extensions = {'.pdf', '.txt'}
            
            file_extension = file.filename.lower().split('.')[-1] if '.' in file.filename else ''
            file_extension_with_dot = f'.{file_extension}'
            
            if file_extension_with_dot not in allowed_extensions:
                return jsonify({
                    "error": "Tipo de arquivo não permitido",
                    "message": f"Apenas arquivos PDF e TXT são permitidos. Tipos aceitos: {', '.join(sorted(allowed_extensions))}"
                }), 400
            
            # Validar tamanho do arquivo (máximo 30MB)
            file.seek(0, 2)  # Move para o final do arquivo
            file_size = file.tell()  # Obtém o tamanho em bytes
            file.seek(0)  # Volta para o início do arquivo
            
            max_size = 30 * 1024 * 1024  # 30MB em bytes
            if file_size > max_size:
                return jsonify({
                    "error": "Arquivo muito grande",
                    "message": f"O arquivo deve ter no máximo 30MB. Tamanho atual: {file_size / (1024 * 1024):.2f}MB"
                }), 400
            
            # Criar contexto a partir do arquivo
            context = self.context_model.create_context_from_file(user_id, file, context_name, context_description)
            
            if not context:
                return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500
            
            return jsonify({
                "data": context,
                "message": "Contexto criado com sucesso a partir do arquivo"
            }), 201
            
        except Exception as e:
            self.logger.error(f"Error creating context from file for user_id {user_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500
