import logging
import traceback
from flask import request, jsonify
from app.models.analyze_text import TextAnalyzer
from app.errors import ValidationError, NotFoundError
from flask_jwt_extended import get_jwt_identity

class AnalyzeTextController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.text_analyzer = TextAnalyzer()

    def analyze_text(self):
        """
        Process text content, analyze with GPT and store results
        
        For JSON requests:
        - text: Text content to analyze
        - vendedor_id: ID of the seller performing the analysis  
        - analysis_name: Name for the analysis
        - context_id: ID of the context for analysis (optional)
        
        For form-data requests:
        - text: Text content as string OR text file (.txt) to analyze
        - vendedor_id: ID of the seller performing the analysis
        - analysis_name: Name for the analysis  
        - context_id: ID of the context for analysis (optional)

        Returns:
        - JSON with analysis results or error message
        """
        try:
            text_content = None
            
            # Handle JSON request
            if request.is_json:
                data = request.get_json()
                if not data:
                    self.logger.warning("Missing JSON body")
                    return jsonify({"error": "Missing request body"}), 400
                
                text_content = data.get('text')
                context_id = data.get('context_id')
                analysis_name = data.get('analysis_name')
                vendedor = data.get('vendedor_id')
                
            # Handle form-data request
            else:
                # Check if text is provided as string in form data
                text_content = request.form.get('text')
                
                # If no text string, check if text file is provided
                if not text_content and 'text' in request.files:
                    text_file = request.files['text']
                    if text_file.filename == '':
                        self.logger.warning("No file selected")
                        return jsonify({"error": "No file selected"}), 400
                    
                    # Validate file extension
                    if not text_file.filename.lower().endswith('.txt'):
                        self.logger.warning("Invalid file format")
                        return jsonify({"error": "Only .txt files are allowed"}), 400
                    
                    # Read file content
                    try:
                        text_content = text_file.read().decode('utf-8')
                    except UnicodeDecodeError:
                        self.logger.warning("Unable to decode file as UTF-8")
                        return jsonify({"error": "File must be valid UTF-8 text"}), 400
                
                # Get form parameters
                context_id = request.form.get('context_id')
                analysis_name = request.form.get('analysis_name')
                vendedor = request.form.get('vendedor_id')
            
            # Extract user from JWT
            user_id = get_jwt_identity()

            # Validate required fields
            if not text_content:
                self.logger.warning("Missing text content")
                return jsonify({"error": "Text content or text file is required"}), 400
                
            if not user_id:
                self.logger.warning("Missing user_id parameter (from JWT)")
                return jsonify({"error": "User ID is required"}), 400
                
            # Log request info
            content_type = "JSON" if request.is_json else "form-data"
            self.logger.info(f"Processing text analysis request: content_type={content_type}, text_length={len(text_content)}, context={context_id}, user={user_id}")
            
            # Process the text
            result, status_code = self.text_analyzer.analyze_text(text_content, context_id, user_id, analysis_name, vendedor)
            
            return jsonify(result), status_code
            
        except ValidationError as e:
            self.logger.warning(f"Validation error: {str(e)}")
            return jsonify({"error": str(e)}), 400
            
        except NotFoundError as e:
            self.logger.warning(f"Not found error: {str(e)}")
            return jsonify({"error": str(e)}), 404
            
        except Exception as e:
            self.logger.error(f"Error in analyze_text endpoint: {str(e)}")
            self.logger.error(traceback.format_exc())
            return jsonify({"error": "Server error processing request"}), 500