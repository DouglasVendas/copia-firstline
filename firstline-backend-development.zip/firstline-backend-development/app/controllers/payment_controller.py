import logging
from flask import request, jsonify
from app.models.payment import PaymentModel
from app.config import Config

class PaymentController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.payment_model = PaymentModel()
        self.greenn_webhook_secret = Config.GREENN_WEBHOOK_SECRET

    def process_payment(self):
        data = request.get_json()
        webhook_token = request.headers.get('X-Webhook-Token')
        # Verificar o token do webhook
        if webhook_token != self.greenn_webhook_secret:
            self.logger.warning("Invalid webhook token received")
            return jsonify({"message": "Invalid webhook token"}), 401
        
        if data['event'] == 'contractPaid':
            if data['currentStatus'] == 'paid':
                # Extrair dados do cliente
                customer_name = data['client']['name']
                customer_email = data['client']['email']
                customer_id = data['client']['id']
                payment_intent_id = data['contract']['id']
                product_id = data['product']['id']
                
                # Criar token de registro (o PaymentModel irá converter o Product ID para nome do plano)
                result = self.payment_model.create_registration_token(
                    customer_email=customer_email,
                    subscription_plan=product_id,
                    payment_intent_id=payment_intent_id,
                    customer_id=customer_id
                )
                
                if result.get('success'):
                    # Obter o nome do plano convertido do PaymentModel
                    plan_name = self.payment_model._get_plan_name_from_product_id(product_id)
                    self.logger.info(
                        f"Payment processed and registration token created for {customer_email}. "
                        f"Plan: {plan_name}, Token: {result['token']}"
                    )
                    return jsonify({
                        "message": "Payment processed successfully",
                        "customer_name": customer_name,
                        "customer_email": customer_email,
                        "subscription_plan": plan_name,
                        "registration_token_sent": True
                    }), 200
                else:
                    self.logger.error(
                        f"Payment processed but failed to create registration token for {customer_email}: "
                        f"{result.get('error')}"
                    )
                    return jsonify({
                        "message": "Payment processed but registration email failed",
                        "customer_name": customer_name,
                        "customer_email": customer_email,
                        "error": result.get('error')
                    }), 500
            else:
                return jsonify({"message": "Payment not successful"}), 400
        
        # Outros tipos de eventos podem ser tratados aqui no futuro
        return jsonify({"message": "Event received"}), 200