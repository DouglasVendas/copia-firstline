import logging
from flask import request, jsonify
from app.models.contact import ContactModel
import uuid
from flask_jwt_extended import get_jwt_identity

class ContactController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.contact_model = ContactModel()

    def get_contacts(self):
        """GET /contacts - Get all contacts with filtering and pagination"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            # Get query parameters
            page = request.args.get('page', 1, type=int)
            limit = request.args.get('limit', 20, type=int)
            contact_type = request.args.get('contact_type')
            search = request.args.get('search')
            
            # Validate parameters
            if page < 1:
                page = 1
            if limit < 1:
                limit = 1
            if limit > 100:
                limit = 100
            
            # Validate contact_type if provided
            if contact_type:
                valid_types = ['lead', 'cliente', 'prospect']
                if contact_type not in valid_types:
                    return jsonify({
                        "error": "Tipo de contato inválido",
                        "details": f"Deve ser um dos seguintes: {', '.join(valid_types)}"
                    }), 400
            
            # Get contacts from model
            result = self.contact_model.get_contacts(
                user_id=user_id,
                page=page,
                limit=limit,
                contact_type=contact_type,
                search=search
            )
            
            if result is None:
                return jsonify({"error": "Erro interno do servidor"}), 500
            
            return jsonify({
                "data": result['contacts'],
                "pagination": result['pagination']
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error getting contacts for user_id {user_id}: {e}")
            return jsonify({"error": "Erro interno do servidor", "message": "Ocorreu um erro inesperado"}), 500

    def create_contact(self, user_id):
        """POST /contacts - Create new contact"""
        try:
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            data = request.get_json()
            if not data:
                return jsonify({"error": "Dados não fornecidos"}), 400
            
            # Validate data
            validation_errors = self.contact_model.validate_contact_data(data)
            if validation_errors:
                return jsonify({
                    "error": "Dados inválidos",
                    "details": validation_errors
                }), 400
            
            # Create contact
            contact = self.contact_model.create_contact(user_id, data)
            
            if not contact:
                return jsonify({"error": "Erro ao criar contato"}), 500
            
            return jsonify({
                "data": contact,
                "message": "Contato criado com sucesso"
            }), 201
            
        except Exception as e:
            self.logger.error(f"Error in create_contact: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def get_contact(self, contact_id):
        """GET /contacts/:id - Get specific contact"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            if not self._is_valid_uuid(contact_id):
                return jsonify({"error": "ID de contato inválido"}), 400
            
            # Get contact from model
            contact = self.contact_model.get_contact_by_id(contact_id, user_id)
            
            if not contact:
                return jsonify({"error": "Contato não encontrado"}), 404
            
            return jsonify({"data": contact}), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_contact: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def update_contact(self, contact_id, user_id):
        """PUT /contacts/:id - Update contact"""
        try:
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            if not self._is_valid_uuid(contact_id):
                return jsonify({"error": "ID de contato inválido"}), 400
            
            data = request.get_json()
            if not data:
                return jsonify({"error": "Dados não fornecidos"}), 400
            
            # Validate data
            validation_errors = self.contact_model.validate_contact_data(data, is_update=True)
            if validation_errors:
                return jsonify({
                    "error": "Dados inválidos",
                    "details": validation_errors
                }), 400
            
            # Update contact
            contact = self.contact_model.update_contact(contact_id, user_id, data)
            
            if not contact:
                return jsonify({"error": "Contato não encontrado"}), 404
            
            return jsonify({
                "data": contact,
                "message": "Contato atualizado com sucesso"
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in update_contact: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def delete_contact(self, contact_id, user_id):
        """DELETE /contacts/:id - Delete contact"""
        try:
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            if not self._is_valid_uuid(contact_id):
                return jsonify({"error": "ID de contato inválido"}), 400
            
            # Delete contact
            deleted = self.contact_model.delete_contact(contact_id, user_id)
            
            if not deleted:
                return jsonify({"error": "Contato não encontrado"}), 404
            
            return jsonify({"message": "Contato deletado com sucesso"}), 200
            
        except Exception as e:
            self.logger.error(f"Error in delete_contact: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def _is_valid_uuid(self, uuid_string):
        """Validate UUID format"""
        try:
            uuid.UUID(uuid_string)
            return True
        except ValueError:
            return False
