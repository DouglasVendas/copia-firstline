import logging
import re
from flask import request, jsonify, make_response
from app.models.auth import AuthModel
from app.models.password_reset import PasswordResetModel
from app.models.two_fa import TwoFAModel
from app.config import Config
from app import limiter
from datetime import timedelta
from flask_jwt_extended import (create_access_token, create_refresh_token, get_jwt_identity,
                                get_jwt, set_access_cookies, set_refresh_cookies, unset_access_cookies,
                                unset_refresh_cookies, verify_jwt_in_request,  decode_token)
class AuthController:
    def __init__(self):
        self.auth_model = AuthModel()
        self.password_reset_model = PasswordResetModel()
        self.two_fa_model = TwoFAModel()
        self.logger = logging.getLogger(__name__)

    def _validate_email(self, email):
        """Validate email format"""
        if not email:
            return False
        
        # Regex pattern for email validation
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(email_pattern, email) is not None

    def _validate_password(self, password):
        """Validate password strength"""
        if not password:
            return False, "Senha é obrigatória"
        
        if len(password) < 8:
            return False, "Senha deve ter no mínimo 8 caracteres"
        
        return True, ""

    #@limiter.limit("5 per 15 minutes")
    def login(self):
        """Handle login POST request"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'JSON payload requerido'
                }), 400
            email = data.get('email').lower().strip()
            password = data.get('password')
            
            # Validate email format
            if not self._validate_email(email):
                return jsonify({
                    'success': False,
                    'error': 'Email deve ser válido'
                }), 400
            
            # Validate password presence
            if not password:
                return jsonify({
                    'success': False,
                    'error': 'Senha é obrigatória'
                }), 400
            
            # Authenticate user
            user, status_code = self.auth_model.login(email, password)

            if status_code != 200:
                return jsonify({
                    'success': False,
                    'error': user.get('error', 'Erro ao autenticar usuário')
                }), status_code

            # Verificar se o usuário tem 2FA habilitado
            if user.get('2fa_enabled'):
                # Criar código 2FA
                two_fa_result = self.two_fa_model.create_code(user.get('id'))
                
                if not two_fa_result or 'error' in two_fa_result:
                    return jsonify({
                        'success': False,
                        'error': two_fa_result.get('error', 'Erro ao enviar código 2FA')
                    }), two_fa_result.get('code', 500)
                
                return jsonify({
                    'success': True,
                    'data': {
                        'requires_2fa': True,
                        'message': 'Código 2FA enviado para o email',
                        'expires_at': two_fa_result.get('expires_at')
                    }
                }), status_code
            else:
                # Gerar access token e refresh token
                access_token = create_access_token(
                    identity=user.get('id') or user.get('email'),
                    additional_claims={'token_version': user.get('token_version'), 'plan': user.get('plan')},
                    expires_delta=Config.JWT_ACCESS_TOKEN_EXPIRES
                )
                
                refresh_token = create_refresh_token(
                    identity=user.get('id') or user.get('email'),
                    additional_claims={'token_version': user.get('token_version'), 'plan': user.get('plan')},
                    expires_delta=Config.JWT_REFRESH_TOKEN_EXPIRES
                )
                
                decoded = decode_token(access_token)
                exp = decoded.get('exp')
                
                # Remove o campo 'token_version' do dicionário user antes de retornar
                user_sanitized = dict(user) if user else {}
                user_sanitized.pop('token_version', None)
                user_sanitized.pop('2fa_enabled', None)
                
                # Criar resposta e definir cookies HTTP-only
                response = make_response(jsonify({
                    'success': True,
                    'data': {
                        'user': user_sanitized,
                        'exp': exp
                    }
                }))
                
                # Definir cookies HTTP-only seguros com max_age adequado e sem restrição de domínio
                set_access_cookies(response, access_token, max_age=Config.JWT_ACCESS_COOKIE_MAX_AGE, domain=None)
                set_refresh_cookies(response, refresh_token, max_age=Config.JWT_REFRESH_COOKIE_MAX_AGE, domain=None)
                
                return response, status_code
            
        except Exception as e:
            self.logger.error(f"Error in login: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def register(self):
        """Handle register POST request with registration token"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'JSON payload requerido'
                }), 400
            
            # Validate required fields
            required_fields = ['email', 'token', 'password', 'companyName', 'responsibleName', 'phone']
            for field in required_fields:
                if not data.get(field) or not data.get(field).strip():
                    return jsonify({
                        'success': False,
                        'error': f'Campo {field} é obrigatório'
                    }), 400
            
            email = data.get('email').lower().strip()
            token = data.get('token').strip()
            password = data.get('password')
            company_name = data.get('companyName').strip()
            responsible_name = data.get('responsibleName').strip()
            phone = data.get('phone').strip()
            cnpj = data.get('cnpj', '').strip() if data.get('cnpj') else None

            # Validate email format
            if not self._validate_email(email):
                return jsonify({
                    'success': False,
                    'error': 'Email deve ser válido'
                }), 400
            
            # Validate password strength
            password_valid, password_error = self._validate_password(password)
            if not password_valid:
                return jsonify({
                    'success': False,
                    'error': password_error
                }), 400
            
            # Register user with token
            result = self.auth_model.register(
                email=email,
                token=token,
                password=password,
                company_name=company_name,
                responsible_name=responsible_name,
                phone=phone,
                cnpj=cnpj
            )
            
            if not result:
                return jsonify({
                    'success': False,
                    'error': 'Erro interno do servidor'
                }), 500
            
            # Check if there was an error in registration
            if 'error' in result:
                return jsonify({
                    'success': False,
                    'error': result['error']
                }), result['code']
            
            response = make_response(jsonify({
                'success': True,
                'data': result
            }))

            # Limpar todos os cookies JWT para, ao redirecionar para o login, não redirecionar para o dashboard
            unset_access_cookies(response)
            unset_refresh_cookies(response)

            return response
            
        except Exception as e:
            self.logger.error(f"Error in register: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def logout(self):
        """Handle logout POST request"""
        try:
            # TODO: Quando Redis estiver disponível, adicionar tokens à blacklist
            # claims = get_jwt()
            # jti = claims.get('jti')
            # token_type = claims.get('type', 'access')
            # 
            # # Adicionar token atual à blacklist
            # if jti:
            #     remaining_time = claims.get('exp') - time.time()
            #     if remaining_time > 0:
            #         blacklist_token(jti, remaining_time)
            #
            # # Se for um access token, cliente deve também invalidar o refresh token
            # # Se for um refresh token, apenas este vai para blacklist
            
            # Criar resposta e limpar cookies HTTP-only
            response = make_response(jsonify({
                'success': True,
                'message': 'Logout realizado com sucesso'
            }))
            
            # Limpar todos os cookies JWT
            unset_access_cookies(response)
            unset_refresh_cookies(response)
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error in logout: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def me(self):
        """Handle user profile GET request"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    'success': False,
                    'error': 'ID do usuário é obrigatório'
                }), 400
            # Get user and profile data
            user_data = self.auth_model.me(user_id)
            if not user_data:
                return jsonify({
                    'success': False,
                    'error': 'Usuário não encontrado'
                }), 404
            return jsonify({
                'success': True,
                'data': user_data
            })
        except Exception as e:
            self.logger.error(f"Error in me: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def request_password_reset(self):
        """Handle password reset request"""
        try:
            data = request.get_json()
            
            if not data or not data.get('email'):
                return jsonify({
                    'success': False,
                    'error': 'Email é obrigatório'
                }), 400
            
            email = data.get('email').strip()
            
            # Validate email format
            if not self._validate_email(email):
                return jsonify({
                    'success': False,
                    'error': 'Email deve ser válido'
                }), 400
            
            # Request password reset
            result = self.password_reset_model.request_reset(email)
            
            # Always return success for security
            return jsonify({
                'success': True,
                'message': 'Enviamos um email com as instruções para redefinição de senha'
            })
            
        except Exception as e:
            self.logger.error(f"Error in password reset request: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def validate_reset_token(self):
        """Handle password reset token validation"""
        try:
            token = request.args.get('token')
            
            if not token:
                return jsonify({
                    'valid': False,
                    'reason': 'Token não fornecido'
                }), 400
            
            result = self.password_reset_model.validate_token(token)
            return jsonify(result)
            
        except Exception as e:
            self.logger.error(f"Error in token validation: {e}")
            return jsonify({
                'valid': False,
                'reason': 'Erro interno do servidor'
            }), 500

    def confirm_password_reset(self):
        """Handle password reset confirmation"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'JSON payload requerido'
                }), 400
            
            token = data.get('token')
            new_password = data.get('new_password')
            
            # Validate required fields
            if not token or not new_password:
                return jsonify({
                    'success': False,
                    'error': 'Token e nova senha são obrigatórios'
                }), 400
            
            # Validate password strength
            password_valid, password_error = self._validate_password(new_password)
            if not password_valid:
                return jsonify({
                    'success': False,
                    'error': password_error
                }), 400
            
            # Confirm password reset
            result = self.password_reset_model.confirm_reset(token, new_password)
            
            if not result['success']:
                return jsonify({
                    'success': False,
                    'error': result['error']
                }), 400
            
            return jsonify({
                'success': True,
                'message': result['message']
            })
            
        except Exception as e:
            self.logger.error(f"Error in password reset confirmation: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    @limiter.limit("5 per 10 minutes")
    def verify_2fa(self):
        """Handle 2FA verification"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'JSON payload requerido'
                }), 400
            
            email = data.get('email')
            code = data.get('code')
            
            if not email or not code:
                return jsonify({
                    'success': False,
                    'error': 'Email e código são obrigatórios'
                }), 400
            
            # Verificar código 2FA
            result = self.two_fa_model.verify_code(email, code)
            
            if not result:
                return jsonify({
                    'success': False,
                    'error': 'Erro interno do servidor'
                }), 500
            
            if not result.get('valid'):
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'Código inválido')
                }), 400
            
            # Buscar dados do usuário para gerar o token
            user_id = result.get('user_id')
            user_data = self.auth_model.me(user_id)
            if not user_data:
                return jsonify({
                    'success': False,
                    'error': 'Usuário não encontrado'
                }), 404
            
            # Gerar access token e refresh token
            access_token = create_access_token(
                identity=user_id,
                additional_claims={'token_version': user_data['user'].get('token_version')},
                expires_delta=Config.JWT_ACCESS_TOKEN_EXPIRES
            )
            
            refresh_token = create_refresh_token(
                identity=user_id,
                additional_claims={'token_version': user_data['user'].get('token_version')},
                expires_delta=Config.JWT_REFRESH_TOKEN_EXPIRES
            )
            
            decoded = decode_token(access_token)
            exp = decoded.get('exp')
            
            # Criar resposta e definir cookies HTTP-only
            response = make_response(jsonify({
                'success': True,
                'data': {
                    'user': user_data['user'],
                    'profile': user_data['profile'],
                    'exp': exp
                }
            }))
            
            # Definir cookies HTTP-only seguros com max_age adequado e sem restrição de domínio
            set_access_cookies(response, access_token, max_age=Config.JWT_ACCESS_COOKIE_MAX_AGE, domain=None)
            set_refresh_cookies(response, refresh_token, max_age=Config.JWT_REFRESH_COOKIE_MAX_AGE, domain=None)
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error in 2FA verification: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    @limiter.limit("3 per 10 minutes")
    def resend_2fa(self):
        """Handle 2FA code resend"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'JSON payload requerido'
                }), 400
            
            email = data.get('email')
            
            if not email:
                return jsonify({
                    'success': False,
                    'error': 'Email é obrigatório'
                }), 400
            
            # Reenviar código 2FA
            result = self.two_fa_model.resend_code(email)
            
            if not result:
                return jsonify({
                    'success': False,
                    'error': 'Erro interno do servidor'
                }), 500
            
            if 'error' in result:
                return jsonify({
                    'success': False,
                    'error': result['error']
                }), result.get('code', 400)
            
            return jsonify({
                'success': True,
                'data': {
                    'message': 'Código reenviado com sucesso',
                    'expires_at': result.get('expires_at')
                }
            })
            
        except Exception as e:
            self.logger.error(f"Error in 2FA resend: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def validate_registration_token(self):
        """Handle registration token validation GET request"""
        try:
            token = request.args.get('token')
            
            if not token:
                return jsonify({
                    'success': False,
                    'error': 'Token é obrigatório'
                }), 400
            
            # Validar token
            result = self.auth_model.validate_registration_token(token)
            
            if not result.get('valid'):
                return jsonify({
                    'success': False,
                    'error': result.get('error', 'Token inválido')
                }), 400
            
            return jsonify({
                'success': True,
                'data': result['data']
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error validating registration token: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def refresh_token(self):
        """Handle refresh token POST request"""
        try:
            # Obter user_id do refresh token
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({
                    'success': False,
                    'error': 'Token inválido'
                }), 401
            
            # Obter claims do refresh token atual
            claims = get_jwt()
            current_token_version = claims.get('token_version')
            
            # Buscar dados atuais do usuário para validar token_version
            user_data = self.auth_model.me(user_id)
            if not user_data or not user_data.get('user'):
                return jsonify({
                    'success': False,
                    'error': 'Usuário não encontrado'
                }), 404
            
            if user_data['user'].get('ativo') is False:
                return jsonify({
                    'success': False,
                    'error': 'Sua conta está inativa, entre em contato com o suporte'
                }), 403
            
            # Validar se token_version ainda é válido (não houve reset de senha)
            db_token_version = user_data['user'].get('token_version')
            if db_token_version != current_token_version:
                return jsonify({
                    'success': False,
                    'error': 'Token inválido - faça login novamente'
                }), 401
            
            # Gerar novos tokens (access + refresh)
            new_access_token = create_access_token(
                identity=user_id,
                additional_claims={'token_version': db_token_version},
                expires_delta=Config.JWT_ACCESS_TOKEN_EXPIRES
            )
            
            new_refresh_token = create_refresh_token(
                identity=user_id,
                additional_claims={'token_version': db_token_version},
                expires_delta=Config.JWT_REFRESH_TOKEN_EXPIRES
            )
            
            decoded = decode_token(new_access_token)
            exp = decoded.get('exp')
            
            # TODO: Quando Redis estiver disponível, adicionar refresh token antigo à blacklist
            # old_jti = claims.get('jti')
            # if old_jti:
            #     blacklist_token(old_jti, remaining_time_of_old_token)
            
            # Criar resposta e definir novos cookies HTTP-only
            response = make_response(jsonify({
                'success': True,
                'data': {
                    'exp': exp
                }
            }))
            
            # Definir novos cookies HTTP-only seguros com max_age adequado e sem restrição de domínio
            set_access_cookies(response, new_access_token, max_age=Config.JWT_ACCESS_COOKIE_MAX_AGE, domain=None)
            set_refresh_cookies(response, new_refresh_token, max_age=Config.JWT_REFRESH_COOKIE_MAX_AGE, domain=None)
            
            return response
            
        except Exception as e:
            self.logger.error(f"Error in refresh token: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def connect_google(self):
        """Handle Google account connection"""
        try:
            data = request.get_json()
            
            if not data:
                return jsonify({
                    'success': False,
                    'error': 'JSON payload requerido'
                }), 400
            
            # Obter ID do usuário do JWT
            user_id = get_jwt_identity()
            
            # Validar dados obrigatórios
            required_fields = ['google_id', 'google_email', 'google_name']
            for field in required_fields:
                if not data.get(field):
                    return jsonify({
                        'success': False,
                        'error': f'Campo {field} é obrigatório'
                    }), 400
            
            # Conectar conta Google
            success = self.auth_model.connect_google_account(
                user_id=user_id,
                google_id=data['google_id'],
                google_email=data['google_email'],
                google_name=data['google_name'],
                google_picture=data.get('google_picture', '')
            )
            
            if not success:
                return jsonify({
                    'success': False,
                    'error': 'Erro ao conectar conta Google'
                }), 500
            
            return jsonify({
                'success': True,
                'message': 'Conta Google conectada com sucesso'
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error connecting Google account: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def disconnect_google(self):
        """Handle Google account disconnection"""
        try:
            # Obter ID do usuário do JWT
            user_id = get_jwt_identity()
            
            # Desconectar conta Google
            success = self.auth_model.disconnect_google_account(user_id)
            
            if not success:
                return jsonify({
                    'success': False,
                    'error': 'Erro ao desconectar conta Google'
                }), 500
            
            return jsonify({
                'success': True,
                'message': 'Conta Google desconectada com sucesso'
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error disconnecting Google account: {e}")
            return jsonify({
                'success': False,
                'error': 'Erro interno do servidor'
            }), 500

    def validate_token(self):
        """Validate if access token is expired"""
        try:
            # Verificar se há um access token válido nos cookies
            verify_jwt_in_request()
            # Se chegou até aqui, o token é válido (não expirado)
            return jsonify({'expired': False}), 200
        except Exception as e:
            # Token inválido ou expirado
            return jsonify({'expired': True}), 200