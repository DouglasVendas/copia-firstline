import logging
from datetime import datetime
from flask import request, jsonify
from flask_jwt_extended import get_jwt_identity
from app.models.meeting_bot import MeetingBot
from svix.webhooks import Webhook, WebhookVerificationError
from app.config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MeetingBotController:
    def __init__(self):
        self.logger = logging
        self.recall_webhook_secret = Config.RECALL_WEBHOOK_SECRET
        self.recall_webhook_secret_update = Config.RECALL_WEBHOOK_SECRET_UPDATE
        self.meeting_bot = MeetingBot()

    def meeting_bot_api(self, platform):
        """Endpoint para cadastrar um bot de transcrição em uma reunião."""
        if platform not in ['meet', 'zoom', 'teams']:
            return jsonify({"error": "Plataforma não especificada ou inválida"}), 400

        data = request.get_json()
        if not data:
            return jsonify({"error": "Dados não fornecidos"}), 400

        meeting_url = data.get("meeting_url")
        context_id = data.get("context_id")
        vendedor_id = data.get("vendedor_id")
        analysis_name = data.get("analysis_name")

        if not analysis_name or not meeting_url or not context_id or not vendedor_id:
            return jsonify({"error": "Parâmetros ausentes"}), 400

        user_id = get_jwt_identity()

        try:
            return self.meeting_bot.create_bot(user_id, platform, meeting_url, context_id, vendedor_id, analysis_name)
        except Exception as e:
            self.logger.error(f"Erro ao cadastrar bot: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500
        
    def get_bots(self):
        """Endpoint para obter informações sobre os bots cadastrados."""
        user_id = get_jwt_identity()
        if not user_id:
            return jsonify({"error": "Usuário não autenticado"}), 401
        try:
            return self.meeting_bot.get_bots(user_id)
        except Exception as e:
            self.logger.error(f"Erro ao obter bots: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def delete_bot(self, bot_id):
        """Endpoint para retirar um bot de transcrição de uma reunião."""
        if not bot_id:
            return jsonify({"error": "ID do bot não fornecido"}), 400

        try:
            return self.meeting_bot.delete_bot(bot_id)
        except Exception as e:
            self.logger.error(f"Erro ao retirar bot: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def webhook_bot_api(self):
        """Endpoint para receber webhooks da Recall AI."""
        data = request.get_json() or {}
        headers = request.headers
        if not data or not headers:
            return jsonify({"error": "Dados não fornecidos"}), 400

         # Verifica a assinatura do webhook
        try:
            webhook = Webhook(self.recall_webhook_secret)
            webhook.verify(request.get_data(), headers)
        except WebhookVerificationError as e:
            self.logger.error(f"Erro na verificação do webhook: {e}")
            return jsonify({"error": "Erro na verificação do webhook"}), 403

        # Extrai os dados do json
        metadata = data.get("data", {}).get("recording", {}).get("metadata", {})
        user_id = metadata.get("user_id")
        context_id = metadata.get("context_id")
        vendedor_id = metadata.get("vendedor_id")
        analysis_name = metadata.get("analysis_name")

        if not user_id or not context_id or not vendedor_id or not analysis_name:
            return jsonify({"error": "Metadados ausentes"}), 400
        
        audio_id = data.get("data", {}).get("audio_mixed", {}).get("id")
        bot_id = data.get("data", {}).get("bot", {}).get("id")
        if not audio_id or not bot_id:
            return jsonify({"error": "ID do áudio ou do bot não encontrado"}), 400
        try:
            return self.meeting_bot.webhook_bot_api(user_id, context_id, vendedor_id, audio_id, bot_id, analysis_name)
        except Exception as e:
            self.logger.error(f"Erro ao receber webhook: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500
        
    def update_bot_api(self):
        """Endpoint para atualizar o status do bot de transcrição."""
        data = request.get_json()
        headers = request.headers
        if not data or not headers:
            return jsonify({"error": "Dados não fornecidos"}), 400
        
        # Verifica a assinatura do webhook
        try:
            webhook = Webhook(self.recall_webhook_secret_update)
            webhook.verify(request.get_data(), headers)
        except WebhookVerificationError as e:
            self.logger.error(f"Erro na verificação do webhook: {e}")
            return jsonify({"error": "Erro na verificação do webhook"}), 403

        bot_id = data.get("data", {}).get("bot", {}).get("id")
        status_data = data.get("data", {}).get("data", {})
        status = status_data.get("code")
        if status == 'done':
            return jsonify({"message": "Nenhum update necessário para o status 'done'"}), 200
        if status_data.get("sub_code") == 'call_ended_by_platform_waiting_room_timeout':
            status = status_data.get("sub_code")
        updated_at_str = status_data.get("updated_at")

        if not bot_id or not status or not updated_at_str:
            return jsonify({"error": "Dados incompletos para atualizar o bot"}), 400

        try:
            # Converte a string ISO para datetime
            updated_at = datetime.fromisoformat(updated_at_str.replace('Z', '+00:00'))
        except ValueError as e:
            self.logger.error(f"Erro ao converter updated_at: {e}")
            return jsonify({"error": "Formato de data inválido"}), 400

        try:
            self.meeting_bot._update_bot_status(bot_id, status, updated_at)
            self.logger.info(f"Status do bot {bot_id} atualizado para {status}")
            return jsonify({"message": "Status do bot atualizado com sucesso"}), 200
        except Exception as e:
            self.logger.error(f"Erro ao atualizar o bot: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500
