import logging
from flask import request, jsonify
from app.models.sellers import SellerModel
from flask_jwt_extended import get_jwt_identity

class SellerController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.seller_model = SellerModel()

    def get_sellers(self):
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return []
            sellers = self.seller_model.get_sellers(user_id)
            return sellers
        except Exception as e:
            self.logger.error(f"Error getting sellers: {e}")
            return []

    def get_seller(self, seller_id):
        user_id = get_jwt_identity()
        seller = self.seller_model.get_seller_by_id(seller_id, user_id)
        if not seller:
            return jsonify({'error': 'Vendedor não encontrado'}), 404
        return jsonify({'data': seller}), 200

    def create_seller(self):
        user_id = get_jwt_identity()
        data = request.get_json()
        seller = self.seller_model.create_seller(user_id, data)
        if not seller:
            return jsonify({'error': 'Erro ao criar vendedor'}), 400
        if isinstance(seller, dict) and 'error' in seller:
            return jsonify({'error': seller['error']}), 429
        return jsonify({'data': seller}), 201

    def update_seller(self, seller_id):
        user_id = get_jwt_identity()
        data = request.get_json()
        seller = self.seller_model.update_seller(seller_id, user_id, data)
        if isinstance(seller, dict) and seller.get('code') == 409:
            return jsonify({'error': seller['error']}), 409
        if not seller:
            return jsonify({'error': 'Erro ao atualizar vendedor'}), 400
        return jsonify({'data': seller}), 200

    def delete_seller(self, seller_id):
        user_id = get_jwt_identity()
        success = self.seller_model.delete_seller(seller_id, user_id)
        if not success:
            return jsonify({'error': 'Erro ao deletar vendedor'}), 400
        return jsonify({'message': 'Vendedor deletado com sucesso'}), 200

    def get_seller_options(self):
        """Retorna as opções de tipos de vendedores disponíveis"""
        try:
            types = self.seller_model.get_seller_types()
            return jsonify({
                'data': {
                    'types': types,
                    'default': 'Geral'
                }
            }), 200
        except Exception as e:
            self.logger.error(f"Error getting seller options: {e}")
            return jsonify({'error': 'Erro ao buscar opções de vendedores'}), 500 