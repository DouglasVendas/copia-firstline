import logging
from flask import request, jsonify
from app.models.report import ReportModel
from flask_jwt_extended import get_jwt_identity

class ReportController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.report_model = ReportModel()

    def get_stats(self):
        """GET /reports/stats - Get statistics summary"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            # Get stats from model
            stats = self.report_model.get_stats(user_id)
            
            if stats is None:
                return jsonify({"error": "Erro interno do servidor"}), 500
            
            return jsonify(stats), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_stats: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500

    def get_analyses_report(self):
        """GET /reports/analyses - Get analyses report with filtering and pagination"""
        try:
            user_id = get_jwt_identity()
            if not user_id:
                return jsonify({"error": "Authentication required"}), 401
            
            # Get query parameters
            search = request.args.get('search')
            vendedor = request.args.get('vendedor')
            page = request.args.get('page', 1, type=int)
            limit = request.args.get('limit', 10, type=int)
            
            # Validate parameters
            if page < 1:
                page = 1
            if limit < 1:
                limit = 1
            if limit > 100:
                limit = 100
            
            # Get analyses report from model
            result = self.report_model.get_analyses_report(
                user_id=user_id,
                search=search,
                vendedor=vendedor,
                page=page,
                limit=limit
            )
            
            if result is None:
                return jsonify({"error": "Erro interno do servidor"}), 500
            
            return jsonify({
                "data": result['analyses'],
                "pagination": result['pagination']
            }), 200
            
        except Exception as e:
            self.logger.error(f"Error in get_analyses_report: {e}")
            return jsonify({"error": "Erro interno do servidor"}), 500
