import logging
import traceback
from flask import request, jsonify
from app.models.analyze_audio import AudioAnalyzer
from app.errors import ValidationError, NotFoundError
from flask_jwt_extended import get_jwt_identity
from app.utils.audio_utils import download_audio_from_url

class AnalyzeAudioController:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.audio_analyzer = AudioAnalyzer()

    def analyze_audio(self):
        """
        Process audio file, transcribe with AssemblyAI, analyze with Claude and store results
        
        Required form parameters:
        - audio: Audio file (multipart/form-data)
        - context_id: ID of the context for analysis
        
        Optional form parameters:
        - vendedor_id: Name of the sales representative
        - analysis_name: Custom name for the analysis
        
        Returns:
        - JSON with analysis results or error message
        """
        try:
            # Log request info
            self.logger.info(f"Request form data: {request.form.to_dict()}")
            self.logger.info(f"Request files: {list(request.files.keys())}")
            self.logger.info(f"Request headers: {dict(request.headers)}")
            self.logger.info(f"Request content type: {request.content_type}")

            # Extract form data
            audio = request.files.get('audio')
            context_id = request.form.get('context_id')
            user_id = get_jwt_identity()
            vendedor = request.form.get('vendedor_id')
            speakers_expected = request.form.get('speakers_expected', type=int, default=None)
            analysis_name = request.form.get('analysis_name')
            
            # Validate input parameters - must have either audio file, base64 audio, or audio_url
            if not audio:
                self.logger.warning("Missing audio file in request")
                return jsonify({"error": "Audio file is required"}), 400
            
            # Validate audio file
            if not audio.filename:
                self.logger.warning("Audio file has no filename")
                return jsonify({"error": "Audio file has no filename"}), 400
            
            # Validate required fields
            if not context_id:
                self.logger.warning("Missing context_id parameter")
                return jsonify({"error": "Context ID is required"}), 400
                
            if not user_id:
                self.logger.warning("Missing user_id parameter (from JWT)")
                return jsonify({"error": "User ID is required"}), 400
                
            # Log request info with file size detection
            file_size = None
            try:
                # Get actual file size by reading the file
                audio.seek(0, 2)  # Seek to end
                file_size = audio.tell()
                audio.seek(0)  # Reset to beginning
            except:
                file_size = audio.content_length
            
            self.logger.info(f"Processing audio analysis request: file={audio.filename}, size={file_size}, content_length={audio.content_length}, context={context_id}, user={user_id}, analysis_name={analysis_name}")
            
            # Validate file size
            if file_size == 0:
                self.logger.error(f"Audio file is empty: {audio.filename}")
                return jsonify({"error": "Audio file is empty"}), 400
                
            # Process the audio
            result, status_code = self.audio_analyzer.analyze_audio(audio, context_id, vendedor, user_id, speakers_expected, analysis_name)
            
            return jsonify(result), status_code
            
        except ValidationError as e:
            self.logger.warning(f"Validation error: {str(e)}")
            return jsonify({"error": str(e)}), 400
            
        except NotFoundError as e:
            self.logger.warning(f"Not found error: {str(e)}")
            return jsonify({"error": str(e)}), 404
            
        except Exception as e:
            self.logger.error(f"Error in analyze_audio endpoint: {str(e)}")
            self.logger.error(traceback.format_exc())
            return jsonify({"error": "Server error processing request"}), 500

    def call_integration(self, user_email):
        """
        Processa integração de chamada
        Parâmetros:
        - user_email: e-mail do usuário (path parameter)
        - analysis_name: nome da análise (query parameter, opcional)
        - speakers_expected: número de speakers esperado (query parameter, opcional)
        - Body: JSON com dados da chamada da API4Com
        """
        try:
            # Log do body da requisição
            self.logger.info(f"Call integration request body: {request.get_data(as_text=True)}")
            
            # Extrair dados do JSON do body
            if not request.is_json:
                self.logger.warning("Request body must be JSON")
                return jsonify({"error": "Request body must be JSON"}), 400

            call_data = request.get_json()
            
            # Validar campos obrigatórios no JSON
            if not call_data.get('recordUrl'):
                self.logger.warning("Missing recordUrl in request body")
                return jsonify({"error": "recordUrl is required in request body"}), 400

            # Extrair parâmetros da query string
            analysis_name = request.args.get('analysis_name', None)
            speakers_expected = request.args.get('speakers_expected', type=int, default=None)

            # Parâmetros opcionais
            context_id = request.args.get('context_id', None)
            vendedor_id = request.args.get('vendedor_id', None)

            client_number = call_data['called'] if 'called' in call_data else None

            # Validar email do usuário
            if not user_email:
                self.logger.warning("Missing user_email parameter")
                return jsonify({"error": "User email is required"}), 400

            # Baixar o arquivo de áudio
            record_url = call_data['recordUrl']
            self.logger.info(f"Downloading audio from: {record_url}")
            
            # Use the helper function to download audio
            audio_file, error_response = download_audio_from_url(record_url, f"call_integration_{call_data.get('id', 'unknown')}")
            if error_response:
                return jsonify(error_response[0]), error_response[1]

            # Processar o áudio
            result, status_code = self.audio_analyzer.call_integration(audio_file, user_email, speakers_expected, analysis_name, context_id, vendedor_id, client_number)

            # Limpar arquivo temporário
            try:
                audio_file.close()
            except:
                pass

            return jsonify(result), status_code

        except ValidationError as e:
            self.logger.warning(f"Validation error: {str(e)}")
            return jsonify({"error": str(e)}), 400

        except NotFoundError as e:
            self.logger.warning(f"Not found error: {str(e)}")
            return jsonify({"error": str(e)}), 404

        except Exception as e:
            self.logger.error(f"Error in call_integration endpoint: {str(e)}")
            self.logger.error(traceback.format_exc())
            return jsonify({"error": "Internal server error"}), 500
