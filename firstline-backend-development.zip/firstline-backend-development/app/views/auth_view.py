from flask import Blueprint, request, make_response
from app.controllers.auth_controller import AuthController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required, refresh_token_required

auth_view = Blueprint('auth', __name__, url_prefix='/auth')
auth_controller = AuthController()

@auth_view.route('/login', methods=['POST'])
def login():
    """POST /auth/login - User login endpoint"""
    return auth_controller.login()

@auth_view.route('/register', methods=['POST'])
def register():
    """POST /auth/register - User registration endpoint"""
    return auth_controller.register()

@auth_view.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
@refresh_token_required
def refresh():
    """POST /auth/refresh - Refresh access token using refresh token"""
    return auth_controller.refresh_token()

@auth_view.route('/logout', methods=['POST'])
@jwt_required()
@token_version_required
def logout():
    """POST /auth/logout - User logout endpoint"""
    return auth_controller.logout()

@auth_view.route('/me', methods=['GET'])
@jwt_required()
@token_version_required
def me():
    """GET /auth/me - Get current user profile"""
    return auth_controller.me()

@auth_view.route('/password-reset/request', methods=['POST'])
def request_password_reset():
    """POST /auth/password-reset/request - Request password reset"""
    return auth_controller.request_password_reset()

@auth_view.route('/password-reset/validate', methods=['GET'])
def validate_reset_token():
    """GET /auth/password-reset/validate - Validate reset token"""
    return auth_controller.validate_reset_token()

@auth_view.route('/password-reset/confirm', methods=['POST'])
def confirm_password_reset():
    """POST /auth/password-reset/confirm - Confirm password reset"""
    return auth_controller.confirm_password_reset()

@auth_view.route('/2fa/verify', methods=['POST'])
def verify_2fa():
    """POST /auth/2fa/verify - Verify 2FA code"""
    return auth_controller.verify_2fa()

@auth_view.route('/2fa/resend', methods=['POST'])
def resend_2fa():
    """POST /auth/2fa/resend - Resend 2FA code"""
    return auth_controller.resend_2fa()

@auth_view.route('/registration-token/validate', methods=['GET'])
def validate_registration_token():
    """GET /auth/registration-token/validate?token=xxx - Validate registration token"""
    return auth_controller.validate_registration_token()

@auth_view.route('/google/connect', methods=['POST'])
@jwt_required()
@token_version_required
def google_connect():
    """POST /auth/google/connect - Connect Google account"""
    return auth_controller.connect_google()

@auth_view.route('/google/disconnect', methods=['POST'])
@jwt_required()
@token_version_required
def google_disconnect():
    """POST /auth/google/disconnect - Disconnect Google account"""
    return auth_controller.disconnect_google()

@auth_view.route('/validate-token', methods=['GET'])
def validate_token():
    """GET /auth/validate-token - Validate if access token is expired"""
    return auth_controller.validate_token()
