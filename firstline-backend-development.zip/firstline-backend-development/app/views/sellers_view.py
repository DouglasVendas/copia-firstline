from flask import Blueprint
from app.controllers.sellers_controller import SellerController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

sellers_view = Blueprint('sellers', __name__, url_prefix='/sellers')
sellers_controller = SellerController()

@sellers_view.route('', methods=['GET'])
@jwt_required()
@token_version_required
def get_sellers():
    return sellers_controller.get_sellers()

@sellers_view.route('/<string:seller_id>', methods=['GET'])
@jwt_required()
@token_version_required
def get_seller(seller_id):
    return sellers_controller.get_seller(seller_id)

@sellers_view.route('', methods=['POST'])
@jwt_required()
@token_version_required
def create_seller():
    return sellers_controller.create_seller()

@sellers_view.route('/<string:seller_id>', methods=['PUT'])
@jwt_required()
@token_version_required
def update_seller(seller_id):
    return sellers_controller.update_seller(seller_id)

@sellers_view.route('/<string:seller_id>', methods=['DELETE'])
@jwt_required()
@token_version_required
def delete_seller(seller_id):
    return sellers_controller.delete_seller(seller_id)

@sellers_view.route('/options/', methods=['GET'])
@jwt_required()
@token_version_required
def get_seller_options():
    return sellers_controller.get_seller_options() 