from flask import Blueprint
from app.controllers.report_controller import ReportController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

report_view = Blueprint('report', __name__, url_prefix='/reports')
report_controller = ReportController()

@report_view.route('/stats', methods=['GET'])
@jwt_required()
@token_version_required
def get_stats():
    return report_controller.get_stats()

@report_view.route('/analyses', methods=['GET'])
@jwt_required()
@token_version_required
def get_analyses_report():
    return report_controller.get_analyses_report()
