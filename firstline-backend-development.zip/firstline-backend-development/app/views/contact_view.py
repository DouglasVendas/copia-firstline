from flask import Blueprint
from app.controllers.contact_controller import ContactController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

contact_view = Blueprint('contact', __name__, url_prefix='/contacts')
contact_controller = ContactController()

@contact_view.route('', methods=['GET'])
@jwt_required()
@token_version_required
def get_contacts():
    return contact_controller.get_contacts()

@contact_view.route('', methods=['POST'])
@jwt_required()
@token_version_required
def create_contact():
    return contact_controller.create_contact()

@contact_view.route('/<string:contact_id>', methods=['GET'])
@jwt_required()
@token_version_required
def get_contact(contact_id):
    return contact_controller.get_contact(contact_id)

@contact_view.route('/<string:contact_id>', methods=['PUT'])
@jwt_required()
@token_version_required
def update_contact(contact_id):
    return contact_controller.update_contact(contact_id)

@contact_view.route('/<string:contact_id>', methods=['DELETE'])
@jwt_required()
@token_version_required
def delete_contact(contact_id):
    return contact_controller.delete_contact(contact_id)
