from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.middleware import token_version_required
from app.controllers.meeting_bot_controller import MeetingBotController

meeting_bot_view = Blueprint('bot-api', __name__)
meeting_bot_controller = MeetingBotController()

@meeting_bot_view.route('/bot-api/<string:platform>', methods=['POST'])
@jwt_required()
@token_version_required
def bot_api(platform):
    """Endpoint para cadastrar um bot de transcrição em uma reunião.
    
    Parameters:
        platform (str): Plataforma do bot (e.g., 'meet', 'zoom', 'teams').
        meeting_url (str): URL da reunião.
        context_id (str): ID do contexto.
        vendedor_id (str): ID do vendedor.
        analysis_name (str): Nome da análise.

    Returns:
        202 Accepted: Se o bot foi cadastrado com sucesso.
        400 Bad Request: Se os parâmetros necessários não forem fornecidos.
        404 Not Found: Se o link estiver expirado ou inválido.
        500 Internal Server Error: Se ocorrer um erro ao processar a solicitação.
        401 Unauthorized: Se o token JWT não for válido ou estiver ausente.
        
    Example:
        POST /bot-api/meet
        {
            "meeting_url": "https://meet.google.com/abc-defg-hij",
            "context_id": "12345",
            "vendedor_id": "67890",
            "analysis_name": "Meeting Transcription"
        }
    """
    return meeting_bot_controller.meeting_bot_api(platform)

@meeting_bot_view.route('/bot-api/', methods=['GET'])
@jwt_required()
@token_version_required
def get_bot_api():
    """Endpoint para obter informações sobre os bots cadastrados."""
    return meeting_bot_controller.get_bots()

@meeting_bot_view.route('/bot-api/<string:bot_id>', methods=['DELETE'])
@jwt_required()
@token_version_required
def delete_bot(bot_id):
    """Endpoint para retirar um bot de transcrição de uma reunião.
    
    Parameters:
        bot_id (str): ID do bot.

    Returns:
        200 OK: Se o bot foi retirado com sucesso.
        400 Bad Request: Se o ID do bot não for fornecido.
        404 Not Found: Se o bot não for encontrado.
        500 Internal Server Error: Se ocorrer um erro ao processar a solicitação.
        401 Unauthorized: Se o token JWT não for válido ou estiver ausente.
    """
    return meeting_bot_controller.delete_bot(bot_id)

@meeting_bot_view.route('/webhook/bot-api', methods=['POST'])
def webhook_bot_api():
    """Endpoint para receber webhooks da Recall AI.
    
    Returns:
        202 Accepted: Aceita a solicitação do webhook.
        400 Bad Request: Se os dados do webhook não forem válidos.
        500 Internal Server Error: Se ocorrer um erro ao processar o webhook.
    """
    return meeting_bot_controller.webhook_bot_api()

@meeting_bot_view.route('/webhook/update-bot', methods=['POST'])
def update_bot_api():
    """Endpoint para atualizar o status do bot de transcrição.
    
    Returns:
        200 OK: Se o status do bot foi atualizado com sucesso.
        400 Bad Request: Se os dados fornecidos não forem válidos.
        500 Internal Server Error: Se ocorrer um erro ao processar a solicitação.
    """
    return meeting_bot_controller.update_bot_api()