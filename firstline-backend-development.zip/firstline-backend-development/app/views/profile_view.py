from flask import Blueprint, make_response
from app.controllers.profile_controller import ProfileController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

profile_view = Blueprint('profile', __name__, url_prefix='/profile')
profile_controller = ProfileController()

@profile_view.route('', methods=['GET'])
@jwt_required()
@token_version_required
def get_profile():
    return profile_controller.get_profile()

@profile_view.route('', methods=['PUT'])
@jwt_required()
@token_version_required
def update_profile():
    return profile_controller.update_profile()

@profile_view.route('/picture', methods=['POST'])
@jwt_required()
@token_version_required
def upload_picture():
    return profile_controller.upload_picture()

@profile_view.route('/picture', methods=['GET'])
@jwt_required()
@token_version_required
def get_picture():
    return profile_controller.get_picture()