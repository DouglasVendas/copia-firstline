from flask import Blueprint, request, jsonify
from app.controllers.context_controller import ContextController
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.middleware import token_version_required

context_view = Blueprint('contexts', __name__, url_prefix='/contexts')
context_controller = ContextController()

@context_view.route('', methods=['GET'])
@jwt_required()
@token_version_required
def get_contexts():
    return context_controller.get_contexts()

@context_view.route('/active', methods=['GET'])
@jwt_required()
@token_version_required
def get_active_context():
    return context_controller.get_active_context()

@context_view.route('', methods=['POST'])
@jwt_required()
@token_version_required
def create_context():
    return context_controller.create_context()

@context_view.route('/<string:context_id>', methods=['PUT'])
@jwt_required()
@token_version_required
def update_context(context_id):
    return context_controller.update_context(context_id)

@context_view.route('/<string:context_id>', methods=['DELETE'])
@jwt_required()
@token_version_required
def delete_context(context_id):
    return context_controller.delete_context(context_id)

@context_view.route('/<string:context_id>/activate', methods=['PUT'])
@jwt_required()
@token_version_required
def activate_context(context_id):
    return context_controller.activate_context(context_id)

@context_view.route('/create/from_file', methods=['POST'])
@jwt_required()
@token_version_required
def create_context_from_file():
    return context_controller.create_context_from_file()