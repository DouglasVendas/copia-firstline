import pandas as pd
import io
from flask import Blueprint, request, jsonify, send_file, abort
from app.controllers.analyze_manager_controller import AnalyzeManagerController
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.middleware import token_version_required, role_required
from datetime import datetime

analyzes_view = Blueprint('analyses', __name__, url_prefix='/analyses')
analyze_manager_controller = AnalyzeManagerController()

@analyzes_view.route('', methods=['GET'])
@jwt_required()
@token_version_required
def get_analyzes():
    """GET /analyses - Get all analyzes with filtering and pagination"""
    return analyze_manager_controller.get_analyzes()

@analyzes_view.route('/<string:analyze_id>', methods=['GET'])
@jwt_required()
@token_version_required
def get_analyze(analyze_id):
    """GET /analyses/<analyze_id> - Get specific analysis"""
    return analyze_manager_controller.get_analyze(analyze_id)

@analyzes_view.route('/<string:analyze_id>', methods=['PUT'])
@jwt_required()
@token_version_required
def update_analyze(analyze_id):
    """PUT /analyses/<analyze_id> - Update specific analysis"""
    return analyze_manager_controller.update_analyze(analyze_id)

@analyzes_view.route('/<string:analyze_id>', methods=['DELETE'])
@jwt_required()
@token_version_required
def delete_analyze(analyze_id):
    """DELETE /analyses/<analyze_id> - Delete specific analysis"""
    return analyze_manager_controller.delete_analyze(analyze_id)

@analyzes_view.route('/stats', methods=['GET'])
@jwt_required()
@token_version_required
def get_analyze_stats():
    """GET /analyses/stats - Get statistics about analyzes"""
    return analyze_manager_controller.get_analyze_stats()

@analyzes_view.route('/cleanup', methods=['DELETE'])
@jwt_required()
@token_version_required
def cleanup_old_analyzes():
    """DELETE /analyses/cleanup - Delete old analyzes"""
    return jsonify({"message": "Endpoint temporarily disabled"}), 503
    #return analyze_manager_controller.cleanup_old_analyzes()

@analyzes_view.route('/dashboard-view/', methods=['GET'])
@jwt_required()
@token_version_required
def get_dashboard_view():
    """GET /analyses/dashboard-view/ - Get dashboard view data"""
    return analyze_manager_controller.get_dashboard_view()

@analyzes_view.route('/ranking/', methods=['GET'])
@jwt_required()
@token_version_required
def get_ranking():
    """GET /analyses/ranking/ - Get ranking data"""
    return analyze_manager_controller.get_ranking()

@analyzes_view.route('/latest/', methods=['GET'])
@jwt_required()
@token_version_required
def get_latest():
    """GET /analyses/latest/ - Get the latest analyze and context"""
    return analyze_manager_controller.get_latest()

@analyzes_view.route('/credits-remaining/', methods=['GET'])
@jwt_required()
@token_version_required
def get_credits_remaining():
    """GET /analyses/credits-remaining/ - Get the remaining credits"""
    return analyze_manager_controller.get_credits_remaining()

@analyzes_view.route('/export-low-credit-users', methods=['GET'])
def export_low_credit_users():
    """GET /analyses/export-low-credit-users - Export low credit users"""
    return analyze_manager_controller.export_low_credit_users_to_view()

@analyzes_view.route('/scores', methods=['GET'])
@jwt_required()
@token_version_required
def get_scores_by_seller():
    """GET /analyses/scores - Get scores grouped by seller"""
    return analyze_manager_controller.get_scores_by_seller()

@analyzes_view.route('/admin/<string:user_email>', methods=['GET'])
@jwt_required()
@token_version_required
@role_required(['ADMIN'])
def admin_get_user_analyzes(user_email):
    """GET /analyses/admin/<user_email> - Get all analyzes for a specific user. Available only for admin users."""
    return analyze_manager_controller.admin_get_user_analyzes(user_email)