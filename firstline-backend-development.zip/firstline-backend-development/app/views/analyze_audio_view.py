from flask import Blueprint, make_response
from app.controllers.analyze_audio_controller import AnalyzeAudioController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

analyze_audio_view = Blueprint('analyze_audio', __name__)
analyze_audio_controller = AnalyzeAudioController()

@analyze_audio_view.route('/analyze-audio', methods=['POST'])
@jwt_required()
@token_version_required
def analyze_audio():
    """POST /analyze-audio/ - Analyze audio file"""
    return analyze_audio_controller.analyze_audio()

@analyze_audio_view.route('/analyze-audio/call-integration/<user_email>', methods=['POST'])
def call_integration(user_email):
    """POST /analyze-audio/call-integration/<user_email> - Call integration
    Parâmetros na URL:
    - user_email: e-mail do usuário (path parameter)
    
    Query parameters:
    - analysis_name: nome da análise (opcional)
    - speakers_expected: número de speakers esperado (opcional)
    
    Body (JSON):
    - Dados da chamada da API4Com (recordUrl, metadata, etc.)
    """
    return analyze_audio_controller.call_integration(user_email)

