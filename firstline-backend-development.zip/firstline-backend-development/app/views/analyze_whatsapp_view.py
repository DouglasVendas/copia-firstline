from flask import Blueprint
from app.controllers.analyze_whatsapp_controller import AnalyzeWhatsappController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

analyze_whatsapp_view = Blueprint('analyze_whatsapp', __name__)
analyze_whatsapp_controller = AnalyzeWhatsappController()

@analyze_whatsapp_view.route('/analyze-whatsapp', methods=['POST'])
@jwt_required()
@token_version_required
def analyze_whatsapp():
    """POST /analyze-whatsapp/ - Analyze WhatsApp content with text and media files"""
    return analyze_whatsapp_controller.analyze_whatsapp()
