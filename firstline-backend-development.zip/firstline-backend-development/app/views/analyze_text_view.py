from flask import Blueprint
from app.controllers.analyze_text_controller import AnalyzeTextController
from flask_jwt_extended import jwt_required
from app.middleware import token_version_required

analyze_text_view = Blueprint('analyze_text', __name__)
analyze_text_controller = AnalyzeTextController()

@analyze_text_view.route('/analyze-text', methods=['POST'])
@jwt_required()
@token_version_required
def analyze_text():
    """POST /analyze-text/ - Analyze text content"""
    return analyze_text_controller.analyze_text()
