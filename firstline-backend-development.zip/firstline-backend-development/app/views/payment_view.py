from flask import Blueprint
from app.controllers.payment_controller import PaymentController

payment_view = Blueprint('payment_view', __name__, url_prefix='/payment')
payment_controller = PaymentController()

@payment_view.route('', methods=['POST'])
def process_payment():
    "Webhook endpoint for processing payments"
    return payment_controller.process_payment()