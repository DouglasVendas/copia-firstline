from flask import Flask
from flask_cors import CORS
from flask_talisman import Talisman
from app.errors import handle_404, handle_500, handle_413
from app.config import Config
import logging
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_jwt_extended import JWTManager

limiter = Limiter(get_remote_address, default_limits=["100 per minute"])

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Configure security headers with Talisman
    if app.config.get("ENV") == "production":
        Talisman(app)
    
    # Allowed origins for CORS with cookies
    allowed_origins = [
        "https://dev.app.firstlineai.com.br",  # New frontend
        "https://app.firstlineai.com.br"  # Production frontend
    ]

    # Add localhost in development
    if app.config.get("ENV") == "development":
        allowed_origins.append("http://localhost:8080")  # Local development

    CORS(
        app,
        origins=allowed_origins,
        supports_credentials=True,  # Required for cookies
        allow_headers=["Content-Type", "Authorization", "X-Requested-With"],
        methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
        expose_headers=["Set-Cookie"]
    )
    limiter.init_app(app)

    # Carregar as chaves RSA
    with open(app.config['PRIVATE_KEY_PATH'], 'r') as f:
        private_key = f.read()
    with open(app.config['PUBLIC_KEY_PATH'], 'r') as f:
        public_key = f.read()
    app.config['JWT_PRIVATE_KEY'] = private_key
    app.config['JWT_PUBLIC_KEY'] = public_key
    app.config['JWT_ALGORITHM'] = 'RS256'
    JWTManager(app)

    app.register_error_handler(404, handle_404)
    app.register_error_handler(500, handle_500)
    app.register_error_handler(413, handle_413)
    
    
    logging.basicConfig(level=logging.INFO, filename='app.log', filemode='a',
                    format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Force immediate log flushing
    for handler in logging.getLogger().handlers:
        handler.flush()

    app.logger.info("Application started!")

    from app.views.auth_view import auth_view
    from app.views.profile_view import profile_view
    from app.views.context_view import context_view
    from app.views.contact_view import contact_view
    from app.views.report_view import report_view
    from app.views.analyze_audio_view import analyze_audio_view
    from app.views.analyze_text_view import analyze_text_view
    from app.views.analyze_whatsapp_view import analyze_whatsapp_view
    from app.views.analyze_manager_view import analyzes_view
    from app.views.sellers_view import sellers_view
    from app.views.meeting_bot_view import meeting_bot_view
    from app.views.payment_view import payment_view
    
    app.register_blueprint(auth_view)
    app.register_blueprint(profile_view)
    app.register_blueprint(context_view)
    app.register_blueprint(contact_view)
    app.register_blueprint(report_view)
    app.register_blueprint(analyze_audio_view)
    app.register_blueprint(analyze_text_view)
    app.register_blueprint(analyze_whatsapp_view)
    app.register_blueprint(analyzes_view)
    app.register_blueprint(sellers_view)
    app.register_blueprint(meeting_bot_view)
    app.register_blueprint(payment_view)
    
    # Apply global error handler middleware
    from app.middleware import error_handler
    error_handler(app)

    return app
