# API de Bots de Reunião - Documentação para Frontend

Esta documentação descreve os endpoints disponíveis para gerenciamento de bots de transcrição em reuniões.

## Autenticação

Todos os endpoints requerem autenticação JWT. Inclua o token no cabeçalho `Authorization`:

```
Authorization: Bearer <jwt_token>
```

---

## 1. Criar Bot de Transcrição

Cria um bot de transcrição para uma reunião específica.

### Endpoint
```
POST /bot-api/{platform}
```

### Parâmetros da URL
- `platform` (string, obrigatório): Plataforma da reunião
  - Valores aceitos: `meet`, `zoom`, `teams`

### Body (JSON)
```json
{
  "bot_name": "string",      // Nome do bot (obrigatório)
  "meeting_url": "string",   // URL da reunião (obrigatório)
  "context_id": "string",    // ID do contexto (obrigatório)
  "vendedor_id": "string"    // ID do vendedor (obrigatório)
}
```

### Exemplo de Requisição
```bash
POST /bot-api/meet
Content-Type: application/json
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...

{
  "bot_name": "TranscriptionBot",
  "meeting_url": "https://meet.google.com/abc-defg-hij",
  "context_id": "12345",
  "vendedor_id": "67890"
}
```

### Respostas

#### ✅ Sucesso (202 Accepted)
```json
{
  "message": "Bot criado com sucesso"
}
```

#### ❌ Erro - Plataforma inválida (400 Bad Request)
```json
{
  "error": "Plataforma não especificada ou inválida"
}
```

#### ❌ Erro - Dados ausentes (400 Bad Request)
```json
{
  "error": "Dados não fornecidos"
}
```

#### ❌ Erro - Parâmetros obrigatórios (400 Bad Request)
```json
{
  "error": "Parâmetros ausentes"
}
```

#### ❌ Erro - Falha na criação (500 Internal Server Error)
```json
{
  "error": "Erro ao criar bot"
}
```

---

## 2. Listar Bots

Obtém todos os bots cadastrados para o usuário autenticado.

### Endpoint
```
GET /bot-api/
```

### Parâmetros
Nenhum parâmetro adicional necessário além da autenticação JWT.

### Exemplo de Requisição
```bash
GET /bot-api/
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...
```

### Respostas

#### ✅ Sucesso (200 OK)
```json
{
  "success": true,
  "bots": [
    {
      "id": "bot_12345",
      "user_id": "user_67890",
      "platform": "meet",
      "bot_name": "TranscriptionBot",
      "meeting_url": "https://meet.google.com/abc-defg-hij",
      "context_id": "12345",
      "vendedor_id": "67890",
      "created_at": "2024-01-15T10:30:00Z",
      "ended_at": "2024-01-15T11:30:00Z",
      "status": "completed",
      "updated_at": "2024-01-15T11:30:00Z"
    }
  ]
}
```

#### ❌ Erro - Usuário não autenticado (401 Unauthorized)
```json
{
  "error": "Usuário não autenticado"
}
```

#### ❌ Erro - Falha interna (500 Internal Server Error)
```json
{
  "error": "Erro interno do servidor"
}
```

### Descrição dos Campos da Resposta

| Campo | Tipo | Descrição |
|-------|------|-----------|
| `id` | string | ID único do bot |
| `user_id` | string | ID do usuário proprietário |
| `platform` | string | Plataforma da reunião (meet, zoom, teams) |
| `bot_name` | string | Nome do bot |
| `meeting_url` | string | URL da reunião |
| `context_id` | string | ID do contexto |
| `vendedor_id` | string | ID do vendedor |
| `created_at` | datetime | Data/hora de criação do bot |
| `ended_at` | datetime | Data/hora de término do bot (null se ainda ativo) |
| `status` | string | Status atual do bot (obtido da API Recall) |
| `updated_at` | datetime | Última atualização do status (obtido da API Recall) |

### Possíveis Status do Bot
- `waiting_for_host` - Aguardando o host iniciar a reunião
- `in_waiting_room` - Bot na sala de espera
- `in_call_recording` - Bot gravando a reunião
- `completed` - Gravação concluída
- `error` - Erro na gravação

---

## 3. Remover Bot

Remove um bot de transcrição de uma reunião específica.

### Endpoint
```
DELETE /bot-api/{bot_id}
```

### Parâmetros da URL
- `bot_id` (string, obrigatório): ID do bot a ser removido

### Exemplo de Requisição
```bash
DELETE /bot-api/bot_12345
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...
```

### Respostas

#### ✅ Sucesso (200 OK)
```json
{
  "message": "Bot retirado com sucesso"
}
```

#### ❌ Erro - ID não fornecido (400 Bad Request)
```json
{
  "error": "ID do bot não fornecido"
}
```

#### ❌ Erro - Bot não encontrado (404 Not Found)
```json
{
  "error": "Bot não encontrado"
}
```

#### ❌ Erro - Falha na remoção (500 Internal Server Error)
```json
{
  "error": "Erro ao retirar bot"
}
```

---

## Códigos de Status HTTP

| Código | Significado | Uso |
|--------|-------------|-----|
| 200 | OK | Operação realizada com sucesso |
| 202 | Accepted | Requisição aceita, processamento iniciado |
| 400 | Bad Request | Parâmetros inválidos ou ausentes |
| 401 | Unauthorized | Token JWT inválido ou ausente |
| 404 | Not Found | Recurso não encontrado |
| 500 | Internal Server Error | Erro interno do servidor |

---

## Notas Importantes

### Sobre a Criação de Bots
- O bot é criado tanto na API da Recall.AI quanto no banco de dados local
- O processo de criação retorna 202 (Accepted) pois pode demorar alguns segundos
- Após a criação, use o endpoint de listagem para verificar o status

### Sobre o Status dos Bots
- O status é obtido em tempo real da API da Recall.AI
- Pode haver atraso na atualização do status devido à latência da API externa
- Bots ativos podem demorar para aparecer com status "in_call_recording"

### Sobre a Remoção de Bots
- A remoção apenas retira o bot da reunião (não deleta do banco)
- O bot para de gravar imediatamente após a remoção
- O áudio já gravado será processado normalmente

### Sobre a Transcrição
- O processamento da transcrição acontece automaticamente via webhook
- O resultado da análise fica disponível nos endpoints de análise de áudio
- O processo é assíncrono e pode levar alguns minutos para completar

---

## Tratamento de Erros Recomendado

### Para o Frontend
1. **Sempre verificar o código de status HTTP**
2. **Implementar retry para erros 500**
3. **Mostrar mensagens de erro amigáveis ao usuário**
4. **Implementar loading states para operações assíncronas**

### Exemplo de Tratamento (JavaScript)
```javascript
try {
  const response = await fetch('/bot-api/meet', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(botData)
  });
  
  const result = await response.json();
  
  if (response.ok) {
    // Sucesso - mostrar mensagem de confirmação
    showSuccess(result.message);
  } else {
    // Erro - mostrar mensagem específica
    showError(result.error);
  }
} catch (error) {
  // Erro de rede ou parsing
  showError('Erro de conexão. Tente novamente.');
}
```
