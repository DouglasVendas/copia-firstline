def test_example():
    assert 1 + 2 == 3