import React, { createContext, useContext, ReactNode } from 'react';
import { useContexts } from '@/hooks/useContexts';

interface Vendedor {
  id: string;
  name: string;
}

interface Context {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  prompt: string;
  vendedores: Vendedor[];
  vendedor_ativo: string | null;
  vendedor_ativo_id: string | null;
}

interface ContextsContextType {
  contexts: Context[];
  activeContexts: Context[];
  loading: boolean;
  error: string | null;
  hasContexts: boolean;
  hasActiveContexts: boolean;
  fetchContexts: () => Promise<void>;
  createContext: (contextData: Omit<Context, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => Promise<Context>;
  updateContext: (id: string, contextData: Partial<Context>) => Promise<Context>;
  deleteContext: (id: string) => Promise<void>;
}

const ContextsContext = createContext<ContextsContextType | undefined>(undefined);

interface ContextsProviderProps {
  children: ReactNode;
}

export function ContextsProvider({ children }: ContextsProviderProps) {
  const contextsHook = useContexts();

  return (
    <ContextsContext.Provider value={contextsHook}>
      {children}
    </ContextsContext.Provider>
  );
}

export function useContextsFromProvider() {
  const context = useContext(ContextsContext);
  if (context === undefined) {
    throw new Error('useContextsFromProvider must be used within a ContextsProvider');
  }
  return context;
}