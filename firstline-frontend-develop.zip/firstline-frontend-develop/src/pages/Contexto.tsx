
import { useState, useEffect, useRef } from "react";
import { Target, Plus, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SalesContextForm } from "@/components/context/SalesContextForm";
import { SellerManagement } from "@/components/context/SellerManagement";
import { ContextCard } from "@/components/context/ContextCard";
import { ContextForm } from "@/components/context/ContextForm";
import { EmptyContextState } from "@/components/context/EmptyContextState";
import { useContextManagement } from "@/hooks/useContextManagement";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';
import { Context, Vendedor, ContextFormData } from '@/types/context';

export default function Contexto() {
  const { toast } = useToast();
  const { user } = useAuth();
  const {
    contexts,
    loading,
    fetchContexts,
    createContext,
    updateContext,
    deleteContext,
    setActiveContext
  } = useContextManagement();

  const [isCreating, setIsCreating] = useState(false);
  const [isCreatingSales, setIsCreatingSales] = useState(false);
  const [editingContext, setEditingContext] = useState<Context | null>(null);
  const [editingSalesContext, setEditingSalesContext] = useState<ContextFormData | null>(null);
  const firstLoad = useRef(true);
  const [formResetCount, setFormResetCount] = useState(0);

  useEffect(() => {
    if (firstLoad.current) {
      setIsCreatingSales(true);
      firstLoad.current = false;
    }
  }, []);

  // Alternar formulário de vendas ao clicar no botão
  const handleToggleSalesContext = () => {
    if (isCreatingSales) {
      setIsCreatingSales(false);
    } else {
      setIsCreatingSales(true);
    }
  };

  const handleCreateSimpleContext = async (contextData: Partial<Context>) => {
    try {
      const contextToSave = {
        ...contextData,
        vendedores: contextData.vendedores || [],
      };
      const success = await createContext(contextToSave);
      if (success) {
        setIsCreating(false);
        toast({
          title: "Contexto criado com sucesso",
          description: "Seu novo contexto está pronto para uso.",
          variant: "success",
        });
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao criar contexto",
        description: "Ocorreu um erro. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleUpdateContext = async (contextData: Partial<Context>) => {
    if (!editingContext) return;
    try {
      const contextToSave = {
        ...contextData,
        vendedores: contextData.vendedores || [],
      };
      const success = await updateContext(editingContext.id, contextToSave);
      if (success) {
        setEditingContext(null);
        toast({
          title: "Contexto atualizado",
          description: "As alterações foram salvas com sucesso.",
          variant: "success",
        });
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao atualizar contexto",
        description: "Ocorreu um erro. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  // Callback executado após o sucesso do save no hook (mesmo comportamento do cancelar)
  const handleSalesContextSave = () => {
    setEditingSalesContext(null);
    setFormResetCount(c => c + 1);
    setIsCreatingSales(true);
    fetchContexts(); // Atualiza a lista de contextos
  };

  const handleVendedoresUpdate = async (contextId: string, vendedores: Vendedor[]) => {
    try {
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/contexts/${contextId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ vendedores })
      });

      if (!response.ok) {
        throw new Error('Failed to update vendedores');
      }

      await fetchContexts();
      toast({
        title: "Vendedores atualizados",
        description: "A lista de vendedores foi atualizada com sucesso.",
        variant: "success",
      });
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao atualizar vendedores",
        description: "Ocorreu um erro. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleVendedorAtivoUpdate = async (contextId: string, vendedorAtivoId: string | null) => {
    try {
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/contexts/${contextId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ vendedor_ativo_id: vendedorAtivoId })
      });

      if (!response.ok) {
        throw new Error('Failed to update vendedor ativo');
      }

      await fetchContexts();
      toast({
        title: "Vendedor padrão atualizado",
        description: "O vendedor padrão foi definido com sucesso.",
        variant: "success",
      });
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao atualizar vendedor padrão",
        description: "Ocorreu um erro. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteContext = async (id: string) => {
    try {
      const success = await deleteContext(id);
      if (success) {
        toast({
          title: "Contexto removido",
          description: "O contexto foi removido com sucesso.",
          variant: "success",
        });
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao remover contexto",
        description: "Ocorreu um erro. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  // Converte contexto da API para formato do formulário
  const convertContextToFormData = (context: Context): ContextFormData => {
    return {
      id: context.id,
      name: context.name,
      description: context.description || "",
      productInfo: context.productInfo || "",
      targetAudience: context.targetAudience || "",
      commonObjections: context.commonObjections && context.commonObjections.length > 0 
        ? context.commonObjections 
        : [{ objection: "", response: "" }],
      pricingStructure: context.pricingStructure || "",
      playbook: context.playbook || "",
      mentalTriggers: context.mentalTriggers || "",
      competitors: context.competitors && context.competitors.length > 0 
        ? context.competitors 
        : [""],
      is_active: context.is_active,
      vendedor_ativo: context.vendedor_ativo,
      vendedores: context.vendedores,
      created_at: context.created_at,
    };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F9FAFB] p-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="ml-3 text-lg font-medium text-gray-700">Carregando contextos...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9FAFB] p-6">
      <div className="max-w-7xl mx-auto space-y-8 animate-fade-in">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-[#111827] font-poppins">
                Configurar Contexto
              </h1>
              <p className="text-[#4B5563] text-lg mt-1">
                Configure o contexto e gerencie vendedores para personalizar as análises
              </p>
            </div>
          </div>
          
          {contexts.length > 0 && (
            <div className="flex space-x-3">
              <Button 
                onClick={handleToggleSalesContext}
                className="bg-[#3B82F6] hover:bg-[#2563EB] text-white font-semibold text-base px-6 py-3"
              >
                <Briefcase className="w-5 h-5 mr-2" />
                Contexto de Vendas
              </Button>
              {/*
              <Button 
                onClick={() => setIsCreating(true)}
                className="bg-[#34D399] hover:bg-[#059669] text-white font-semibold text-base px-6 py-3"
              >
                <Plus className="w-5 h-5 mr-2" />
                Contexto Simples
              </Button>
              */}
            </div>
          )}
        </div>

        {contexts.length === 0 && !isCreating && !isCreatingSales && (
          <EmptyContextState
            onCreateSimple={() => {}}
            onCreateSales={() => setIsCreatingSales(true)}
          />
        )}

        {isCreatingSales && (
          <SalesContextForm
            key={editingSalesContext ? editingSalesContext.id : `novo-${formResetCount}`}
            onSave={handleSalesContextSave}
            onCancel={() => {
              setEditingSalesContext(null);
              setFormResetCount(c => c + 1);
              setIsCreatingSales(true);
            }}
            context={editingSalesContext}
          />
        )}

        {/* Renderizar lista de contextos cadastrados abaixo do cadastro, exceto o que está sendo editado */}
        {contexts.length > 0 && (
          <div className="space-y-4 mt-8">
            {contexts
              .filter(context => !(isCreatingSales && editingSalesContext && context.id === editingSalesContext.id))
              .sort((a, b) => {
                // Contexto ativo sempre fica primeiro
                if (a.is_active && !b.is_active) return -1;
                if (!a.is_active && b.is_active) return 1;
                // Se ambos são ativos ou inativos, mantém ordem original (por data de criação)
                return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
              })
              .map(context => (
                <ContextCard
                  key={context.id}
                  context={context}
                  onEdit={() => {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    const formData = convertContextToFormData(context);
                    setEditingSalesContext(formData);
                    setIsCreatingSales(true);
                  }}
                  onDelete={() => handleDeleteContext(context.id)}
                  onVendedoresUpdate={handleVendedoresUpdate}
                  onVendedorAtivoUpdate={handleVendedorAtivoUpdate}
                  onSetActive={setActiveContext}
                />
              ))}
          </div>
        )}
      </div>
    </div>
  );
}