
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, Target, FileText, TrendingUp, Users, Star, CheckCircle, AlertCircle, X, DollarSign, Percent } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useContexts } from "@/hooks/useContexts";
import { useDashboardStats } from "@/hooks/useDashboardStats";
import { fetchLatestActivity } from "@/services/dashboardService";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useCreditsRemaining } from "@/hooks/useCreditsRemaining";

export default function Dashboard() {
  const navigate = useNavigate();
  const { contexts, hasContexts, hasActiveContexts, activeContexts, loading } = useContexts();
  const { user } = useAuth();

  const { stats: dashboardStats, loading: statsLoading, error: statsError } = useDashboardStats();
  const { credits, loading: creditsLoading } = useCreditsRemaining();
  const [hideCreditsWarning, setHideCreditsWarning] = useState(false);

  const formatCurrency = (value: number) => {
    const formatNumber = (num: number, suffix: string) => {
      const formatted = (num).toFixed(1);
      if (formatted.endsWith('.0')) {
        return `R$ ${Math.round(num)}${suffix}`;
      }
      return `R$ ${formatted}${suffix}`;
    };

    if (value >= 1e9) {
      return formatNumber(value / 1e9, 'B');
    }
    if (value >= 1e6) {
      return formatNumber(value / 1e6, 'M');
    }
    if (value >= 1e3) {
      return formatNumber(value / 1e3, 'k');
    }
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const stats = dashboardStats
    ? [
        {
          title: "Total de Análises",
          value: dashboardStats.totalAnalises,
          icon: FileText,
          color: "blue"
        },
        {
          title: "Média Geral de Pontuação",
          value: dashboardStats.mediaPontuacao.toFixed(1),
          suffix: "/100",
          icon: TrendingUp,
          color: "blue"
        },
        {
          title: "Taxa Conversão Preditiva",
          value: dashboardStats.taxaConversao.toFixed(1),
          suffix: "%",
          icon: Percent,
          color: "blue"
        },
        {
          title: "Pipeline Total",
          value: formatCurrency(dashboardStats.pipelineTotal),
          icon: DollarSign,
          color: "blue"
        }
      ]
    : [];

  const getStatCardColors = (color: string) => {
    const colors = {
      emerald: "bg-emerald-500 text-white",
      blue: "bg-blue-500 text-white",
      purple: "bg-purple-500 text-white",
      orange: "bg-orange-500 text-white",
      red: "bg-red-500 text-white",
      yellow: "bg-yellow-500 text-white"
    };
    return colors[color as keyof typeof colors] || colors.emerald;
  };

  const quickActions = [
    {
      title: "Analisar Nova Call",
      description: hasActiveContexts 
        ? `${activeContexts?.length || 0} contexto${(activeContexts?.length || 0) > 1 ? 's' : ''} disponível${(activeContexts?.length || 0) > 1 ? 'is' : ''}`
        : "Configure um contexto primeiro",
      icon: Upload,
      action: () => hasActiveContexts ? navigate("/interacoes") : navigate("/contexto"),
      variant: hasActiveContexts ? "default" : "outline",
      disabled: !hasActiveContexts,
      badge: hasActiveContexts ? null : "Configurar contexto"
    },
    {
      title: "Configurar Contexto",
      description: hasContexts 
        ? `${activeContexts?.length || 0} ativo${(activeContexts?.length || 0) !== 1 ? 's' : ''} de ${contexts?.length || 0} tota${(contexts?.length || 0) !== 1 ? 'is' : 'l'}`
        : "Nenhum contexto criado ainda",
      icon: Target,
      action: () => navigate("/contexto"),
      variant: "outline",
      badge: hasContexts ? (hasActiveContexts ? "Configurado" : "Ativar") : "Novo"
    },
    {
      title: "Ver Relatórios",
      description: "Acesse suas análises anteriores",
      icon: FileText,
      action: () => navigate("/relatorios"),
      variant: "outline"
    }
  ];

  // Estado para atividade recente
  const [latestActivity, setLatestActivity] = useState<any>(null);
  const [activityLoading, setActivityLoading] = useState(true);
  const [activityError, setActivityError] = useState<string | null>(null);

  useEffect(() => {
    async function loadLatestActivity() {
      setActivityLoading(true);
      setActivityError(null);
      try {
        if (!user?.id) return;
        const res = await fetchLatestActivity(user.id);
        setLatestActivity(res.data);
      } catch (err: any) {
        if (err instanceof Error && err.message === "NOT_FOUND") {
          setActivityError("NOT_FOUND");
        } else {
          setActivityError("Erro ao buscar atividade recente");
        }
      } finally {
        setActivityLoading(false);
      }
    }
    if (user?.id) loadLatestActivity();
  }, [user]);

  // Função para calcular tempo decorrido
  function timeAgo(dateString: string) {
    const now = new Date();
    const date = new Date(dateString);
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (seconds < 60) return `${seconds} segundo${seconds !== 1 ? 's' : ''} atrás`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} minuto${minutes !== 1 ? 's' : ''} atrás`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hora${hours !== 1 ? 's' : ''} atrás`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days} dia${days !== 1 ? 's' : ''} atrás`;
    const weeks = Math.floor(days / 7);
    if (weeks < 4) return `${weeks} semana${weeks !== 1 ? 's' : ''} atrás`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months} mês${months !== 1 ? 'es' : ''} atrás`;
    const years = Math.floor(days / 365);
    return `${years} ano${years !== 1 ? 's' : ''} atrás`;
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Warning de créditos */}
      {(!hideCreditsWarning && !creditsLoading && credits && credits.user_credits > 0) ? (() => {
        const percent = credits.analyses_this_month / credits.user_credits;
        if (percent >= 0.85) {
          const percentUsed = Math.round(percent * 100);
          return (
            <div className="flex items-center bg-amber-100 border border-amber-300 text-amber-900 px-4 py-3 rounded-lg mb-2 relative">
              <AlertCircle className="w-5 h-5 mr-3 text-amber-600" />
              <span className="font-semibold">Atenção: você já utilizou {percentUsed}% dos seus créditos deste mês. Considere adquirir mais créditos para não interromper suas análises.</span>
              <button
                onClick={() => setHideCreditsWarning(true)}
                className="absolute right-3 top-3 p-1 rounded hover:bg-amber-200 focus:outline-none flex items-center justify-center"
                aria-label="Fechar aviso de créditos"
                type="button"
              >
                <X className="w-4 h-4 text-amber-700" />
              </button>
            </div>
          );
        }
        return null;
      })() : null}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-slate-900 font-poppins">
            Dashboard
          </h1>
          <p className="text-slate-700 mt-3 text-lg">
            Bem-vindo de volta! Aqui está um resumo da sua performance.
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          {hasActiveContexts ? (
            <div className="flex items-center space-x-3 bg-emerald-50 px-4 py-3 rounded-lg border border-emerald-200">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              <span className="text-sm font-bold text-emerald-800">
                Contexto ativado
              </span>
            </div>
          ) : (
            <div className="flex items-center space-x-3 bg-amber-50 px-4 py-3 rounded-lg border border-amber-200">
              <AlertCircle className="w-5 h-5 text-amber-600" />
              <span className="text-sm font-bold text-amber-800">
                Configure um contexto
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="hover-lift bg-white border-slate-200 shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-base font-bold text-slate-700 mb-2">{stat.title}</p>
                  <div className="flex items-baseline mb-1">
                    <p className="text-4xl font-bold text-slate-900">{stat.value}</p>
                    {stat.suffix && (
                      <span className="text-lg font-normal text-slate-500 ml-1">{stat.suffix}</span>
                    )}
                  </div>
                </div>
                <div className={`w-14 h-14 rounded-lg flex items-center justify-center ${getStatCardColors(stat.color)}`}>
                  <stat.icon className="w-7 h-7" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center text-2xl font-bold text-slate-900">
            <TrendingUp className="w-6 h-6 mr-3 text-emerald-600" />
            Ações Rápidas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {quickActions.map((action, index) => (
              <div 
                key={index}
                className="p-6 border-2 border-slate-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50/50 transition-all group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-slate-100 group-hover:bg-emerald-100 rounded-lg flex items-center justify-center transition-colors">
                    <action.icon className="w-6 h-6 text-slate-700 group-hover:text-emerald-600" />
                  </div>
                  {action.badge && (
                    <Badge variant="secondary" className="text-xs font-semibold">
                      {action.badge}
                    </Badge>
                  )}
                </div>
                
                <h3 className="font-bold text-slate-900 mb-2 text-lg">{action.title}</h3>
                <p className="text-sm text-slate-700 mb-5 leading-relaxed">{action.description}</p>
                
                <Button
                  variant={action.variant as "default" | "outline"}
                  size="sm"
                  onClick={action.action}
                  disabled={action.disabled}
                  className="w-full font-semibold"
                >
                  {action.title}
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-slate-900">Atividade Recente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activityLoading ? (
              <div className="text-slate-500">Carregando...</div>
            ) : activityError === "NOT_FOUND" ? (
              <div className="text-slate-500 text-left">
                <span>Nenhuma atividade recente encontrada ainda. Configure um contexto e faça sua primeira análise para começar!</span>
              </div>
            ) : activityError ? (
              <div className="text-red-500">{activityError}</div>
            ) : latestActivity ? (
              <>
                {latestActivity.analyse && (
                  <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-lg">
                    <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                      <Upload className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-slate-900">Call Analisada com Sucesso!</p>
                      <p className="text-xs text-slate-600">{timeAgo(latestActivity.analyse.created_at)}</p>
                    </div>
                  </div>
                )}
                {latestActivity.context && (
                  <div className="flex items-center space-x-4 p-4 bg-slate-50 rounded-lg">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Target className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-bold text-slate-900">Contexto Atualizado!</p>
                      <p className="text-xs text-slate-600">{timeAgo(latestActivity.context.updated_at)}</p>
                    </div>
                  </div>
                )}
                {!latestActivity.analyse && !latestActivity.context && (
                  <div className="text-slate-500">Nenhuma atividade recente encontrada.</div>
                )}
              </>
            ) : (
              <div className="text-slate-500">Nenhuma atividade recente encontrada.</div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
