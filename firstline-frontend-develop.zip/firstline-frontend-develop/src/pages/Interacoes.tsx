import { useEffect, useState, useRef } from 'react';
import { useContexts } from "@/hooks/useContexts";
import { useSecureFileUpload } from "@/hooks/useSecureFileUpload";
import { AnalysisResults } from "@/components/analysis/AnalysisResults";
import { FileUploadCard } from "@/components/upload/FileUploadCard";
import { ContextStatusCard } from "@/components/upload/ContextStatusCard";
import { InstructionsCard } from "@/components/upload/InstructionsCard";
import { ProcessingProgress } from "@/components/upload/ProcessingProgress";
import { useToast } from "@/hooks/use-toast";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface AnalysisData {
  analysis: {
    id: string;
    score_geral: number;
    pontos_positivos: string[];
    pontos_atencao: string[];
    objecoes_identificadas: string[];
    sugestoes_melhoria: string[];
    proximos_passos: string[];
    resumo: string;
    client_name: string;
  };
  transcription: string;
  contextUsed: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

export default function Interacoes() {
  const { toast } = useToast();
  const { activeContexts, hasActiveContexts, loading: contextsLoading, contexts } = useContexts();
  const [analysisResult, setAnalysisResult] = useState<AnalysisData | null>(null);
  const [sellers, setSellers] = useState<Array<{ id: string; name: string }>>([]);
  const [audioDuration, setAudioDuration] = useState<number | undefined>(undefined);
  const isMountedRef = useRef(true);
  
  const {
    selectedFile,
    uploadType,
    selectedContext,
    selectedVendedor,
    selectedAnalysisName,
    isUploading,
    textContent,
    uploadProgress,
    estimatedTime,
    autoDetectSpeakers,
    speakersCount,
    isCompressing,
    compressionProgress,
    queue,
    setUploadType,
    setSelectedContext,
    setSelectedVendedor,
    setSelectedAnalysisName,
    handleFileSelect,
    handleTextContentChange,
    handleSecureUpload,
    handleAutoDetectSpeakersChange,
    handleSpeakersCountChange,
    whatsAppZip
  } = useSecureFileUpload();

  useEffect(() => {
    if (selectedFile && uploadType === 'audio') {
      const audio = document.createElement('audio');
      audio.src = URL.createObjectURL(selectedFile);
      audio.addEventListener('loadedmetadata', () => {
        setAudioDuration(audio.duration);
        URL.revokeObjectURL(audio.src);
      });
    } else {
      setAudioDuration(undefined);
    }
  }, [selectedFile, uploadType]);

  // Buscar vendedores
  const fetchSellers = async () => {
    try {
      const response = await apiFetch(`${API_BASE_URL}/sellers`);
      if (response.ok) {
        const data = await response.json();
        // Adaptação para garantir o formato {id, name}
        if (Array.isArray(data.data)) {
          setSellers(data.data.map((v: any) => ({
            id: v.id || v.vendedor_id,
            name: v.name || v.vendedor
          })));
        } else if (Array.isArray(data)) {
          setSellers(data.map((v: any) => ({
            id: v.id || v.vendedor_id,
            name: v.name || v.vendedor
          })));
        } else {
          setSellers([]);
        }
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  // Buscar vendedores ao montar o componente
  useEffect(() => {
    fetchSellers();
  }, []);

  // Auto-select context if only one is active
  useEffect(() => {
    if (activeContexts.length === 1 && !selectedContext && isMountedRef.current) {
      setSelectedContext(activeContexts[0].id);
    }
  }, [activeContexts, selectedContext, setSelectedContext]);

  useEffect(() => {
    if (!isMountedRef.current) return;
    if (sellers.length > 0) {
      if (!selectedVendedor || !sellers.some(v => v.id === selectedVendedor)) {
        setSelectedVendedor(sellers[0].id);
      }
    } else if (selectedVendedor) {
      setSelectedVendedor("");
    }
  }, [sellers]);

  const selectedContextData = contexts.find(ctx => ctx.id === selectedContext);
  const vendedorNome = sellers.find(s => s.id === selectedVendedor)?.name || "";

  const handleUpload = async () => {
    if (!isMountedRef.current) return;
    let vendedorParaAnalise = selectedVendedor;
    // Garantir que o vendedor selecionado existe na lista
    if (!sellers.some(v => v.id === vendedorParaAnalise)) {
      if (sellers.length > 0) {
        vendedorParaAnalise = sellers[0].id;
        setSelectedVendedor(vendedorParaAnalise);
      } else {
        vendedorParaAnalise = "";
        setSelectedVendedor("");
      }
    }
    try {
  const result = await handleSecureUpload(contexts, hasActiveContexts, sellers);
      if (result && result.analysis && isMountedRef.current) {
        setAnalysisResult(result);
        // Reset WhatsApp ZIP state after successful upload
        if (uploadType === 'whatsapp') {
          whatsAppZip.reset();
        }
        toast({
          title: "Análise concluída",
          description: "Sua análise foi processada com sucesso!",
        });
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      // Error já tratado
    }
  };

  const handleNewAnalysis = () => {
    if (!isMountedRef.current) return;
    setAnalysisResult(null);
  };

  // Calcular tempo estimado para exibir na barra
  let estimatedTimeValue = estimatedTime;
  if (audioDuration) {
    estimatedTimeValue = audioDuration * 0.15;
  } else if (textContent) {
    estimatedTimeValue = textContent.length * 0.005;
  }

  // Show analysis results if available
  if (analysisResult) {
    return (
      <div className="space-y-8 animate-fade-in bg-slate-50 min-h-screen">
        <div className="bg-white border-b border-slate-200 px-6 py-8">
          <h1 className="text-3xl font-bold text-slate-900 font-poppins">
            Resultado da Análise
          </h1>
          <p className="text-slate-600 mt-2 text-lg">
            Análise inteligente da sua conversa de vendas
          </p>
        </div>

        <div className="px-6">
          <AnalysisResults
            transcription={analysisResult.transcription}
            analysis={analysisResult.analysis}
            clientName={analysisResult.analysis.client_name}
            analysisId={analysisResult.analysis.id}
            contextUsed={selectedContextData}
            vendedor={vendedorNome}
            onNewAnalysis={handleNewAnalysis}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in bg-slate-50 min-h-screen">
      <div className="bg-white border-b border-slate-200 px-6 py-8">
        <h1 className="text-3xl font-bold text-slate-900 font-poppins">
          Analisar Interações
        </h1>
        <p className="text-slate-600 mt-2 text-lg">
          Faça upload de suas calls ou conversas para análise com IA
        </p>
      </div>

      <div className="px-6 space-y-6">
        <ContextStatusCard 
          contextsLoading={contextsLoading}
          hasActiveContexts={hasActiveContexts}
          activeContexts={activeContexts}
        />

        <ProcessingProgress
          isUploading={isUploading}
          uploadProgress={uploadProgress}
          estimatedTime={estimatedTimeValue}
          isCompressing={isCompressing}
          compressionProgress={compressionProgress}
          queueLength={queue.length}
          audioDuration={audioDuration}
          textLength={textContent ? textContent.length : undefined}
        />

        <FileUploadCard
          uploadType={uploadType}
          selectedFile={selectedFile}
          selectedContext={selectedContext}
          selectedVendedor={selectedVendedor}
          selectedAnalysisName={selectedAnalysisName}
          textContent={textContent}
          isUploading={isUploading}
          activeContexts={activeContexts}
          selectedContextData={selectedContextData}
          autoDetectSpeakers={autoDetectSpeakers}
          speakersCount={speakersCount}
          onUploadTypeChange={setUploadType}
          onFileSelect={handleFileSelect}
          onContextChange={setSelectedContext}
          onVendedorChange={setSelectedVendedor}
          onAnalysisNameChange={setSelectedAnalysisName}
          onUpload={handleUpload}
          onTextContentChange={handleTextContentChange}
          onAutoDetectSpeakersChange={handleAutoDetectSpeakersChange}
          onSpeakersCountChange={handleSpeakersCountChange}
          hasActiveContexts={hasActiveContexts}
          sellers={sellers}
          whatsAppZip={whatsAppZip}
        />

        <InstructionsCard />
      </div>
    </div>
  );
}
