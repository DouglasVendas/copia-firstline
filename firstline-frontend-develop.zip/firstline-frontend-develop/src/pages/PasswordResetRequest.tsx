import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { AuthHeader } from "@/components/auth/AuthHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Mail, Lock, Eye, EyeOff, Check, X, Shield } from "lucide-react";

export default function PasswordResetRequest() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showPasswordPopover, setShowPasswordPopover] = useState(false);
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");

  // Função para validar senha forte
  const validatePassword = (password: string) => {
    const minLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar
    };
  };

  const handleRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/auth/password-reset/request`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      if (response.ok && data.success) {
        toast({
          title: "Sucesso!",
          description: data.message || "Enviamos um email com as instruções para redefinição de senha.",
          variant: "success",
        });
      } else {
        toast({
          title: "Erro",
          description: data.message || "Não foi possível enviar o email de recuperação.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao tentar enviar o email de recuperação.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async (e: React.FormEvent) => {
    e.preventDefault();
    const passwordValidation = validatePassword(newPassword);
    if (!passwordValidation.isValid) {
      toast({
        title: "Senha não atende aos requisitos",
        description: "A senha deve atender a todos os requisitos de segurança.",
        variant: "destructive",
      });
      return;
    }
    if (newPassword !== confirmPassword) {
      toast({
        title: "Senhas não coincidem",
        description: "A senha e a confirmação devem ser iguais.",
        variant: "destructive",
      });
      return;
    }
    setLoading(true);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL}/auth/password-reset/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, new_password: newPassword }),
      });
      const data = await response.json();
      if (response.ok && data.success) {
        navigate('/auth?reset=success');
      } else {
        toast({
          title: "Erro",
          description: data.message || "Não foi possível redefinir a senha.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Erro ao tentar redefinir a senha.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex justify-center p-6">
      <div className="w-full max-w-md space-y-6">
        <AuthHeader isSignUp={false} />
        <Card className="bg-white border-gray-200 shadow-lg mt-8">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl text-gray-800 text-center">
              {token ? "Redefinir senha" : "Recuperar senha"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {token ? (
              <form onSubmit={handleConfirm} className="space-y-4">
                <div>
                  <label htmlFor="new-password" className="block text-gray-700 font-medium mb-1 pl-1 flex items-center">
                    <Lock className="w-4 h-4 mr-2" />
                    Nova senha
                  </label>
                  <div className="relative flex items-center">
                    <Input
                      id="new-password"
                      type={showPassword ? "text" : "password"}
                      value={newPassword}
                      onChange={e => setNewPassword(e.target.value)}
                      required
                      placeholder="Mínimo 8 caracteres"
                      className="bg-white border-gray-300 focus:border-emerald-400 text-gray-900 mb-2"
                      onFocus={() => setShowPasswordPopover(true)}
                      onBlur={() => setTimeout(() => setShowPasswordPopover(false), 150)}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                    {/* Popover de requisitos de senha */}
                    {showPasswordPopover && (
                      <div className="absolute z-20 left-full ml-3 w-72 bg-white border border-gray-200 rounded-xl shadow-xl p-4 text-sm animate-in slide-in-from-left-2 duration-200">
                        <div className="flex items-center gap-2 mb-3 text-gray-800">
                          <Shield size={16} className="text-blue-500" />
                          <span className="font-semibold">Requisitos da Senha</span>
                        </div>
                        <div className="space-y-2.5">
                          <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                            validatePassword(newPassword).minLength 
                              ? 'bg-green-50 text-green-700 border border-green-200' 
                              : 'bg-gray-50 text-gray-600 border border-gray-200'
                          }`}>
                            <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                              validatePassword(newPassword).minLength 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-300 text-gray-500'
                            }`}>
                              {validatePassword(newPassword).minLength ? (
                                <Check size={12} />
                              ) : (
                                <X size={12} />
                              )}
                            </div>
                            <span className="text-xs font-medium">Mínimo 8 caracteres</span>
                          </div>
                          
                          <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                            validatePassword(newPassword).hasUpperCase 
                              ? 'bg-green-50 text-green-700 border border-green-200' 
                              : 'bg-gray-50 text-gray-600 border border-gray-200'
                          }`}>
                            <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                              validatePassword(newPassword).hasUpperCase 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-300 text-gray-500'
                            }`}>
                              {validatePassword(newPassword).hasUpperCase ? (
                                <Check size={12} />
                              ) : (
                                <X size={12} />
                              )}
                            </div>
                            <span className="text-xs font-medium">Uma letra maiúscula (A-Z)</span>
                          </div>
                          
                          <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                            validatePassword(newPassword).hasLowerCase 
                              ? 'bg-green-50 text-green-700 border border-green-200' 
                              : 'bg-gray-50 text-gray-600 border border-gray-200'
                          }`}>
                            <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                              validatePassword(newPassword).hasLowerCase 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-300 text-gray-500'
                            }`}>
                              {validatePassword(newPassword).hasLowerCase ? (
                                <Check size={12} />
                              ) : (
                                <X size={12} />
                              )}
                            </div>
                            <span className="text-xs font-medium">Uma letra minúscula (a-z)</span>
                          </div>
                          
                          <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                            validatePassword(newPassword).hasNumbers 
                              ? 'bg-green-50 text-green-700 border border-green-200' 
                              : 'bg-gray-50 text-gray-600 border border-gray-200'
                          }`}>
                            <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                              validatePassword(newPassword).hasNumbers 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-300 text-gray-500'
                            }`}>
                              {validatePassword(newPassword).hasNumbers ? (
                                <Check size={12} />
                              ) : (
                                <X size={12} />
                              )}
                            </div>
                            <span className="text-xs font-medium">Um número (0-9)</span>
                          </div>
                          
                          <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                            validatePassword(newPassword).hasSpecialChar 
                              ? 'bg-green-50 text-green-700 border border-green-200' 
                              : 'bg-gray-50 text-gray-600 border border-gray-200'
                          }`}>
                            <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                              validatePassword(newPassword).hasSpecialChar 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-300 text-gray-500'
                            }`}>
                              {validatePassword(newPassword).hasSpecialChar ? (
                                <Check size={12} />
                              ) : (
                                <X size={12} />
                              )}
                            </div>
                            <span className="text-xs font-medium">Um caractere especial</span>
                          </div>
                        </div>
                        
                        {/* Indicador de força da senha */}
                        <div className="mt-4 pt-3 border-t border-gray-200">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs font-medium text-gray-600">Força da senha:</span>
                            <span className={`text-xs font-semibold ${
                              validatePassword(newPassword).isValid 
                                ? 'text-green-600' 
                                : Object.values(validatePassword(newPassword)).filter(Boolean).length >= 3
                                ? 'text-yellow-600'
                                : 'text-red-500'
                            }`}>
                              {validatePassword(newPassword).isValid 
                                ? 'Forte' 
                                : Object.values(validatePassword(newPassword)).filter(Boolean).length >= 3
                                ? 'Média'
                                : 'Fraca'}
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full transition-all duration-300 ${
                                validatePassword(newPassword).isValid 
                                  ? 'bg-green-500 w-full' 
                                  : Object.values(validatePassword(newPassword)).filter(Boolean).length >= 3
                                  ? 'bg-yellow-500 w-2/3'
                                  : 'bg-red-500 w-1/3'
                              }`}
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div>
                  <label htmlFor="confirm-password" className="block text-gray-700 font-medium mb-1 pl-1 flex items-center">
                    <Lock className="w-4 h-4 mr-2" />
                    Confirmar nova senha
                  </label>
                  <div className="relative">
                    <Input
                      id="confirm-password"
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      required
                      placeholder="Confirme a nova senha"
                      className="bg-white border-gray-300 focus:border-emerald-400 text-gray-900 mb-2"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                      tabIndex={-1}
                    >
                      {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                  {confirmPassword && newPassword !== confirmPassword && (
                    <p className="text-xs text-red-500 mt-1">As senhas não coincidem</p>
                  )}
                </div>
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loading || !newPassword || !confirmPassword || !validatePassword(newPassword).isValid || newPassword !== confirmPassword}
                >
                  Redefinir senha
                </Button>
              </form>
            ) : (
              <form onSubmit={handleRequest} className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-gray-700 font-medium mb-1 flex items-center pl-1">
                    <Mail className="w-4 h-4 mr-2" />
                    E-mail
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                    placeholder="Digite seu e-mail"
                    className="bg-white border-gray-300 focus:border-emerald-400 text-gray-900 mb-1"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading || !email}>
                  Enviar
                </Button>
                <Button type="button" variant="link" className="w-full mt-2 text-blue-500 hover:text-blue-600 font-medium transition-colors" onClick={() => navigate('/auth')}>
                  Voltar para o login
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
} 