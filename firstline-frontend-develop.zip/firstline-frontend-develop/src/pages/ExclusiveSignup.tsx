
import { useState, useEffect } from "react";
import { useParams, Navigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useTokenValidation } from "@/hooks/useTokenValidation";
import { AuthHeader } from "@/components/auth/AuthHeader";
import { TokenValidationCard } from "@/components/auth/TokenValidationCard";
import { ExclusiveSignupForm } from "@/components/auth/ExclusiveSignupForm";

export default function ExclusiveSignup() {
  const { token } = useParams();
  const { toast } = useToast();
  const { validateToken, loading: tokenLoading, tokenData } = useTokenValidation();
  
  const [tokenValid, setTokenValid] = useState(false);

  useEffect(() => {
    if (token) {
      validateTokenOnLoad();
    }
  }, [token]);

  const validateTokenOnLoad = async () => {
    if (!token) return;
    
    const result = await validateToken(token);
    if (result.valid) {
      setTokenValid(true);
      toast({
        title: "Token válido!",
        description: `Acesso autorizado: ${result.tokenData?.label || 'Cadastro exclusivo'}`,
      });
    } else {
      toast({
        title: "Token inválido",
        description: result.error || "Este link de cadastro não é válido ou expirou.",
        variant: "destructive",
      });
    }
  };

  const handleReturnHome = () => {
    window.location.href = '/';
  };

  // Redirect if no token provided
  if (!token) {
    return <Navigate to="/auth" replace />;
  }

  // Show loading while validating token
  if (tokenLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Validando acesso...</p>
        </div>
      </div>
    );
  }

  // Show error if token is invalid
  if (!tokenValid) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <TokenValidationCard 
          tokenValid={false} 
          tokenData={null} 
          onReturnHome={handleReturnHome} 
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md space-y-6">
        <AuthHeader isSignUp={true} />
        
        <Card className="bg-white border-gray-200 shadow-lg">
          <CardHeader className="pb-4">
            <TokenValidationCard 
              tokenValid={true} 
              tokenData={tokenData} 
              onReturnHome={handleReturnHome} 
            />
            <CardTitle className="text-xl text-gray-800 text-center">
              Cadastro Exclusivo
            </CardTitle>
            {tokenData?.label && (
              <p className="text-sm text-gray-600 text-center">{tokenData.label}</p>
            )}
          </CardHeader>
          <CardContent>
            <ExclusiveSignupForm tokenData={tokenData} onSubmit={() => Promise.resolve(true)} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
