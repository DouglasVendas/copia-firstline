
import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { AuthHeader } from "@/components/auth/AuthHeader";
import { AuthFormFields } from "@/components/auth/AuthFormFields";
import { AuthSubmitButton } from "@/components/auth/AuthSubmitButton";
import { AuthToggle } from "@/components/auth/AuthToggle";
import { useAuth } from "@/hooks/useAuth";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import privacyHtml from "../legal/privacy-policy.html?raw";
import termsHtml from "../legal/terms-of-use.html?raw";
import { AuthRedirectError } from '@/lib/apiFetch';
import TwoFactorAuth from "@/components/auth/TwoFactorAuth";
import { useTwoFactorAuth } from "@/hooks/useTwoFactorAuth";
import { SEO } from "@/components/SEO";

export default function Auth() {
  return (
    <>
      <SEO 
        title="FirstLineAI"
        description="Transforme suas conversas de vendas em insights acionáveis de receita. A IA treina o gestor. O gestor treina o time. O time bate meta."
        keywords="FirstLineAI, IA vendas, análise conversas, gestão vendas"
      />
      <AuthContent />
    </>
  );
}

function AuthContent() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register, user } = useAuth();
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [openModal, setOpenModal] = useState<null | "privacy" | "terms">(null);
  const { show2FA, pendingEmail, handleLoginWith2FA, handle2FASuccess, handle2FACancel } = useTwoFactorAuth();

  useEffect(() => {
    const handler = () => setOpenModal(null);
    window.addEventListener('close-all-overlays', handler);
    
    // Listener para navegar após sucesso do 2FA
    const handle2FASuccess = () => {
      navigate('/', { replace: true });
    };
    window.addEventListener('2fa-success', handle2FASuccess);
    
    return () => {
      window.removeEventListener('close-all-overlays', handler);
      window.removeEventListener('2fa-success', handle2FASuccess);
    };
  }, [navigate]);
  
  useEffect(() => {
    if (user) {
      navigate('/', { replace: true });
    }
  }, [user, navigate]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('reset') === 'success') {
      toast({
        title: 'Senha redefinida com sucesso!',
        description: 'Agora você pode acessar com sua nova senha.',
        variant: 'success',
      });
      // Remove o parâmetro da URL após exibir o toast
      params.delete('reset');
      navigate({ search: params.toString() }, { replace: true });
    }
  }, [location.search, toast, navigate]);

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    companyName: '',
    responsibleName: '',
    phone: '',
    cnpj: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const validateForm = () => {
    if (!formData.email || !formData.password) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha e-mail e senha.",
        variant: "destructive"
      });
      return false;
    }

    if (isSignUp) {
      if (formData.password !== formData.confirmPassword) {
        toast({
          title: "Senhas não coincidem",
          description: "As senhas devem ser iguais.",
          variant: "destructive"
        });
        return false;
      }

      if (!formData.companyName || !formData.responsibleName || !formData.phone || !formData.cnpj) {
        toast({
          title: "Campos obrigatórios",
          description: "Por favor, preencha todos os campos obrigatórios.",
          variant: "destructive"
        });
        return false;
      }
    }

    return true;
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);

    try {
      if (isSignUp) {
        await register(formData);
        toast({
          title: "Conta criada com sucesso!",
          description: "Bem-vindo ao First Line AI.",
        });
        // Aguarda um pouco antes de navegar para permitir que o navegador detecte o sucesso
        setTimeout(() => {
          navigate('/', { replace: true });
        }, 100);
      } else {
        const requires2FA = await handleLoginWith2FA(formData.email, formData.password);
        
        // Se não requer 2FA, aguarda antes de navegar para permitir salvamento de senha
        if (!requires2FA) {
          setTimeout(() => {
            navigate('/', { replace: true });
          }, 100);
        }
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex justify-center items-center p-6">
      <div className="w-full max-w-md space-y-6 mt-16 md:mt-20">
        <AuthHeader isSignUp={isSignUp} />

        <Card className="bg-white border-gray-200 shadow-lg mt-6 md:mt-10">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl text-gray-800 text-center">
              {isSignUp ? "Criar Conta" : "Login"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form 
              onSubmit={onSubmit} 
              className="space-y-4" 
              autoComplete="on"
              id={isSignUp ? "signup-form" : "login-form"}
              method="post"
            >
              <AuthFormFields
                isSignUp={isSignUp}
                formData={formData}
                showPassword={showPassword}
                showConfirmPassword={showConfirmPassword}
                onInputChange={handleInputChange}
                onTogglePassword={() => setShowPassword(!showPassword)}
                onToggleConfirmPassword={() => setShowConfirmPassword(!showConfirmPassword)}
                toast={toast}
              />

              <div className="flex items-start gap-2 mt-2 pl-1">
                <Checkbox id="accept-terms" checked={acceptedTerms} onCheckedChange={v => setAcceptedTerms(v === true)} />
                <label htmlFor="accept-terms" className="text-xs text-gray-500 select-none">
                  Eu li e aceito os
                  <button type="button" className="underline ml-1 hover:text-gray-700 transition-colors" onClick={() => setOpenModal("terms")}>Termos de Uso</button>{' '}
                  {' '}e a
                  <button type="button" className="underline ml-1 hover:text-gray-700 transition-colors" onClick={() => setOpenModal("privacy")}>Política de Privacidade</button>
                </label>
              </div>
              <Dialog open={openModal !== null} onOpenChange={open => setOpenModal(open ? openModal : null)}>
                <DialogContent className="w-[600px] max-w-full h-[60vh] max-h-[60vh] overflow-y-auto animate-slide-in bg-white">
                  <DialogHeader>
                    <DialogTitle className="text-base text-gray-700">
                      {openModal === "terms" ? "Termos de Uso" : "Política de Privacidade"}
                    </DialogTitle>
                  </DialogHeader>
                  <div
                    className="prose max-w-none"
                    style={{ maxHeight: '45vh', overflowY: 'auto' }}
                    dangerouslySetInnerHTML={{ __html: `
                      <style>
                        .popup-legal p { font-size: 11px !important; color: #4b5563 !important; margin-bottom: 0.7em !important; }
                        .popup-legal span, .popup-legal div { font-size: 11px !important; color: #4b5563 !important; }
                        .popup-legal ul, .popup-legal ol { font-size: 0.875rem !important; color: #4b5563 !important; margin-left: 1.25em; list-style-position: inside !important; list-style-type: initial !important; margin-bottom: 0 !important; }
                        .popup-legal li { font-size: 0.875rem !important; color: #4b5563 !important; list-style-type: initial !important; margin-bottom: 0.2em !important; line-height: 1.2 !important; }
                      </style>
                      <div class='popup-legal'>${openModal === "terms" ? termsHtml : privacyHtml}</div>
                    ` }}
                  />
                  <div className="flex justify-end mt-4">
                    <DialogClose asChild>
                      <Button variant="outline" size="sm">Fechar</Button>
                    </DialogClose>
                  </div>
                </DialogContent>
              </Dialog>

              <AuthSubmitButton loading={loading} isSignUp={isSignUp} 
                disabled={
                  loading ||
                  !formData.email ||
                  !formData.password ||
                  (isSignUp && (!formData.companyName || !formData.responsibleName || !formData.phone || !formData.cnpj)) ||
                  !acceptedTerms
                }
              />
            </form>

            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-gray-300" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">ou</span>
              </div>
            </div>

            <AuthToggle isSignUp={isSignUp} onToggle={() => setIsSignUp(!isSignUp)} />
          </CardContent>
        </Card>
      </div>

      {/* Modal 2FA */}
      {show2FA && (
        <TwoFactorAuth
          email={pendingEmail}
          onSuccess={handle2FASuccess}
          onCancel={handle2FACancel}
        />
      )}
    </div>
  );
}
