
import Dashboard from "./Dashboard";
import { SEO } from "@/components/SEO";

const Index = () => {
  return (
    <>
      <SEO 
        title="FirstLineAI"
        description="Plataforma de IA empresarial que transforma suas conversas de vendas em insights acionáveis de receita e otimizações estratégicas. Venda não se escala com fé. Se escala com dados."
        keywords="IA, inteligência artificial, vendas, análise de conversas, receita, gestão de vendas, otimização estratégica, FirstLineAI"
      />
      <Dashboard />
    </>
  );
};

export default Index;
