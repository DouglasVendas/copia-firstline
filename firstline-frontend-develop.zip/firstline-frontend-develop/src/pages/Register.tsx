import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { AuthHeader } from "@/components/auth/AuthHeader";
import { SEO } from "@/components/SEO";
import { RegisterForm } from "@/components/auth/RegisterForm";
import { useTokenRegistration } from "@/hooks/useTokenRegistration";
import { useAuth } from "@/hooks/useAuth";

export default function Register() {
  return (
    <>
      <SEO 
        title="Cadastro - FirstLineAI"
        description="Complete seu cadastro na FirstLineAI e comece a transformar suas conversas de vendas em insights acionáveis."
        keywords="FirstLineAI, registro, cadastro, IA vendas"
      />
      <RegisterContent />
    </>
  );
}

function RegisterContent() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const {
    validatingToken,
    tokenData,
    tokenValid,
    loading,
    registerWithToken,
    validateRegistrationToken
  } = useTokenRegistration();

  const { signOut } = useAuth();

  useEffect(() => {
    if (!token) {
      toast({
        title: "Token não encontrado",
        description: "Link inválido. Verifique se você está usando o link correto do email.",
        variant: "destructive"
      });
      navigate('/auth', { replace: true });
      return;
    }

    validateRegistrationToken(token);
  }, [token, validateRegistrationToken, navigate, toast]);

  const handleSubmit = async (formData: {
    email: string;
    password: string;
    confirmPassword: string;
    companyName: string;
    responsibleName: string;
    phone: string;
    cnpj?: string;
  }) => {
    if (!token) return;

    try {
      await registerWithToken(token, formData);
      
      toast({
        title: "Cadastro realizado com sucesso!",
        description: "Bem-vindo à FirstLineAI. Você será redirecionado para fazer login.",
      });

      // Redireciona para login após sucesso
      setTimeout(async () => {
        await signOut();
        navigate('/auth', { replace: true });
      }, 2000);
    } catch (error) {
      // O erro já é tratado no hook
    }
  };

  // Exibe loading enquanto valida o token
  if (validatingToken) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Validando token de registro...</p>
        </div>
      </div>
    );
  }

  // Se token inválido, exibe mensagem de erro
  if (!tokenValid) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <Card className="bg-white border-red-200 shadow-lg">
            <CardHeader className="text-center">
              <CardTitle className="text-xl text-red-600">Token Inválido</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-600">
                Este link de cadastro não é válido ou já expirou.
              </p>
              <p className="text-sm text-gray-500">
                Entre em contato conosco para gerar um novo link de cadastro.
              </p>
              <button
                onClick={() => navigate('/auth')}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
              >
                Ir para Login
              </button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex justify-center items-center p-6">
      <div className="w-full max-w-md space-y-6 mt-16 md:mt-20">
        <AuthHeader isSignUp={true} />

        <Card className="bg-white border-gray-200 shadow-lg mt-6 md:mt-10">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl text-gray-800 text-center">
              Complete seu Cadastro
            </CardTitle>
            {tokenData?.subscription_plan && (
              <p className="text-xs text-blue-600 text-center">
                Plano: {tokenData.subscription_plan}
              </p>
            )}
          </CardHeader>
          <CardContent>
            <RegisterForm 
              onSubmit={handleSubmit}
              loading={loading}
              email={tokenData?.customer_email || ''}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
