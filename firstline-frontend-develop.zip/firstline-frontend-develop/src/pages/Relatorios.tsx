
import { useState, useEffect, useMemo } from "react";
import { useLocation } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, FileText, TrendingUp, Brain } from "lucide-react";
import { ReportViewer } from "@/components/analysis/ReportViewer";
import { TemporalComparison } from "@/components/analytics/TemporalComparison";
import { PredictiveAI } from "@/components/analytics/PredictiveAI";
import { useReportsData } from "@/hooks/useReportsData";
import { useReportActions } from "@/hooks/useReportActions";
import { ReportsStats } from "@/components/reports/ReportsStats";
import { ReportsFilters } from "@/components/reports/ReportsFilters";
import { AnalysisListItem } from "@/components/reports/AnalysisListItem";
import { AdminUserSearch } from "@/components/reports/AdminUserSearch";
import { ContextsProvider, useContextsFromProvider } from "@/contexts/ContextsProvider";

interface Analysis {
  id: string;
  created_at: string;
  client_name: string;
  score_geral: number;
  upload_type: string;
  resumo: string;
  pontos_positivos: string[];
  pontos_atencao: string[];
  objecoes_identificadas: string[];
  sugestoes_melhoria: string[];
  proximos_passos: string[];
  context_uuid: string;
  transcription: string;
  vendedor: string;
  // Enhanced AI analysis fields
  framework_analysis?: any;
  coaching_insights?: string[];
  performance_analysis?: any;
  mental_triggers?: any;
  reformulacoes_pnl?: any;
  plano_fechamento?: string[];
  ia_preditiva?: any;
  analysis_name: string;
  audio_duration_seconds?: number;
  desempenho_geral?: {
    abertura: number;
    descoberta: number;
    fechamento: number;
    qualificacao: number;
  };
  tempo_de_fala?: {
    tempo_geral: {
      vendedor: number;
      cliente: number;
    };
    tempo_por_fase: {
      abertura: number;
      descoberta: number;
      qualificacao: number;
      fechamento: number;
    };
  };
}

function RelatoriosContent() {
  const { contexts, activeContexts } = useContextsFromProvider();
  const location = useLocation();
  const {
    analyses,
    filteredAnalyses,
    loading,
    searchTerm,
    selectedVendedor,
    dateRange,
    scoreRange,
    selectedContext,
    vendedores,
    isAdmin,
    adminUserEmail,
    setAdminUserEmail,
    adminSearchLoading,
    searchUserAnalyses,
    clearAdminSearch,
    setSearchTerm,
    setSelectedVendedor,
    setDateRange,
    setScoreRange,
    setSelectedContext,
    fetchAnalyses,
    updateAnalysisName
  } = useReportsData();

  const { loadingAction, handleDownloadPDF, handleShareLink } = useReportActions();

  const [selectedAnalysis, setSelectedAnalysis] = useState<Analysis | null>(null);

  // Check if analysis was passed from bot page
  useEffect(() => {
    if (location.state?.selectedAnalysis && location.state?.fromBot) {
      setSelectedAnalysis(location.state.selectedAnalysis);
      // Clear the location state to prevent re-loading on refresh
      window.history.replaceState({}, document.title);
    }
  }, [location.state]);

  const handleViewReport = (analysis: Analysis) => {
    setSelectedAnalysis(analysis);
  };

  const handleBackToList = () => {
    setSelectedAnalysis(null);
  };

  const handleContextChanged = () => {
    fetchAnalyses();
  };

  const handleAnalysisNameChanged = (analysisId: string, newName: string) => {
    updateAnalysisName(analysisId, newName);
  };

  const onDownloadPDF = () => {
    if (selectedAnalysis) {
      const contextUsed = contexts.find(ctx => ctx.id === selectedAnalysis.context_uuid);
      handleDownloadPDF(selectedAnalysis, contextUsed);
    }
  };

  const onShareLink = () => {
    if (selectedAnalysis) {
      handleShareLink(selectedAnalysis);
    }
  };

  // Memoizar a lista de análises para evitar re-renders desnecessários
  const analysisListItems = useMemo(() => 
    filteredAnalyses
      .map(sanitizeAnalysis)
      .filter(Boolean)
      .map(analysis => {
        const contextUsed = contexts.find(ctx => ctx.id === analysis.context_uuid);
        return (
          <AnalysisListItem
            key={analysis.id}
            analysis={analysis}
            contextUsed={contextUsed}
            onViewReport={handleViewReport}
            onContextChanged={handleContextChanged}
            onAnalysisNameChanged={handleAnalysisNameChanged}
          />
        );
      }), [filteredAnalyses, contexts, handleViewReport, handleContextChanged, handleAnalysisNameChanged]
  );

  // Função utilitária para tratar análise com campos null
  function sanitizeAnalysis(analysis: any): Analysis | null {
    const ESSENTIAL_FIELDS = [
      'analysis_name',
      'client_name',
      'score_geral',
      'resumo',
      'pontos_positivos',
      'pontos_atencao',
      'objecoes_identificadas',
      'sugestoes_melhoria',
      'proximos_passos',
      'transcription',
    ];
    let nullCount = 0;
    const sanitized: Analysis = {
      id: analysis.id || 'N/A',
      created_at: analysis.created_at || 'N/A',
      client_name: analysis.client_name ?? 'N/A',
      score_geral: typeof analysis.score_geral === 'number' ? analysis.score_geral : 0,
      upload_type: analysis.upload_type ?? 'N/A',
      resumo: analysis.resumo ?? 'N/A',
      pontos_positivos: Array.isArray(analysis.pontos_positivos) ? analysis.pontos_positivos : [],
      pontos_atencao: Array.isArray(analysis.pontos_atencao) ? analysis.pontos_atencao : [],
      objecoes_identificadas: Array.isArray(analysis.objecoes_identificadas) ? analysis.objecoes_identificadas : [],
      sugestoes_melhoria: Array.isArray(analysis.sugestoes_melhoria) ? analysis.sugestoes_melhoria : [],
      proximos_passos: Array.isArray(analysis.proximos_passos) ? analysis.proximos_passos : [],
      context_uuid: analysis.context_uuid ?? 'N/A',
      transcription: analysis.transcription ?? 'N/A',
      vendedor: analysis.vendedor ?? 'N/A',
      framework_analysis: analysis.framework_analysis,
      coaching_insights: analysis.coaching_insights,
      performance_analysis: analysis.performance_analysis,
      mental_triggers: analysis.mental_triggers,
      reformulacoes_pnl: analysis.reformulacoes_pnl,
      plano_fechamento: analysis.plano_fechamento,
      ia_preditiva: analysis.ia_preditiva,
      analysis_name: analysis.analysis_name ?? 'N/A',
      audio_duration_seconds: analysis.audio_duration_seconds,
      desempenho_geral: analysis.desempenho_geral,
      tempo_de_fala: analysis.tempo_de_fala,
    };
    ESSENTIAL_FIELDS.forEach(field => {
      if (analysis[field] === null || analysis[field] === undefined) {
        nullCount++;
      }
    });
    if (nullCount > 3) return null;
    return sanitized;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        </div>
      </div>
    );
  }

  // Show full report view if an analysis is selected
  if (selectedAnalysis) {
    const contextUsed = contexts.find(ctx => ctx.id === selectedAnalysis.context_uuid);
    return (
      <ReportViewer 
        analysis={selectedAnalysis} 
        contextUsed={contextUsed} 
        onBack={handleBackToList}
        onDownloadPDF={onDownloadPDF}
        onShareLink={onShareLink}
        loadingAction={loadingAction}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-8 animate-fade-in">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-slate-800 font-poppins">
              Relatórios e Analytics
            </h1>
            <p className="text-slate-700 text-lg">
              Análises, comparações temporais e insights preditivos
            </p>
          </div>
        </div>

        <ReportsStats analyses={analyses} vendedores={vendedores} />

        <Tabs defaultValue="analyses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="analyses" className="flex items-center space-x-2">
              <FileText className="w-4 h-4" />
              <span>Análises</span>
            </TabsTrigger>
            <TabsTrigger value="temporal" className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4" />
              <span>Comparação Temporal</span>
            </TabsTrigger>
            <TabsTrigger value="predictive" className="flex items-center space-x-2">
              <Brain className="w-4 h-4" />
              <span>IA Preditiva</span>
            </TabsTrigger>
          </TabsList>

                      <TabsContent value="analyses" className="space-y-6">
              <AdminUserSearch
                adminUserEmail={adminUserEmail}
                setAdminUserEmail={setAdminUserEmail}
                adminSearchLoading={adminSearchLoading}
                searchUserAnalyses={searchUserAnalyses}
                clearAdminSearch={clearAdminSearch}
                isAdmin={isAdmin}
              />
              <ReportsFilters
              searchTerm={searchTerm}
              selectedVendedor={selectedVendedor}
              vendedores={vendedores}
              onSearchChange={setSearchTerm}
              onVendedorChange={setSelectedVendedor}
              dateRange={dateRange}
              onDateRangeChange={setDateRange}
              minScore={scoreRange.min}
              maxScore={scoreRange.max}
              onScoreRangeChange={(min, max) => setScoreRange({ min, max })}
              selectedContext={selectedContext}
              contexts={contexts}
              onContextChange={setSelectedContext}
            />

            <Card className="bg-white border-blue-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-slate-800">
                  Histórico de Análises ({filteredAnalyses.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                {filteredAnalyses.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="w-16 h-16 text-slate-400 mx-auto mb-4" />
                    <p className="text-slate-600 text-lg font-semibold">
                      {analyses.length === 0 ? "Nenhuma análise encontrada" : "Nenhum resultado para sua busca"}
                    </p>
                    <p className="text-slate-500 mt-2">
                      {analyses.length === 0 ? "Faça sua primeira análise para começar" : "Tente ajustar os filtros de busca"}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {analysisListItems}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="temporal">
            <TemporalComparison />
          </TabsContent>

          <TabsContent value="predictive">
            <PredictiveAI />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function Relatorios() {
  return (
    <ContextsProvider>
      <RelatoriosContent />
    </ContextsProvider>
  );
}
