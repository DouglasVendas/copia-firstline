import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useContexts } from "@/hooks/useContexts";
import { useAuth } from "@/hooks/useAuth";
import { Loader2, Video, Bot, Settings, History, RefreshCw, Eye } from 'lucide-react';
import { apiFetch, AuthRedirectError } from "@/lib/apiFetch";

type Platform = 'meet' | 'zoom' | 'teams';

interface PlatformOption {
  id: Platform;
  name: string;
  logo: string;
  endpoint: string;
  placeholder: string;
  regex: RegExp;
}

// Função para formatar links do Meet e Zoom
const formatMeetingUrl = (url: string, platform: Platform): string => {
  if (platform === 'teams') {
    return url; // Teams deixa como está
  }

  let formattedUrl = url.trim();

  if (platform === 'meet') {
    // Adicionar https se não tiver
    if (!formattedUrl.startsWith('https://')) {
      if (formattedUrl.startsWith('meet.google.com')) {
        formattedUrl = 'https://' + formattedUrl;
      } else if (formattedUrl.startsWith('http://')) {
        formattedUrl = formattedUrl.replace('http://', 'https://');
      } else if (formattedUrl.startsWith('www.meet.google.com')) {
        formattedUrl = 'https://' + formattedUrl;
      }
    }

    // Remover parâmetros extras (tudo após ?)
    const urlParts = formattedUrl.split('?');
    if (urlParts.length > 1) {
      formattedUrl = urlParts[0];
    }

    // Remover fragmentos (tudo após #)
    const fragmentParts = formattedUrl.split('#');
    if (fragmentParts.length > 1) {
      formattedUrl = fragmentParts[0];
    }
  }

  if (platform === 'zoom') {
    // Adicionar https se não tiver
    if (!formattedUrl.startsWith('https://')) {
      if (formattedUrl.startsWith('zoom.us') || formattedUrl.includes('zoom.us')) {
        // Se o link não começa com subdomínio, assumir que é o principal
        if (formattedUrl.startsWith('zoom.us')) {
          formattedUrl = 'https://' + formattedUrl;
        } else {
          formattedUrl = 'https://' + formattedUrl;
        }
      } else if (formattedUrl.startsWith('http://')) {
        formattedUrl = formattedUrl.replace('http://', 'https://');
      }
    }

    // Remover parâmetros extras (tudo após ?)
    const urlParts = formattedUrl.split('?');
    if (urlParts.length > 1) {
      formattedUrl = urlParts[0];
    }

    // Remover fragmentos (tudo após #)
    const fragmentParts = formattedUrl.split('#');
    if (fragmentParts.length > 1) {
      formattedUrl = fragmentParts[0];
    }
  }

  return formattedUrl;
};

const platforms: PlatformOption[] = [
  {
    id: 'meet',
    name: 'Google Meet',
    logo: '/meet.png',
    endpoint: '/bot-api/meet',
    placeholder: 'https://meet.google.com/abc-defg-hij',
    regex: /^https:\/\/meet\.google\.com\/[a-z\-]+$/
  },
  {
    id: 'zoom',
    name: 'Zoom',
    logo: '/zoom.png',
    endpoint: '/bot-api/zoom',
    placeholder: 'https://zoom.us/j/1234567890',
    regex: /^https:\/\/(\w+\.)?zoom\.us\/(j|my)\/.+$/
  },
  {
    id: 'teams',
    name: 'Microsoft Teams',
    logo: '/teams.png',
    endpoint: '/bot-api/teams',
    placeholder: 'https://teams.microsoft.com/l/meetup-join/...',
    regex: /^https:\/\/teams\.microsoft\.com\/l\/meetup-join\/.+$/
  }
];

interface Seller {
  id: string;
  name: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

export default function MeetingBot() {
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>('meet');
  const [analysisName, setAnalysisName] = useState("");
  const [meetingUrl, setMeetingUrl] = useState("");
  const [selectedContext, setSelectedContext] = useState("");
  const [selectedVendedor, setSelectedVendedor] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [bots, setBots] = useState<any[]>([]);
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [loadingBots, setLoadingBots] = useState(false);
  const [loadingAnalysis, setLoadingAnalysis] = useState<string | null>(null);
  const { toast } = useToast();
  const { contexts, loading: contextsLoading } = useContexts();
  const { user } = useAuth(); // Removido token, agora usa cookies HTTP-only
  const navigate = useNavigate();

  // Buscar vendedores
  const fetchSellers = async () => {
    try {
      const response = await apiFetch(`${API_BASE_URL}/sellers`);
      if (response.ok) {
        const data = await response.json();
        // Adaptação para garantir o formato {id, name}
        if (Array.isArray(data.data)) {
          setSellers(data.data.map((v: any) => ({
            id: v.id || v.vendedor_id,
            name: v.name || v.vendedor
          })));
        } else if (Array.isArray(data)) {
          setSellers(data.map((v: any) => ({
            id: v.id || v.vendedor_id,
            name: v.name || v.vendedor
          })));
        } else {
          setSellers([]);
        }
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    }
  };

  // Buscar bots ativos
  const fetchBots = async () => {
    setLoadingBots(true);
    try {
      const response = await apiFetch(`${API_BASE_URL}/bot-api/`, {
        credentials: 'include', // Usa cookies HTTP-only
      });
      
      if (response.ok) {
        const data = await response.json();
        // A API retorna { bots: [...], success: true }
        // Ordenar bots por data de criação (mais recente primeiro)
        const sortedBots = (data.bots || []).sort((a: any, b: any) => {
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        });
        setBots(sortedBots);
      }
    } catch (error) {
    } finally {
      setLoadingBots(false);
    }
  };

  // Buscar vendedores e bots ao carregar o componente
  useEffect(() => {
    if (user) {
      fetchSellers();
      fetchBots();
    }
  }, [user]);

  // Auto-select context if only one is available
  useEffect(() => {
    if (contexts.length === 1 && !selectedContext) {
      setSelectedContext(contexts[0].id);
    }
  }, [contexts, selectedContext]);

  // Auto-select vendedor if only one is available
  useEffect(() => {
    if (sellers.length === 1 && !selectedVendedor) {
      setSelectedVendedor(sellers[0].id);
    }
  }, [sellers, selectedVendedor]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedPlatform || !analysisName.trim() || !meetingUrl.trim() || !selectedContext || !selectedVendedor) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      });
      return;
    }

    const platform = platforms.find(p => p.id === selectedPlatform);
    if (!platform) return;

    // Formatar o link para Meet e Zoom
    const formattedUrl = formatMeetingUrl(meetingUrl, selectedPlatform);

    // Validação do link da chamada (após formatação)
    if (!platform.regex.test(formattedUrl)) {
      toast({
        title: "Link inválido",
        description: `O link inserido não parece ser um link válido do ${platform.name}. Verifique o formato.`,
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await apiFetch(`${API_BASE_URL}${platform.endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include', // Usa cookies HTTP-only
        body: JSON.stringify({
          analysis_name: analysisName,
          meeting_url: formattedUrl, // Usar o link formatado
          context_id: selectedContext,
          vendedor_id: selectedVendedor,
        }),
      });

      toast({
        title: "Bot configurado com sucesso!",
        description: `O bot "${analysisName}" foi configurado para entrar na chamada ${platform.name}.`,
        variant: "success",
      });

      // Reset form
      setAnalysisName("");
      setMeetingUrl("");
      setSelectedContext("");
      setSelectedVendedor("");
      setSelectedPlatform('meet');

      // Atualizar lista de bots
      fetchBots();

    } catch (error) {
      toast({
        title: "Erro ao configurar bot",
        description: "Ocorreu um erro ao tentar configurar o bot. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Remover bot da chamada
  const handleRemoveBot = async (botId: string) => {
    try {
      const response = await apiFetch(`${API_BASE_URL}/bot-api/${botId}`, {
        method: 'DELETE',
        credentials: 'include', // Usa cookies HTTP-only
      });

      if (response.ok) {
        toast({
          title: "Bot removido com sucesso!",
          description: "O bot foi removido da chamada.",
        });
        // Atualizar lista de bots
        fetchBots();
      }
    } catch (error) {
      toast({
        title: "Erro ao remover bot",
        description: "Ocorreu um erro ao tentar remover o bot. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  // Visualizar análise do bot
  const handleViewAnalysis = async (analysisId: string) => {
    setLoadingAnalysis(analysisId);
    try {
      const response = await apiFetch(`${API_BASE_URL}/analyses/${analysisId}`, {
        credentials: 'include', // Usa cookies HTTP-only
      });

      if (response.ok) {
        const responseData = await response.json();
        // Extract the analysis data from the response
        const analysisData = responseData.data;
        // Navigate to reports page with the analysis data
        navigate('/relatorios', { 
          state: { 
            selectedAnalysis: analysisData,
            fromBot: true 
          } 
        });
      } else {
        toast({
          title: "Erro ao carregar análise",
          description: "Não foi possível carregar a análise. Verifique se ela ainda existe.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro ao carregar análise",
        description: "Ocorreu um erro ao tentar carregar a análise. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setLoadingAnalysis(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'created':
        return 'bg-gray-500';
      case 'joining_call':
        return 'bg-yellow-500';
      case 'in_waiting_room':
        return 'bg-orange-500';
      case 'in_call_not_recording':
        return 'bg-yellow-500';
      case 'in_call_recording':
        return 'bg-green-500';
      case 'call_ended':
        return 'bg-gray-500';
      case 'call_ended_by_platform_waiting_room_timeout':
        return 'bg-red-500';
      case 'done':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status?.toLowerCase()) {
      case 'created':
        return 'Criado';
      case 'joining_call':
        return 'Entrando na chamada';
      case 'in_waiting_room':
        return 'Na sala de espera';
      case 'in_call_not_recording':
        return 'Na chamada (não gravando)';
      case 'in_call_recording':
        return 'Na chamada (gravando)';
      case 'call_ended':
        return 'Chamada finalizada';
      case 'call_ended_by_platform_waiting_room_timeout':
        return 'Não admitido na chamada';
      case 'done':
        return 'Concluído';
      default:
        return status || 'Desconhecido';
    }
  };

  const getPlatformIcon = (platform: string) => {
    const platformData = platforms.find(p => p.id === platform);
    return platformData?.logo || "/placeholder.svg";
  };

  const calculateDuration = (createdAt: string, endedAt: string | null) => {
    if (!endedAt) return null;
    
    const start = new Date(createdAt);
    const end = new Date(endedAt);
    const diffMs = end.getTime() - start.getTime();
    
    const minutes = Math.floor(diffMs / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (hours > 0) {
      return `${hours}h ${remainingMinutes}m`;
    }
    return `${minutes}m`;
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-[#111827] font-poppins">
              Meeting Bot
            </h1>
            <p className="text-[#4B5563] text-lg mt-1">
              Configure um bot para entrar automaticamente em suas chamadas.
            </p>
          </div>
        </div>
      </div>

      <div className="grid gap-6">
        {/* Platform Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Video className="h-6 w-6 text-[rgb(37,99,235)]" />
              Selecione a Plataforma
            </CardTitle>
            <CardDescription>
              Escolha a plataforma onde será realizada a chamada
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {platforms.map((platform) => (
                <div
                  key={platform.id}
                  className={`relative cursor-pointer rounded-lg border-2 p-6 transition-all hover:shadow-md ${
                    selectedPlatform === platform.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedPlatform(platform.id)}
                >
                  <div className="flex flex-col items-center text-center space-y-3">
                    <img
                      src={platform.logo || "/placeholder.svg"}
                      alt={platform.name}
                      className="h-12 w-12 object-contain"
                      onError={(e) => {
                        // Fallback if image doesn't exist
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                    <div>
                      <h3 className="font-semibold text-gray-900">{platform.name}</h3>
                    </div>
                    {selectedPlatform === platform.id && (
                      <div className="absolute top-2 right-2">
                        <div className="h-3 w-3 rounded-full bg-blue-500"></div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Bot Configuration Form */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-6 w-6" />
              Configuração do Bot
            </CardTitle>
            <CardDescription>
              Configure os detalhes do bot que entrará na chamada
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="context" className="ml-1">Contexto</Label>
                  <Select 
                    value={selectedContext} 
                    onValueChange={setSelectedContext}
                    disabled={contextsLoading || contexts.length === 0}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={
                        contextsLoading 
                          ? "Carregando contextos..." 
                          : contexts.length === 0 
                            ? "Nenhum contexto disponível" 
                            : "Selecione um contexto"
                      } />
                    </SelectTrigger>
                    <SelectContent>
                      {contexts.map((context) => (
                        <SelectItem key={context.id} value={context.id}>
                          {context.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vendedor" className="ml-1">Vendedor</Label>
                  <Select 
                    value={selectedVendedor} 
                    onValueChange={setSelectedVendedor}
                    disabled={sellers.length === 0}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder={
                        sellers.length === 0
                          ? "Nenhum vendedor disponível"
                          : "Selecione um vendedor"
                      } />
                    </SelectTrigger>
                    <SelectContent>
                      {sellers.map((seller) => (
                        <SelectItem key={seller.id} value={seller.id}>
                          {seller.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="analysisName" className="ml-1">Nome da Análise</Label>
                  <Input
                    id="analysisName"
                    type="text"
                    placeholder="Digite o nome da análise"
                    value={analysisName}
                    onChange={(e) => setAnalysisName(e.target.value)}
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="meetingUrl" className="ml-1">Link da Chamada</Label>
                  <Input
                    id="meetingUrl"
                    type="url"
                    placeholder={platforms.find(p => p.id === selectedPlatform)?.placeholder || "Selecione uma plataforma"}
                    value={meetingUrl}
                    onChange={(e) => setMeetingUrl(e.target.value)}
                    className="w-full"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  type="submit"
                  disabled={isLoading || !selectedPlatform || !analysisName.trim() || !meetingUrl.trim() || !selectedContext || !selectedVendedor}
                  className="min-w-[150px]"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Configurando...
                    </>
                  ) : (
                    <>
                      <Bot className="mr-2 h-4 w-4" />
                      Configurar Bot
                    </>
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Active Bots */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="h-6 w-6 text-gray-700" />
              Histórico de Bots
              <Button
                variant="outline"
                size="sm"
                onClick={fetchBots}
                disabled={loadingBots}
                className="ml-auto"
              >
                {loadingBots ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
              </Button>
            </CardTitle>
            <CardDescription>
              Acompanhe o status dos bots configurados para suas chamadas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative">
              {/* Overlay de loading */}
              {loadingBots && (
                <div className="absolute inset-0 bg-white/50 backdrop-blur-[1px] z-10 flex items-center justify-center rounded-lg">
                  <div className="bg-white rounded-full p-3 shadow-lg">
                    <Loader2 className="h-6 w-6 animate-spin text-blue-600" />
                  </div>
                </div>
              )}
              
              {bots.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center text-gray-500">
                  <Bot className="w-12 h-12 mb-3 text-gray-400" />
                  <h3 className="font-semibold text-lg mb-2">Nenhum bot configurado</h3>
                  <p className="text-sm">Configure um bot acima para começar a monitorar suas chamadas.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {bots.map((bot) => (
                  <div key={bot.id} className="border rounded-xl p-4 hover:shadow-lg transition-all duration-200 bg-gradient-to-r from-white to-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="flex flex-col">
                          <div className="flex items-center gap-3 mb-1">
                            <div className="flex items-center gap-2">
                              <Bot className="h-4 w-4" />
                              <h3 className="font-semibold text-base text-gray-900">{bot.analysis_name || bot.bot_name || bot.name}</h3>
                            </div>
                            <div className={`px-2 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(bot.status)}`}>
                              {getStatusText(bot.status)}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-6 text-sm text-gray-600">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">Plataforma:</span>
                              <div className="inline-flex items-center rounded-md border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 text-foreground w-fit shadow-sm">
                                <div className="flex flex-row whitespace-nowrap text-sm font-extralight items-center">
                                  <div className="flex flex-row items-center mr-1">
                                    <img 
                                      src={getPlatformIcon(bot.platform)} 
                                      alt={bot.platform}
                                      className="w-3 h-3 object-contain"
                                      onError={(e) => {
                                        e.currentTarget.style.display = 'none';
                                      }}
                                    />
                                  </div>
                                  <div className="text-xs capitalize font-semibold">{bot.platform}</div>
                                </div>
                              </div>
                            </div>
                            {calculateDuration(bot.created_at, bot.ended_at) && (
                              <div className="flex items-center gap-1">
                                <span className="font-medium">Duração:</span>
                                <span>{calculateDuration(bot.created_at, bot.ended_at)}</span>
                              </div>
                            )}
                            <div className="flex items-center gap-1">
                              <span className="font-medium">Última atualização:</span>
                              <span>{new Date(bot.updated_at).toLocaleString('pt-BR', {
                                day: '2-digit',
                                month: '2-digit', 
                                year: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {bot.analysis_id && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewAnalysis(bot.analysis_id)}
                            disabled={loadingAnalysis === bot.analysis_id}
                            className="px-3 py-1 text-xs"
                          >
                            {loadingAnalysis === bot.analysis_id ? (
                              <>
                                <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                                Carregando...
                              </>
                            ) : (
                              <>
                                <Eye className="w-3 h-3 mr-1" />
                                Ver Análise
                              </>
                            )}
                          </Button>
                        )}
                        
                        {bot.status && (
                         bot.status.toLowerCase() === 'created' || 
                         bot.status.toLowerCase() === 'joining_call' || 
                         bot.status.toLowerCase() === 'in_waiting_room' ||
                         bot.status.toLowerCase() === 'in_call_not_recording' ||
                         bot.status.toLowerCase() === 'in_call_recording'
                        ) && (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleRemoveBot(bot.id)}
                            className="px-3 py-1 text-xs"
                          >
                            Remover
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}