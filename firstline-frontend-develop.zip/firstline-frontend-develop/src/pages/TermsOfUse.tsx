import { SEO } from "@/components/SEO";

const TermsOfUse = () => {
  return (
    <>
      <SEO 
        title="Termos de Uso - First Line AI"
        description="Termos de uso da First Line AI - Condições de utilização da nossa plataforma de IA empresarial."
      />
      
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="px-6 py-8 sm:px-8 sm:py-10">
              <div className="prose max-w-none">
                <h1 className="text-3xl font-bold text-gray-900 mb-8">
                  Termos de Uso
                </h1>
                
                <div className="space-y-6 text-gray-700 leading-relaxed">
                  <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                    1. Termos
                  </h2>
                  
                  <p>
                    Ao acessar ao site <a href="https://app.firstlineai.com.br" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline">First Line AI</a>, concorda em cumprir estes termos de serviço, todas as leis e regulamentos aplicáveis ​​e concorda que é responsável pelo cumprimento de todas as leis locais aplicáveis. Se você não concordar com algum desses termos, está proibido de usar ou acessar este site. Os materiais contidos neste site são protegidos pelas leis de direitos autorais e marcas comerciais aplicáveis.
                  </p>
                  
                  <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                    2. Uso de Licença
                  </h2>
                  
                  <p>
                    É concedida permissão para baixar temporariamente uma cópia dos materiais (informações ou software) no site First Line AI, apenas para visualização transitória pessoal e não comercial. Esta é a concessão de uma licença, não uma transferência de título e, sob esta licença, você não pode:
                  </p>
                  
                  <ol className="space-y-3 pl-6">
                    <li>modificar ou copiar os materiais;</li>
                    <li>usar os materiais para qualquer finalidade comercial ou para exibição pública (comercial ou não comercial);</li>
                    <li>tentar descompilar ou fazer engenharia reversa de qualquer software contido no site First Line AI;</li>
                    <li>remover quaisquer direitos autorais ou outras notações de propriedade dos materiais; ou</li>
                    <li>transferir os materiais para outra pessoa ou 'espelhe' os materiais em qualquer outro servidor.</li>
                  </ol>
                  
                  <p>
                    Esta licença será automaticamente rescindida se você violar alguma dessas restrições e poderá ser rescindida por First Line AI a qualquer momento. Ao encerrar a visualização desses materiais ou após o término desta licença, você deve apagar todos os materiais baixados em sua posse, seja em formato eletrónico ou impresso.
                  </p>
                  
                  <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                    3. Isenção de responsabilidade
                  </h2>
                  
                  <ol className="space-y-3 pl-6">
                    <li>
                      Os materiais no site da First Line AI são fornecidos 'como estão'. First Line AI não oferece garantias, expressas ou implícitas, e, por este meio, isenta e nega todas as outras garantias, incluindo, sem limitação, garantias implícitas ou condições de comercialização, adequação a um fim específico ou não violação de propriedade intelectual ou outra violação de direitos.
                    </li>
                    <li>
                      Além disso, o First Line AI não garante ou faz qualquer representação relativa à precisão, aos resultados prováveis ​​ou à confiabilidade do uso dos materiais em seu site ou de outra forma relacionado a esses materiais ou em sites vinculados a este site.
                    </li>
                  </ol>
                  
                  <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                    4. Limitações
                  </h2>
                  
                  <p>
                    Em nenhum caso o First Line AI ou seus fornecedores serão responsáveis ​​por quaisquer danos (incluindo, sem limitação, danos por perda de dados ou lucro ou devido a interrupção dos negócios) decorrentes do uso ou da incapacidade de usar os materiais em First Line AI, mesmo que First Line AI ou um representante autorizado da First Line AI tenha sido notificado oralmente ou por escrito da possibilidade de tais danos. Como algumas jurisdições não permitem limitações em garantias implícitas, ou limitações de responsabilidade por danos conseqüentes ou incidentais, essas limitações podem não se aplicar a você.
                  </p>
                  
                  <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                    5. Precisão dos materiais
                  </h2>
                  
                  <p>
                    Os materiais exibidos no site da First Line AI podem incluir erros técnicos, tipográficos ou fotográficos. First Line AI não garante que qualquer material em seu site seja preciso, completo ou atual. First Line AI pode fazer alterações nos materiais contidos em seu site a qualquer momento, sem aviso prévio. No entanto, First Line AI não se compromete a atualizar os materiais.
                  </p>
                  
                  <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">
                    6. Links
                  </h2>
                  
                  <p>
                    O First Line AI não analisou todos os sites vinculados ao seu site e não é responsável pelo conteúdo de nenhum site vinculado. A inclusão de qualquer link não implica endosso por First Line AI do site. O uso de qualquer site vinculado é por conta e risco do usuário.
                  </p>
                  
                  <h3 className="text-xl font-semibold text-gray-900 mt-8 mb-4">
                    Modificações
                  </h3>
                  
                  <p>
                    O First Line AI pode revisar estes termos de serviço do site a qualquer momento, sem aviso prévio. Ao usar este site, você concorda em ficar vinculado à versão atual desses termos de serviço.
                  </p>
                  
                  <h3 className="text-xl font-semibold text-gray-900 mt-8 mb-4">
                    Lei aplicável
                  </h3>
                  
                  <p>
                    Estes termos e condições são regidos e interpretados de acordo com as leis do First Line AI e você se submete irrevogavelmente à jurisdição exclusiva dos tribunais naquele estado ou localidade.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default TermsOfUse;
