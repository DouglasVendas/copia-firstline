
import { useRef, useEffect } from "react";
import { Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function Planos() {
  const isMountedRef = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const plans = [
    {
      name: "Plano Mensal",
      price: "R$ 1.997",
      period: "/mês",
      description: "Sem fidelidade, cancele quando quiser",
      features: [
        "Análise ilimitada para até 3 vendedores",
        "Frameworks de SPIN, BANT e GPCT",
        "Dashboard de performance",
        "IA Preditiva",
        "Suporte por WhatsApp",
        "Treinamento de Vendas semanal",
        "Cursos de vendas com certificado"
      ],
      isPopular: false
    },
    {
      name: "Plano Anual",
      price: "R$ 997",
      period: "/mês",
      originalPrice: "Em 12x ou à vista R$ 9.970",
      badge: "Programa Partner Founder",
      description: "Mesmos entregáveis em ambos os planos. A diferença está apenas na forma de pagamento e no tempo de contrato.",
      features: [
        "Análise ilimitada para até 3 vendedores",
        "Frameworks de SPIN, BANT e GPCT",
        "Dashboard de performance",
        "IA Preditiva",
        "Suporte por WhatsApp",
        "Treinamento de Vendas semanal",
        "Cursos de vendas com certificado"
      ],
      isPopular: true
    }
  ];

  const handlePlanSelection = (planName: string) => {
    if (!isMountedRef.current) return;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto px-6 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold mb-6">
            Planos: <span className="text-blue-400">Oferta Exclusiva</span>
          </h1>
          <p className="text-xl text-slate-300 max-w-4xl mx-auto">
            Seja um dos primeiros a transformar seu time de vendas com o FirstLine AI
          </p>
          <div className="w-24 h-1 bg-blue-500 mx-auto mt-6"></div>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-12">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-300 ${
                plan.isPopular ? 'ring-2 ring-blue-500 transform scale-105' : ''
              }`}
            >
              <CardHeader className="text-center pb-8">
                <div className="flex justify-between items-start mb-4">
                  <CardTitle className="text-2xl font-bold text-blue-400">
                    {plan.name}
                  </CardTitle>
                  {plan.badge && (
                    <Badge className="bg-blue-600 text-white">
                      {plan.badge}
                    </Badge>
                  )}
                </div>
                
                <div className="mb-4">
                  <div className="flex items-baseline justify-center gap-2">
                    <span className="text-5xl font-bold text-white">
                      {plan.price}
                    </span>
                    <span className="text-xl text-slate-400">
                      {plan.period}
                    </span>
                  </div>
                  {plan.originalPrice && (
                    <p className="text-sm text-slate-400 mt-2">
                      {plan.originalPrice}
                    </p>
                  )}
                </div>

                <p className="text-sm text-slate-300">
                  {plan.description}
                </p>
              </CardHeader>

              <CardContent className="space-y-6">
                <ul className="space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                      <span className="text-slate-200">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full py-6 text-lg font-semibold ${
                    plan.isPopular 
                      ? 'bg-blue-600 hover:bg-blue-700' 
                      : 'bg-slate-700 hover:bg-slate-600'
                  }`}
                  onClick={() => handlePlanSelection(plan.name)}
                >
                  Escolher {plan.name}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Footer Note */}
        <div className="text-center">
          <p className="text-slate-400 max-w-3xl mx-auto">
            Mesmos entregáveis em ambos os planos. A diferença está apenas na forma de pagamento e no tempo de contrato.
          </p>
        </div>
      </div>
    </div>
  );
}
