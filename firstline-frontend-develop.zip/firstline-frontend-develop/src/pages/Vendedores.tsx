import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Layout } from "@/components/layout/Layout";
import { User, Users, Plus, Trash2, Edit2, Check, X, Search, AlertCircle, Handshake, UserCheck, UserPlus, BriefcaseBusiness } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';

const API_BASE_URL = import.meta.env.VITE_API_URL;

type SellerType = 'SDR' | 'CLOSER' | 'Geral';

interface Seller {
  id: string;
  name: string;
  tipo?: SellerType;
  email?: string | null;
  telefone?: string | null;
}

export default function Vendedores() {
  const { user } = useAuth();
  const [sellers, setSellers] = useState<Seller[]>([]);
  const [selectedSellerId, setSelectedSellerId] = useState("");
  const [novoVendedor, setNovoVendedor] = useState("");
  const [novoVendedorTipo, setNovoVendedorTipo] = useState<SellerType>("Geral");
  const [novoVendedorEmail, setNovoVendedorEmail] = useState("");
  const [novoVendedorTelefone, setNovoVendedorTelefone] = useState("");
  const [editandoVendedor, setEditandoVendedor] = useState<string | null>(null);
  const [vendedorEditado, setVendedorEditado] = useState("");
  const [vendedorEditadoTipo, setVendedorEditadoTipo] = useState<SellerType>("Geral");
  const [vendedorEditadoEmail, setVendedorEditadoEmail] = useState("");
  const [vendedorEditadoTelefone, setVendedorEditadoTelefone] = useState("");
  const [search, setSearch] = useState("");
  const [filterByType, setFilterByType] = useState<SellerType | 'ALL'>('ALL');
  const [isUpdating, setIsUpdating] = useState(false);
  const [contexts, setContexts] = useState([]);
  const [selectedContextId, setSelectedContextId] = useState("");
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [sellerToDelete, setSellerToDelete] = useState(null);
  const [isSellerActive, setIsSellerActive] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [telefoneError, setTelefoneError] = useState("");

  // Validações
  const validateEmail = (email: string): boolean => {
    if (!email.trim()) return true; // Email é opcional
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateTelefone = (telefone: string): boolean => {
    if (!telefone.trim()) return true; // Telefone é opcional
    // Remove todos os caracteres não numéricos
    const numeros = telefone.replace(/\D/g, '');
    // Aceita telefones com 10 ou 11 dígitos (com ou sem DDD)
    return numeros.length >= 10 && numeros.length <= 11;
  };

  const formatTelefone = (value: string): string => {
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, '');
    
    // Formata o telefone
    if (numbers.length <= 10) {
      return numbers.replace(/(\d{2})(\d{4})(\d{0,4})/, (_, p1, p2, p3) => {
        let result = `(${p1})`;
        if (p2) result += ` ${p2}`;
        if (p3) result += `-${p3}`;
        return result;
      });
    } else {
      return numbers.replace(/(\d{2})(\d{5})(\d{0,4})/, (_, p1, p2, p3) => {
        let result = `(${p1})`;
        if (p2) result += ` ${p2}`;
        if (p3) result += `-${p3}`;
        return result;
      });
    }
  };

  // Buscar vendedores
  const fetchSellers = async () => {
    const response = await apiFetch(`${API_BASE_URL}/sellers`);
    if (response.ok) {
      const data = await response.json();
      // Adaptar caso venha em outro formato
      if (Array.isArray(data)) {
        setSellers(data.map((v: any) => ({ 
          id: v.id || v.vendedor_id, 
          name: v.name || v.vendedor,
          tipo: (!v.tipo || v.tipo === '' || !['SDR', 'CLOSER'].includes(v.tipo)) ? 'Geral' : v.tipo,
          email: v.email || null,
          telefone: v.telefone || null
        })));
      } else if (Array.isArray(data.data)) {
        setSellers(data.data.map((v: any) => ({ 
          id: v.id || v.vendedor_id, 
          name: v.name || v.vendedor,
          tipo: (!v.tipo || v.tipo === '' || !['SDR', 'CLOSER'].includes(v.tipo)) ? 'Geral' : v.tipo,
          email: v.email || null,
          telefone: v.telefone || null
        })));
      } else {
        setSellers([]);
      }
    } else {
      setSellers([]);
    }
  };

  // Buscar contextos (apenas para ativar vendedor)
  const fetchContexts = async () => {
    const response = await apiFetch(`${API_BASE_URL}/contexts`);
    if (response.ok) {
      const data = await response.json();
      // Adaptar caso venha em outro formato
      if (Array.isArray(data)) {
        setContexts(data.map((ctx: any) => ({
          ...ctx,
          vendedores: (ctx.vendedores || []).map((v: any) => ({
            id: v.vendedor_id || v.id || v,
            name: v.vendedor || v.name || v,
          })),
          vendedor_ativo: ctx.vendedor_ativo_id || ctx.vendedor_ativo || null,
        })));
      } else if (Array.isArray(data.data)) {
        setContexts(data.data.map((ctx: any) => ({
          ...ctx,
          vendedores: (ctx.vendedores || []).map((v: any) => ({
            id: v.vendedor_id || v.id || v,
            name: v.vendedor || v.name || v,
          })),
          vendedor_ativo: ctx.vendedor_ativo_id || ctx.vendedor_ativo || null,
        })));
      } else {
        setContexts([]);
      }
    } else {
      setContexts([]);
    }
  };

  useEffect(() => {
    fetchSellers();
    fetchContexts();
  }, []);

  useEffect(() => {
    if (contexts.length > 0 && !selectedContextId) {
      const ativo = contexts.find((ctx) => ctx.is_active) || contexts[0];
      setSelectedContextId(ativo.id);
    }
  }, [contexts, selectedContextId]);

  useEffect(() => {
    const handler = () => setShowDeleteDialog(false);
    window.addEventListener('close-all-overlays', handler);
    return () => window.removeEventListener('close-all-overlays', handler);
  }, []);

  // Filtrar vendedores
  const vendedoresFiltrados = sellers.filter(v => {
    const matchesName = v.name.toLowerCase().includes(search.toLowerCase());
    const matchesType = filterByType === 'ALL' || v.tipo === filterByType;
    return matchesName && matchesType;
  });

  // Função para obter o ícone do tipo de vendedor
  const getSellerTypeIcon = (tipo: SellerType) => {
    switch (tipo) {
      case 'SDR':
        return <BriefcaseBusiness className="w-4 h-4" />;
      case 'CLOSER':
        return <Handshake className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };

  // Função para obter a cor do badge do tipo
  const getSellerTypeBadgeColor = (tipo: SellerType) => {
    switch (tipo) {
      case 'SDR':
        return 'bg-blue-500 hover:bg-blue-600';
      case 'CLOSER':
        return 'bg-purple-500 hover:bg-purple-600';
      default:
        return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  // Função para obter o label do tipo
  const getSellerTypeLabel = (tipo: SellerType) => {
    switch (tipo) {
      case 'SDR':
        return 'SDR';
      case 'CLOSER':
        return 'Closer';
      case 'Geral':
        return 'Geral';
      default:
        return 'Geral';
    }
  };

  // Criar vendedor
  const handleAdicionar = async () => {
    if (!novoVendedor.trim()) return;
    
    // Validar email
    if (novoVendedorEmail && !validateEmail(novoVendedorEmail)) {
      setEmailError("Email inválido");
      toast({
        title: "Email inválido",
        description: "Por favor, insira um email válido.",
        variant: "destructive"
      });
      return;
    }
    
    // Validar telefone
    if (novoVendedorTelefone && !validateTelefone(novoVendedorTelefone)) {
      setTelefoneError("Telefone inválido");
      toast({
        title: "Telefone inválido",
        description: "Por favor, insira um telefone válido com 10 ou 11 dígitos.",
        variant: "destructive"
      });
      return;
    }
    
    setEmailError("");
    setTelefoneError("");
    setIsUpdating(true);
    
    const response = await apiFetch(`${API_BASE_URL}/sellers`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        name: novoVendedor.trim(),
        tipo: novoVendedorTipo,
        email: novoVendedorEmail.trim() || null,
        telefone: novoVendedorTelefone.replace(/\D/g, '') || null
      })
    });
    if (response.ok) {
      await fetchSellers();
      setNovoVendedor("");
      setNovoVendedorTipo("Geral");
      setNovoVendedorEmail("");
      setNovoVendedorTelefone("");
      toast({
        title: "Vendedor adicionado",
        description: "O vendedor foi adicionado com sucesso.",
      });
    } else if (response.status === 429) {
      const data = await response.json();
      toast({
        title: "Limite excedido!",
        description: data.error || "Limite de criação de vendedores excedido. Faça upgrade do seu plano para criar mais vendedores.",
        variant: "destructive"
      });
    }
    setIsUpdating(false);
  };

  // Editar vendedor
  const handleSalvarEdicao = async () => {
    if (!editandoVendedor || !vendedorEditado.trim()) return;
    
    // Validar email
    if (vendedorEditadoEmail && !validateEmail(vendedorEditadoEmail)) {
      setEmailError("Email inválido");
      toast({
        title: "Email inválido",
        description: "Por favor, insira um email válido.",
        variant: "destructive"
      });
      return;
    }
    
    // Validar telefone
    if (vendedorEditadoTelefone && !validateTelefone(vendedorEditadoTelefone)) {
      setTelefoneError("Telefone inválido");
      toast({
        title: "Telefone inválido",
        description: "Por favor, insira um telefone válido com 10 ou 11 dígitos.",
        variant: "destructive"
      });
      return;
    }
    
    setEmailError("");
    setTelefoneError("");
    setIsUpdating(true);
    
    const response = await apiFetch(`${API_BASE_URL}/sellers/${editandoVendedor}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        name: vendedorEditado.trim(),
        tipo: vendedorEditadoTipo,
        email: vendedorEditadoEmail.trim() || null,
        telefone: vendedorEditadoTelefone.replace(/\D/g, '') || null
      })
    });
    if (response.ok) {
      await fetchSellers();
      setEditandoVendedor(null);
      setVendedorEditado("");
      setVendedorEditadoTipo("Geral");
      setVendedorEditadoEmail("");
      setVendedorEditadoTelefone("");
      toast({
        title: "Vendedor atualizado",
        description: "O vendedor foi atualizado com sucesso.",
      });
    }
    setIsUpdating(false);
  };

  // Remover vendedor
  const handleRemover = async (sellerId: string) => {
    const ativo = contexts.some(ctx => ctx.vendedor_ativo_id === sellerId);
    if (ativo) {
      setSellerToDelete(sellerId);
      setIsSellerActive(true);
      setShowDeleteDialog(true);
      return;
    }
    setSellerToDelete(sellerId);
    setIsSellerActive(false);
    setShowDeleteDialog(true);
  };

  const confirmDeleteSeller = async () => {
    if (!sellerToDelete) return;
    setIsUpdating(true);
    const response = await apiFetch(`${API_BASE_URL}/sellers/${sellerToDelete}`, {
      method: 'DELETE',
    });
    if (response.ok) {
      await fetchSellers();
    }
    setIsUpdating(false);
    setShowDeleteDialog(false);
    setSellerToDelete(null);
  };

  // Ativar vendedor em um contexto
  const handleSetVendedorAtivo = async (contextId: string, sellerId: string) => {
    setIsUpdating(true);
    const response = await apiFetch(`${API_BASE_URL}/contexts/${contextId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ vendedor_ativo_id: sellerId })
    });
    if (response.ok) {
      await fetchContexts();
    }
    setIsUpdating(false);
  };

  // Função para ativar modo de edição
  const handleEditar = (vendedorId: string) => {
    setEditandoVendedor(vendedorId);
    const vendedor = sellers.find(v => v.id === vendedorId);
    setVendedorEditado(vendedor ? vendedor.name : "");
    setVendedorEditadoTipo(vendedor ? (vendedor.tipo || "Geral") : "Geral");
    setVendedorEditadoEmail(vendedor?.email || "");
    setVendedorEditadoTelefone(vendedor?.telefone ? formatTelefone(vendedor.telefone) : "");
    setEmailError("");
    setTelefoneError("");
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto space-y-8 animate-fade-in mt-4">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center shadow-lg">
            <Users className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-[#111827] font-poppins tracking-tight">
              Cadastro de Vendedores
            </h1>
            <p className="text-[#4B5563] text-lg mt-1 max-w-6xl">
              Gerencie facilmente os vendedores de cada contexto. Adicione, edite, pesquise e remova vendedores de forma rápida e intuitiva.
            </p>
          </div>
        </div>
        {/* Card para Adicionar Vendedor */}
        <Card className="border-0 bg-white mb-6">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-[#1e293b] mb-3 flex items-center gap-2">
              <UserPlus className="w-5 h-5" />
              Adicionar Novo Vendedor
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block mb-1.5 text-sm font-medium text-[#374151]">Nome *</label>
                <Input
                  placeholder={!selectedContextId ? "Selecione um contexto primeiro" : "Nome do vendedor"}
                  value={novoVendedor}
                  onChange={(e) => setNovoVendedor(e.target.value)}
                  className="border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 disabled:opacity-50 disabled:cursor-not-allowed h-9 text-sm"
                  onKeyDown={e => { if (e.key === 'Enter' && novoVendedor.trim()) handleAdicionar(); }}
                  disabled={!selectedContextId}
                />
              </div>
              <div>
                <label className="block mb-1.5 text-sm font-medium text-[#374151]">Tipo *</label>
                <Select value={novoVendedorTipo} onValueChange={(value: SellerType) => setNovoVendedorTipo(value)} disabled={!selectedContextId}>
                  <SelectTrigger className="w-full border border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 transition-all h-9 disabled:opacity-50 disabled:cursor-not-allowed text-sm">
                    <SelectValue placeholder="Selecione o tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Geral">Geral</SelectItem>
                    <SelectItem value="SDR">SDR</SelectItem>
                    <SelectItem value="CLOSER">Closer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block mb-1.5 text-sm font-medium text-[#374151]">Email</label>
                <Input
                  type="email"
                  placeholder="email@exemplo.com"
                  value={novoVendedorEmail}
                  onChange={(e) => {
                    setNovoVendedorEmail(e.target.value);
                    if (emailError) setEmailError("");
                  }}
                  className={`border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 disabled:opacity-50 disabled:cursor-not-allowed h-9 text-sm ${emailError ? 'border-red-500' : ''}`}
                  disabled={!selectedContextId}
                />
                {emailError && <span className="text-red-500 text-xs mt-0.5 block">{emailError}</span>}
              </div>
              <div>
                <label className="block mb-1.5 text-sm font-medium text-[#374151]">Telefone</label>
                <Input
                  type="tel"
                  placeholder="(00) 00000-0000"
                  value={novoVendedorTelefone}
                  onChange={(e) => {
                    const formatted = formatTelefone(e.target.value);
                    setNovoVendedorTelefone(formatted);
                    if (telefoneError) setTelefoneError("");
                  }}
                  className={`border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 disabled:opacity-50 disabled:cursor-not-allowed h-9 text-sm ${telefoneError ? 'border-red-500' : ''}`}
                  disabled={!selectedContextId}
                  maxLength={15}
                />
                {telefoneError && <span className="text-red-500 text-xs mt-0.5 block">{telefoneError}</span>}
              </div>
            </div>
            <div className="flex justify-end">
              <Button
                onClick={handleAdicionar}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold shadow-md hover:from-blue-700 hover:to-indigo-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed h-9 px-5 text-sm"
                aria-label="Adicionar vendedor"
                disabled={isUpdating || !selectedContextId || !novoVendedor.trim()}
              >
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Vendedor
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Card para Filtros e Lista de Vendedores */}
        <Card className="shadow-xl border-0 bg-white">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg font-semibold text-[#111827] flex items-center gap-2 mb-2">
              <Users className="w-5 h-5" />
              Lista de Vendedores
            </CardTitle>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block mb-2 font-semibold text-[#1e293b]">Contexto</label>
                <Select 
                  value={selectedContextId} 
                  onValueChange={setSelectedContextId}
                  disabled={contexts.length === 0}
                >
                  <SelectTrigger className="w-full border border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 transition-all h-10 disabled:opacity-50 disabled:cursor-not-allowed">
                    <SelectValue placeholder={contexts.length === 0 ? "Nenhum contexto disponível" : "Selecione um contexto"} />
                  </SelectTrigger>
                  <SelectContent>
                    {contexts.map((ctx) => (
                      <SelectItem key={ctx.id} value={ctx.id}>
                        {ctx.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block mb-2 font-semibold text-[#1e293b]">Pesquisar</label>
                <div className="relative w-full">
                  <Input
                    placeholder="Digite o nome do vendedor"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 pl-10 h-10"
                  />
                  <Search className="w-4 h-4 text-blue-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block mb-2 font-semibold text-[#1e293b]">Filtrar por tipo</label>
                <Select value={filterByType} onValueChange={(value: SellerType | 'ALL') => setFilterByType(value)}>
                  <SelectTrigger className="w-full border border-blue-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-400 transition-all h-10">
                    <SelectValue placeholder="Todos os tipos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ALL">Todos os tipos</SelectItem>
                    <SelectItem value="SDR">SDR</SelectItem>
                    <SelectItem value="CLOSER">Closer</SelectItem>
                    <SelectItem value="Geral">Geral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {vendedoresFiltrados.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-center bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg border-2 border-dashed border-gray-200">
                  <User className="w-16 h-16 mb-4 text-gray-400" />
                  <span className="font-semibold text-xl text-gray-600 mb-2">Nenhum vendedor encontrado</span>
                  <span className="text-sm text-gray-500 max-w-sm">
                    {search || filterByType !== 'ALL' 
                      ? "Tente ajustar os filtros de pesquisa ou adicione um novo vendedor."
                      : "Adicione seu primeiro vendedor para começar a gerenciar sua equipe de vendas."
                    }
                  </span>
                </div>
              ) : (
                <div className="grid gap-4">
                  {vendedoresFiltrados.map((v) => {
                    const contextoSelecionado = contexts.find(ctx => ctx.id === selectedContextId);
                    const isAtivo = contextoSelecionado && contextoSelecionado.vendedor_ativo_id === v.id;
                    return (
                      <div 
                        key={v.id} 
                        className={`bg-white border rounded-lg p-3 transition-all duration-200 hover:shadow-sm ${
                          isAtivo ? 'ring-2 ring-green-400 border-green-200 bg-green-50/30' : 'border-gray-200'
                        }`}
                      >
                        {editandoVendedor === v.id ? (
                          <div className="space-y-2.5">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                              <div>
                                <label className="block mb-1 text-sm font-medium text-gray-700">Nome *</label>
                                <Input
                                  value={vendedorEditado}
                                  onChange={(e) => setVendedorEditado(e.target.value)}
                                  className="border-blue-200 focus:ring-2 focus:ring-blue-400 h-8 text-sm"
                                  onKeyDown={e => { if (e.key === 'Enter') handleSalvarEdicao(); if (e.key === 'Escape') { setEditandoVendedor(null); setEmailError(""); setTelefoneError(""); } }}
                                  autoFocus
                                />
                              </div>
                              <div>
                                <label className="block mb-1 text-sm font-medium text-gray-700">Tipo *</label>
                                <Select value={vendedorEditadoTipo} onValueChange={(value: SellerType) => setVendedorEditadoTipo(value)}>
                                  <SelectTrigger className="border-blue-200 focus:ring-2 focus:ring-blue-400 h-8 text-sm">
                                    <SelectValue placeholder="Selecione o tipo" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Geral">Geral</SelectItem>
                                    <SelectItem value="SDR">SDR</SelectItem>
                                    <SelectItem value="CLOSER">Closer</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="block mb-1 text-sm font-medium text-gray-700">Email</label>
                                <Input
                                  type="email"
                                  placeholder="email@exemplo.com"
                                  value={vendedorEditadoEmail}
                                  onChange={(e) => {
                                    setVendedorEditadoEmail(e.target.value);
                                    if (emailError) setEmailError("");
                                  }}
                                  className={`border-blue-200 focus:ring-2 focus:ring-blue-400 h-8 text-sm ${emailError ? 'border-red-500' : ''}`}
                                  onKeyDown={e => { if (e.key === 'Enter') handleSalvarEdicao(); }}
                                />
                                {emailError && <span className="text-red-500 text-xs mt-0.5 block">{emailError}</span>}
                              </div>
                              <div>
                                <label className="block mb-1 text-sm font-medium text-gray-700">Telefone</label>
                                <Input
                                  type="tel"
                                  placeholder="(00) 00000-0000"
                                  value={vendedorEditadoTelefone}
                                  onChange={(e) => {
                                    const formatted = formatTelefone(e.target.value);
                                    setVendedorEditadoTelefone(formatted);
                                    if (telefoneError) setTelefoneError("");
                                  }}
                                  className={`border-blue-200 focus:ring-2 focus:ring-blue-400 h-8 text-sm ${telefoneError ? 'border-red-500' : ''}`}
                                  maxLength={15}
                                  onKeyDown={e => { if (e.key === 'Enter') handleSalvarEdicao(); }}
                                />
                                {telefoneError && <span className="text-red-500 text-xs mt-0.5 block">{telefoneError}</span>}
                              </div>
                            </div>
                            <div className="flex gap-2 justify-end">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => { setEditandoVendedor(null); setVendedorEditado(""); setVendedorEditadoTipo("Geral"); setVendedorEditadoEmail(""); setVendedorEditadoTelefone(""); setEmailError(""); setTelefoneError(""); }}
                                disabled={isUpdating}
                                className="border-gray-300 h-8 text-sm"
                              >
                                <X className="w-2 h-2"/>Cancelar</Button>
                              <Button 
                                size="sm"
                                onClick={handleSalvarEdicao} 
                                disabled={isUpdating || !vendedorEditado.trim()}
                                className="bg-green-600 hover:bg-green-700 h-8 text-sm"
                              >
                                <Check className="w-2 h-2"/>Salvar</Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3 flex-1">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${getSellerTypeBadgeColor(v.tipo)}`}>
                                {getSellerTypeIcon(v.tipo)}
                              </div>
                              <div className="flex flex-col gap-1 flex-1">
                                <div className="flex items-center gap-2">
                                  <h3 className="font-semibold text-base text-gray-900">{v.name}</h3>
                                  {v.tipo && v.tipo !== 'Geral' && (
                                    <Badge 
                                      className={`${getSellerTypeBadgeColor(v.tipo)} text-white text-xs px-2 py-0.5`}
                                    >
                                      {getSellerTypeLabel(v.tipo)}
                                    </Badge>
                                  )}
                                  {isAtivo && (
                                    <Badge className="bg-green-500 text-white text-xs px-2 py-0.5">
                                      ✓ Ativo
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-1">
                              {!isAtivo && (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleSetVendedorAtivo(selectedContextId, v.id)}
                                  className="border-green-200 text-green-700 hover:bg-green-50 hover:border-green-300 h-8 px-2"
                                  disabled={isUpdating}
                                >
                                  <UserCheck className="w-3 h-3 mr-1" />
                                  Ativar
                                </Button>
                              )}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditar(v.id)}
                                className="border-blue-200 text-blue-700 hover:bg-blue-50 hover:border-blue-300 h-8 w-8 p-0"
                                disabled={isUpdating}
                              >
                                <Edit2 className="w-3 h-3" />
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRemover(v.id)}
                                className="border-red-200 text-red-700 hover:bg-red-50 hover:border-red-300 h-8 w-8 p-0"
                                disabled={isUpdating}
                              >
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            {/* Dialog de confirmação de exclusão */}
            <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Confirmar exclusão</DialogTitle>
                </DialogHeader>
                {isSellerActive ? (
                  <div className="flex items-center gap-3 mb-2">
                    <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                    <span className="text-red-600 text-sm font-semibold">Este vendedor está ativo em um contexto. Tem certeza que deseja removê-lo?</span>
                  </div>
                ) : (
                  <div className="mb-2">Tem certeza que deseja remover este vendedor?</div>
                )}
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
                    Cancelar
                  </Button>
                  <Button variant="destructive" onClick={confirmDeleteSeller} disabled={isUpdating}>
                    Remover
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
} 