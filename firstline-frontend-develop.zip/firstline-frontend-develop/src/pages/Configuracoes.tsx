import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import { Settings, Building, CreditCard, Moon, Sun, Bell, Shield, Save, User, Camera, Edit, Mail, Phone, Link } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { validateEmail, validatePhone, sanitizeInput } from "@/utils/validation";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';
import { GoogleSignInButton } from '@/components/auth/GoogleSignInButton';

interface Profile {
  company_name: string;
  responsible_name: string;
  phone: string;
  cnpj: string;
  contact_email: string;
  current_plan: string;
  plan_renewal_date: string | null;
  google_connected?: boolean;
  google_email?: string;
  google_name?: string;
  google_picture?: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

// Extrair client_id do Google OAuth
const getGoogleClientId = () => {
  return import.meta.env.VITE_GOOGLE_CLIENT_ID || '';
};

export default function Configuracoes() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState<Profile>({
    company_name: "",
    responsible_name: "",
    phone: "",
    cnpj: "",
    contact_email: "",
    current_plan: "free",
    plan_renewal_date: null,
    google_connected: false,
    google_email: "",
    google_name: "",
    google_picture: "",
  });
  const [editingPerfil, setEditingPerfil] = useState(false);
  const [connectingGoogle, setConnectingGoogle] = useState(false);

  useEffect(() => {
    if (user) {
      fetchProfile();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const response = await apiFetch(`${API_BASE_URL}/profile`);

      if (!response.ok) {
        throw new Error('Failed to fetch profile');
      }

      const data = await response.json();
      setProfile(data);
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível carregar o perfil.",
        variant: "destructive"
      });
    }
  };

  const handleInputChange = (field: keyof Profile, value: string) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case 'premium':
        return 'bg-yellow-100 text-yellow-800';
      case 'professional':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getPlanName = (plan: string) => {
    switch (plan) {
      case 'premium':
        return 'Premium';
      case 'professional':
        return 'Professional';
      default:
        return 'Gratuito';
    }
  };

  // Função de validação extraída para reuso
  const validarCampos = () => {
    const errors: string[] = [];
    if (!profile.company_name || profile.company_name.trim() === '') {
      errors.push('Nome da empresa é obrigatório');
    }
    if (!profile.responsible_name || profile.responsible_name.trim() === '') {
      errors.push('Nome do responsável é obrigatório');
    }
    if (!profile.phone || profile.phone.trim() === '') {
      errors.push('Telefone é obrigatório');
    } else if (!validatePhone(profile.phone)) {
      errors.push('Telefone deve ter um formato válido');
    }
    if (!profile.contact_email || profile.contact_email.trim() === '') {
      errors.push('Email de contato é obrigatório');
    } else if (!validateEmail(profile.contact_email)) {
      errors.push('Email deve ter um formato válido');
    }
    return errors;
  };

  // Salvar perfil
  const handleSavePerfil = async () => {
    if (!user) return;
    const errors = validarCampos();
    if (errors.length > 0) {
      toast({
        title: "Erro de Validação",
        description: errors.join(", "),
        variant: "destructive",
      });
      return false;
    }
    setLoading(true);
    try {
      const sanitizedProfile = {
        ...profile,
        company_name: sanitizeInput(profile.company_name),
        responsible_name: sanitizeInput(profile.responsible_name),
        phone: sanitizeInput(profile.phone),
        contact_email: sanitizeInput(profile.contact_email),
      };
      const response = await apiFetch(`${API_BASE_URL}/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(sanitizedProfile),
      });
      if (!response.ok) {
        throw new Error('Failed to update profile');
      }
      toast({
        title: "Configurações Salvas",
        description: "Suas informações foram atualizadas com sucesso.",
      });
      return true;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao Salvar",
        description: "Ocorreu um erro ao salvar as configurações.",
        variant: "destructive",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Conectar com Google
  const handleGoogleConnect = async (userData: { id: string; email: string; name: string; picture: string }) => {
    setConnectingGoogle(true);
    try {
      const response = await apiFetch(`${API_BASE_URL}/auth/google/connect`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          google_id: userData.id,
          google_email: userData.email,
          google_name: userData.name,
          google_picture: userData.picture,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to connect Google account');
      }

      // Atualizar o perfil com as informações da conexão
      setProfile(prev => ({
        ...prev,
        google_connected: true,
        google_email: userData.email,
        google_name: userData.name,
        google_picture: userData.picture,
      }));

      toast({
        title: "Conta Google Conectada",
        description: `Conta ${userData.email} conectada com sucesso.`,
      });
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao Conectar",
        description: "Não foi possível conectar sua conta Google.",
        variant: "destructive",
      });
    } finally {
      setConnectingGoogle(false);
    }
  };

  // Desconectar Google
  const handleGoogleDisconnect = async () => {
    setConnectingGoogle(true);
    try {
      const response = await apiFetch(`${API_BASE_URL}/auth/google/disconnect`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to disconnect Google account');
      }

      // Atualizar o perfil removendo as informações da conexão
      setProfile(prev => ({
        ...prev,
        google_connected: false,
        google_email: "",
        google_name: "",
        google_picture: "",
      }));

      toast({
        title: "Conta Google Desconectada",
        description: "Sua conta Google foi desconectada com sucesso.",
      });
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro ao Desconectar",
        description: "Não foi possível desconectar sua conta Google.",
        variant: "destructive",
      });
    } finally {
      setConnectingGoogle(false);
    }
  };

  const handleGoogleError = (error: any) => {
    toast({
      title: "Erro na Autenticação",
      description: "Ocorreu um erro ao tentar conectar com o Google.",
      variant: "destructive",
    });
  };

  return (
    <div className="container mx-auto px-20 p-6 max-w-none">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Configurações</h1>
        <p className="text-gray-600">Gerencie suas informações e preferências</p>
      </div>

      <div className="flex gap-8"> {/* Sidebar mais à esquerda */}
        {/* Sidebar */}
        <div className="w-64 flex-shrink-0"> {/* Largura fixa e alinhamento à esquerda */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Menu
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="ghost" className="w-full justify-start">
                <User className="w-4 h-4 mr-2" />
                Meu Perfil
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Link className="w-4 h-4 mr-2" />
                Integrações
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <CreditCard className="w-4 h-4 mr-2" />
                Plano e Cobrança
              </Button>
              {/*<Button variant="ghost" className="w-full justify-start">
                <Bell className="w-4 h-4 mr-2" />
                Notificações
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                <Shield className="w-4 h-4 mr-2" />
                Segurança
              </Button>*/}
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <div className="flex-1 space-y-8"> {/* Mais espaçamento e largura */}
          {/* Meu Perfil */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <User className="w-5 h-5" />
                Meu Perfil
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-0 items-start">
                {/* Foto do Perfil */}
                {/*
                <div className="flex flex-col items-start space-y-5 -mt-2 pl-20">
                  <Avatar className="w-32 h-32">
                    <AvatarImage src="" alt="Profile" />
                    <AvatarFallback className="text-3xl bg-blue-100 text-blue-600">
                      {profile.responsible_name ? profile.responsible_name.charAt(0) : (user?.email?.charAt(0) || 'U')}
                    </AvatarFallback>
                  </Avatar>
                  <Button>
                    <Camera className="w-4 h-4 mr-2" />
                    Alterar Foto
                  </Button>
                </div>
                */}
                {/* Informações Pessoais */}
                <div className="col-span-1 lg:col-span-3 -mt-3 w-full pr-2 pl-2">
                  <div className="flex flex-row items-center justify-between mb-2">
                    <span className="text-xl text-gray-700 font-bold">Informações Pessoais</span>
                    <Button
                      onClick={async () => {
                        if (editingPerfil) {
                          const ok = await handleSavePerfil();
                          if (ok) setEditingPerfil(false);
                        } else {
                          setEditingPerfil(true);
                        }
                      }}
                    >
                      {editingPerfil ? (
                        <>
                          <Save className="w-4 h-4 mr-2" />Salvar
                        </>
                      ) : (
                        <>
                          <Edit className="w-4 h-4 mr-2" />Editar
                        </>
                      )}
                    </Button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5"> 
                    <div>
                      <Label htmlFor="responsible_name" className="text-[#4B5563] font-medium flex items-center">
                        <User className="w-4 h-4 mr-2" />Nome Completo
                      </Label>
                      <Input
                        id="responsible_name"
                        value={profile.responsible_name}
                        onChange={(e) => handleInputChange('responsible_name', e.target.value)}
                        disabled={!editingPerfil}
                        className={`mt-2 bg-white border-gray-300 focus:border-emerald-400 text-[#111827] disabled:bg-gray-50 ${editingPerfil && !profile.responsible_name?.trim() ? "border-red-300 focus:border-red-500" : ""}`}
                      />
                    </div>
                    <div>
                      <Label htmlFor="contact_email" className="text-[#4B5563] font-medium flex items-center">
                        <Mail className="w-4 h-4 mr-2" />Email
                      </Label>
                      <Input
                        id="contact_email"
                        type="email"
                        value={profile.contact_email}
                        onChange={(e) => handleInputChange('contact_email', e.target.value)}
                        disabled={!editingPerfil}
                        className={`mt-2 bg-white border-gray-300 focus:border-emerald-400 text-[#111827] disabled:bg-gray-50 ${editingPerfil && !profile.contact_email?.trim() ? "border-red-300 focus:border-red-500" : ""}`}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-[#4B5563] font-medium flex items-center">
                        <Phone className="w-4 h-4 mr-2" />Telefone
                      </Label>
                      <Input
                        id="phone"
                        value={profile.phone}
                        onChange={(e) => handleInputChange('phone', e.target.value)}
                        disabled={!editingPerfil}
                        placeholder="(11) 99999-9999"
                        className={`mt-2 bg-white border-gray-300 focus:border-emerald-400 text-[#111827] disabled:bg-gray-50 placeholder:text-[#4B5563] ${editingPerfil && !profile.phone?.trim() ? "border-red-300 focus:border-red-500" : ""}`}
                      />
                    </div>
                    <div>
                      <Label htmlFor="company_name" className="text-[#4B5563] font-medium flex items-center">
                        <Building className="w-4 h-4 mr-2" />Empresa
                      </Label>
                      <Input
                        id="company_name"
                        value={profile.company_name}
                        onChange={(e) => handleInputChange('company_name', e.target.value)}
                        disabled={!editingPerfil}
                        placeholder="Nome da sua empresa"
                        className={`mt-2 bg-white border-gray-300 focus:border-emerald-400 text-[#111827] disabled:bg-gray-50 placeholder:text-[#4B5563] ${editingPerfil && !profile.company_name?.trim() ? "border-red-300 focus:border-red-500" : ""}`}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Integrações */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Link className="w-5 h-5" />
                Integrações
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 pr-2 pl-1">
                {/* Google Integration */}
                <div className="border rounded-lg p-4 bg-gray-50/50">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-white rounded-lg shadow-sm flex items-center justify-center border">
                        <svg viewBox="0 0 24 24" className="w-5 h-5">
                          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-base">Google</h3>
                        <p className="text-sm text-gray-500">
                          {profile.google_connected 
                            ? `Conectado com ${profile.google_email}`
                            : "Conecte sua conta Google"
                          }
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3 ml-4">
                      {profile.google_connected ? (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={handleGoogleDisconnect}
                          disabled={connectingGoogle}
                          className="rounded-lg text-red-600 border-red-300 hover:bg-red-50 hover:border-red-400 hover:text-red-700"
                        >
                          {connectingGoogle ? "Desconectando..." : "Desconectar"}
                        </Button>
                      ) : (
                        <GoogleSignInButton
                          clientId={getGoogleClientId()}
                          onSuccess={handleGoogleConnect}
                          onError={handleGoogleError}
                          buttonConfig={{
                            type: 'standard',
                            theme: 'outline',
                            size: 'large',
                            text: 'continue_with',
                            shape: 'pill',
                            width: '192'
                          }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>          {/* Plano Atual */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <CreditCard className="w-5 h-5" />
                Plano Atual
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between pr-2 pl-2">
                <div>
                    <Badge className={`text-xs px-4 py-2 ${getPlanColor(profile.current_plan)}`}>
                    {getPlanName(profile.current_plan)}
                    </Badge>
                  {profile.plan_renewal_date && (
                    <p className="text-sm text-gray-600 mt-1">
                      Renovação: {new Date(profile.plan_renewal_date).toLocaleDateString()}
                    </p>
                  )}
                </div>
                <Button 
                  variant="outline"
                  onClick={() => window.open('https://firstlineai.com.br/#preco', '_blank')}
                  className="relative bottom-1"
                >
                  Alterar Plano
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Preferências */}
          {/*<Card className="w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Preferências
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="notifications">Notificações</Label>
                  <p className="text-sm text-gray-600">Receber notificações sobre análises</p>
                </div>
                <Switch
                  id="notifications"
                  checked={notifications}
                  onCheckedChange={setNotifications}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="dark-mode">Modo Escuro</Label>
                  <p className="text-sm text-gray-600">Alternar tema da interface</p>
                </div>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={setDarkMode}
                />
              </div>
            </CardContent>
          </Card>*/}
        </div>
      </div>
    </div>
  );
}
