// Types para o sistema de contextos com campos estruturados em JSON

export interface ObjectionResponse {
  objection: string;
  response: string;
}

export interface Vendedor {
  id: string;
  name: string;
}

export interface Context {
  id: string;
  user_id?: string;
  name: string;
  description?: string;
  
  // Campos estruturados (JSON)
  productInfo?: string;
  targetAudience?: string;
  commonObjections?: ObjectionResponse[]; // Array de objetos
  pricingStructure?: string;
  playbook?: string;
  mentalTriggers?: string;
  competitors?: string[]; // Array de strings
  
  is_active: boolean;
  vendedores: Vendedor[];
  vendedor_ativo: string | null;
  vendedor_ativo_id?: string;
  vendedor_ativo_nome?: string;
  vendedor_ativo_tipo?: string;
  created_at: string;
  updated_at?: string;
}

export interface ContextFormData {
  id?: string;
  name: string;
  description?: string;
  vendedor_ativo_id?: string;
  
  // Campos estruturados
  productInfo?: string;
  targetAudience?: string;
  commonObjections?: ObjectionResponse[];
  pricingStructure?: string;
  playbook?: string;
  mentalTriggers?: string;
  competitors?: string[];
  
  // Campos de controle
  is_active?: boolean;
  vendedor_ativo?: string | null;
  vendedores?: Vendedor[];
  created_at?: string;
}

export interface ContextAPIPayload {
  name: string;
  description?: string;
  vendedor_ativo_id?: string;
  
  // Campos estruturados enviados para API
  productInfo?: string;
  targetAudience?: string;
  commonObjections?: ObjectionResponse[];
  pricingStructure?: string;
  playbook?: string;
  mentalTriggers?: string;
  competitors?: string[];
}
