import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
import mammoth from 'mammoth';
import JSZip from 'jszip';

// Configurar worker do PDF.js para Vite
async function setupPDFWorker() {
  if (typeof window !== 'undefined' && !GlobalWorkerOptions.workerSrc) {
    try {
      // Tentar usar o worker do CDN jsdelivr que é mais estável
      GlobalWorkerOptions.workerSrc = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@5.4.296/build/pdf.worker.min.mjs';
    } catch (error) {
    }
  }
}

// Inicializar worker
setupPDFWorker();

export interface TextExtractionResult {
  success: boolean;
  text: string;
  error?: string;
  originalSize: number;
  extractedSize: number;
}

export async function extractTextFromFile(file: File): Promise<TextExtractionResult> {
  try {
    const originalSize = file.size;
    let extractedText = '';

    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();

    switch (fileExtension) {
      case '.pdf':
        try {
          extractedText = await extractTextFromPDF(file);
        } catch (pdfError) {
          // Fallback: se PDF falhar, retorna erro para não processar
          throw new Error('PDF não pôde ser processado. Tente um arquivo de texto.');
        }
        break;

      case '.docx':
      case '.doc':
        extractedText = await extractTextFromWord(file);
        break;

      case '.odt':
        extractedText = await extractTextFromODT(file);
        break;

      case '.txt':
      case '.rtf':
        extractedText = await extractTextFromPlainText(file);
        break;

      default:
        throw new Error(`Tipo de arquivo não suportado: ${fileExtension}`);
    }

    const extractedSize = new Blob([extractedText]).size;

    return {
      success: true,
      text: extractedText,
      originalSize,
      extractedSize
    };
  } catch (error) {
    return {
      success: false,
      text: '',
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      originalSize: file.size,
      extractedSize: 0
    };
  }
}

async function extractTextFromPDF(file: File): Promise<string> {
  try {
    // Garantir que o worker está configurado
    await setupPDFWorker();
    
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await getDocument({ 
      data: arrayBuffer,
      verbosity: 0 // Reduzir logs
    }).promise;
    
    let fullText = '';
    
    for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
      const page = await pdf.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      const pageText = textContent.items
        .map((item: any) => item.str)
        .join(' ');
      
      fullText += pageText + '\n\n';
    }
    
    return fullText.trim();
  } catch (error) {
    throw new Error('Não foi possível extrair texto do PDF. Verifique se o arquivo não está corrompido.');
  }
}

async function extractTextFromWord(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  
  return result.value;
}

async function extractTextFromPlainText(file: File): Promise<string> {
  return await file.text();
}

async function extractTextFromODT(file: File): Promise<string> {
  // ODT é um ZIP com content.xml dentro; vamos extrair e limpar tags XML
  const arrayBuffer = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(arrayBuffer);
  const contentFile = zip.file('content.xml');
  if (!contentFile) {
    throw new Error('Arquivo ODT inválido: content.xml ausente');
  }

  const contentXml = await contentFile.async('string');
  // Remover tags XML simplificando para texto legível
  const text = contentXml
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return text;
}

export function createTextFile(text: string, originalFileName: string): File {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const fileName = originalFileName.replace(/\.[^/.]+$/, '') + '_extracted.txt';
  
  return new File([blob], fileName, { type: 'text/plain' });
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}