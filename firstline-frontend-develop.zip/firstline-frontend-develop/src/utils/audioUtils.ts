import { parseBuffer } from 'music-metadata';

/**
 * Get the actual duration of an audio file in minutes
 * Tries multiple methods: Audio API first, then music-metadata as fallback
 */
export const getAudioDuration = async (file: File): Promise<number> => {
  try {
    // Method 1: Try using HTML5 Audio API (fastest)
    const duration = await getAudioDurationFromAudioAPI(file);
    if (duration && duration > 0) {
      return duration / 60; // Convert seconds to minutes
    }
  } catch (error) {
  }

  try {
    // Method 2: Use music-metadata library (more reliable)
    const duration = await getAudioDurationFromMetadata(file);
    if (duration && duration > 0) {
      return duration / 60; // Convert seconds to minutes
    }
  } catch (error) {
  }

  // Method 3: Fallback to file size estimation
  return estimateAudioDurationFromSize(file.size);
};

/**
 * Get audio duration using HTML5 Audio API
 */
const getAudioDurationFromAudioAPI = (file: File): Promise<number> => {
  return new Promise((resolve, reject) => {
    const audio = new Audio();
    const url = URL.createObjectURL(file);
    
    audio.addEventListener('loadedmetadata', () => {
      URL.revokeObjectURL(url);
      if (audio.duration && isFinite(audio.duration)) {
        resolve(audio.duration);
      } else {
        reject(new Error('Invalid duration'));
      }
    });
    
    audio.addEventListener('error', () => {
      URL.revokeObjectURL(url);
      reject(new Error('Audio loading failed'));
    });
    
    // Set timeout to prevent hanging
    setTimeout(() => {
      URL.revokeObjectURL(url);
      reject(new Error('Audio loading timeout'));
    }, 5000);
    
    audio.src = url;
  });
};

/**
 * Get audio duration using music-metadata library
 */
const getAudioDurationFromMetadata = async (file: File): Promise<number> => {
  const buffer = await file.arrayBuffer();
  const metadata = await parseBuffer(Buffer.from(buffer), file.type || 'audio/mpeg');
  
  if (metadata.format && metadata.format.duration) {
    return metadata.format.duration;
  }
  
  throw new Error('No duration found in metadata');
};

/**
 * Fallback: estimate duration from file size
 */
const estimateAudioDurationFromSize = (fileSizeBytes: number): number => {
  // Conservative estimate based on common audio formats:
  // MP3 at 128kbps: ~1MB per minute
  // M4A/AAC: ~0.5-1MB per minute
  // Using: 1MB ≈ 1.2 minutes
  const sizeInMB = fileSizeBytes / (1024 * 1024);
  return sizeInMB * 1.2;
};

/**
 * Get total duration of multiple audio files
 */
export const getTotalAudioDuration = async (files: File[]): Promise<number> => {
  const audioFiles = files.filter(file => {
    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    const audioExtensions = [
      '.mp3', '.wav', '.m4a', '.mp4', '.webm', '.ogg', '.opus', '.aac', 
      '.ac3', '.aiff', '.aif', '.alac', '.amr', '.ape', '.au', '.dss', 
      '.flac', '.tta', '.voc', '.wma', '.3ga', '.8svx', '.flv', '.qcp', 
      '.m4b', '.m4p', '.m4r', '.m4v', '.mts', '.mxf', '.mov', '.qt', 
      '.ts', '.m2t', '.m2ts'
    ];
    return audioExtensions.includes(ext);
  });

  if (audioFiles.length === 0) {
    return 0;
  }

  // Process files in parallel for better performance
  const durations = await Promise.all(
    audioFiles.map(file => getAudioDuration(file))
  );

  return durations.reduce((total, duration) => total + duration, 0);
};
