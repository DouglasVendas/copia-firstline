// Security validation utilities
export const SECURITY_LIMITS = {
  MAX_FILE_SIZE: 200 * 1024 * 1024, // 200MB
  MAX_TEXT_LENGTH: 100000, // 100k characters
  MAX_CLIENT_NAME_LENGTH: 100,
  MAX_CONTEXT_NAME_LENGTH: 100,
  MAX_VENDEDOR_NAME_LENGTH: 100,
  ALLOWED_AUDIO_TYPES: ['audio/mpeg', 'audio/wav', 'audio/mp4', 'audio/webm', 'audio/ogg', 'audio/x-m4a'],
  ALLOWED_TEXT_TYPES: ['text/plain']
};

export function sanitizeInput(input: string): string {
  if (!input) return '';
  
  // Remove potentially dangerous characters and normalize
  return input
    .replace(/[<>]/g, '') // Remove HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: URLs
    .replace(/on\w+=/gi, '') // Remove event handlers
    .trim()
    .substring(0, SECURITY_LIMITS.MAX_TEXT_LENGTH);
}

export function validateFileName(fileName: string): boolean {
  if (!fileName) return false;
  
  // Check for path traversal attempts
  if (fileName.includes('..') || fileName.includes('/') || fileName.includes('\\')) {
    return false;
  }
  
  // Check length
  if (fileName.length > 255) {
    return false;
  }
  
  return true;
}

export function validateFileType(file: File, allowedTypes: string[]): boolean {
  // Check MIME type first
  if (allowedTypes.includes(file.type)) {
    return true;
  }
  
  // For ZIP files, also check file extension since MIME type can vary
  const fileName = file.name.toLowerCase();
  const fileExtension = '.' + fileName.split('.').pop();
  
  // If checking for ZIP files, accept common ZIP MIME types and .zip extension
  if (allowedTypes.includes('.zip')) {
    const zipMimeTypes = [
      'application/zip',
      'application/x-zip-compressed',
      'application/x-zip',
      'multipart/x-zip'
    ];
    
    if (zipMimeTypes.includes(file.type) || fileExtension === '.zip') {
      return true;
    }
  }
  
  // For other file types, check if extension matches allowed types
  return allowedTypes.includes(fileExtension);
}

export function validateFileSize(file: File, maxSize: number = SECURITY_LIMITS.MAX_FILE_SIZE): boolean {
  return file.size <= maxSize;
}

export function validateTextContent(content: string): { isValid: boolean; error?: string } {
  if (!content) {
    return { isValid: false, error: 'Content cannot be empty' };
  }
  
  if (content.length > SECURITY_LIMITS.MAX_TEXT_LENGTH) {
    return { isValid: false, error: `Content exceeds maximum length of ${SECURITY_LIMITS.MAX_TEXT_LENGTH} characters` };
  }
  
  // Check for suspicious patterns
  const suspiciousPatterns = [
    /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    /javascript:/gi,
    /vbscript:/gi,
    /on\w+\s*=/gi
  ];
  
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(content)) {
      return { isValid: false, error: 'Content contains potentially unsafe elements' };
    }
  }
  
  return { isValid: true };
}

export function validateContextOwnership(contextId: string, userContexts: any[]): boolean {
  return userContexts.some(ctx => ctx.id === contextId);
}

export function validateVendedorSelection(vendedor: string, contextVendedores: string[]): boolean {
  if (!vendedor || !contextVendedores) return true; // Optional field
  return contextVendedores.includes(vendedor);
}

// Profile validation utilities
export interface ProfileData {
  company_name: string;
  responsible_name: string;
  phone: string;
  contact_email: string;
}

export function validateEmail(email: string): boolean {
  if (!email) return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  if (!phone) return false;
  // Remove all non-numeric characters
  const numericPhone = phone.replace(/\D/g, '');
  // Should have at least 10 digits (Brazilian phone numbers)
  return numericPhone.length >= 10;
}

export function validateProfileData(profile: ProfileData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Validate required fields
  if (!profile.company_name || profile.company_name.trim() === '') {
    errors.push('Nome da empresa é obrigatório');
  }
  
  if (!profile.responsible_name || profile.responsible_name.trim() === '') {
    errors.push('Nome do responsável é obrigatório');
  }
  
  if (!profile.phone || profile.phone.trim() === '') {
    errors.push('Telefone é obrigatório');
  } else if (!validatePhone(profile.phone)) {
    errors.push('Telefone deve ter um formato válido');
  }
  
  if (!profile.contact_email || profile.contact_email.trim() === '') {
    errors.push('Email de contato é obrigatório');
  } else if (!validateEmail(profile.contact_email)) {
    errors.push('Email deve ter um formato válido');
  }
  
  // Validate length limits
  if (profile.company_name && profile.company_name.length > 100) {
    errors.push('Nome da empresa não pode ter mais de 100 caracteres');
  }
  
  if (profile.responsible_name && profile.responsible_name.length > 100) {
    errors.push('Nome do responsável não pode ter mais de 100 caracteres');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

export function sanitizeProfileData(profile: ProfileData): ProfileData {
  return {
    company_name: sanitizeInput(profile.company_name),
    responsible_name: sanitizeInput(profile.responsible_name),
    phone: sanitizeInput(profile.phone),
    contact_email: sanitizeInput(profile.contact_email)
  };
}
