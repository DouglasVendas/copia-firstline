import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Layout } from "@/components/layout/Layout";
import Dashboard from "./pages/Dashboard";
import Contexto from "./pages/Contexto";
import Interacoes from "./pages/Interacoes";
import Relatorios from "./pages/Relatorios";
import Planos from "./pages/Planos";
import Perfil from "./pages/Perfil";
import Configuracoes from "./pages/Configuracoes";
import Auth from "./pages/Auth";
import Register from "./pages/Register";
import ExclusiveSignup from "./pages/ExclusiveSignup";
import NotFound from "./pages/NotFound";
import Vendedores from "./pages/Vendedores";
import PasswordResetRequest from "./pages/PasswordResetRequest";
import MeetingBot from "./pages/MeetingBot";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfUse from "./pages/TermsOfUse";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route path="/register" element={<Register />} />
            <Route path="/redefinir-senha" element={<PasswordResetRequest />} />
            <Route path="/politica-privacidade" element={<PrivacyPolicy />} />
            <Route path="/termos-de-uso" element={<TermsOfUse />} />
            {/* <Route path="/cadastro-exclusivo-:token" element={<ExclusiveSignup />} /> */}
            <Route path="/" element={
              <ProtectedRoute>
                <Layout>
                  <Dashboard />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/contexto" element={
              <ProtectedRoute>
                <Layout>
                  <Contexto />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/interacoes" element={
              <ProtectedRoute>
                <Layout>
                  <Interacoes />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/relatorios" element={
              <ProtectedRoute>
                <Layout>
                  <Relatorios />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/planos" element={
              <ProtectedRoute>
                <Layout>
                  <Planos />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/perfil" element={
              <ProtectedRoute>
                <Layout>
                  <Perfil />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/configuracoes" element={
              <ProtectedRoute>
                <Layout>
                  <Configuracoes />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="/vendedores" element={<Vendedores />} />
            <Route path="/meeting-bot" element={
              <ProtectedRoute>
                <Layout>
                  <MeetingBot />
                </Layout>
              </ProtectedRoute>
            } />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
