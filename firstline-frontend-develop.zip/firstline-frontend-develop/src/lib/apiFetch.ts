// Utilitário central para chamadas de API com cookies HTTP-only

const API_BASE_URL = import.meta.env.VITE_API_URL;
// Usando cookies HTTP-only - sem dependência de localStorage para tokens

let isRefreshing = false;
let refreshSubscribers: Array<() => void> = [];

function isAuthRoute(input: RequestInfo): boolean {
  if (typeof input === 'string') {
    return input.includes('/auth/') && !input.includes('/auth/refresh');
  }
  if (input instanceof Request) {
    return input.url.includes('/auth/') && !input.url.includes('/auth/refresh');
  }
  return false;
}

function onRefreshCompleted() {
  refreshSubscribers.forEach(callback => callback());
  refreshSubscribers = [];
}

function subscribeToTokenRefresh(callback: () => void) {
  refreshSubscribers.push(callback);
}

function clearAuthData() {
  // Limpar apenas dados do usuário do localStorage - os tokens estão em cookies HTTP-only
  localStorage.removeItem('auth-user');
  localStorage.removeItem('auth-exp');
}

async function refreshAccessToken(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
      method: 'POST',
      credentials: 'include', // Inclui cookies HTTP-only automaticamente
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error('Refresh failed');
    }

    const data = await response.json();
    return data.success;
  } catch (error) {
    return false;
  }
}

export class AuthRedirectError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AuthRedirectError";
  }
}

export async function apiFetch(input: RequestInfo, init?: RequestInit): Promise<Response> {
  // Configurar requisição com cookies HTTP-only
  const requestInit: RequestInit = {
    ...init,
    credentials: 'include', // Sempre incluir cookies
    headers: {
      // Não definir Content-Type se for FormData (para permitir multipart/form-data)
      ...(init?.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...init?.headers,
    },
  };

  // Se for uma rota de autenticação (exceto refresh), faz requisição diretamente
  if (isAuthRoute(input)) {
    return await fetch(input, requestInit);
  }
  
  const response = await fetch(input, requestInit);

  // Se recebeu 401 e não é uma rota de auth, tenta fazer refresh
  if (response.status === 401 && !isAuthRoute(input)) {
    // Se já está fazendo refresh, aguarda o resultado
    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        subscribeToTokenRefresh(async () => {
          try {
            // Refaz a requisição após o refresh
            const retryResponse = await fetch(input, requestInit);
            resolve(retryResponse);
          } catch (error) {
            reject(error);
          }
        });
      });
    }

    // Tenta fazer refresh uma vez
    isRefreshing = true;
    
    try {
      const refreshSuccess = await refreshAccessToken();
      
      if (refreshSuccess) {
        isRefreshing = false;
        onRefreshCompleted();
        
        // Refaz a requisição original após o refresh
        return await fetch(input, requestInit);
      } else {
        // Refresh falhou, redireciona para login
        isRefreshing = false;
        clearAuthData();
        window.location.href = "/auth";
        throw new AuthRedirectError('Não autorizado. Redirecionando para login.');
      }
    } catch (error) {
      isRefreshing = false;
      clearAuthData();
      window.location.href = "/auth";
      throw new AuthRedirectError('Erro ao renovar sessão. Redirecionando para login.');
    }
  }

  return response;
}
