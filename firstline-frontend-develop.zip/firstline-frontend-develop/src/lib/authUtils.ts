// Utilitários para gerenciamento de autenticação com cookies HTTP-only

const EXP_KEY = 'auth-exp';

export function getStoredExpiration(): number | null {
  const exp = localStorage.getItem(EXP_KEY);
  return exp ? Number(exp) : null;
}

export function isTokenExpired(marginSeconds: number = 30): boolean {
  const exp = getStoredExpiration();
  if (!exp) {
    return true; // Se não temos expiração salva, assumimos expirado
  }
  
  const now = Math.floor(Date.now() / 1000);
  return now >= (exp - marginSeconds);
}


export function clearTokens(): void {
  // Com cookies HTTP-only, apenas limpamos dados locais
  // Os cookies serão limpos pelo servidor via endpoint de logout
  localStorage.removeItem('auth-user');
  localStorage.removeItem(EXP_KEY);
}
