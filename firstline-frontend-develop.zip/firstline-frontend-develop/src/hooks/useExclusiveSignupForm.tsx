import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { AuthRedirectError } from '@/lib/apiFetch';

interface SignupFormData {
  email: string;
  password: string;
  confirmPassword: string;
  companyName: string;
  responsibleName: string;
  phone: string;
  cnpj: string;
}

export function useExclusiveSignupForm() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<SignupFormData>({
    email: '',
    password: '',
    confirmPassword: '',
    companyName: '',
    responsibleName: '',
    phone: '',
    cnpj: ''
  });

  const handleInputChange = (field: keyof SignupFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const submitSignup = async (tokenData: any) => {
    setLoading(true);
    try {
      // Validações básicas
      if (!formData.email || !formData.password || !formData.confirmPassword) {
        toast({
          title: "Erro de validação",
          description: "Por favor, preencha todos os campos obrigatórios",
          variant: "destructive"
        });
        return false;
      }

      if (formData.password !== formData.confirmPassword) {
        toast({
          title: "Erro de validação",
          description: "As senhas não coincidem",
          variant: "destructive"
        });
        return false;
      }

      toast({
        title: "Cadastro realizado!",
        description: "Sua conta foi criada com sucesso",
        variant: "default"
      });

      return true;

    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro no cadastro",
        description: "Ocorreu um erro ao criar sua conta. Tente novamente.",
        variant: "destructive"
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    loading,
    handleInputChange,
    submitSignup
  };
}