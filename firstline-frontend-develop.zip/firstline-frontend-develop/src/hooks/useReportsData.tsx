import { useState, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface Analysis {
  id: string;
  created_at: string;
  client_name: string;
  score_geral: number;
  upload_type: string;
  resumo: string;
  pontos_positivos: string[];
  pontos_atencao: string[];
  objecoes_identificadas: string[];
  sugestoes_melhoria: string[];
  proximos_passos: string[];
  context_uuid: string;
  transcription: string;
  vendedor: string; // nome
  vendedor_id: string; // id
  // Enhanced AI analysis fields
  framework_analysis?: any;
  coaching_insights?: string[];
  performance_analysis?: any;
  mental_triggers?: any;
  reformulacoes_pnl?: any;
  plano_fechamento?: string[];
  ia_preditiva?: any;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

export function useReportsData() {
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVendedor, setSelectedVendedor] = useState('');
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({ from: undefined, to: undefined });
  const [scoreRange, setScoreRange] = useState<{ min: number | undefined; max: number | undefined }>({ min: undefined, max: undefined });
  const [selectedContext, setSelectedContext] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminUserEmail, setAdminUserEmail] = useState('');
  const [adminSearchLoading, setAdminSearchLoading] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchAnalyses = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const response = await apiFetch(`${API_BASE_URL}/analyses`);

      if (!response.ok) {
        throw new Error('Failed to fetch analyses');
      }

      const data = await response.json();
      
      // A API retorna {data: [...], pagination: {...}, success: true, is_admin: boolean}
      const analysesArray = data.data || [];
      setAnalyses(Array.isArray(analysesArray) ? analysesArray : []);
      setIsAdmin(data.is_admin || false);
    } catch (err) {
      if (err instanceof AuthRedirectError) return;
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch analyses';
      setError(errorMessage);
      toast({
        title: "Erro ao carregar dados",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const searchUserAnalyses = async (userEmail: string) => {
    if (!user || !isAdmin || !userEmail.trim()) return;

    try {
      setAdminSearchLoading(true);
      setError(null);

      const response = await apiFetch(`${API_BASE_URL}/analyses/admin/${encodeURIComponent(userEmail.trim())}`);

      if (!response.ok) {
        throw new Error('Failed to fetch user analyses');
      }

      const data = await response.json();
      
      const analysesArray = data.data || [];
      setAnalyses(Array.isArray(analysesArray) ? analysesArray : []);
      
      toast({
        title: "Busca concluída",
        description: `Encontradas ${analysesArray.length} análises para ${userEmail}`,
      });
    } catch (err) {
      if (err instanceof AuthRedirectError) return;
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch user analyses';
      setError(errorMessage);
      toast({
        title: "Erro ao buscar análises",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setAdminSearchLoading(false);
    }
  };

  const clearAdminSearch = () => {
    setAdminUserEmail('');
    fetchAnalyses();
  };

  const updateAnalysisName = (analysisId: string, newName: string) => {
    setAnalyses(prevAnalyses => 
      prevAnalyses.map(analysis => 
        analysis.id === analysisId 
          ? { ...analysis, analysis_name: newName }
          : analysis
      )
    );
  };

  const getAnalysisById = async (id: string): Promise<Analysis | null> => {
    if (!user) return null;

    try {
      const response = await apiFetch(`${API_BASE_URL}/analyses/${id}`);

      if (!response.ok) {
        throw new Error('Failed to fetch analysis');
      }

      const data = await response.json();
      return data;
    } catch (err) {
      if (err instanceof AuthRedirectError) return null;
      toast({
        title: "Erro ao carregar análise",
        description: "Não foi possível carregar os dados da análise.",
        variant: "destructive"
      });
      return null;
    }
  };

  const getAnalyticsSummary = () => {
    if (!analyses.length) return null;

    const totalAnalyses = analyses.length;
    const avgScore = analyses.reduce((sum, analysis) => sum + analysis.score_geral, 0) / totalAnalyses;
    
    // Group by month for trend analysis
    const monthlyData = analyses.reduce((acc, analysis) => {
      const month = new Date(analysis.created_at).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
      if (!acc[month]) {
        acc[month] = { count: 0, totalScore: 0 };
      }
      acc[month].count++;
      acc[month].totalScore += analysis.score_geral;
      return acc;
    }, {} as Record<string, { count: number; totalScore: number }>);

    // Group by vendedor for performance analysis
    const vendedorPerformance = analyses.reduce((acc, analysis) => {
      const vendedor = analysis.vendedor || 'Não informado';
      if (!acc[vendedor]) {
        acc[vendedor] = { count: 0, totalScore: 0 };
      }
      acc[vendedor].count++;
      acc[vendedor].totalScore += analysis.score_geral;
      return acc;
    }, {} as Record<string, { count: number; totalScore: number }>);

    return {
      totalAnalyses,
      avgScore,
      monthlyData,
      vendedorPerformance,
      bestScore: Math.max(...analyses.map(a => a.score_geral)),
      worstScore: Math.min(...analyses.map(a => a.score_geral)),
    };
  };

  const getFilteredAnalyses = (filters: {
    dateRange?: { start: Date; end: Date };
    vendedor?: string;
    minScore?: number;
    maxScore?: number;
    contextId?: string;
  }) => {
    return analyses.filter(analysis => {
      if (filters.dateRange) {
        const analysisDate = new Date(analysis.created_at);
        if (analysisDate < filters.dateRange.start || analysisDate > filters.dateRange.end) {
          return false;
        }
      }

      if (filters.vendedor && analysis.vendedor !== filters.vendedor) {
        return false;
      }

      if (filters.minScore !== undefined && analysis.score_geral < filters.minScore) {
        return false;
      }

      if (filters.maxScore !== undefined && analysis.score_geral > filters.maxScore) {
        return false;
      }

      if (filters.contextId && analysis.context_uuid !== filters.contextId) {
        return false;
      }

      return true;
    });
  };

  useEffect(() => {
    fetchAnalyses();
  }, [user]);

  // Computed values
  const vendedores = Array.from(new Set(analyses.map(a => a.vendedor).filter(Boolean)));
  
  const filteredAnalyses = analyses.filter(analysis => {
    // Filtro por busca
    const matchesSearch = !searchTerm || 
      analysis.client_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      analysis.resumo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      analysis.vendedor?.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filtro por vendedor
    const matchesVendedor = !selectedVendedor || analysis.vendedor === selectedVendedor;
    
    // Filtro por contexto
    const matchesContext = !selectedContext || analysis.context_uuid === selectedContext;
    
    // Filtro por data
    const matchesDate = (() => {
      if (!dateRange.from && !dateRange.to) return true;
      
      const analysisDate = new Date(analysis.created_at);
      
      if (dateRange.from && dateRange.to) {
        // Comparar horário completo para garantir inclusão do dia final
        const fromDate = new Date(dateRange.from);
        fromDate.setHours(0, 0, 0, 0);
        const toDate = new Date(dateRange.to);
        toDate.setHours(23, 59, 59, 999);
        return analysisDate >= fromDate && analysisDate <= toDate;
      } else if (dateRange.from) {
        const fromDate = new Date(dateRange.from);
        fromDate.setHours(0, 0, 0, 0);
        return analysisDate >= fromDate;
      } else if (dateRange.to) {
        const toDate = new Date(dateRange.to);
        toDate.setHours(23, 59, 59, 999);
        return analysisDate <= toDate;
      }
      
      return true;
    })();
    
    // Filtro por score
    const matchesScore = (() => {
      if (scoreRange.min !== undefined && analysis.score_geral < scoreRange.min) return false;
      if (scoreRange.max !== undefined && analysis.score_geral > scoreRange.max) return false;
      return true;
    })();
    
    return matchesSearch && matchesVendedor && matchesContext && matchesDate && matchesScore;
  });

  return {
    analyses,
    filteredAnalyses,
    loading,
    error,
    searchTerm,
    selectedVendedor,
    dateRange,
    scoreRange,
    selectedContext,
    vendedores,
    setSearchTerm,
    setSelectedVendedor,
    setDateRange,
    setScoreRange,
    setSelectedContext,
    fetchAnalyses,
    getAnalysisById,
    getAnalyticsSummary,
    getFilteredAnalyses,
    refetch: fetchAnalyses,
    isAdmin,
    adminUserEmail,
    setAdminUserEmail,
    adminSearchLoading,
    searchUserAnalyses,
    clearAdminSearch,
    updateAnalysisName,
  };
}
