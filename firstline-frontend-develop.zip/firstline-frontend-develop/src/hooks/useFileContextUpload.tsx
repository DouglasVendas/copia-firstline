 import { useState, useCallback, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';
import { extractTextFromFile, createTextFile, formatFileSize } from '@/utils/textExtraction';

interface FileUploadState {
  file: File | null;
  isUploading: boolean;
  uploadProgress: number;
  isExtracting: boolean;
  extractionInfo?: {
    originalSize: string;
    extractedSize: string;
    wasExtracted: boolean;
  };
  preview: {
    name: string;
    size: string;
    type: string;
  } | null;
}

const ACCEPTED_FILE_TYPES = ['.pdf', '.docx', '.doc', '.txt', '.rtf', '.odt'];
const MAX_FILE_SIZE = 30 * 1024 * 1024; // 30MB

export function useFileContextUpload() {
  const { toast } = useToast();
  const [fileState, setFileState] = useState<FileUploadState>({
    file: null,
    isUploading: false,
    uploadProgress: 0,
    isExtracting: false,
    preview: null
  });

  const validateFile = useCallback((file: File): boolean => {
    const extension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!ACCEPTED_FILE_TYPES.includes(extension)) {
      toast({
        title: "Tipo de arquivo não suportado",
        description: `Apenas arquivos ${ACCEPTED_FILE_TYPES.join(', ')} são aceitos.`,
        variant: "destructive",
      });
      return false;
    }

    // Não aplicamos limites especiais aqui além do MAX_FILE_SIZE para arquivos que não serão extraídos.
    // PDFs podem ser maiores que 30MB (serão extraídos) — validação de tamanho maior será feita antes da extração.
    if (file.size > 200 * 1024 * 1024) {
      // Rejeitar arquivos absurdamente grandes (>200MB)
      toast({
        title: "Arquivo muito grande",
        description: `O arquivo excede o limite máximo permitido (200MB).`,
        variant: "destructive",
      });
      return false;
    }

    return true;
  }, [toast]);

  const formatFileSize = useCallback((bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }, []);

  const handleFileSelect = useCallback(async (file: File) => {
    if (!validateFile(file)) return;

    const ext = '.' + file.name.split('.').pop()?.toLowerCase();

    // Regras:
    // - Sempre converter: .docx, .doc, .rtf, .odt -> txt
    // - Converter PDF somente se maior que 30MB
    const alwaysConvert = ['.docx', '.doc', '.rtf', '.odt'].includes(ext);
    const pdfConvert = ext === '.pdf' && file.size > MAX_FILE_SIZE;

    if (alwaysConvert || pdfConvert) {
      setFileState({
        file,
        isUploading: false,
        uploadProgress: 0,
        isExtracting: true,
        preview: {
          name: file.name,
          size: formatFileSize(file.size),
          type: file.type || 'application/octet-stream'
        }
      });
      try {
        const extractionResult = await extractTextFromFile(file);

        if (!extractionResult.success) {
          throw new Error(extractionResult.error || 'Falha na extração');
        }

        const textFile = createTextFile(extractionResult.text, file.name);

        setFileState({
          file: textFile,
          isUploading: false,
          uploadProgress: 0,
          isExtracting: false,
          extractionInfo: {
            originalSize: formatFileSize(extractionResult.originalSize),
            extractedSize: formatFileSize(extractionResult.extractedSize),
            wasExtracted: true
          },
          // Mantemos preview com o nome e tipo originais para transparência ao usuário
          preview: {
            name: file.name,
            size: formatFileSize(file.size),
            type: file.type || 'application/octet-stream'
          }
        });

        toast({
          title: "Arquivo selecionado",
          description: `${file.name} foi anexado com sucesso.`,
          variant: "success",
        });
      } catch (error) {
        setFileState({
          file: null,
          isUploading: false,
          uploadProgress: 0,
          isExtracting: false,
          preview: null
        });

        toast({
          title: "Erro ao processar arquivo",
          description: "Ocorreu um erro. Tente novamente.",
          variant: "destructive",
        });
        return;
      }
    } else {
      setFileState({
        file,
        isUploading: false,
        uploadProgress: 0,
        isExtracting: false,
        preview: {
          name: file.name,
          size: formatFileSize(file.size),
          type: file.type || 'application/octet-stream'
        }
      });

      toast({
        title: "Arquivo selecionado",
        description: `${file.name} foi anexado com sucesso.`,
        variant: "success",
      });
    }
  }, [validateFile, toast]);

  const handleFileRemove = useCallback(() => {
    setFileState({
      file: null,
      isUploading: false,
      uploadProgress: 0,
      isExtracting: false,
      preview: null
    });
  }, []);

  const uploadContext = useCallback(async (name: string, description: string = ''): Promise<boolean> => {
    if (!fileState.file || !name.trim()) {
      toast({
        title: "Dados incompletos",
        description: "Nome do contexto é obrigatório.",
        variant: "destructive",
      });
      return false;
    }

    setFileState(prev => ({ ...prev, isUploading: true, uploadProgress: 0 }));

    // Timer de progresso de 60 segundos
    const totalDuration = 60000;
    const startTime = Date.now();
    
    const progressInterval = setInterval(() => {
      setFileState(prev => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(99, (elapsed / totalDuration) * 99);
        
        return { ...prev, uploadProgress: progress };
      });
    }, 100); // Atualiza a cada 100ms para suavidade

    try {
      const formData = new FormData();
      formData.append('file', fileState.file);
      formData.append('name', name.trim());
      if (description.trim()) {
        formData.append('description', description.trim());
      }

      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/contexts/create/from_file`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        throw new Error('Failed to upload context from file');
      }

      // Completar progresso ao finalizar
      clearInterval(progressInterval);
      setFileState(prev => ({ ...prev, uploadProgress: 100 }));

      // Pequeno delay para mostrar 100% antes de resetar
      setTimeout(() => {
        toast({
          title: "Contexto criado com sucesso",
          description: "Seu contexto foi criado a partir do arquivo enviado.",
          variant: "success",
        });

        // Reset file state after successful upload
        setFileState({
          file: null,
          isUploading: false,
          uploadProgress: 0,
          isExtracting: false,
          preview: null
        });
      }, 500);

      return true;
    } catch (error) {
      clearInterval(progressInterval);
      if (error instanceof AuthRedirectError) return false;
      
      toast({
        title: "Erro ao criar contexto",
        description: "Ocorreu um erro ao processar o arquivo. Tente novamente.",
        variant: "destructive",
      });
      return false;
    } finally {
      clearInterval(progressInterval);
      setFileState(prev => ({ ...prev, isUploading: false }));
    }
  }, [fileState.file, toast]);

  return {
    fileState,
    handleFileSelect,
    handleFileRemove,
    uploadContext,
    acceptedTypes: ACCEPTED_FILE_TYPES.join(','),
    maxFileSize: MAX_FILE_SIZE
  };
}