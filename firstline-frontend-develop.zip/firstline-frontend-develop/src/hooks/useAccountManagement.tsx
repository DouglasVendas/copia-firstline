
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

export function useAccountManagement() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const approveAccount = async (userId: string, email: string) => {
    if (!AUTH_CONFIG.REQUIRE_ACCOUNT_APPROVAL) {
      toast({
        title: "Funcionalidade desabilitada",
        description: "A aprovação de contas está temporariamente desabilitada.",
        variant: "destructive",
      });
      return { success: false };
    }

    setLoading(true);
    try {
      // TODO: Implement account approval with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/admin/accounts/${userId}/approve`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error('Failed to approve account');
      }

      toast({
        title: "Conta aprovada",
        description: "O usuário foi notificado por email.",
      });

      return { success: true };
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível aprovar a conta.",
        variant: "destructive",
      });
      return { success: false, error };
    } finally {
      setLoading(false);
    }
  };

  const rejectAccount = async (userId: string, email: string, reason?: string) => {
    if (!AUTH_CONFIG.REQUIRE_ACCOUNT_APPROVAL) {
      toast({
        title: "Funcionalidade desabilitada",
        description: "A rejeição de contas está temporariamente desabilitada.",
        variant: "destructive",
      });
      return { success: false };
    }

    setLoading(true);
    try {
      // TODO: Implement account rejection with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/admin/accounts/${userId}/reject`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, reason }),
      });

      if (!response.ok) {
        throw new Error('Failed to reject account');
      }

      toast({
        title: "Conta rejeitada",
        description: "O usuário foi notificado por email.",
      });

      return { success: true };
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível rejeitar a conta.",
        variant: "destructive",
      });
      return { success: false, error };
    } finally {
      setLoading(false);
    }
  };

  const getPendingAccounts = async () => {
    if (!AUTH_CONFIG.REQUIRE_ACCOUNT_APPROVAL) {
      return { data: [], error: null };
    }

    try {
      // TODO: Implement get pending accounts with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/admin/accounts/pending`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch pending accounts');
      }

      const data = await response.json();
      return { data, error: null };
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      return { data: null, error };
    }
  };

  return {
    loading,
    approveAccount,
    rejectAccount,
    getPendingAccounts
  };
}
