import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";

export function useReportActions() {
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const { toast } = useToast();

  const handleDownloadPDF = async (analysis: any, contextUsed?: any) => {
    setLoadingAction("download");
    try {
      const jsPDF = (await import('jspdf')).default;
      const doc = new jsPDF();
      
      let yPosition = 20;
      const pageHeight = doc.internal.pageSize.height;
      const margin = 20;
      const maxWidth = 170;
      
      // Helper function to add new page if needed
      const checkAndAddPage = (requiredSpace: number = 30) => {
        if (yPosition + requiredSpace >= pageHeight - margin) {
          doc.addPage();
          yPosition = 20;
        }
      };

      // Helper function to add text with word wrap
      const addText = (text: string, fontSize: number = 10, isBold: boolean = false) => {
        doc.setFontSize(fontSize);
        if (isBold) {
          doc.setFont(undefined, 'bold');
        } else {
          doc.setFont(undefined, 'normal');
        }
        const splitText = doc.splitTextToSize(text, maxWidth);
        checkAndAddPage(splitText.length * 5 + 5);
        doc.text(splitText, margin, yPosition);
        yPosition += splitText.length * 5 + 5;
      };

      // Helper function to get score badge
      const getScoreBadge = (score: number) => {
        if (score >= 9) return "Excelente";
        if (score >= 7) return "Bom";
        if (score >= 5) return "Razoável";
        if (score >= 3) return "Fraco";
        return "Crítico";
      };

      // Header
      addText('RELATÓRIO COMPLETO DE CALL - FIRSTLINE AI', 20, true);
      yPosition += 10;
      
      // Basic Info
      addText(`Cliente: ${analysis.client_name}`, 12, true);
      addText(`Data: ${new Date(analysis.created_at).toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: '2-digit', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })}`, 12);
      addText(`Produto: ${contextUsed?.name || "Produto Geral"}`, 12);
      addText(`Vendedor: ${analysis.vendedor || "Não informado"}`, 12);
      addText(`Duração: ${analysis.audio_duration_seconds ? `${(analysis.audio_duration_seconds / 60).toFixed(1)}min` : "N/A"}`, 12);
      addText(`Score Final: ${analysis.score_geral}/10 - ${getScoreBadge(analysis.score_geral)}`, 12, true);
      yPosition += 10;

      // Resumo da Call
      checkAndAddPage(40);
      addText('RESUMO DA CALL', 16, true);
      addText(analysis.resumo || "Resumo não disponível", 10);
      yPosition += 10;

      // Pontos Positivos
      if (analysis.pontos_positivos && analysis.pontos_positivos.length > 0) {
        checkAndAddPage(40);
        addText('PONTOS POSITIVOS', 16, true);
        analysis.pontos_positivos.forEach((point: string, index: number) => {
          addText(`${index + 1}. ${point}`, 10);
        });
        yPosition += 10;
      }

      // Pontos de Atenção
      if (analysis.pontos_atencao && analysis.pontos_atencao.length > 0) {
        checkAndAddPage(40);
        addText('PONTOS DE ATENÇÃO', 16, true);
        analysis.pontos_atencao.forEach((point: string, index: number) => {
          addText(`${index + 1}. ${point}`, 10);
        });
        yPosition += 10;
      }

      // IA Preditiva
      if (analysis.ia_preditiva) {
        checkAndAddPage(60);
        addText('IA PREDITIVA - FIRSTLINE', 16, true);
        
        if (analysis.ia_preditiva.probabilidade_fechamento !== undefined) {
          addText(`Probabilidade de Fechamento: ${analysis.ia_preditiva.probabilidade_fechamento}%`, 12, true);
        }
        
        if (analysis.ia_preditiva.proximos_passos_ia && Array.isArray(analysis.ia_preditiva.proximos_passos_ia)) {
          addText('Próximos Passos Recomendados pela IA:', 12, true);
          analysis.ia_preditiva.proximos_passos_ia.forEach((passo: string, index: number) => {
            addText(`${index + 1}. ${passo}`, 10);
          });
        }
        
        if (analysis.ia_preditiva.insights_comportamentais && Array.isArray(analysis.ia_preditiva.insights_comportamentais)) {
          addText('Insights Comportamentais:', 12, true);
          analysis.ia_preditiva.insights_comportamentais.forEach((insight: string, index: number) => {
            addText(`• ${insight}`, 10);
          });
        }
        yPosition += 10;
      }

      // Framework Analysis
      if (analysis.framework_analysis) {
        checkAndAddPage(60);
        addText('ANÁLISE DOS FRAMEWORKS DE VENDAS', 16, true);
        
        ['spin', 'bant', 'gpct'].forEach(framework => {
          if (analysis.framework_analysis[framework]) {
            const frameworkData = analysis.framework_analysis[framework];
            addText(`${framework.toUpperCase()}:`, 14, true);
            
            Object.keys(frameworkData).forEach(key => {
              if (frameworkData[key] && typeof frameworkData[key] === 'object') {
                addText(`${key.charAt(0).toUpperCase() + key.slice(1)}:`, 12, true);
                addText(`Presente: ${frameworkData[key].presente ? 'Sim' : 'Não'}`, 10);
                if (frameworkData[key].trecho) {
                  addText(`Trecho: "${frameworkData[key].trecho}"`, 10);
                }
                if (frameworkData[key].avaliacao) {
                  addText(`Avaliação: ${frameworkData[key].avaliacao}`, 10);
                }
              }
            });
            yPosition += 5;
          }
        });
        yPosition += 10;
      }

      // Performance Analysis
      if (analysis.performance_analysis) {
        checkAndAddPage(60);
        addText('ANÁLISE DE PERFORMANCE', 16, true);
        
        Object.keys(analysis.performance_analysis).forEach(skill => {
          const skillData = analysis.performance_analysis[skill];
          if (skillData && typeof skillData === 'object') {
            addText(`${skill.charAt(0).toUpperCase() + skill.slice(1).replace(/_/g, ' ')}:`, 12, true);
            addText(`Score: ${skillData.score || 0}/10`, 10);
            if (skillData.observacao) {
              addText(`Observação: ${skillData.observacao}`, 10);
            }
            if (skillData.frase_real) {
              addText(`Frase Real: "${skillData.frase_real}"`, 10);
            }
            if (skillData.sugestao_firstline) {
              addText(`Sugestão FirstLine: "${skillData.sugestao_firstline}"`, 10);
            }
            yPosition += 3;
          }
        });
        yPosition += 10;
      }

      // Mental Triggers
      if (analysis.mental_triggers) {
        checkAndAddPage(40);
        addText('GATILHOS MENTAIS IDENTIFICADOS', 16, true);
        
        // Handle both array and object formats
        if (Array.isArray(analysis.mental_triggers)) {
          analysis.mental_triggers.forEach((trigger: any, index: number) => {
            if (typeof trigger === 'object') {
              addText(`${index + 1}. ${trigger.tipo || trigger.name || 'Gatilho'}`, 11, true);
              if (trigger.descricao || trigger.description) {
                addText(`Descrição: ${trigger.descricao || trigger.description}`, 10);
              }
              if (trigger.trecho || trigger.excerpt) {
                addText(`Trecho: "${trigger.trecho || trigger.excerpt}"`, 10);
              }
            } else {
              addText(`${index + 1}. ${trigger}`, 10);
            }
          });
        } else if (typeof analysis.mental_triggers === 'object') {
          // Handle object format where keys are trigger names
          let triggerIndex = 1;
          Object.keys(analysis.mental_triggers).forEach(triggerName => {
            const triggerData = analysis.mental_triggers[triggerName];
            addText(`${triggerIndex}. ${triggerName}`, 11, true);
            
            if (triggerData.detectado !== undefined) {
              addText(`Detectado: ${triggerData.detectado ? 'Sim' : 'Não'}`, 10);
            }
            
            if (triggerData.frase_real && triggerData.frase_real.trim()) {
              addText(`Frase Real: "${triggerData.frase_real}"`, 10);
            }
            
            if (triggerData.recomendacao_firstline) {
              addText(`Recomendação FirstLine: "${triggerData.recomendacao_firstline}"`, 10);
            }
            
            yPosition += 3;
            triggerIndex++;
          });
        }
        yPosition += 10;
      }

      // Reformulações PNL
      if (analysis.reformulacoes_pnl && Array.isArray(analysis.reformulacoes_pnl)) {
        checkAndAddPage(60);
        addText('REFORMULAÇÕES COM BASE EM PNL', 16, true);
        analysis.reformulacoes_pnl.forEach((reformulacao: any, index: number) => {
          addText(`${index + 1}. ${reformulacao.categoria || 'Reformulação'}`, 12, true);
          if (reformulacao.frase_real) {
            addText(`Frase Real: "${reformulacao.frase_real}"`, 10);
          }
          if (reformulacao.recomendacao_firstline) {
            addText(`Recomendação FirstLine: "${reformulacao.recomendacao_firstline}"`, 10);
          }
          yPosition += 5;
        });
        yPosition += 10;
      }

      // Plano de Fechamento
      if (analysis.plano_fechamento && Array.isArray(analysis.plano_fechamento)) {
        checkAndAddPage(40);
        addText('PLANO DE FECHAMENTO', 16, true);
        analysis.plano_fechamento.forEach((passo: string, index: number) => {
          addText(`${index + 1}. ${passo}`, 10);
        });
        yPosition += 10;
      }

      // Coaching Insights
      if (analysis.coaching_insights && Array.isArray(analysis.coaching_insights)) {
        checkAndAddPage(40);
        addText('INSIGHTS DE COACHING', 16, true);
        analysis.coaching_insights.forEach((insight: string, index: number) => {
          addText(`${index + 1}. ${insight}`, 10);
        });
        yPosition += 10;
      }

      // Objeções Identificadas
      if (analysis.objecoes_identificadas && analysis.objecoes_identificadas.length > 0) {
        checkAndAddPage(40);
        addText('OBJEÇÕES IDENTIFICADAS', 16, true);
        analysis.objecoes_identificadas.forEach((objecao: string, index: number) => {
          addText(`${index + 1}. ${objecao}`, 10);
        });
        yPosition += 10;
      }

      // Sugestões de Melhoria
      if (analysis.sugestoes_melhoria && analysis.sugestoes_melhoria.length > 0) {
        checkAndAddPage(40);
        addText('SUGESTÕES DE MELHORIA', 16, true);
        analysis.sugestoes_melhoria.forEach((sugestao: string, index: number) => {
          addText(`${index + 1}. ${sugestao}`, 10);
        });
        yPosition += 10;
      }

      // Próximos Passos
      if (analysis.proximos_passos && analysis.proximos_passos.length > 0) {
        checkAndAddPage(40);
        addText('PRÓXIMOS PASSOS', 16, true);
        analysis.proximos_passos.forEach((passo: string, index: number) => {
          addText(`${index + 1}. ${passo}`, 10);
        });
        yPosition += 10;
      }

      // Footer on each page
      const totalPages = doc.internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setFont(undefined, 'normal');
        doc.text(`FirstLine AI - Relatório Completo | Página ${i} de ${totalPages}`, margin, pageHeight - 10);
        doc.text(`Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}`, margin, pageHeight - 5);
      }

      // Save the PDF
      const fileName = `relatorio-completo-${analysis.client_name}-${new Date(analysis.created_at).toLocaleDateString('pt-BR').replace(/\//g, '-')}.pdf`;
      doc.save(fileName);

      toast({
        title: "PDF gerado com sucesso!",
        description: "Relatório PDF completo gerado com sucesso!",
      });
    } catch (error) {
      toast({
        title: "Erro ao gerar PDF",
        description: "Não foi possível gerar o arquivo PDF. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoadingAction(null);
    }
  };

  const handleShareLink = async (analysis: any) => {
    setLoadingAction("share");
    try {
      // Criar um link compartilhável (pode ser implementado com um sistema de links temporários)
      const shareUrl = `${window.location.origin}/relatorios?analysis=${analysis.id}`;
      
      // Copiar para a área de transferência
      await navigator.clipboard.writeText(shareUrl);
      
      toast({
        title: "Link copiado!",
        description: "O link do relatório foi copiado para a área de transferência.",
      });
    } catch (error) {
      toast({
        title: "Erro ao compartilhar",
        description: "Não foi possível copiar o link. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoadingAction(null);
    }
  };

  return {
    loadingAction,
    handleDownloadPDF,
    handleShareLink,
  };
} 