import { useState, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { AuthRedirectError } from '@/lib/apiFetch';
import { getAudioDuration, getTotalAudioDuration } from "@/utils/audioUtils";

interface QueueItem {
  id: string;
  file: File;
  contextId: string;
  vendedor: string | null;
  status: 'waiting' | 'processing' | 'completed' | 'error';
  estimatedTime: number;
  startTime?: number;
  endTime?: number;
  error?: string;
}

export function useProcessingQueue() {
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  // New processing time calculation using the formula: 0.67 + x^(0.33)
  const calculateProcessingTime = (audioDurationMinutes: number): number => {
    const result = 0.67 + Math.pow(audioDurationMinutes, 0.33);
    const resultInSeconds = result * 60; // Convert to seconds
    const minTimeInSeconds = 1.5 * 60; // 1.5 minutes in seconds
    
    return Math.max(resultInSeconds, minTimeInSeconds);
  };

  // Updated function to get actual audio duration
  const estimateProcessingTime = async (file: File): Promise<number> => {
    try {
      // Get actual audio duration in minutes
      const actualDurationMinutes = await getAudioDuration(file);
      return calculateProcessingTime(actualDurationMinutes);
    } catch (error) {
      // Fallback to old estimation method
      const sizeInMB = file.size / (1024 * 1024);
      const estimatedDurationMinutes = sizeInMB * 1.2;
      return calculateProcessingTime(estimatedDurationMinutes);
    }
  };

  // Updated function for WhatsApp processing time calculation
  const estimateWhatsAppProcessingTime = async (audioFiles: File[]): Promise<number> => {
    if (!audioFiles || audioFiles.length === 0) {
      return 60; // Default 1 minute if no audio files
    }

    try {
      // Get actual total duration of all audio files
      const totalDurationMinutes = await getTotalAudioDuration(audioFiles);
      return calculateProcessingTime(totalDurationMinutes);
    } catch (error) {
      // Fallback to size-based estimation
      const totalDurationMinutes = audioFiles.reduce((total, file) => {
        const sizeInMB = file.size / (1024 * 1024);
        return total + (sizeInMB * 1.2);
      }, 0);
      return calculateProcessingTime(totalDurationMinutes);
    }
  };

  const addToQueue = useCallback(async (
    file: File,
    contextId: string,
    vendedor: string | null
  ): Promise<string> => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    
    // Get estimated time (this is now async)
    const estimatedTime = await estimateProcessingTime(file);
    
    const newItem: QueueItem = {
      id,
      file,
      contextId,
      vendedor,
      status: 'waiting',
      estimatedTime
    };

    setQueue(prev => [...prev, newItem]);
    
    toast({
      title: "Adicionado à fila",
      description: `Arquivo ${file.name} adicionado. Tempo estimado: ${Math.ceil(estimatedTime / 60)} minutos`,
    });

    return id;
  }, [toast]);

  const updateQueueItem = useCallback((id: string, updates: Partial<QueueItem>) => {
    setQueue(prev => prev.map(item => 
      item.id === id ? { ...item, ...updates } : item
    ));
  }, []);

  const removeFromQueue = useCallback((id: string) => {
    setQueue(prev => prev.filter(item => item.id !== id));
  }, []);

  const getQueuePosition = useCallback((id: string): number => {
    const waitingItems = queue.filter(item => item.status === 'waiting');
    return waitingItems.findIndex(item => item.id === id) + 1;
  }, [queue]);

  const getTotalEstimatedTime = useCallback((beforeId?: string): number => {
    const items = beforeId 
      ? queue.filter(item => 
          item.status === 'waiting' && 
          queue.findIndex(q => q.id === item.id) < queue.findIndex(q => q.id === beforeId)
        )
      : queue.filter(item => item.status === 'waiting');
    
    return items.reduce((total, item) => total + item.estimatedTime, 0);
  }, [queue]);

  const startProcessing = useCallback(async (
    id: string,
    processFn: (file: File, contextId: string, vendedor: string | null) => Promise<any>
  ) => {
    const item = queue.find(q => q.id === id);
    if (!item) return;

    setIsProcessing(true);
    updateQueueItem(id, { 
      status: 'processing', 
      startTime: Date.now() 
    });

    try {
      const result = await processFn(item.file, item.contextId, item.vendedor);
      
      updateQueueItem(id, { 
        status: 'completed', 
        endTime: Date.now() 
      });
      
      toast({
        title: "Processamento concluído",
        description: `Arquivo ${item.file.name} processado com sucesso!`,
      });

      return result;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      
      updateQueueItem(id, { 
        status: 'error', 
        error: errorMessage,
        endTime: Date.now() 
      });
      
      toast({
        title: "Erro no processamento",
        description: `Falha ao processar ${item.file.name}: ${errorMessage}`,
        variant: "destructive",
      });

      throw error;
    } finally {
      setIsProcessing(false);
    }
  }, [queue, updateQueueItem, toast]);

  const clearCompletedItems = useCallback(() => {
    setQueue(prev => prev.filter(item => 
      item.status !== 'completed' && item.status !== 'error'
    ));
  }, []);

  return {
    queue,
    isProcessing,
    addToQueue,
    updateQueueItem,
    removeFromQueue,
    getQueuePosition,
    getTotalEstimatedTime,
    startProcessing,
    clearCompletedItems,
    estimateProcessingTime,
    estimateWhatsAppProcessingTime
  };
}