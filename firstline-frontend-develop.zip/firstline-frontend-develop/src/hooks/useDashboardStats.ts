import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { fetchDashboardView } from "@/services/dashboardService";
import { AuthRedirectError } from '@/lib/apiFetch';

interface DashboardStats {
  mediaPontuacao: number;
  totalAnalises: number;
  pipelineTotal: number;
  taxaConversao: number;
}

export function useDashboardStats() {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchStats() {
      if (!user) return;
      setLoading(true);
      setError(null);
      try {
        const response = await fetchDashboardView(user.id);
        if (response.success && response.data) {
          setStats(response.data);
        } else {
          setError("Dados inválidos do dashboard");
        }
      } catch (err: any) {
        if (err instanceof AuthRedirectError) return;
        setError(err.message || "Erro ao buscar dados do dashboard");
      } finally {
        setLoading(false);
      }
    }
    fetchStats();
  }, [user]);

  return { stats, loading, error };
}
