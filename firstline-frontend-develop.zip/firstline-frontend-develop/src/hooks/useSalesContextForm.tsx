import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';
import { ContextFormData, ObjectionResponse, ContextAPIPayload } from '@/types/context';

const API_BASE_URL = import.meta.env.VITE_API_URL;

export function useSalesContextForm(initialContext?: ContextFormData) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<ContextFormData>({
    name: initialContext?.name || "",
    description: initialContext?.description || "",
    productInfo: initialContext?.productInfo || "",
    targetAudience: initialContext?.targetAudience || "",
    commonObjections: initialContext?.commonObjections || [{ objection: "", response: "" }],
    pricingStructure: initialContext?.pricingStructure || "",
    playbook: initialContext?.playbook || "",
    mentalTriggers: initialContext?.mentalTriggers || "",
    competitors: initialContext?.competitors || [""]
  });

  // Prepara os dados para enviar à API
  const prepareContextData = (data: ContextFormData): ContextAPIPayload => {
    // Filtra objeções válidas (pelo menos um campo preenchido)
    const validObjections = data.commonObjections?.filter(obj => 
      obj.objection.trim() || obj.response.trim()
    ) || [];
    
    // Filtra competidores válidos (não vazios)
    const validCompetitors = data.competitors?.filter(c => c.trim()) || [];
    
    return {
      name: data.name,
      description: data.description || "", // Envia string vazia para limpar campo
      vendedor_ativo_id: data.vendedor_ativo_id || undefined,
      
      // Envia os campos estruturados diretamente como JSON
      // Campos vazios são enviados como string vazia para permitir limpar
      productInfo: data.productInfo || "",
      targetAudience: data.targetAudience || "",
      commonObjections: validObjections.length > 0 ? validObjections : [], // Array vazio limpa o campo
      pricingStructure: data.pricingStructure || "",
      playbook: data.playbook || "",
      mentalTriggers: data.mentalTriggers || "",
      competitors: validCompetitors.length > 0 ? validCompetitors : [], // Array vazio limpa o campo
    };
  };

  const handleSave = async (onSave: () => void) => {
    if (!formData.name.trim()) {
      toast({
        title: "Nome obrigatório",
        description: "O nome do contexto é obrigatório.",
        variant: "destructive",
      });
      return;
    }

    if (!user) {
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para salvar o contexto.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const payload = prepareContextData(formData);
      const url = initialContext?.id 
        ? `${API_BASE_URL}/contexts/${initialContext.id}`
        : `${API_BASE_URL}/contexts`;
      
      const response = await apiFetch(url, {
        method: initialContext?.id ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error('Failed to save context');
      }

      toast({
        title: "Contexto salvo",
        description: initialContext?.id
          ? "Seu contexto de vendas foi atualizado com sucesso."
          : "Seu contexto de vendas foi criado com sucesso.",
        variant: "success",
      });
      
      onSave();
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível salvar o contexto.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const addObjection = () => {
    setFormData(prev => ({
      ...prev,
      commonObjections: [...prev.commonObjections, { objection: "", response: "" }]
    }));
  };

  const removeObjection = (index: number) => {
    setFormData(prev => ({
      ...prev,
      commonObjections: prev.commonObjections.filter((_, i) => i !== index)
    }));
  };

  const updateObjection = (index: number, field: 'objection' | 'response', value: string) => {
    setFormData(prev => ({
      ...prev,
      commonObjections: prev.commonObjections.map((item, i) => 
        i === index ? { ...item, [field]: value } : item
      )
    }));
  };

  const addCompetitor = () => {
    setFormData(prev => ({
      ...prev,
      competitors: [...prev.competitors, ""]
    }));
  };

  const removeCompetitor = (index: number) => {
    setFormData(prev => ({
      ...prev,
      competitors: prev.competitors.filter((_, i) => i !== index)
    }));
  };

  const updateCompetitor = (index: number, value: string) => {
    setFormData(prev => ({
      ...prev,
      competitors: prev.competitors.map((comp, i) => i === index ? value : comp)
    }));
  };

  return {
    formData,
    setFormData,
    loading,
    handleSave,
    addObjection,
    removeObjection,
    updateObjection,
    addCompetitor,
    removeCompetitor,
    updateCompetitor
  };
}
