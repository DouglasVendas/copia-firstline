
import { useState, useEffect, createContext, useContext, useCallback } from 'react';
import { apiFetch } from '@/lib/apiFetch';

interface User {
  id: string;
  email: string;
  created_at: string;
  updated_at?: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signOut: () => Promise<void>;
  login: (email: string, password: string) => Promise<{ requires2FA: boolean; email?: string }>;
  register: (userData: RegisterData) => Promise<void>;
  verify2FA: (email: string, code: string) => Promise<void>;
  exp: number | null;
}

interface RegisterData {
  email: string;
  password: string;
  confirmPassword: string;
  companyName: string;
  responsibleName: string;
  phone: string;
  cnpj?: string;
  token?: string; // Novo campo para o token de registro
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const API_BASE_URL = import.meta.env.VITE_API_URL;
// Removendo dependência de tokens no localStorage - agora usando cookies HTTP-only
const EXP_KEY = 'auth-exp'; // Mantém apenas a expiração para controle de UI

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [exp, setExp] = useState<number | null>(null);

  useEffect(() => {
    // Verificar se usuário já está logado (dados salvos no localStorage)
    const savedUser = localStorage.getItem('auth-user');
    const savedExp = localStorage.getItem(EXP_KEY);
    
    if (savedUser && savedExp) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        setExp(Number(savedExp));
      } catch (error) {
        // Se houve erro ao parsear, limpa os dados
        localStorage.removeItem('auth-user');
        localStorage.removeItem(EXP_KEY);
      }
    }
    setLoading(false);
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const response = await apiFetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Login failed');
    }

    const data = await response.json();
    
    // Verifica se o usuário tem 2FA habilitado
    if (data.requires_2fa || data.data?.requires_2fa) {
      return { requires2FA: true, email };
    }

    // Se não tem 2FA, processa o login normalmente
    const userData = data.data?.user || data.user;
    const exp = data.data?.exp || data.exp;
    
    if (!exp) {
      throw new Error('Dados de expiração não retornados pela API');
    }
    
    // Salvar apenas dados do usuário e expiração - os tokens estão em cookies HTTP-only
    setUser(userData);
    setExp(exp);
    localStorage.setItem('auth-user', JSON.stringify(userData));
    localStorage.setItem(EXP_KEY, String(exp));
    
    // Dispara evento personalizado para que o navegador detecte o sucesso do login
    window.dispatchEvent(new Event('login-success'));
    
    return { requires2FA: false };
  }, []);

  const register = useCallback(async (userData: RegisterData) => {
    const response = await apiFetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Registration failed');
    }

    const data = await response.json();
    // Registration successful - do not auto-login
    // User will need to login manually after registration
    
    // Dispara evento personalizado para que o navegador detecte o sucesso do cadastro
    window.dispatchEvent(new Event('signup-success'));
  }, []);

  const verify2FA = useCallback(async (email: string, code: string) => {
    const response = await apiFetch(`${API_BASE_URL}/auth/2fa/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, code }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Código 2FA inválido');
    }

    const data = await response.json();
    const userData = data.data?.user || data.user;
    const exp = data.data?.exp || data.exp;
    
    if (!exp) {
      throw new Error('Dados de expiração não retornados pela API após verificação 2FA');
    }
    
    // Salvar apenas dados do usuário e expiração - os tokens estão em cookies HTTP-only
    setUser(userData);
    setExp(exp);
    localStorage.setItem('auth-user', JSON.stringify(userData));
    localStorage.setItem(EXP_KEY, String(exp));
    
    // Dispara evento personalizado para que o navegador detecte o sucesso do login
    window.dispatchEvent(new Event('login-success'));
  }, []);

  const signOut = useCallback(async () => {
    // Chama o endpoint de logout para limpar cookies HTTP-only no servidor
    try {
      await apiFetch(`${API_BASE_URL}/auth/logout`, {
        method: 'POST',
      });
    } catch (error) {
    }
    
    // Limpar estado local
    setUser(null);
    setExp(null);
    localStorage.removeItem('auth-user');
    localStorage.removeItem(EXP_KEY);
    
    // Redirecionar para a página de login após logout
    window.location.href = '/auth';
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, signOut, login, register, verify2FA, exp }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
