import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface Context {
  id: string;
  name: string;
  description: string;
  vendedores: string[];
  vendedor_ativo: string | null;
}

interface AnalysisData {
  score_geral: number;
  pontos_positivos: string[];
  pontos_atencao: string[];
  objecoes_identificadas: string[];
  sugestoes_melhoria: string[];
  proximos_passos: string[];
  resumo: string;
}

interface AnalysisResult {
  id: string;
  transcription: string;
  analysis: AnalysisData;
  clientName: string;
  contextUsed: { id: string; name: string; description: string };
  vendedor?: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

export function useFileUpload() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadType, setUploadType] = useState<'audio' | 'text'>('audio');
  const [selectedContext, setSelectedContext] = useState<string>('');
  const [selectedVendedor, setSelectedVendedor] = useState<string>('');
  const [isUploading, setIsUploading] = useState(false);
  const [textContent, setTextContent] = useState('');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  const handleFileSelect = (file: File | null) => {
    setSelectedFile(file);
    
    // If it's a text file, read its content
    if (file && file.type === 'text/plain') {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        setTextContent(content);
      };
      reader.readAsText(file);
    } else {
      // Clear text content when switching to audio
      setTextContent('');
    }
  };

  const handleUpload = async (contexts: Context[]) => {
    if (!selectedContext) {
      toast({
        title: "Contexto obrigatório",
        description: "Por favor, selecione um contexto antes de fazer upload.",
        variant: "destructive"
      });
      return;
    }

    if (uploadType === 'audio' && !selectedFile) {
      toast({
        title: "Arquivo obrigatório",
        description: "Por favor, selecione um arquivo de áudio.",
        variant: "destructive"
      });
      return;
    }

    if (uploadType === 'text' && !textContent.trim()) {
      toast({
        title: "Texto obrigatório",
        description: "Por favor, digite ou cole o texto para análise.",
        variant: "destructive"
      });
      return;
    }

    setIsUploading(true);

    try {
      if (uploadType === 'audio') {
        const formData = new FormData();
        formData.append('audio', selectedFile!);
        formData.append('contextId', selectedContext);
        if (selectedVendedor) {
          formData.append('vendedor_id', selectedVendedor);
        }
        
        const response = await apiFetch(`${API_BASE_URL}/analyze-audio`, {
          method: 'POST',
          body: formData,
        });

        if (response.status === 429) {
          const data = await response.json();
          toast({
            title: "Limite excedido!",
            description: data.error || "Limite de uso excedido. Faça upgrade do seu plano.",
            variant: "destructive"
          });
          setIsUploading(false);
          return;
        }
        if (!response.ok) {
          throw new Error('Failed to analyze audio');
        }

        const data = await response.json();
        
        // Transform the response to match the expected format
        const contextUsed = contexts.find(ctx => ctx.id === selectedContext);
        const transformedResult: AnalysisResult = {
          id: data.id,
          transcription: data.transcription,
          analysis: data.analysis,
          clientName: data.client_name || 'Cliente',
          contextUsed: {
            id: data.context_id || selectedContext,
            name: contextUsed?.name || 'Contexto',
            description: contextUsed?.description || ''
          },
          vendedor: data.vendedor
        };

        setAnalysisResult(transformedResult);
      } else {
        // For text content
        const finalTextContent = textContent.trim();
                
        const response = await apiFetch(`${API_BASE_URL}/analyze-text`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            text: finalTextContent,
            contextId: selectedContext,
            vendedor_id: selectedVendedor || null,
          }),
        });

        if (response.status === 429) {
          const data = await response.json();
          toast({
            title: "Limite excedido!",
            description: data.error || "Limite de uso excedido. Faça upgrade do seu plano.",
            variant: "destructive"
          });
          setIsUploading(false);
          return;
        }
        if (!response.ok) {
          throw new Error('Failed to analyze text');
        }

        const data = await response.json();
        
        // Transform the response to match the expected format
        const contextUsed = contexts.find(ctx => ctx.id === selectedContext);
        const transformedResult: AnalysisResult = {
          id: data.id,
          transcription: data.transcription || finalTextContent,
          analysis: data.analysis,
          clientName: data.client_name || 'Cliente',
          contextUsed: {
            id: data.context_id || selectedContext,
            name: contextUsed?.name || 'Contexto',
            description: contextUsed?.description || ''
          },
          vendedor: data.vendedor
        };

        setAnalysisResult(transformedResult);
      }

      toast({
        title: "Análise concluída!",
        description: "O arquivo foi processado com sucesso.",
      });

    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      
      let errorMessage = "Não foi possível processar a análise. Tente novamente.";
      let errorTitle = "Erro na análise";
      
      if (error instanceof Error) {
        errorMessage = error.message;
      }

      toast({
        title: errorTitle,
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  const clearAnalysis = () => {
    setAnalysisResult(null);
    setSelectedFile(null);
    setTextContent('');
    setSelectedContext('');
    setSelectedVendedor('');
  };

  const downloadPdf = () => {
    if (!analysisResult) return;

    toast({
      title: "Funcionalidade em desenvolvimento",
      description: "A exportação em PDF estará disponível em breve.",
    });
  };

  return {
    selectedFile,
    uploadType,
    selectedContext,
    selectedVendedor,
    isUploading,
    textContent,
    analysisResult,
    handleFileSelect,
    handleUpload,
    clearAnalysis,
    downloadPdf,
    setUploadType,
    setSelectedContext,
    setSelectedVendedor,
    setTextContent,
  };
}
