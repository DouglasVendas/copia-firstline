import { useState, useCallback } from 'react';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

interface UseTwoFactorAuthReturn {
  show2FA: boolean;
  pendingEmail: string;
  handleLoginWith2FA: (email: string, password: string) => Promise<boolean>;
  handle2FASuccess: () => void;
  handle2FACancel: () => void;
}

export function useTwoFactorAuth(): UseTwoFactorAuthReturn {
  const [show2FA, setShow2FA] = useState(false);
  const [pendingEmail, setPendingEmail] = useState('');
  const { login } = useAuth();
  const { toast } = useToast();

  const handleLoginWith2FA = useCallback(async (email: string, password: string): Promise<boolean> => {
    try {
      const loginResult = await login(email, password);
      
      if (loginResult.requires2FA) {
        setPendingEmail(loginResult.email || email);
        setShow2FA(true);
        toast({
          title: "Verificação necessária",
          description: "Um código de verificação foi enviado para seu email.",
        });
        return true; // Indica que 2FA é necessário
      } else {
        toast({
          title: "Login realizado com sucesso!",
          description: "Bem-vindo de volta!",
        });
        return false; // Login direto sem 2FA
      }
    } catch (error) {
      throw error;
    }
  }, [login, toast]);

  const handle2FASuccess = useCallback(() => {
    setShow2FA(false);
    setPendingEmail('');
    toast({
      title: "Login realizado com sucesso!",
      description: "Bem-vindo de volta!",
    });
    
    // Dispara evento para navegação após 2FA
    setTimeout(() => {
      window.dispatchEvent(new Event('2fa-success'));
    }, 100);
  }, [toast]);

  const handle2FACancel = useCallback(() => {
    setShow2FA(false);
    setPendingEmail('');
  }, []);

  return {
    show2FA,
    pendingEmail,
    handleLoginWith2FA,
    handle2FASuccess,
    handle2FACancel,
  };
} 