import { useState, useEffect } from 'react';

type UploadType = 'audio' | 'text' | 'whatsapp';

export const useUploadState = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [textFile, setTextFile] = useState<File | null>(null);
  const [whatsappFile, setWhatsappFile] = useState<File | null>(null);
  const [uploadType, setUploadType] = useState<UploadType>('audio');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [textContent, setTextContent] = useState('');
  const [selectedContext, setSelectedContext] = useState('');
  const [selectedVendedor, setSelectedVendedor] = useState('');
  const [selectedAnalysisName, setSelectedAnalysisName] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [estimatedTime, setEstimatedTime] = useState<number | null>(null);
  const [autoDetectSpeakers, setAutoDetectSpeakers] = useState(false);
  const [speakersCount, setSpeakersCount] = useState(2);

  // Sincronizar selectedFile quando uploadType ou arquivos mudarem
  useEffect(() => {
    if (uploadType === 'audio') {
      setSelectedFile(audioFile);
    } else if (uploadType === 'text') {
      setSelectedFile(textFile);
    } else if (uploadType === 'whatsapp') {
      setSelectedFile(whatsappFile);
    }
  }, [uploadType, audioFile, textFile, whatsappFile]);

  const setSelectedFileHandler = (file: File | null) => {
    setSelectedFile(file);
    if (uploadType === 'audio') {
      setAudioFile(file);
    } else if (uploadType === 'text') {
      setTextFile(file);
    } else if (uploadType === 'whatsapp') {
      setWhatsappFile(file);
    }
  };

  // setters auxiliares para cada tipo
  const setAudioFileDirect = setAudioFile;
  const setTextFileDirect = setTextFile;
  const setWhatsappFileDirect = setWhatsappFile;

  const resetForm = () => {
    setAudioFile(null);
    setTextFile(null);
    setWhatsappFile(null);
    setSelectedFile(null);
    setTextContent('');
    setUploadProgress(0);
    setEstimatedTime(null);
    setSelectedAnalysisName('');
  };

  const resetProgress = () => {
    setUploadProgress(0);
    setEstimatedTime(null);
  };

  const updateTextContent = (content: string) => {
    setTextContent(content);
    setTextFile(null); // Limpa arquivo de texto ao digitar
  };

  return {
    // State
    isUploading,
    selectedFile,
    uploadType,
    textContent,
    selectedContext,
    selectedVendedor,
    selectedAnalysisName,
    uploadProgress,
    estimatedTime,
    autoDetectSpeakers,
    speakersCount,
    audioFile,
    textFile,
    whatsappFile,

    // Setters
    setIsUploading,
    setSelectedFile: setSelectedFileHandler,
    setUploadType,
    setTextContent,
    setSelectedContext,
    setSelectedVendedor,
    setSelectedAnalysisName,
    setUploadProgress,
    setEstimatedTime,
    setAutoDetectSpeakers,
    setSpeakersCount,
    setAudioFileDirect,
    setTextFileDirect,
    setWhatsappFileDirect,

    // Utilities
    resetForm,
    resetProgress,
    updateTextContent
  };
};