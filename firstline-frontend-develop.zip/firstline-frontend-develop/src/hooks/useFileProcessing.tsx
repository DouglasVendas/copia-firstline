
import { useRef, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useAudioCompression } from "@/hooks/useAudioCompression";
import { useTranscriptionCache } from "@/hooks/useTranscriptionCache";
import { useProcessingQueue } from "@/hooks/useProcessingQueue";
import { AuthRedirectError } from '@/lib/apiFetch';
import { 
  validateAndSanitizeUploadData, 
  performAudioUpload, 
  performTextUpload,
  performWhatsAppUpload 
} from "@/services/uploadService";

type UploadType = 'audio' | 'text' | 'whatsapp';

interface ProcessingParams {
  uploadType: UploadType;
  selectedFile: File | null;
  textContent: string;
  selectedContext: string;
  selectedVendedor: string;
  selectedAnalysisName: string;
  contexts: any[];
  sellers: Array<{ id: string; name: string }>; // NOVO
  autoDetectSpeakers: boolean;
  speakersCount: number;
  setUploadProgress: (progress: number) => void;
  setEstimatedTime: (time: number | null) => void;
  // WhatsApp specific params
  whatsAppFiles?: File[];
  includeAudios?: boolean;
  includeImages?: boolean;
}

export const useFileProcessing = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { compressAudio } = useAudioCompression();
  const { saveToCache } = useTranscriptionCache();
  const { 
    addToQueue, 
    startProcessing, 
    estimateProcessingTime,
    estimateWhatsAppProcessingTime
  } = useProcessingQueue();
  
  const isMountedRef = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const processAudioFile = async (
    file: File,
    setEstimatedTime: (time: number | null) => void
  ): Promise<{ fileToProcess: File }> => {
    // Check if component is still mounted
    if (!isMountedRef.current) {
      throw new Error('Component unmounted');
    }

    // Estimate processing time using actual audio duration
    try {
      const estimatedSeconds = await estimateProcessingTime(file);
      setEstimatedTime(estimatedSeconds);
    } catch (error) {
      // Fallback to a default time
      setEstimatedTime(120); // 2 minutes default
    }

    let fileToProcess = file;

    // TODO: Re-enable audio compression when MIME type issue is resolved
    /*
    // Compress large audio files
    if (file.size > 10 * 1024 * 1024) { // > 10MB
      if (isMountedRef.current) {
        toast({
          title: "Comprimindo áudio",
          description: "Otimizando arquivo para melhor performance...",
        });
      }

      try {
        const compressionResult = await compressAudio(file);
        if (!isMountedRef.current) {
          throw new Error('Component unmounted');
        }
        
        fileToProcess = compressionResult.compressedFile;
        
        if (isMountedRef.current) {
          toast({
            title: "Compressão concluída",
            description: `Arquivo reduzido em ${compressionResult.compressionRatio.toFixed(1)}%`,
          });
        }
      } catch (compressionError) {
        if (compressionError instanceof AuthRedirectError) return;
      }
    }
    */

    return { fileToProcess };
  };

  // Função de upload agora dentro do hook
  const executeUpload = async (params) => {
    if (!isMountedRef.current) {
      throw new Error('Component unmounted');
    }
    const {
      uploadType,
      selectedFile,
      textContent,
      selectedContext,
      selectedVendedor,
      selectedAnalysisName,
      contexts,
      sellers, // NOVO
      autoDetectSpeakers,
      speakersCount,
      setUploadProgress,
      setEstimatedTime,
      whatsAppFiles,
      includeAudios,
      includeImages
    } = params;

    let contentToAnalyze = '';
    let clientName = '';
    let fileToProcess = selectedFile;

    if (uploadType === 'whatsapp') {
      // Handle WhatsApp ZIP upload
      if (!whatsAppFiles || whatsAppFiles.length === 0) {
        throw new Error('Nenhum arquivo extraído do ZIP');
      }

      // Calculate estimated time based on audio files in the WhatsApp export
      // Filter only audio files for time estimation
      const audioFiles = whatsAppFiles.filter(file => {
        const ext = '.' + file.name.split('.').pop()?.toLowerCase();
        const audioExtensions = ['.mp3', '.wav', '.m4a', '.mp4', '.webm', '.ogg', '.opus', '.aac', '.ac3', '.aiff', '.aif', '.alac', '.amr', '.ape', '.au', '.dss', '.flac', '.tta', '.voc', '.wma', '.3ga', '.8svx', '.flv', '.qcp', '.m4b', '.m4p', '.m4r', '.m4v', '.mts', '.mxf', '.mov', '.qt', '.ts', '.m2t', '.m2ts'];
        return audioExtensions.includes(ext);
      });

      try {
        const estimatedSeconds = await estimateWhatsAppProcessingTime(audioFiles);
        setEstimatedTime(estimatedSeconds);
      } catch (error) {
        // Fallback to a default time
        setEstimatedTime(90); // 1.5 minutes default
      }

      return await performWhatsAppUpload(
        whatsAppFiles,
        includeAudios || true,
        includeImages || true,
        selectedContext,
        selectedVendedor,
        selectedAnalysisName || 'Análise WhatsApp',
        setUploadProgress
      );
    } else if (uploadType === 'audio') {
      const result = await processAudioFile(selectedFile!, setEstimatedTime);
      fileToProcess = result.fileToProcess;
      clientName = selectedFile!.name.split('.')[0];
    } else {
      contentToAnalyze = selectedFile ? await selectedFile.text() : textContent;
      clientName = selectedFile ? selectedFile.name.split('.')[0] : 'Análise de Texto';
    }

    // Check if still mounted before validation
    if (!isMountedRef.current) {
      throw new Error('Component unmounted');
    }

    // Validate and sanitize inputs
    const validation = validateAndSanitizeUploadData({
      clientName,
      content: contentToAnalyze,
      contextId: selectedContext,
      vendedor: selectedVendedor,
      contexts,
      sellers // NOVO
    });

    if (!validation.isValid) {
      if (isMountedRef.current) {
        toast({
          title: "Erro de validação",
          description: validation.error,
          variant: "destructive",
        });
      }
      throw new Error(validation.error);
    }

    if (!isMountedRef.current) {
      throw new Error('Component unmounted');
    }

    let analysisData;

    if (uploadType === 'audio') {
      analysisData = await performAudioUpload(
        fileToProcess!,
        selectedContext,
        validation.sanitizedData!.vendedor,
        user?.id || '',
        autoDetectSpeakers,
        speakersCount,
        selectedAnalysisName,
        (progress) => {
          if (isMountedRef.current) {
            setUploadProgress(progress);
          }
        }
      );

      // Save to cache
      if (analysisData && selectedFile && isMountedRef.current) {
        await saveToCache(selectedFile, analysisData.transcription, analysisData.analysis, selectedAnalysisName);
      }

    } else {
      analysisData = await performTextUpload(
        validation.sanitizedData!.content,
        selectedContext,
        validation.sanitizedData!.vendedor,
        user?.id || '',
        selectedAnalysisName,
        (progress) => {
          if (isMountedRef.current) {
            setUploadProgress(progress);
          }
        }
      );
    }

    if (analysisData?.error) {
      throw new Error(analysisData.error);
    }

    return analysisData;
  };

  return {
    executeUpload,
    isCompressing: false, // This would come from useAudioCompression if needed
    compressionProgress: 0 // This would come from useAudioCompression if needed
  };
};
