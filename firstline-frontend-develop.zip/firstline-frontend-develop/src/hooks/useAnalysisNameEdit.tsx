import { useState } from "react";
import { apiFetch } from "@/lib/apiFetch";
import { useAuth } from "@/hooks/useAuth";

export function useAnalysisNameEdit() {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState<string>("");
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();

  const startEditing = (analysisId: string, currentName: string) => {
    setEditingId(analysisId);
    setEditingName(currentName);
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditingName("");
  };

  const saveAnalysisName = async (
    analysisId: string, 
    newName: string, 
    onSuccess?: (updatedName: string) => void
  ) => {
    if (!newName.trim()) return false;
    
    setSaving(true);
    try {
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyses/${analysisId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ analysis_name: newName.trim() }),
      });

      if (!response.ok) {
        throw new Error('Erro ao atualizar o nome da análise');
      }

      setEditingId(null);
      setEditingName("");
      setSaving(false);
      
      // Chama o callback de sucesso para atualizar o estado local
      if (onSuccess) {
        onSuccess(newName.trim());
      }
      
      return true;
    } catch (error) {
      setSaving(false);
      return false;
    }
  };

  return {
    editingId,
    editingName,
    saving,
    setEditingName,
    startEditing,
    cancelEditing,
    saveAnalysisName
  };
}
