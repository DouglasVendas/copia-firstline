import { 
  SECURITY_LIMITS, 
  validateFileName, 
  validateFileType, 
  validateFileSize 
} from "@/utils/validation";

type UploadType = 'audio' | 'text' | 'whatsapp';

export const useFileValidation = (uploadType: UploadType) => {
  const validateFile = (file: File): { isValid: boolean; error?: string } => {
    // Validate file name
    if (!validateFileName(file.name)) {
      return { isValid: false, error: 'Invalid file name' };
    }

    // Validate file size
    if (!validateFileSize(file)) {
      return { isValid: false, error: `File size exceeds ${SECURITY_LIMITS.MAX_FILE_SIZE / 1024 / 1024}MB limit` };
    }

    // Validate file type
    let allowedTypes;
    if (uploadType === 'audio') {
      allowedTypes = SECURITY_LIMITS.ALLOWED_AUDIO_TYPES;
    } else if (uploadType === 'text') {
      allowedTypes = SECURITY_LIMITS.ALLOWED_TEXT_TYPES;
    } else if (uploadType === 'whatsapp') {
      allowedTypes = ['.zip']; // WhatsApp exports are ZIP files
    } else {
      return { isValid: false, error: 'Invalid upload type' };
    }
    
    if (!validateFileType(file, allowedTypes)) {
      return { isValid: false, error: 'Invalid file type' };
    }

    return { isValid: true };
  };

  return { validateFile };
};