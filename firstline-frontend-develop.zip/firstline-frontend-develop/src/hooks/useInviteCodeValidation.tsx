
import { useState } from 'react';
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

export function useInviteCodeValidation() {
  const [loading, setLoading] = useState(false);
  const [codeData, setCodeData] = useState<any>(null);

  const validateInviteCode = async (code: string) => {
    if (!AUTH_CONFIG.INVITE_CODES) {
      return { valid: true, codeData: null };
    }

    setLoading(true);
    try {
      // TODO: Implement invite code validation with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/validate-invite-code`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code }),
      });

      if (!response.ok) {
        return { valid: false, error: 'Erro ao validar código' };
      }

      const data = await response.json();
      
      if (data.valid) {
        setCodeData(data.codeData);
      }

      return data;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      return { valid: false, error: 'Erro ao validar código' };
    } finally {
      setLoading(false);
    }
  };

  return {
    validateInviteCode,
    loading,
    codeData
  };
}
