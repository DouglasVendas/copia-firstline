import { useState, useEffect, useCallback } from 'react';
import { isTokenExpired, clearTokens } from '@/lib/authUtils';

interface TokenState {
  accessToken: string | null;
  refreshToken: string | null;
  isExpired: boolean;
  isLoading: boolean;
}

export function useTokens() {
  const [tokenState, setTokenState] = useState<TokenState>({
    accessToken: null,
    refreshToken: null,
    isExpired: false,
    isLoading: true,
  });

  const refreshTokenState = useCallback(() => {
    // Com cookies HTTP-only, não temos acesso direto aos tokens
    // Verificamos apenas se temos dados de usuário e expiração salvos
    const userData = localStorage.getItem('auth-user');
    const expired = isTokenExpired();

    setTokenState({
      accessToken: userData ? 'cookie' : null, // Indicativo de que existe via cookie
      refreshToken: userData ? 'cookie' : null, // Indicativo de que existe via cookie
      isExpired: expired,
      isLoading: false,
    });
  }, []);

  const clearAuthState = useCallback(() => {
    clearTokens();
    setTokenState({
      accessToken: null,
      refreshToken: null,
      isExpired: true,
      isLoading: false,
    });
  }, []);

  useEffect(() => {
    refreshTokenState();

    // Atualiza o estado quando dados de autenticação mudam
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'auth-user' || e.key === 'auth-exp') {
        refreshTokenState();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Listener para eventos customizados de login/logout
    const handleLoginSuccess = () => refreshTokenState();
    const handleLogout = () => clearAuthState();

    window.addEventListener('login-success', handleLoginSuccess);
    window.addEventListener('logout', handleLogout);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('login-success', handleLoginSuccess);
      window.removeEventListener('logout', handleLogout);
    };
  }, [refreshTokenState, clearAuthState]);

  return {
    ...tokenState,
    refreshTokenState,
    clearAuthState,
    hasValidTokens: tokenState.accessToken && tokenState.refreshToken && !tokenState.isExpired,
  };
}
