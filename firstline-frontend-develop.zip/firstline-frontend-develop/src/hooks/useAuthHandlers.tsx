
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/hooks/use-toast";
import { useSecurityValidation } from "@/hooks/useSecurityValidation";
import { useEmailValidation } from "@/hooks/useEmailValidation";
import { useAuth } from "@/hooks/useAuth";
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { AuthRedirectError } from '@/lib/apiFetch';

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  companyName: string;
  responsibleName: string;
  phone: string;
}

export function useAuthHandlers() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { securityCheck, checkSecurity, recordLoginAttempt } = useSecurityValidation();
  const { checkEmailExists, loading: emailLoading } = useEmailValidation();
  const { login, register } = useAuth();

  const handleSignIn = async (formData: FormData, setShowSecurityFlow: (show: boolean) => void) => {
    setLoading(true);

    try {      
      // Check security before login attempt if advanced auth is enabled
      if (AUTH_CONFIG.SECURITY_ENHANCED_AUTH) {
        await checkSecurity(formData.email);
        
        if (securityCheck.ipBlocked) {
          toast({
            title: "Acesso bloqueado",
            description: "Muitas tentativas de login. Tente novamente em 15 minutos.",
            variant: "destructive",
          });
          return;
        }
      }

      // Use the basic auth login function
      await login(formData.email, formData.password);

      // Record login attempt if advanced auth is enabled
      if (AUTH_CONFIG.SECURITY_ENHANCED_AUTH) {
        await recordLoginAttempt(formData.email, true);
      }

      toast({
        title: "Login realizado com sucesso!",
        description: "Bem-vindo de volta.",
      });
      
      navigate("/");
    } catch (error: any) {
      if (error instanceof AuthRedirectError) return;
      
      // Record failed login attempt if advanced auth is enabled
      if (AUTH_CONFIG.SECURITY_ENHANCED_AUTH) {
        await recordLoginAttempt(formData.email, false);
      }

      if (error.message.includes("Invalid login credentials") || error.message.includes("Credenciais inválidas")) {
        toast({
          title: "Credenciais inválidas",
          description: "E-mail ou senha incorretos.",
          variant: "destructive",
        });
      } else if (error.message.includes("Email not confirmed")) {
        toast({
          title: "E-mail não confirmado",
          description: "Verifique seu e-mail e clique no link de confirmação.",
          variant: "destructive",
        });
        if (AUTH_CONFIG.EMAIL_VERIFICATION) {
          setShowSecurityFlow(true);
        }
      } else {
        toast({
          title: "Erro de login",
          description: error.message || "Erro inesperado durante o login.",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (formData: FormData, setShowSecurityFlow: (show: boolean) => void) => {
    setLoading(true);

    try {      
      // Check if email already exists if advanced auth is enabled
      if (AUTH_CONFIG.EMAIL_VERIFICATION) {
        const emailCheck = await checkEmailExists(formData.email);
        
        if (emailCheck.error) {
          toast({
            title: "Erro de validação",
            description: emailCheck.error,
            variant: "destructive",
          });
          return;
        }

        if (emailCheck.exists) {
          toast({
            title: "E-mail já cadastrado",
            description: "Este e-mail já possui uma conta. Tente fazer login ou use outro e-mail.",
            variant: "destructive",
          });
          return;
        }
      }
      
      // Use the basic auth register function
      await register({
        email: formData.email,
        password: formData.password,
        confirmPassword: formData.confirmPassword,
        companyName: formData.companyName,
        responsibleName: formData.responsibleName,
        phone: formData.phone,
        cnpj: '' // CNPJ is not required for basic auth
      });

      if (AUTH_CONFIG.EMAIL_VERIFICATION || AUTH_CONFIG.REQUIRE_ACCOUNT_APPROVAL) {
        toast({
          title: "Cadastro realizado!",
          description: "Verifique seu e-mail para confirmar sua conta. Sua conta ficará pendente até aprovação manual.",
        });
        setShowSecurityFlow(true);
      } else {
        toast({
          title: "Cadastro realizado!",
          description: "Bem-vindo ao FirstLine!",
        });
        navigate("/");
      }
    } catch (error: any) {
      if (error instanceof AuthRedirectError) return;
            
      const errorMessage = error.message.toLowerCase();
      if (errorMessage.includes("already registered") || 
          errorMessage.includes("already exists") ||
          errorMessage.includes("user already registered") ||
          errorMessage.includes("email already taken") ||
          errorMessage.includes("já cadastrado")) {
        toast({
          title: "E-mail já cadastrado",
          description: "Este e-mail já possui uma conta. Tente fazer login ou use outro e-mail.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro de cadastro",
          description: error.message || "Erro inesperado durante o cadastro.",
          variant: "destructive",
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return {
    loading: loading || emailLoading,
    handleSignIn,
    handleSignUp
  };
}
