import { useEffect, useCallback } from 'react';

interface GoogleAuthConfig {
  client_id: string;
  callback: (response: any) => void;
  auto_select?: boolean;
  cancel_on_tap_outside?: boolean;
}

interface GoogleAccount {
  id: string;
  email: string;
  name: string;
  picture: string;
}

declare global {
  interface Window {
    google: {
      accounts: {
        id: {
          initialize: (config: any) => void;
          renderButton: (element: HTMLElement, options: any) => void;
          prompt: () => void;
          disableAutoSelect: () => void;
        };
      };
    };
  }
}

export const useGoogleAuth = (config: GoogleAuthConfig) => {
  const initializeGoogleAuth = useCallback(() => {
    if (window.google && window.google.accounts && window.google.accounts.id) {
      window.google.accounts.id.initialize({
        client_id: config.client_id,
        callback: config.callback,
        auto_select: config.auto_select || false,
        cancel_on_tap_outside: config.cancel_on_tap_outside || true,
      });
    }
  }, [config]);

  const renderGoogleButton = useCallback((element: HTMLElement, options = {}) => {
    if (window.google && window.google.accounts && window.google.accounts.id) {
      const defaultOptions = {
        type: 'standard',
        theme: 'outline',
        size: 'large',
        text: 'continue_with',
        shape: 'rectangular',
        logo_alignment: 'left',
        width: '100%',
        ...options
      };
      
      window.google.accounts.id.renderButton(element, defaultOptions);
    }
  }, []);

  const decodeGoogleToken = (token: string): GoogleAccount | null => {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));
      
      const payload = JSON.parse(jsonPayload);
      
      return {
        id: payload.sub,
        email: payload.email,
        name: payload.name,
        picture: payload.picture,
      };
    } catch (error) {
      return null;
    }
  };

  useEffect(() => {
    // Aguarda o script do Google carregar
    const checkGoogle = () => {
      if (window.google) {
        initializeGoogleAuth();
      } else {
        setTimeout(checkGoogle, 100);
      }
    };
    
    checkGoogle();
  }, [initializeGoogleAuth]);

  return {
    renderGoogleButton,
    decodeGoogleToken,
    initializeGoogleAuth
  };
};
