import { useToast } from "@/hooks/use-toast";
import { useFileValidation } from "@/hooks/useFileValidation";
import { sanitizeInput, validateTextContent } from "@/utils/validation";

type UploadType = 'audio' | 'text' | 'whatsapp';

export const useUploadValidation = (uploadType: UploadType) => {
  const { toast } = useToast();
  const { validateFile } = useFileValidation(uploadType);

  const validateFileSelection = (file: File | null): boolean => {
    if (!file) {
      return false;
    }

    const validation = validateFile(file);
    if (!validation.isValid) {
      toast({
        title: "Arquivo inválido",
        description: validation.error,
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const validateTextInput = (content: string): string | null => {
    const textValidation = validateTextContent(content);
    if (!textValidation.isValid) {
      toast({
        title: "Conteúdo inválido",
        description: textValidation.error,
        variant: "destructive",
      });
      return null;
    }

    return sanitizeInput(content);
  };

  const validateContextAccess = (
    contexts: any[], 
    selectedContext: string, 
    hasActiveContexts: boolean
  ): boolean => {
    if (!hasActiveContexts) {
      toast({
        title: "Erro de segurança",
        description: "Nenhum contexto ativo disponível",
        variant: "destructive",
      });
      return false;
    }

    const activeContext = contexts.find(ctx => ctx.is_active && ctx.id === selectedContext);
    if (!activeContext) {
      toast({
        title: "Erro de autorização",
        description: "Contexto selecionado não está ativo ou não pertence ao usuário",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const validateUploadInputs = (
    uploadType: UploadType,
    selectedFile: File | null,
    textContent: string
  ): boolean => {
    if (uploadType === 'audio') {
      if (!selectedFile) {
        toast({
          title: "Erro de validação",
          description: "Nenhum arquivo selecionado",
          variant: "destructive",
        });
        return false;
      }

      return validateFileSelection(selectedFile);
    } else if (uploadType === 'whatsapp') {
      if (!selectedFile) {
        toast({
          title: "Erro de validação",
          description: "Nenhum arquivo ZIP selecionado",
          variant: "destructive",
        });
        return false;
      }

      return validateFileSelection(selectedFile);
    } else {
      if (!textContent.trim() && !selectedFile) {
        toast({
          title: "Erro de validação",
          description: "Conteúdo de texto ou arquivo é obrigatório",
          variant: "destructive",
        });
        return false;
      }

      return true;
    }
  };

  return {
    validateFileSelection,
    validateTextInput,
    validateContextAccess,
    validateUploadInputs
  };
};