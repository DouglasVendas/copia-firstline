
import { useToast } from "@/hooks/use-toast";

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
  companyName: string;
  responsibleName: string;
}

export function useAuthValidation() {
  const { toast } = useToast();

  const validateForm = (formData: FormData, isSignUp: boolean) => {
    if (!formData.email || !formData.password) {
      toast({
        title: "Campos obrigatórios",
        description: "E-mail e senha são obrigatórios.",
        variant: "destructive",
      });
      return false;
    }

    if (isSignUp) {
      if (formData.password !== formData.confirmPassword) {
        toast({
          title: "Senhas não coincidem",
          description: "As senhas digitadas não são iguais.",
          variant: "destructive",
        });
        return false;
      }

      if (formData.password.length < 8) {
        toast({
          title: "Senha muito fraca",
          description: "A senha deve ter pelo menos 8 caracteres.",
          variant: "destructive",
        });
        return false;
      }

      if (!formData.companyName || !formData.responsibleName) {
        toast({
          title: "Informações obrigatórias",
          description: "Nome da empresa e responsável são obrigatórios.",
          variant: "destructive",
        });
        return false;
      }
    }

    return true;
  };

  return { validateForm };
}
