
import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface ProfileData {
  account_status: string;
  company_name: string | null;
  contact_email: string | null;
}

export function useAccountStatus() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchProfileData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const fetchProfileData = async () => {
    if (!user) return;

    if (!AUTH_CONFIG.REQUIRE_ACCOUNT_APPROVAL) {
      // For basic auth, assume approved status
      setProfileData({
        account_status: 'approved',
        company_name: 'Empresa',
        contact_email: user.email
      });
      setLoading(false);
      return;
    }

    try {
      // TODO: Implement profile data fetching with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/profile`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        return;
      }

      const data = await response.json();
      setProfileData(data);
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    } finally {
      setLoading(false);
    }
  };

  const isAccountPending = () => {
    return profileData?.account_status === 'pending';
  };

  const isAccountApproved = () => {
    return profileData?.account_status === 'approved';
  };

  return {
    profileData,
    loading,
    isAccountPending,
    isAccountApproved,
    refreshProfile: fetchProfileData
  };
}
