import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { apiFetch, AuthRedirectError } from '@/lib/apiFetch';

interface TokenData {
  customer_email: string;
  subscription_plan: string;
  stripe_payment_intent_id: string;
  stripe_customer_id: string;
  expires_at: string;
  created_at: string;
}

interface RegisterFormData {
  email: string;
  password: string;
  confirmPassword: string;
  companyName: string;
  responsibleName: string;
  phone: string;
  cnpj?: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

export function useTokenRegistration() {
  const { toast } = useToast();
  const [validatingToken, setValidatingToken] = useState(false);
  const [tokenData, setTokenData] = useState<TokenData | null>(null);
  const [tokenValid, setTokenValid] = useState(false);
  const [loading, setLoading] = useState(false);

  const validateRegistrationToken = useCallback(async (token: string) => {
    setValidatingToken(true);
    setTokenValid(false);
    setTokenData(null);

    try {
      const response = await apiFetch(`${API_BASE_URL}/auth/registration-token/validate?token=${encodeURIComponent(token)}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        let errorMessage = "Token inválido";
        
        // Mapeia erros para mensagens amigáveis
        if (errorData.error === "Token já utilizado") {
          errorMessage = "Você já completou seu cadastro. Faça login na plataforma.";
        } else if (errorData.error === "Token expirado") {
          errorMessage = "Este link expirou. Entre em contato conosco para gerar um novo.";
        } else if (errorData.error === "Token inválido") {
          errorMessage = "Link inválido. Verifique se você está usando o link correto do email.";
        }

        toast({
          title: "Erro na validação",
          description: errorMessage,
          variant: "destructive"
        });
        return;
      }

      const data = await response.json();
      
      if (data.success && data.data) {
        setTokenData(data.data);
        setTokenValid(true);
      } else {
        toast({
          title: "Erro na validação",
          description: "Token inválido ou expirado.",
          variant: "destructive"
        });
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      
      toast({
        title: "Erro de conexão",
        description: "Erro ao validar token. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setValidatingToken(false);
    }
  }, [toast]);

  const registerWithToken = useCallback(async (token: string, formData: RegisterFormData) => {
    // Função para validar email
    const isValidEmail = (email: string) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailRegex.test(email);
    };

    // Função para validar senha forte
    const validatePassword = (password: string) => {
      const minLength = password.length >= 8;
      const hasUpperCase = /[A-Z]/.test(password);
      const hasLowerCase = /[a-z]/.test(password);
      const hasNumbers = /\d/.test(password);
      const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
      
      return {
        isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
        minLength,
        hasUpperCase,
        hasLowerCase,
        hasNumbers,
        hasSpecialChar
      };
    };

    // Validações locais
    if (!formData.email) {
      toast({
        title: "E-mail obrigatório",
        description: "Por favor, informe o e-mail.",
        variant: "destructive"
      });
      return;
    }

    if (!isValidEmail(formData.email)) {
      toast({
        title: "E-mail inválido",
        description: "Por favor, informe um e-mail válido.",
        variant: "destructive"
      });
      return;
    }

    const passwordValidation = validatePassword(formData.password);
    if (!formData.password || !passwordValidation.isValid) {
      let missingRequirements = [];
      if (!passwordValidation.minLength) missingRequirements.push("8 caracteres");
      if (!passwordValidation.hasUpperCase) missingRequirements.push("letra maiúscula");
      if (!passwordValidation.hasLowerCase) missingRequirements.push("letra minúscula");
      if (!passwordValidation.hasNumbers) missingRequirements.push("número");
      if (!passwordValidation.hasSpecialChar) missingRequirements.push("caractere especial");
      
      toast({
        title: "Senha não atende aos requisitos",
        description: `A senha deve conter: ${missingRequirements.join(", ")}.`,
        variant: "destructive"
      });
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Senhas não coincidem",
        description: "As senhas devem ser iguais.",
        variant: "destructive"
      });
      return;
    }

    if (!formData.companyName || !formData.responsibleName || !formData.phone) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos obrigatórios.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      const response = await apiFetch(`${API_BASE_URL}/auth/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          token,
          email: formData.email,
          password: formData.password,
          confirmPassword: formData.confirmPassword,
          companyName: formData.companyName,
          responsibleName: formData.responsibleName,
          phone: formData.phone,
          cnpj: formData.cnpj || ''
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        let errorMessage = "Erro no cadastro";
        
        // Mapeia erros para mensagens amigáveis
        if (errorData.error?.includes("já cadastrado") || errorData.error?.includes("already registered")) {
          errorMessage = "Este e-mail já está cadastrado. Faça login na plataforma.";
        } else if (errorData.error?.includes("Token")) {
          errorMessage = "Token inválido ou expirado. Entre em contato conosco.";
        } else if (errorData.error) {
          errorMessage = errorData.error;
        }

        toast({
          title: "Erro no cadastro",
          description: errorMessage,
          variant: "destructive"
        });
        return;
      }

      const data = await response.json();
      
      if (data.success) {
        // Cadastro realizado com sucesso
        return data.data;
      } else {
        throw new Error(data.error || "Erro no cadastro");
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      
      toast({
        title: "Erro no cadastro",
        description: error instanceof Error ? error.message : "Erro desconhecido no cadastro.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  return {
    validatingToken,
    tokenData,
    tokenValid,
    loading,
    validateRegistrationToken,
    registerWithToken
  };
}
