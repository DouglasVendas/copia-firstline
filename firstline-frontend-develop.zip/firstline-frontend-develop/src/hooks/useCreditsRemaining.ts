import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch, AuthRedirectError } from "@/lib/apiFetch";

interface CreditsData {
  analyses_this_month: number;
  user_credits: number;
}

export function useCreditsRemaining() {
  const { user } = useAuth();
  const [credits, setCredits] = useState<CreditsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCredits = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyses/credits-remaining/`, {
        method: "GET",
      });
      if (!response.ok) {
        throw new Error("Erro ao buscar créditos restantes");
      }
      const data = await response.json();
      setCredits(data.data);
    } catch (err: any) {
      if (err instanceof AuthRedirectError) return;
      setError(err.message || "Erro ao buscar créditos restantes");
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchCredits();
  }, [fetchCredits]);

  return {
    credits,
    loading,
    error,
    refreshCredits: fetchCredits,
  };
} 