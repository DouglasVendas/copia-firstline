import { useState } from 'react';

interface CompressionResult {
  compressedFile: File;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
}

export function useAudioCompression() {
  const [isCompressing, setIsCompressing] = useState(false);
  const [compressionProgress, setCompressionProgress] = useState(0);

  const compressAudio = async (file: File): Promise<CompressionResult> => {
    setIsCompressing(true);
    setCompressionProgress(0);

    try {
      // Create audio context for compression
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Read file as array buffer
      const arrayBuffer = await file.arrayBuffer();
      setCompressionProgress(25);
      
      // Decode audio data
      const audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
      setCompressionProgress(50);
      
      // Determine optimal compression settings based on file size
      const originalSize = file.size;
      let sampleRate = audioBuffer.sampleRate;
      let bitRate = 128; // Default bitrate for Whisper
      
      // Adjust compression based on file size
      if (originalSize > 25 * 1024 * 1024) { // > 25MB
        sampleRate = Math.min(sampleRate, 16000); // Reduce to 16kHz for large files
        bitRate = 96; // Lower bitrate for large files
      } else if (originalSize > 10 * 1024 * 1024) { // > 10MB
        sampleRate = Math.min(sampleRate, 22050); // Reduce to 22kHz
        bitRate = 112;
      }

      // Create new audio buffer with optimized settings
      const newAudioBuffer = audioContext.createBuffer(
        1, // Convert to mono for better compression
        audioBuffer.duration * sampleRate,
        sampleRate
      );

      // Copy and downsample audio data
      const inputData = audioBuffer.getChannelData(0);
      const outputData = newAudioBuffer.getChannelData(0);
      
      const downsampleFactor = audioBuffer.sampleRate / sampleRate;
      
      for (let i = 0; i < outputData.length; i++) {
        const inputIndex = Math.floor(i * downsampleFactor);
        outputData[i] = inputData[inputIndex] || 0;
      }
      
      setCompressionProgress(75);

      // Convert back to file using Web Audio API
      const compressedBlob = await audioBufferToBlob(newAudioBuffer, bitRate);
      setCompressionProgress(90);

      const compressedFile = new File(
        [compressedBlob],
        `compressed_${file.name.replace(/\.[^/.]+$/, '.webm')}`,
        { type: 'audio/webm' }
      );

      setCompressionProgress(100);

      const result: CompressionResult = {
        compressedFile,
        originalSize,
        compressedSize: compressedFile.size,
        compressionRatio: (1 - compressedFile.size / originalSize) * 100
      };

      return result;
    } finally {
      setIsCompressing(false);
      setCompressionProgress(0);
    }
  };

  return {
    compressAudio,
    isCompressing,
    compressionProgress
  };
}

// Helper function to convert AudioBuffer to Blob
async function audioBufferToBlob(audioBuffer: AudioBuffer, bitRate: number): Promise<Blob> {
  const offlineContext = new OfflineAudioContext(
    audioBuffer.numberOfChannels,
    audioBuffer.length,
    audioBuffer.sampleRate
  );

  const source = offlineContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(offlineContext.destination);
  source.start();

  const renderedBuffer = await offlineContext.startRendering();
  
  // Convert to WebM format (supported by Whisper and has good compression)
  const mediaRecorder = await createMediaRecorderFromBuffer(renderedBuffer, bitRate);
  
  return new Promise((resolve) => {
    const chunks: BlobPart[] = [];
    
    mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        chunks.push(event.data);
      }
    };
    
    mediaRecorder.onstop = () => {
      resolve(new Blob(chunks, { type: 'audio/webm' }));
    };
    
    mediaRecorder.start();
    setTimeout(() => mediaRecorder.stop(), 100);
  });
}

// Create MediaRecorder from AudioBuffer
async function createMediaRecorderFromBuffer(audioBuffer: AudioBuffer, bitRate: number): Promise<MediaRecorder> {
  const stream = new MediaStream();
  
  // Create audio context and source
  const audioContext = new AudioContext();
  const source = audioContext.createBufferSource();
  const destination = audioContext.createMediaStreamDestination();
  
  source.buffer = audioBuffer;
  source.connect(destination);
  
  const mediaRecorder = new MediaRecorder(destination.stream, {
    mimeType: 'audio/webm',
    audioBitsPerSecond: bitRate * 1000
  });
  
  source.start();
  
  return mediaRecorder;
}