import { useState, useCallback } from 'react';
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface CacheEntry {
  fileHash: string;
  transcription: string;
  analysis: any;
  createdAt: number;
  fileSize: number;
  fileName: string;
}

const API_BASE_URL = import.meta.env.VITE_API_URL

export function useTranscriptionCache() {
  const { user } = useAuth();

  // Generate file hash for caching
  const generateFileHash = async (file: File): Promise<string> => {
    try {
      // Check if crypto.subtle is available
      if (!crypto?.subtle?.digest) {
        throw new Error('crypto.subtle.digest not available');
      }

      const buffer = await file.arrayBuffer();
      const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch (error) {
      // Fallback: use file name, size, and timestamp as hash
      const fallbackData = `${file.name}_${file.size}_${file.lastModified}`;
      return btoa(fallbackData).replace(/[^a-zA-Z0-9]/g, '').substring(0, 32);
    }
  };

  // Save transcription to cache
  const saveToCache = useCallback(async (
    file: File,
    transcription: string,
    analysis: any,
    analysisName: string
  ): Promise<void> => {
    try {
      const fileHash = await generateFileHash(file);
      if (analysis?.id) {
        try {
          // Only update if analysis_name is not already set or is different
          if (!analysis.analysis_name || analysis.analysis_name !== analysisName) {
            
            const updatePayload = {
              analysis_name: analysisName,
              // Include other fields that might be needed
              transcription: transcription,
              client_name: analysis.client_name || file.name.split('.')[0],
              vendedor: analysis.vendedor || null,
              context_uuid: analysis.context_uuid || null
            };

            const response = await apiFetch(`${API_BASE_URL}/analyses/${analysis.id}`, {
              method: 'PUT',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify(updatePayload),
            });
          }
        } catch (updateError) {
          if (updateError instanceof AuthRedirectError) return;
        }
      }
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    }
  }, [user?.id]);

  // Clear old cache entries (older than 30 days)
  const clearOldCache = useCallback(async (): Promise<void> => {
    try {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      await apiFetch(`${API_BASE_URL}/analyses/cleanup`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          older_than: thirtyDaysAgo.toISOString()
        }),
      });
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    }
  }, [user?.id]);

  // Get cache statistics
  const getCacheStats = useCallback(async () => {
    try {
      const totalResponse = await apiFetch(`${API_BASE_URL}/analyses/stats`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!totalResponse.ok) {
        throw new Error('Failed to fetch cache stats');
      }

      const stats = await totalResponse.json();

      return {
        totalCachedItems: stats.total_count || 0,
        recentItems: stats.recent_count || 0
      };
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      return { totalCachedItems: 0, recentItems: 0 };
    }
  }, [user?.id]);

  return {
    saveToCache,
    clearOldCache,
    getCacheStats
  };
}