import { useState } from 'react';
import JSZip from 'jszip';
import { useToast } from "@/hooks/use-toast";

interface ExtractedFiles {
  textFiles: File[];
  audioFiles: File[];
  imageFiles: File[];
}

interface ZipAnalysis {
  isValid: boolean;
  hasTextFiles: boolean;
  hasAudioFiles: boolean;
  hasImageFiles: boolean;
  audioCount: number;
  imageCount: number;
  extractedFiles: ExtractedFiles;
}

export const useWhatsAppZip = () => {
  const { toast } = useToast();
  const [isExtracting, setIsExtracting] = useState(false);
  const [zipAnalysis, setZipAnalysis] = useState<ZipAnalysis | null>(null);
  const [includeAudios, setIncludeAudios] = useState(true);
  const [includeImages, setIncludeImages] = useState(true);

  // Extensões permitidas
  const allowedTextExtensions = ['.txt'];
  const allowedAudioExtensions = ['.mp3', '.wav', '.m4a', '.mp4', '.webm', '.ogg', '.opus', '.aac', '.ac3', '.aiff', '.aif', '.alac', '.amr', '.ape', '.au', '.dss', '.flac', '.tta', '.voc', '.wma', '.3ga', '.8svx', '.flv', '.qcp', '.m4b', '.m4p', '.m4r', '.m4v', '.mts', '.mxf', '.mov', '.qt', '.ts', '.m2t', '.m2ts'];
  const allowedImageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.tiff', '.tif'];

  // Validação de segurança
  const isSecurePath = (path: string): boolean => {
    // Prevenir path traversal
    if (path.includes('..') || path.includes('\\..\\') || path.includes('../')) {
      return false;
    }
    
    // Verificar se não é um caminho absoluto
    if (path.startsWith('/') || path.includes(':') || path.startsWith('\\')) {
      return false;
    }

    return true;
  };

  const isAllowedFile = (fileName: string): boolean => {
    const ext = '.' + fileName.split('.').pop()?.toLowerCase();
    
    // Verificar se é uma extensão permitida
    const isAllowed = allowedTextExtensions.includes(ext) || 
                      allowedAudioExtensions.includes(ext) || 
                      allowedImageExtensions.includes(ext);
    
    if (!isAllowed) return false;

    // Verificar se não é um executável ou arquivo perigoso
    const dangerousExtensions = ['.exe', '.bat', '.cmd', '.com', '.scr', '.pif', '.vbs', '.vbe', '.js', '.jar', '.msi', '.dll', '.app', '.deb', '.rpm', '.dmg', '.pkg', '.sh', '.ps1', '.py', '.php', '.asp', '.aspx', '.jsp', '.htm', '.html'];
    const isDangerous = dangerousExtensions.some(dangerous => fileName.toLowerCase().endsWith(dangerous));
    
    return !isDangerous;
  };

  const isSticker = (fileName: string): boolean => {
    const baseName = fileName.split('/').pop() || fileName;
    return baseName.toUpperCase().startsWith('STK');
  };

  const analyzeZip = async (file: File): Promise<ZipAnalysis> => {
    setIsExtracting(true);
    
    try {
      const zip = new JSZip();
      const zipContent = await zip.loadAsync(file);
      
      const extractedFiles: ExtractedFiles = {
        textFiles: [],
        audioFiles: [],
        imageFiles: []
      };

      let audioCount = 0;
      let imageCount = 0;

      // Analisar cada arquivo no ZIP
      for (const [relativePath, zipEntry] of Object.entries(zipContent.files)) {
        // Pular diretórios
        if (zipEntry.dir) continue;

        // Validações de segurança
        if (!isSecurePath(relativePath) || !isAllowedFile(relativePath)) {
          continue;
        }

        const fileName = relativePath.split('/').pop() || relativePath;
        const ext = '.' + fileName.split('.').pop()?.toLowerCase();

        try {
          const content = await zipEntry.async('blob');
          const extractedFile = new File([content], fileName, { type: getContentType(ext) });

          // Classificar arquivo
          if (allowedTextExtensions.includes(ext)) {
            extractedFiles.textFiles.push(extractedFile);
          } else if (allowedAudioExtensions.includes(ext)) {
            extractedFiles.audioFiles.push(extractedFile);
            audioCount++;
          } else if (allowedImageExtensions.includes(ext) && !isSticker(fileName)) {
            extractedFiles.imageFiles.push(extractedFile);
            imageCount++;
          }
        } catch (error) {
        }
      }

      const analysis: ZipAnalysis = {
        isValid: true,
        hasTextFiles: extractedFiles.textFiles.length > 0,
        hasAudioFiles: extractedFiles.audioFiles.length > 0,
        hasImageFiles: extractedFiles.imageFiles.length > 0,
        audioCount,
        imageCount,
        extractedFiles
      };

      setZipAnalysis(analysis);
      return analysis;

    } catch (error) {
      toast({
        title: "Erro ao processar arquivo",
        description: "O arquivo ZIP não pôde ser processado. Verifique se é um arquivo válido.",
        variant: "destructive",
      });
      
      return {
        isValid: false,
        hasTextFiles: false,
        hasAudioFiles: false,
        hasImageFiles: false,
        audioCount: 0,
        imageCount: 0,
        extractedFiles: { textFiles: [], audioFiles: [], imageFiles: [] }
      };
    } finally {
      setIsExtracting(false);
    }
  };

  const getContentType = (extension: string): string => {
    const mimeTypes: { [key: string]: string } = {
      '.txt': 'text/plain',
      '.mp3': 'audio/mpeg',
      '.wav': 'audio/wav',
      '.m4a': 'audio/mp4',
      '.mp4': 'video/mp4',
      '.webm': 'audio/webm',
      '.ogg': 'audio/ogg',
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.gif': 'image/gif',
      '.bmp': 'image/bmp',
      '.webp': 'image/webp',
      '.svg': 'image/svg+xml',
    };
    
    return mimeTypes[extension] || 'application/octet-stream';
  };

  const getSelectedFiles = (): File[] => {
    if (!zipAnalysis) return [];
    
    const files: File[] = [...zipAnalysis.extractedFiles.textFiles];
    
    if (includeAudios) {
      files.push(...zipAnalysis.extractedFiles.audioFiles);
    }
    
    if (includeImages) {
      files.push(...zipAnalysis.extractedFiles.imageFiles);
    }
    
    return files;
  };

  const reset = () => {
    setZipAnalysis(null);
    setIncludeAudios(true);
    setIncludeImages(true);
  };

  return {
    isExtracting,
    zipAnalysis,
    includeAudios,
    includeImages,
    setIncludeAudios,
    setIncludeImages,
    analyzeZip,
    getSelectedFiles,
    reset
  };
};
