
import { useState, useEffect, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';
import { Context, Vendedor } from '@/types/context';

const API_BASE_URL = import.meta.env.VITE_API_URL;

// Função utilitária para adaptar o contexto da API
const adaptContext = (ctx: any): Context => {
  return {
    id: ctx.id,
    user_id: ctx.user_id,
    name: ctx.name,
    description: ctx.description,
    
    // Campos estruturados (já vêm como arrays da API)
    productInfo: ctx.productInfo,
    targetAudience: ctx.targetAudience,
    commonObjections: ctx.commonObjections || [],
    pricingStructure: ctx.pricingStructure,
    playbook: ctx.playbook,
    mentalTriggers: ctx.mentalTriggers,
    competitors: ctx.competitors || [],
    
    is_active: ctx.is_active,
    vendedores: (ctx.vendedores || []).map((v: any) => ({
      id: v.vendedor_id || v.id || v,
      name: v.vendedor || v.name || v,
    })),
    vendedor_ativo: ctx.vendedor_ativo_id || ctx.vendedor_ativo || null,
    vendedor_ativo_id: ctx.vendedor_ativo_id,
    vendedor_ativo_nome: ctx.vendedor_ativo_nome,
    vendedor_ativo_tipo: ctx.vendedor_ativo_tipo,
    created_at: ctx.created_at,
    updated_at: ctx.updated_at,
  };
};

export function useContextManagement() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [contexts, setContexts] = useState<Context[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchContexts = useCallback(async () => {
    if (!user) {
      setContexts([]);
      setLoading(false);
      return;
    }
    
    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch contexts');
      }

      const result = await response.json();
      setContexts((result.data || []).map(adaptContext));
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível carregar os contextos.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }, [user, toast]);

  const createContext = async (contextData: Partial<Context>) => {
    if (!contextData.name?.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Nome é obrigatório.",
        variant: "destructive",
      });
      return false;
    }

    if (!user) {
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para criar contextos.",
        variant: "destructive",
      });
      return false;
    }

    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: contextData.name,
          description: contextData.description || undefined,
          productInfo: contextData.productInfo || undefined,
          targetAudience: contextData.targetAudience || undefined,
          commonObjections: contextData.commonObjections || undefined,
          pricingStructure: contextData.pricingStructure || undefined,
          playbook: contextData.playbook || undefined,
          mentalTriggers: contextData.mentalTriggers || undefined,
          competitors: contextData.competitors || undefined,
          is_active: contexts.length === 0,
          vendedores: contextData.vendedores || [],
          vendedor_ativo_id: contextData.vendedor_ativo_id || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create context');
      }

      const result = await response.json();
      
      setContexts([adaptContext(result.data), ...contexts]);
      toast({
        title: "Contexto criado",
        description: "Seu contexto foi criado com sucesso.",
      });
      return true;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível criar o contexto.",
        variant: "destructive",
      });
      return false;
    }
  };

  const updateContext = async (id: string, contextData: Partial<Context>) => {
    if (!contextData.name?.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Nome é obrigatório.",
        variant: "destructive",
      });
      return false;
    }

    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: contextData.name,
          description: contextData.description || undefined,
          productInfo: contextData.productInfo || undefined,
          targetAudience: contextData.targetAudience || undefined,
          commonObjections: contextData.commonObjections || undefined,
          pricingStructure: contextData.pricingStructure || undefined,
          playbook: contextData.playbook || undefined,
          mentalTriggers: contextData.mentalTriggers || undefined,
          competitors: contextData.competitors || undefined,
          vendedores: contextData.vendedores || [],
          vendedor_ativo_id: contextData.vendedor_ativo_id || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update context');
      }

      const result = await response.json();
      
      setContexts(contexts.map(c => c.id === id ? adaptContext(result.data) : c));
      
      toast({
        title: "Contexto atualizado",
        description: "Suas alterações foram salvas com sucesso.",
      });
      return true;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      return false;
    }
  };

  const deleteContext = async (id: string) => {
    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to delete context');
      }

      setContexts(contexts.filter(c => c.id !== id));
      toast({
        title: "Contexto removido",
        description: "O contexto foi removido com sucesso.",
      });
      return true;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Não foi possível remover o contexto.",
        variant: "destructive",
      });
      return false;
    }
  };

  const setActiveContext = async (id: string) => {
    if (!user?.id) {
      toast({
        title: "Erro de autenticação",
        description: "Você precisa estar logado para ativar contextos.",
        variant: "destructive",
      });
      return false;
    }

    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts/${id}/activate`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to activate context');
      }

      const result = await response.json();

      // Update local state immediately
      setContexts(contexts.map(c => ({
        ...c,
        is_active: c.id === id
      })));
      
      toast({
        title: "Contexto ativo",
        description: "Este contexto agora será usado nas análises.",
        variant: "success",
      });
      
      // Refresh in background to ensure consistency
      setTimeout(() => fetchContexts(), 100);
      
      return true;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      toast({
        title: "Erro",
        description: "Erro inesperado ao ativar contexto.",
        variant: "destructive",
      });
      return false;
    }
  };

  useEffect(() => {
    fetchContexts();
  }, [fetchContexts]);

  return {
    contexts,
    loading,
    fetchContexts,
    createContext,
    updateContext,
    deleteContext,
    setActiveContext
  };
}
