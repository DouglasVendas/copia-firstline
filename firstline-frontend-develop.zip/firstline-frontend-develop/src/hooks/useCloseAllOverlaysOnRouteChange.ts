import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useToast } from './use-toast';

export function useCloseAllOverlaysOnRouteChange() {
  const location = useLocation();
  const { dismiss } = useToast();

  useEffect(() => {
    // Fecha todos os toasts
    dismiss();
    // Dispara evento global para fechar modais/dialogs/drawers/sheets/alert-dialogs
    window.dispatchEvent(new Event('close-all-overlays'));
  }, [location]);
} 