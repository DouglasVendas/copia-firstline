import { useRef, useEffect, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { useUploadState } from "@/hooks/useUploadState";
import { useUploadValidation } from "@/hooks/useUploadValidation";
import { useFileProcessing } from "@/hooks/useFileProcessing";
import { useAudioCompression } from "@/hooks/useAudioCompression";
import { useProcessingQueue } from "@/hooks/useProcessingQueue";
import { useWhatsAppZip } from "@/hooks/useWhatsAppZip";

export const useSecureFileUpload = () => {
  const { toast } = useToast();
  const isMountedRef = useRef(true);
  
  const {
    isUploading,
    selectedFile,
    uploadType,
    textContent,
    selectedContext,
    selectedVendedor,
    selectedAnalysisName,
    uploadProgress,
    estimatedTime,
    autoDetectSpeakers,
    speakersCount,
    setIsUploading,
    setSelectedFile,
    setUploadType,
    setTextContent,
    setSelectedContext,
    setSelectedVendedor,
    setSelectedAnalysisName,
    setUploadProgress,
    setEstimatedTime,
    setAutoDetectSpeakers,
    setSpeakersCount,
    resetForm,
    resetProgress,
    updateTextContent,
    audioFile,
    textFile,
    whatsappFile,
    setAudioFileDirect,
    setTextFileDirect,
    setWhatsappFileDirect
  } = useUploadState();

  const {
    validateFileSelection,
    validateTextInput,
    validateContextAccess,
    validateUploadInputs
  } = useUploadValidation(uploadType);

  const { executeUpload } = useFileProcessing();
  const { isCompressing, compressionProgress } = useAudioCompression();
  const { queue } = useProcessingQueue();
  
  // WhatsApp ZIP hook
  const whatsAppZip = useWhatsAppZip();

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  // Restaurar arquivo correto ao trocar de tipo
  const handleUploadTypeChange = useCallback((type: 'audio' | 'text' | 'whatsapp') => {
    if (type === uploadType) return;
    
    // Reset WhatsApp ZIP state when changing types
    if (uploadType === 'whatsapp' || type !== 'whatsapp') {
      whatsAppZip.reset();
    }
    
    // Troca o tipo - o useEffect no useUploadState cuidará da sincronização
    setUploadType(type);
  }, [uploadType, whatsAppZip, setUploadType]);

  const handleSecureUpload = useCallback(async (contexts: any[], hasActiveContexts: boolean, sellers: Array<{ id: string; name: string }>) => {
    // Check if component is still mounted
    if (!isMountedRef.current) return;
    
    // Validate context access
    if (!validateContextAccess(contexts, selectedContext, hasActiveContexts)) {
      return;
    }

    // Validate upload inputs
    if (!validateUploadInputs(uploadType, selectedFile, textContent)) {
      return;
    }

    if (!isMountedRef.current) return;
    setIsUploading(true);
    resetProgress();

    try {
      const analysisData = await executeUpload({
        uploadType,
        selectedFile,
        textContent,
        selectedContext,
        selectedVendedor,
        selectedAnalysisName,
        contexts,
        sellers, // NOVO
        autoDetectSpeakers,
        speakersCount,
        setUploadProgress: (progress) => {
          if (isMountedRef.current) {
            setUploadProgress(progress);
          }
        },
        setEstimatedTime: (time) => {
          if (isMountedRef.current) {
            setEstimatedTime(time);
          }
        },
        // WhatsApp ZIP specific params
        whatsAppFiles: uploadType === 'whatsapp' ? whatsAppZip.getSelectedFiles() : undefined,
        includeAudios: whatsAppZip.includeAudios,
        includeImages: whatsAppZip.includeImages
      });

      // Check if still mounted before updating state
      if (!isMountedRef.current) return;

      // Reset form after successful upload
      resetForm();

      toast({
        title: "Análise concluída",
        description: "Sua análise foi processada com sucesso!",
      });

      return analysisData;

    } catch (error) {
      
      // Only show error if component is still mounted
      if (isMountedRef.current) {
        const errorMessage = error instanceof Error ? error.message : "Erro desconhecido durante a análise";
        
        toast({
          title: "Erro na análise",
          description: errorMessage,
          variant: "destructive",
        });
      }
      
      throw error; // Re-throw so caller can handle it
    } finally {
      if (isMountedRef.current) {
        setIsUploading(false);
        resetProgress();
      }
    }
  }, [
    validateContextAccess, 
    validateUploadInputs, 
    uploadType, 
    selectedFile, 
    textContent, 
    selectedContext, 
    executeUpload, 
    selectedVendedor, 
    selectedAnalysisName, 
    autoDetectSpeakers, 
    speakersCount, 
    whatsAppZip, 
    setIsUploading, 
    setUploadProgress, 
    setEstimatedTime, 
    resetForm, 
    resetProgress, 
    toast
  ]);

  // Corrigir para sempre limpar o outro tipo ao adicionar arquivo
  const handleFileSelect = useCallback(async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files && event.target.files[0] ? event.target.files[0] : null;
    
    if (!file) {
      setSelectedFile(null);
      return;
    }

    // Se for WhatsApp e arquivo ZIP, analisar o conteúdo
    if (uploadType === 'whatsapp' && file.name.toLowerCase().endsWith('.zip')) {
      try {
        await whatsAppZip.analyzeZip(file);
      } catch (error) {
        return;
      }
    }
    
    // Limpar o arquivo dos outros tipos
    if (uploadType === 'audio') {
      setTextFileDirect(null);
      setWhatsappFileDirect(null);
    } else if (uploadType === 'text') {
      setAudioFileDirect(null);
      setWhatsappFileDirect(null);
    } else if (uploadType === 'whatsapp') {
      setAudioFileDirect(null);
      setTextFileDirect(null);
    }
    
    // Salvar no estado correto
    setSelectedFile(file);
  }, [uploadType, whatsAppZip, setSelectedFile, setTextFileDirect, setWhatsappFileDirect, setAudioFileDirect]);

  const handleTextContentChange = useCallback((content: string) => {
    if (!isMountedRef.current) return;
    
    const sanitizedContent = validateTextInput(content);
    if (sanitizedContent !== null) {
      updateTextContent(sanitizedContent);
    }
  }, [validateTextInput, updateTextContent]);
  
  return {
    isUploading,
    selectedFile,
    uploadType,
    textContent,
    selectedContext,
    selectedVendedor,
    selectedAnalysisName,
    uploadProgress,
    estimatedTime,
    autoDetectSpeakers,
    speakersCount,
    isCompressing,
    compressionProgress,
    queue,
    setIsUploading,
    setSelectedFile,
    setUploadType: handleUploadTypeChange,
    setTextContent,
    setSelectedContext,
    setSelectedVendedor,
    setSelectedAnalysisName,
    setUploadProgress,
    setEstimatedTime,
    setAutoDetectSpeakers,
    setSpeakersCount,
    handleFileSelect,
    handleSecureUpload,
    handleTextContentChange,
    handleAutoDetectSpeakersChange: (checked: boolean) => {
      if (isMountedRef.current) {
        setAutoDetectSpeakers(checked);
      }
    },
    handleSpeakersCountChange: (count: number) => {
      if (isMountedRef.current) {
        setSpeakersCount(count);
      }
    },
    // WhatsApp ZIP functionality
    whatsAppZip
  };
};
