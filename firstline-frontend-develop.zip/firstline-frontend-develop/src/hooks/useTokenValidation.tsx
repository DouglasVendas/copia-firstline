
import { useState } from 'react';
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

export function useTokenValidation() {
  const [loading, setLoading] = useState(false);
  const [tokenData, setTokenData] = useState<any>(null);

  const validateToken = async (token: string) => {
    if (!AUTH_CONFIG.TOKEN_VALIDATION) {
      return { valid: true, tokenData: null };
    }

    setLoading(true);
    try {
      // TODO: Implement token validation with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/validate-token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ token }),
      });

      if (!response.ok) {
        return { valid: false, error: 'Erro ao validar token' };
      }

      const data = await response.json();
      
      if (data.valid) {
        setTokenData(data.tokenData);
      }

      return data;
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      return { valid: false, error: 'Erro ao validar token' };
    } finally {
      setLoading(false);
    }
  };

  return {
    validateToken,
    loading,
    tokenData
  };
}
