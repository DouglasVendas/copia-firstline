
import { useState } from 'react';

interface AuthFormData {
  email: string;
  password: string;
  confirmPassword: string;
  companyName: string;
  responsibleName: string;
  phone: string;
}

export function useAuthForm() {
  const [formData, setFormData] = useState<AuthFormData>({
    email: "",
    password: "",
    confirmPassword: "",
    companyName: "",
    responsibleName: "",
    phone: "",
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const resetForm = () => {
    setFormData({
      email: "",
      password: "",
      confirmPassword: "",
      companyName: "",
      responsibleName: "",
      phone: "",
    });
  };

  return {
    formData,
    handleInputChange,
    resetForm
  };
}
