
import { useState } from 'react';
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

export function useEmailValidation() {
  const [loading, setLoading] = useState(false);
  const [emailCache, setEmailCache] = useState<Map<string, boolean>>(new Map());

  const checkEmailExists = async (email: string): Promise<{ exists: boolean; error?: string }> => {
    // Check cache first
    if (emailCache.has(email)) {
      return { exists: emailCache.get(email)! };
    }

    if (!AUTH_CONFIG.EMAIL_VERIFICATION) {
      // For basic auth, assume email doesn't exist to allow registration
      return { exists: false };
    }

    setLoading(true);
    try {
      // TODO: Implement email validation with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/check-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        return { exists: false, error: 'Erro ao validar email' };
      }

      const data = await response.json();
      
      // Cache the result
      setEmailCache(prev => new Map(prev).set(email, data.exists));
      
      return { exists: data.exists };
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
      return { exists: false, error: 'Erro ao validar email' };
    } finally {
      setLoading(false);
    }
  };

  const clearCache = () => {
    setEmailCache(new Map());
  };

  return {
    checkEmailExists,
    loading,
    clearCache
  };
}
