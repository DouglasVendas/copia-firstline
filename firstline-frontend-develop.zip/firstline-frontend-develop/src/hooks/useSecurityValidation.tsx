
import { useState, useEffect } from 'react';
import { AUTH_CONFIG } from '@/components/auth/auth-config';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface SecurityCheck {
  emailVerified: boolean;
  subscriptionActive: boolean;
  loginAttempts: number;
  ipBlocked: boolean;
  requiresCaptcha: boolean;
}

export function useSecurityValidation(email?: string) {
  const [securityCheck, setSecurityCheck] = useState<SecurityCheck>({
    emailVerified: true, // Assume verified for basic auth
    subscriptionActive: true, // Assume active for basic auth
    loginAttempts: 0,
    ipBlocked: false,
    requiresCaptcha: false,
  });
  const [loading, setLoading] = useState(false);

  const checkSecurity = async (userEmail: string, ipAddress?: string) => {
    if (!AUTH_CONFIG.SECURITY_ENHANCED_AUTH) {
      // For basic auth, return positive security check
      setSecurityCheck({
        emailVerified: true,
        subscriptionActive: true,
        loginAttempts: 0,
        ipBlocked: false,
        requiresCaptcha: false,
      });
      return;
    }

    setLoading(true);
    try {
      // TODO: Implement security check with REST API when advanced auth is enabled
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/security-check`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email: userEmail,
          ip_address: ipAddress || getClientIP()
        }),
      });

      if (!response.ok) {
        return;
      }

      const data = await response.json();
      setSecurityCheck(data);
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    } finally {
      setLoading(false);
    }
  };

  const recordLoginAttempt = async (userEmail: string, success: boolean, ipAddress?: string) => {
    if (!AUTH_CONFIG.SECURITY_ENHANCED_AUTH) {
      return; // Skip recording for basic auth
    }

    try {
      // TODO: Implement login attempt recording with REST API when advanced auth is enabled
      await apiFetch(`${import.meta.env.VITE_API_URL}/auth/record-login-attempt`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: userEmail,
          success,
          ip_address: ipAddress || getClientIP(),
          user_agent: navigator.userAgent
        }),
      });
    } catch (error) {
      if (error instanceof AuthRedirectError) return;
    }
  };

  const getClientIP = () => {
    // This is a simplified approach - in production you might want to use a service
    return 'unknown';
  };

  useEffect(() => {
    if (email) {
      checkSecurity(email);
    }
  }, [email]);

  return {
    securityCheck,
    loading,
    checkSecurity,
    recordLoginAttempt,
    refreshSecurity: () => email && checkSecurity(email)
  };
}
