import { useState, useEffect, useRef } from 'react';
import { useAuth } from './useAuth';
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface Vendedor {
  id: string;
  name: string;
}

interface Context {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  prompt: string;
  vendedores: Vendedor[];
  vendedor_ativo: string | null; // nome
  vendedor_ativo_id: string | null;
}

const API_BASE_URL = import.meta.env.VITE_API_URL;

export function useContexts() {
  const [contexts, setContexts] = useState<Context[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const isMountedRef = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const fetchContexts = async () => {
    if (!user) return;

    try {
      setLoading(true);
      setError(null);

      const response = await apiFetch(`${API_BASE_URL}/contexts`);

      if (!response.ok) {
        throw new Error('Failed to fetch contexts');
      }

      const data = await response.json();

      // A API pode retornar {data: [...]} ou diretamente [...]
      const adaptContext = (ctx: any) => ({
        ...ctx,
        is_active: !!ctx.is_active || ctx.is_active === 1 || ctx.is_active === "1" || ctx.is_active === true || ctx.is_active === "true",
        vendedores: (ctx.vendedores || []).map((v: any) => ({
          id: v.vendedor_id || v.id || v,
          name: v.vendedor || v.name || v,
        })),
        vendedor_ativo: ctx.vendedor_ativo_id || null,
        // Remover vendedor_ativo_nome se não for usado
      });
      const contextsArray = (data.data || data).map(adaptContext);
      
      if (isMountedRef.current) {
        setContexts(Array.isArray(contextsArray) ? contextsArray : []);
      }
    } catch (err) {
      if (err instanceof AuthRedirectError) return;
      if (isMountedRef.current) {
        setError(err instanceof Error ? err.message : 'Failed to fetch contexts');
      }
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  };

  const createContext = async (contextData: Omit<Context, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(contextData),
      });

      if (!response.ok) {
        throw new Error('Failed to create context');
      }

      const newContext = await response.json();
      
      if (isMountedRef.current) {
        setContexts(prev => Array.isArray(prev) ? [...prev, newContext] : [newContext]);
      }
      
      return newContext;
    } catch (err) {
      if (err instanceof AuthRedirectError) return;
      throw err;
    }
  };

  const updateContext = async (id: string, contextData: Partial<Context>) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(contextData),
      });

      if (!response.ok) {
        throw new Error('Failed to update context');
      }

      const updatedContext = await response.json();
      
      if (isMountedRef.current) {
        setContexts(prev => Array.isArray(prev) ? prev.map(ctx => ctx.id === id ? updatedContext : ctx) : [updatedContext]);
      }
      
      return updatedContext;
    } catch (err) {
      if (err instanceof AuthRedirectError) return;
      throw err;
    }
  };

  const deleteContext = async (id: string) => {
    if (!user) throw new Error('User not authenticated');

    try {
      const response = await apiFetch(`${API_BASE_URL}/contexts/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete context');
      }

      if (isMountedRef.current) {
        setContexts(prev => Array.isArray(prev) ? prev.filter(ctx => ctx.id !== id) : []);
      }
    } catch (err) {
      if (err instanceof AuthRedirectError) return;
      throw err;
    }
  };

  useEffect(() => {
    fetchContexts();
  }, [user]);

  // Computed values
  const hasContexts = Array.isArray(contexts) && contexts.length > 0;
  const activeContexts = Array.isArray(contexts) ? contexts.filter(ctx => ctx.is_active) : [];
  const hasActiveContexts = activeContexts.length > 0;

  return {
    contexts,
    loading,
    error,
    fetchContexts,
    createContext,
    updateContext,
    deleteContext,
    hasContexts,
    hasActiveContexts,
    activeContexts,
  };
}
