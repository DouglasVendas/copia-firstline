import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';

const API_BASE_URL = import.meta.env.VITE_API_URL;

export async function fetchDashboardView(userId: string) {
  const response = await apiFetch(`${API_BASE_URL}/analyses/dashboard-view/`, {
    method: "GET",
  });

  if (!response.ok) {
    throw new Error("Erro ao buscar dados do dashboard");
  }

  const data = await response.json();
  return data;
}

export async function fetchLatestActivity(userId: string) {
  const response = await apiFetch(`${API_BASE_URL}/analyses/latest/`, {
    method: "GET",
  });

  if (response.status === 404) {
    throw new Error("NOT_FOUND");
  }

  if (!response.ok) {
    throw new Error("Erro ao buscar atividade recente");
  }

  const data = await response.json();
  return data;
}
