import { 
  sanitizeInput, 
  validateContextOwnership,
  validateVendedorSelection 
} from "@/utils/validation";
import { apiFetch, AuthRedirectError } from '@/lib/apiFetch';

interface UploadData {
  clientName: string;
  content: string;
  contextId: string;
  vendedor: string;
  contexts: any[];
  sellers: Array<{ id: string; name: string }>; // NOVO
}

interface SanitizedData {
  clientName: string;
  content: string;
  vendedor: string | null;
}

export const validateAndSanitizeUploadData = (
  data: UploadData
): { isValid: boolean; error?: string; sanitizedData?: SanitizedData } => {
  const { clientName, content, contextId, vendedor, contexts, sellers } = data;

  // Validate client name
  const sanitizedClientName = sanitizeInput(clientName);
  if (!sanitizedClientName || sanitizedClientName.length > 100) {
    return { isValid: false, error: 'Invalid client name' };
  }

  // Validate context ownership
  if (!validateContextOwnership(contextId, contexts)) {
    return { isValid: false, error: 'Unauthorized context access' };
  }

  // Validar vendedor usando lista global
  let vendedoresIds: string[] = [];
  if (sellers) {
    vendedoresIds = sellers.map((v: any) => v.id).filter(Boolean);
  }
  
  if (!validateVendedorSelection(vendedor, vendedoresIds)) {
    return { isValid: false, error: 'Invalid vendedor selection' };
  }

  return {
    isValid: true,
    sanitizedData: {
      clientName: sanitizedClientName,
      content: sanitizeInput(content),
      vendedor: vendedor ? sanitizeInput(vendedor) : null
    }
  };
};

export const performAudioUpload = async (
  file: File,
  contextId: string,
  vendedor: string | null,
  userId: string,
  autoDetectSpeakers: boolean,
  speakersCount: number,
  analysisName: string,
  onProgress?: (progress: number) => void
) => {
  onProgress?.(10);

  const formData = new FormData();
  formData.append('audio', file);
  formData.append('context_id', contextId);
  formData.append('analysis_name', analysisName);
  if (vendedor) {
    formData.append('vendedor_id', vendedor);
  }

  // Add speakers configuration - only send if not auto-detecting
  if (!autoDetectSpeakers) {
    formData.append('speakers_expected', speakersCount.toString());
  }
  // If autoDetectSpeakers is true, don't send speakers_expected parameter (empty = auto-detect)

  onProgress?.(20);
  
  try {
    const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyze-audio`, {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      // Handle specific HTTP errors
      if (response.status === 401) {
        throw new Error('Não autorizado. Verifique suas credenciais.');
      }
      
      if (response.status === 413) {
        throw new Error('Arquivo muito grande. Tente comprimir o áudio antes de enviar.');
      }
      
      if (response.status === 403) {
        throw new Error('Acesso negado. Verifique suas credenciais.');
      }
      
      if (response.status === 404) {
        throw new Error('Serviço não encontrado. Tente novamente mais tarde.');
      }
      
      if (response.status === 429) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Limite de uso excedido. Faça upgrade do seu plano.');
      }
      
      if (response.status >= 500) {
        throw new Error('Erro interno do servidor. Tente novamente mais tarde.');
      }

      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Erro do servidor: ${errorData.error || response.statusText}`);
    }

    const data = await response.json();

    if (!data || !data.success) {
      throw new Error('Resposta inválida do servidor');
    }

    // Parse JSON string fields that should be arrays
    if (data.analysis) {
      const fieldsToParseAsArray = [
        'pontos_positivos',
        'pontos_atencao', 
        'objecoes_identificadas',
        'sugestoes_melhoria',
        'proximos_passos',
        'coaching_insights',
        'plano_fechamento'
      ];

      fieldsToParseAsArray.forEach(field => {
        if (data.analysis[field] && typeof data.analysis[field] === 'string') {
          try {
            data.analysis[field] = JSON.parse(data.analysis[field]);
          } catch (e) {
            data.analysis[field] = [];
          }
        }
      });

      // Parse JSON string fields that should be objects
      const fieldsToParseAsObject = [
        'framework_analysis',
        'ia_preditiva',
        'mental_triggers',
        'performance_analysis',
        'tempo_de_fala',
        'desempenho_geral'
      ];

      fieldsToParseAsObject.forEach(field => {
        if (data.analysis[field] && typeof data.analysis[field] === 'string') {
          try {
            data.analysis[field] = JSON.parse(data.analysis[field]);
          } catch (e) {
            data.analysis[field] = {};
          }
        }
      });

      // Parse reformulacoes_pnl as array of objects
      if (data.analysis.reformulacoes_pnl && typeof data.analysis.reformulacoes_pnl === 'string') {
        try {
          data.analysis.reformulacoes_pnl = JSON.parse(data.analysis.reformulacoes_pnl);
        } catch (e) {
          data.analysis.reformulacoes_pnl = [];
        }
      }
    }

    onProgress?.(100);
    return data;

  } catch (err) {
    if (err instanceof AuthRedirectError) return;
    
    // Handle network errors (CORS, etc.)
    if (err instanceof TypeError && err.message.includes('Failed to fetch')) {
      throw new Error('Erro de conexão. Verifique sua internet e tente novamente.');
    }
    
    throw err;
  }
};

export const performTextUpload = async (
  content: string,
  contextId: string,
  vendedor: string | null,
  userId: string,
  analysisName: string,
  onProgress?: (progress: number) => void
) => {
  // Report initial progress
  onProgress?.(10);

  try {
    const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyze-text`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text: content,
        context_id: contextId,
        vendedor_id: vendedor,
        analysis_name: analysisName
      })
    });

    if (!response.ok) {
      // Handle specific HTTP errors
      if (response.status === 401) {
        throw new Error('Não autorizado. Verifique suas credenciais.');
      }
      
      if (response.status === 403) {
        throw new Error('Acesso negado. Verifique suas permissões.');
      }
      
      if (response.status === 413) {
        throw new Error('Texto muito longo. Reduza o tamanho do texto.');
      }
      
      if (response.status === 429) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Limite de uso excedido. Faça upgrade do seu plano.');
      }
      
      if (response.status >= 500) {
        throw new Error('Erro interno do servidor. Tente novamente mais tarde.');
      }

      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Erro do servidor: ${errorData.error || response.statusText}`);
    }

    const data = await response.json();

    // Parse JSON string fields that should be arrays
    if (data.analysis) {
      const fieldsToParseAsArray = [
        'pontos_positivos',
        'pontos_atencao', 
        'objecoes_identificadas',
        'sugestoes_melhoria',
        'proximos_passos',
        'coaching_insights',
        'plano_fechamento'
      ];

      fieldsToParseAsArray.forEach(field => {
        if (data.analysis[field] && typeof data.analysis[field] === 'string') {
          try {
            data.analysis[field] = JSON.parse(data.analysis[field]);
          } catch (e) {
            data.analysis[field] = [];
          }
        }
      });

      // Parse JSON string fields that should be objects
      const fieldsToParseAsObject = [
        'framework_analysis',
        'ia_preditiva',
        'mental_triggers',
        'performance_analysis',
        'tempo_de_fala',
        'desempenho_geral'
      ];

      fieldsToParseAsObject.forEach(field => {
        if (data.analysis[field] && typeof data.analysis[field] === 'string') {
          try {
            data.analysis[field] = JSON.parse(data.analysis[field]);
          } catch (e) {
            data.analysis[field] = {};
          }
        }
      });

      // Parse reformulacoes_pnl as array of objects
      if (data.analysis.reformulacoes_pnl && typeof data.analysis.reformulacoes_pnl === 'string') {
        try {
          data.analysis.reformulacoes_pnl = JSON.parse(data.analysis.reformulacoes_pnl);
        } catch (e) {
          data.analysis.reformulacoes_pnl = [];
        }
      }
    }

    // Report completion
    onProgress?.(100);

    return data;
  } catch (error) {
    if (error instanceof AuthRedirectError) return;    
    // Handle network errors (CORS, etc.)
    if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
      throw new Error('Erro de conexão. Verifique sua internet e tente novamente.');
    }
    
    throw error;
  }
};

export const performWhatsAppUpload = async (
  files: File[],
  includeAudios: boolean,
  includeImages: boolean,
  contextId: string,
  vendedor: string,
  analysisName: string,
  onProgress?: (progress: number) => void
) => {
  const API_BASE_URL = import.meta.env.VITE_API_URL;
  
  try {
    onProgress?.(10);

    const formData = new FormData();
    let textContent = '';
    
    // Process files and extract text content
    for (const file of files) {
      const ext = '.' + file.name.split('.').pop()?.toLowerCase();
      const audioExtensions = ['.mp3', '.wav', '.m4a', '.mp4', '.webm', '.ogg', '.opus', '.aac', '.ac3', '.aiff', '.aif', '.alac', '.amr', '.ape', '.au', '.dss', '.flac', '.tta', '.voc', '.wma', '.3ga', '.8svx', '.flv', '.qcp', '.m4b', '.m4p', '.m4r', '.m4v', '.mts', '.mxf', '.mov', '.qt', '.ts', '.m2t', '.m2ts'];
      const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.svg', '.tiff', '.tif'];
      const textExtensions = ['.txt'];
      
      const isAudio = audioExtensions.includes(ext);
      const isImage = imageExtensions.includes(ext);
      const isText = textExtensions.includes(ext);
      
      if (isText) {
        // Extract text content from .txt files
        try {
          const content = await file.text();
          textContent += content + '\n';
        } catch (error) {
        }
      } else if (isAudio && includeAudios) {
        // Add audio files with original names
        formData.append('files', file, file.name);
      } else if (isImage && includeImages) {
        // Add image files with original names
        formData.append('files', file, file.name);
      }
    }

    // Add extracted text content
    if (textContent.trim()) {
      formData.append('text_content', textContent.trim());
    }

    formData.append('context_id', contextId);
    formData.append('vendedor_id', vendedor);
    formData.append('analysis_name', analysisName);

    onProgress?.(30);

    const response = await apiFetch(`${API_BASE_URL}/analyze-whatsapp`, {
      method: 'POST',
      body: formData,
    });

    onProgress?.(70);

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Não autorizado. Verifique suas credenciais.');
      }
      
      if (response.status === 413) {
        throw new Error('Arquivos muito grandes. Reduza o tamanho dos arquivos.');
      }
      
      if (response.status === 403) {
        throw new Error('Acesso negado. Verifique suas credenciais.');
      }
      
      if (response.status === 404) {
        throw new Error('Serviço não encontrado. Tente novamente mais tarde.');
      }
      
      if (response.status === 429) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Limite de uso excedido. Faça upgrade do seu plano.');
      }
      
      if (response.status >= 500) {
        throw new Error('Erro interno do servidor. Tente novamente mais tarde.');
      }

      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Erro do servidor: ${errorData.error || response.statusText}`);
    }

    const data = await response.json();

    if (!data || !data.success) {
      throw new Error('Resposta inválida do servidor');
    }

    // Parse JSON fields similar to other upload functions
    if (data.analysis) {
      const fieldsToParseAsArray = [
        'pontos_positivos',
        'pontos_atencao', 
        'objecoes_identificadas',
        'sugestoes_melhoria',
        'proximos_passos',
        'coaching_insights',
        'plano_fechamento'
      ];

      fieldsToParseAsArray.forEach(field => {
        if (data.analysis[field] && typeof data.analysis[field] === 'string') {
          try {
            data.analysis[field] = JSON.parse(data.analysis[field]);
          } catch (e) {
            data.analysis[field] = [];
          }
        }
      });

      const fieldsToParseAsObject = [
        'nlp_analysis',
        'framework_analise',
        'deep_analysis',
        'evolucao_vendedor',
        'ia_preditiva',
        'mental_triggers',
        'performance_analysis',
        'tempo_de_fala',
        'desempenho_geral'
      ];

      fieldsToParseAsObject.forEach(field => {
        if (data.analysis[field] && typeof data.analysis[field] === 'string') {
          try {
            data.analysis[field] = JSON.parse(data.analysis[field]);
          } catch (e) {
            data.analysis[field] = {};
          }
        }
      });
    }

    onProgress?.(100);
    return data;
    
  } catch (error) {
    if (error instanceof AuthRedirectError) return;    
    if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
      throw new Error('Erro de conexão. Verifique sua internet e tente novamente.');
    }
    
    throw error;
  }
};