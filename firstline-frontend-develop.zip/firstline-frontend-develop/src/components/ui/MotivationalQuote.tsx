
import { useState, useEffect } from "react";

const motivationalQuotes = [
  "O sucesso é a soma de pequenos esforços repetidos dia após dia.",
  "Cada NÃO te aproxima de um SIM mais qualificado.",
  "Vendas não é sobre convencer, é sobre servir.",
  "A persistência é o caminho do êxito.",
  "Seu próximo cliente está esperando sua próxima ligação.",
  "Excelência é um hábito, não um ato.",
  "A confiança é o fechamento da venda.",
  "Cada objeção é uma oportunidade de educar.",
];

export function MotivationalQuote() {
  const [currentQuote, setCurrentQuote] = useState(motivationalQuotes[0]);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomIndex = Math.floor(Math.random() * motivationalQuotes.length);
      setCurrentQuote(motivationalQuotes[randomIndex]);
    }, 10000); // Muda a cada 10 segundos

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex items-center space-x-2 max-w-2xl">
      <div className="w-1 h-8 bg-gradient-to-b from-gold-400 to-gold-600"></div>
      <p className="text-sm italic text-muted-foreground animate-fade-in whitespace-nowrap overflow-hidden text-ellipsis">
        "{currentQuote}"
      </p>
    </div>
  );
}
