
import { Button } from "@/components/ui/button";

interface AuthSubmitButtonProps {
  loading: boolean;
  isSignUp: boolean;
  disabled?: boolean;
}

export function AuthSubmitButton({ loading, isSignUp, disabled }: AuthSubmitButtonProps) {
  return (
    <Button
      type="submit"
      disabled={loading || disabled}
      className="w-full bg-emerald-500 hover:bg-emerald-500 text-white font-medium py-2 px-4 rounded-md transition-colors"
    >
      {loading ? "Processando..." : (isSignUp ? "Criar Conta" : "Entrar")}
    </Button>
  );
}
