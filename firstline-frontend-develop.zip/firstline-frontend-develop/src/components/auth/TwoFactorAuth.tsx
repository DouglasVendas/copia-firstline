import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Shield, Smartphone, RefreshCw, Mail } from 'lucide-react';
import { apiFetch } from '@/lib/apiFetch';
import { useAuth } from '@/hooks/useAuth';

interface TwoFactorAuthProps {
  onSuccess: () => void;
  onCancel: () => void;
  email: string;
}

export function TwoFactorAuth({ onSuccess, onCancel, email }: TwoFactorAuthProps) {
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60); // 1 minute
  const [rateLimitCooldown, setRateLimitCooldown] = useState(0); // Cooldown do rate limit
  const { toast } = useToast();
  const { verify2FA } = useAuth();
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Timer para o cooldown do rate limit
  useEffect(() => {
    if (rateLimitCooldown <= 0) return;

    const timer = setInterval(() => {
      setRateLimitCooldown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [rateLimitCooldown]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCodeChange = (index: number, value: string) => {
    // Se o valor tem mais de 1 caractere, provavelmente é um colar
    if (value.length > 1) {
      // Remove caracteres não numéricos
      const numericValue = value.replace(/\D/g, '');
      
      // Se tem 6 dígitos, distribui pelos campos
      if (numericValue.length === 6) {
        const newCode = [...code];
        for (let i = 0; i < 6; i++) {
          newCode[i] = numericValue[i];
        }
        setCode(newCode);
        
        // Foca no último campo
        inputRefs.current[5]?.focus();
        return;
      }
      
      // Se tem menos de 6 dígitos, preenche até onde der
      if (numericValue.length < 6) {
        const newCode = [...code];
        for (let i = 0; i < numericValue.length && index + i < 6; i++) {
          newCode[index + i] = numericValue[i];
        }
        setCode(newCode);
        
        // Foca no próximo campo vazio
        const nextEmptyIndex = Math.min(index + numericValue.length, 5);
        inputRefs.current[nextEmptyIndex]?.focus();
        return;
      }
      
      return;
    }
    
    // Comportamento normal para um caractere
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);
    
    // Move para o próximo campo se digitou algo
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      // Move para o campo anterior se apagou um campo vazio
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text');
    const numericValue = pastedData.replace(/\D/g, '');
    
    if (numericValue.length === 6) {
      const newCode = [...code];
      for (let i = 0; i < 6; i++) {
        newCode[i] = numericValue[i];
      }
      setCode(newCode);
      
      // Foca no último campo
      inputRefs.current[5]?.focus();
    }
  };

  const handleVerify = async () => {
    const codeString = code.join('');
    if (codeString.length !== 6) {
      toast({
        title: "Código inválido",
        description: "Por favor, digite o código de 6 dígitos.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await verify2FA(email, codeString);
      toast({
        title: "Verificação concluída",
        description: "Autenticação de dois fatores confirmada com sucesso.",
      });
      onSuccess();
    } catch (error) {
      toast({
        title: "Erro na verificação",
        description: error instanceof Error ? error.message : "Não foi possível verificar o código.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    setResending(true);
    try {
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/2fa/resend`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        // Tratamento específico para rate limit (429)
        if (response.status === 429) {
          const errorData = await response.json().catch(() => ({}));
          const retryAfter = response.headers.get('Retry-After');
          const waitTime = retryAfter ? parseInt(retryAfter) : 600; // 10 minutos padrão
          
          // Define o cooldown do rate limit
          setRateLimitCooldown(waitTime);
          
          toast({
            title: "Limite de reenvios excedido",
            description: `Você pode solicitar um novo código em ${Math.ceil(waitTime / 60)} minutos.`,
            variant: "destructive",
          });
          return;
        }
        
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao reenviar código');
      }

      toast({
        title: "Código reenviado",
        description: "Um novo código foi enviado para seu email.",
      });

      // Reset timer
      setTimeLeft(60);
    } catch (error) {
      // Se for um erro de rede ou outro tipo, mostrar mensagem genérica
      toast({
        title: "Erro ao reenviar",
        description: error instanceof Error ? error.message : "Não foi possível reenviar o código.",
        variant: "destructive",
      });
    } finally {
      setResending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md bg-white shadow-xl">
        <CardHeader className="text-center pb-4">
          <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
            <Shield className="w-6 h-6 text-blue-600" />
          </div>
          <CardTitle className="text-xl text-gray-800">
            Verificação de Segurança
          </CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            Digite o código de 6 dígitos enviado para
          </p>
          <p className="text-sm font-medium text-gray-800">
            {email}
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div className="flex gap-3 justify-center">
                             {code.map((digit, index) => (
                 <Input
                   key={index}
                   ref={(el) => (inputRefs.current[index] = el)}
                   type="text"
                   inputMode="numeric"
                   pattern="[0-9]*"
                   maxLength={1}
                   value={digit}
                   onChange={(e) => handleCodeChange(index, e.target.value)}
                   onKeyDown={(e) => handleKeyDown(index, e)}
                   onPaste={handlePaste}
                   className="w-14 h-14 text-center text-xl font-semibold"
                   placeholder=""
                 />
               ))}
            </div>
            
            <div className="text-center">
              <p className="text-xs text-gray-500">
                Reenviar novamente em: <span className="font-mono">{formatTime(timeLeft)}</span>
              </p>
            </div>
          </div>

          <div className="space-y-3">
                         <Button
               onClick={handleVerify}
               disabled={code.join('').length !== 6 || loading || timeLeft === 0}
               className="w-full"
             >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Verificando...
                </>
              ) : (
                'Verificar Código'
              )}
            </Button>

            <Button
              variant="outline"
              onClick={handleResendCode}
              disabled={resending || timeLeft > 0 || rateLimitCooldown > 0}
              className="w-full"
            >
              {resending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Reenviando...
                </>
              ) : rateLimitCooldown > 0 ? (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Aguarde {Math.ceil(rateLimitCooldown / 60)}m {rateLimitCooldown % 60}s
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Reenviar Código
                </>
              )}
            </Button>

            <Button
              variant="ghost"
              onClick={onCancel}
              disabled={loading}
              className="w-full"
            >
              Cancelar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Exporta a versão envolvida que pode ser desabilitada
export default TwoFactorAuth;

// Exporta interface para uso futuro
export type { TwoFactorAuthProps };
