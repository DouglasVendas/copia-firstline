import React from 'react';

/**
 * Configuração de autenticação
 * 
 * Este arquivo controla quais recursos de autenticação estão ativos.
 * Para implementações futuras, basta alterar as flags aqui.
 */

export const AUTH_CONFIG = {
  // Recursos básicos (sempre ativos)
  BASIC_AUTH: true,
  EMAIL_PASSWORD: true,
  
  // Recursos avançados (desabilitados temporariamente)
  TWO_FACTOR_AUTH: true,
  EMAIL_VERIFICATION: false,
  TOKEN_VALIDATION: false,
  EXCLUSIVE_SIGNUP: false,
  ACCOUNT_APPROVAL: false,
  
  // Recursos de segurança avançada (desabilitados temporariamente)
  SECURITY_ENHANCED_AUTH: false,
  INVITE_CODES: false,
  SIGNUP_TOKENS: false,
  
  // Configurações adicionais
  REQUIRE_EMAIL_VERIFICATION: false,
  REQUIRE_2FA: false,
  REQUIRE_ACCOUNT_APPROVAL: false
} as const;

/**
 * Função para verificar se um recurso está ativo
 */
export function isFeatureEnabled(feature: keyof typeof AUTH_CONFIG): boolean {
  return AUTH_CONFIG[feature];
}

/**
 * Wrapper para componentes que devem ser condicionalmente renderizados
 */
export function withAuthFeature<T>(feature: keyof typeof AUTH_CONFIG, Component: React.ComponentType<T>) {
  return function ConditionalComponent(props: T) {
    if (!isFeatureEnabled(feature)) {
      return null; // Componente não renderizado se feature estiver desabilitada
    }
    return React.createElement(Component, props);
  };
}
