
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Mail, CheckCircle, Phone, MessageCircle } from "lucide-react";

interface ImprovedPendingApprovalProps {
  email: string;
  companyName?: string;
  onSignOut: () => void;
}

export function ImprovedPendingApproval({ 
  email, 
  companyName, 
  onSignOut 
}: ImprovedPendingApprovalProps) {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
          <CardTitle className="text-yellow-600">Conta Aguardando Aprovação</CardTitle>
          <p className="text-sm text-gray-600 mt-2">
            Sua solicitação de acesso está sendo analisada pela nossa equipe
          </p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-blue-800 mb-2">Informações da Conta</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center">
                <Mail className="w-4 h-4 text-blue-600 mr-2" />
                <span className="text-blue-700">{email}</span>
              </div>
              {companyName && (
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-blue-600 mr-2" />
                  <span className="text-blue-700">{companyName}</span>
                </div>
              )}
            </div>
          </div>

          <div className="bg-green-50 p-4 rounded-lg border border-green-200">
            <h3 className="font-semibold text-green-800 mb-2">O que acontece agora?</h3>
            <ol className="text-sm text-green-700 space-y-2">
              <li className="flex items-start">
                <span className="font-bold mr-2">1.</span>
                Nossa equipe analisará suas informações
              </li>
              <li className="flex items-start">
                <span className="font-bold mr-2">2.</span>
                Você receberá um email com o resultado em até 24 horas
              </li>
              <li className="flex items-start">
                <span className="font-bold mr-2">3.</span>
                Após aprovação, faça login normalmente
              </li>
            </ol>
          </div>

          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-800 mb-3">Precisa de ajuda?</h3>
            <div className="space-y-2">
              <div className="flex items-center text-sm text-gray-600">
                <MessageCircle className="w-4 h-4 mr-2" />
                <span>WhatsApp: (11) 99999-9999</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Mail className="w-4 h-4 mr-2" />
                <span>Email: suporte@firstlineai.com</span>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button 
              onClick={onSignOut}
              variant="outline"
              className="flex-1"
            >
              Sair
            </Button>
            <Button 
              onClick={() => window.location.reload()}
              variant="default"
              className="flex-1"
            >
              Verificar Status
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
