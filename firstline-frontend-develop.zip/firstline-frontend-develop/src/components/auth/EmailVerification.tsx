/*
 * COMPONENTE EMAIL VERIFICATION - TEMPORARIAMENTE DESABILITADO
 * 
 * Este componente implementa verificação de email.
 * Está preservado para implementação futura quando o sistema de verificação for ativado.
 */

import { withAuthFeature } from './auth-config';
import { apiFetch } from '@/lib/apiFetch';

interface EmailVerificationProps {
  email: string;
  onVerificationComplete: () => void;
  onCancel: () => void;
}

// Placeholder component para quando estiver desabilitado
function EmailVerificationPlaceholder(_props: EmailVerificationProps) {
  return null;
}

// Exporta a versão envolvida que pode ser desabilitada
export default withAuthFeature('EMAIL_VERIFICATION', EmailVerificationPlaceholder);

// Exporta interface para uso futuro
export type { EmailVerificationProps };

/*
CÓDIGO ORIGINAL PRESERVADO PARA IMPLEMENTAÇÃO FUTURA:
---------------------------------------------------------

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, CheckCircle, RefreshCw } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";

export function EmailVerificationOriginal({ email, onVerificationComplete, onCancel }: EmailVerificationProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleResendEmail = async () => {
    setLoading(true);
    try {
      // TODO: Implementar reenvio de email com novo backend
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/resend-verification`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        throw new Error('Falha ao reenviar email');
      }

      toast({
        title: "Email reenviado",
        description: "Um novo email de verificação foi enviado.",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível reenviar o email de verificação.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Resto do componente preservado...
}
*/
