
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Mail, CheckCircle } from "lucide-react";

interface PendingApprovalProps {
  email: string;
  companyName?: string;
  onSignOut: () => void;
}

export function PendingApproval({ email, companyName, onSignOut }: PendingApprovalProps) {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mb-4">
            <Clock className="w-8 h-8 text-yellow-600" />
          </div>
          <CardTitle className="text-yellow-600">Conta Pendente de Aprovação</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <div className="space-y-2">
            <p className="text-gray-600">
              Sua conta foi criada com sucesso, mas ainda precisa ser aprovada manualmente.
            </p>
            
            <div className="bg-gray-50 p-3 rounded-lg text-left text-sm">
              <div className="flex items-center mb-2">
                <Mail className="w-4 h-4 text-gray-500 mr-2" />
                <span className="font-medium">E-mail:</span>
              </div>
              <p className="text-gray-700 ml-6">{email}</p>
              
              {companyName && (
                <>
                  <div className="flex items-center mb-2 mt-3">
                    <CheckCircle className="w-4 h-4 text-gray-500 mr-2" />
                    <span className="font-medium">Empresa:</span>
                  </div>
                  <p className="text-gray-700 ml-6">{companyName}</p>
                </>
              )}
            </div>
          </div>

          <div className="bg-blue-50 p-3 rounded-lg text-sm">
            <p className="text-blue-800">
              <strong>Próximos passos:</strong>
            </p>
            <ul className="text-blue-700 mt-2 text-left list-disc list-inside space-y-1">
              <li>Aguarde a aprovação da sua conta</li>
              <li>Você receberá um e-mail quando for aprovada</li>
              <li>Após aprovação, faça login normalmente</li>
            </ul>
          </div>

          <Button 
            onClick={onSignOut}
            variant="outline"
            className="w-full"
          >
            Sair
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
