
interface AuthHeaderProps {
  isSignUp: boolean;
}

export function AuthHeader({ isSignUp }: AuthHeaderProps) {
  return (
    <div className="text-center">
      <div className="flex justify-center mb-8 mt-4">
        <img 
          src="LogoHorizontal01.png" 
          alt="FirstLineAI" 
          className="w-auto"
        />
      </div>
      <p className="text-gray-600 mt-4">
        {isSignUp ? "Crie sua conta" : "Entre na sua conta"}
      </p>
    </div>
  );
}
