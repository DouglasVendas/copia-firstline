
interface AuthToggleProps {
  isSignUp: boolean;
  onToggle: () => void;
}

export function AuthToggle({ isSignUp, onToggle }: AuthToggleProps) {
  const handleClick = () => {
    if (!isSignUp) {
      window.location.href = "https://firstlineai.com.br/";
    } else {
      onToggle();
    }
  };
  return (
    <div className="mt-6 text-center">
      {isSignUp ? (
        <button
          onClick={handleClick}
          className="text-blue-500 hover:text-blue-600 font-medium transition-colors"
        >
          Já tem uma conta? Entre aqui
        </button>
      ) : (
        <span className="text-gray-600">
          Ainda não tem uma conta?{" "}
          <button
            onClick={handleClick}
            className="text-blue-500 hover:text-blue-600 font-medium transition-colors"
          >
            Cadastre-se
          </button>
        </span>
      )}
    </div>
  );
}
