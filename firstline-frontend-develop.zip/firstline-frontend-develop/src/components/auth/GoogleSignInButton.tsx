import { useEffect, useRef } from 'react';
import { useGoogleAuth } from '@/hooks/useGoogleAuth';

interface GoogleSignInButtonProps {
  onSuccess: (userData: { id: string; email: string; name: string; picture: string }) => void;
  onError?: (error: any) => void;
  clientId: string;
  buttonConfig?: {
    type?: 'standard' | 'icon';
    theme?: 'outline' | 'filled_blue' | 'filled_black';
    size?: 'large' | 'medium' | 'small';
    text?: 'signin_with' | 'signup_with' | 'continue_with' | 'signin';
    shape?: 'rectangular' | 'pill' | 'circle' | 'square';
    logo_alignment?: 'left' | 'center';
    width?: string | number;
  };
}

export const GoogleSignInButton: React.FC<GoogleSignInButtonProps> = ({
  onSuccess,
  onError,
  clientId,
  buttonConfig = {}
}) => {
  const buttonRef = useRef<HTMLDivElement>(null);
  
  const handleGoogleResponse = (response: any) => {
    try {
      if (response.credential) {
        const userData = decodeGoogleToken(response.credential);
        if (userData) {
          onSuccess(userData);
        } else {
          onError?.(new Error('Failed to decode Google token'));
        }
      } else {
        onError?.(new Error('No credential received from Google'));
      }
    } catch (error) {
      onError?.(error);
    }
  };

  const { renderGoogleButton, decodeGoogleToken } = useGoogleAuth({
    client_id: clientId,
    callback: handleGoogleResponse,
    auto_select: false,
    cancel_on_tap_outside: true,
  });

  useEffect(() => {
    if (buttonRef.current) {
      // Limpar conteúdo anterior
      buttonRef.current.innerHTML = '';
      
      const defaultConfig = {
        type: 'standard',
        theme: 'outline',
        size: 'large',
        text: 'continue_with',
        shape: 'rectangular',
        logo_alignment: 'left',
        width: '100%',
        ...buttonConfig
      };
      
      renderGoogleButton(buttonRef.current, defaultConfig);
      
      // Aplicar bordas arredondadas após o render
      setTimeout(() => {
        const googleButton = buttonRef.current?.querySelector('div[role="button"]') as HTMLElement;
        if (googleButton) {
          googleButton.style.borderRadius = '8px';
        }
      }, 100);
    }
  }, [renderGoogleButton, buttonConfig]);

  return (
    <div 
      ref={buttonRef} 
      className="w-full flex justify-center"
      style={{ minHeight: '36px' }}
    />
  );
};
