import React, { useState, useEffect } from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Eye, EyeOff, Mail, Lock, Building, User, Phone, FileText, Check, X, Shield } from "lucide-react";
import privacyHtml from "../../legal/privacy-policy.html?raw";
import termsHtml from "../../legal/terms-of-use.html?raw";

interface RegisterFormProps {
  onSubmit: (formData: {
    email: string;
    password: string;
    confirmPassword: string;
    companyName: string;
    responsibleName: string;
    phone: string;
    cnpj?: string;
  }) => Promise<void>;
  loading: boolean;
  email: string;
}

export function RegisterForm({ onSubmit, loading, email }: RegisterFormProps) {
  const [formData, setFormData] = useState({
    email: email,
    password: '',
    confirmPassword: '',
    companyName: '',
    responsibleName: '',
    phone: '',
    cnpj: ''
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [openModal, setOpenModal] = useState<null | "privacy" | "terms">(null);
  const [showPasswordPopover, setShowPasswordPopover] = useState(false);

  // Atualiza o email no formulário quando a prop mudar
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      email: email
    }));
  }, [email]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // Função para validar email
  const isValidEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Função para validar senha forte
  const validatePassword = (password: string) => {
    const minLength = password.length >= 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumbers = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    
    return {
      isValid: minLength && hasUpperCase && hasLowerCase && hasNumbers && hasSpecialChar,
      minLength,
      hasUpperCase,
      hasLowerCase,
      hasNumbers,
      hasSpecialChar
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(formData);
  };

  const isFormValid = () => {
    const passwordValidation = validatePassword(formData.password);
    return formData.email &&
           isValidEmail(formData.email) &&
           formData.password && 
           formData.confirmPassword && 
           formData.companyName && 
           formData.responsibleName && 
           formData.phone && 
           acceptedTerms &&
           passwordValidation.isValid &&
           formData.password === formData.confirmPassword;
  };

  // Função para formatar telefone
  const formatPhone = (value: string) => {
    const phoneNumber = value.replace(/\D/g, '');
    if (phoneNumber.length <= 10) {
      return phoneNumber.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
    } else {
      return phoneNumber.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
  };

  // Função para formatar CNPJ
  const formatCNPJ = (value: string) => {
    const cnpj = value.replace(/\D/g, '');
    return cnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  };

  return (
    <>
      <form onSubmit={handleSubmit} className="space-y-4" autoComplete="on">
        {/* Email (editável) */}
        <div className="space-y-2">
          <Label htmlFor="email" className="pl-1 flex items-center gap-2">
            <Mail size={16} className="text-gray-500" />
            E-mail *
          </Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            required
            autoComplete="email"
          />
          {formData.email && !isValidEmail(formData.email) && (
            <p className="text-xs text-red-500">Por favor, insira um e-mail válido</p>
          )}
        </div>

        {/* Senha */}
        <div className="space-y-2">
          <Label htmlFor="password" className="pl-1 flex items-center gap-2">
            <Lock size={16} className="text-gray-500" />
            Senha *
          </Label>
          <div className="relative flex items-center">
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              placeholder="Mínimo 8 caracteres"
              required
              autoComplete="new-password"
              onFocus={() => setShowPasswordPopover(true)}
              onBlur={() => setTimeout(() => setShowPasswordPopover(false), 150)}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 text-gray-400 hover:text-gray-600"
              tabIndex={-1}
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
            {/* Popover de requisitos de senha */}
            {showPasswordPopover && (
              <div className="absolute z-20 left-full ml-3 w-72 bg-white border border-gray-200 rounded-xl shadow-xl p-4 text-sm animate-in slide-in-from-left-2 duration-200">
                <div className="flex items-center gap-2 mb-3 text-gray-800">
                  <Shield size={16} className="text-blue-500" />
                  <span className="font-semibold">Requisitos da Senha</span>
                </div>
                <div className="space-y-2.5">
                  <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                    validatePassword(formData.password).minLength 
                      ? 'bg-green-50 text-green-700 border border-green-200' 
                      : 'bg-gray-50 text-gray-600 border border-gray-200'
                  }`}>
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      validatePassword(formData.password).minLength 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                    }`}>
                      {validatePassword(formData.password).minLength ? (
                        <Check size={12} />
                      ) : (
                        <X size={12} />
                      )}
                    </div>
                    <span className="text-xs font-medium">Mínimo 8 caracteres</span>
                  </div>
                  
                  <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                    validatePassword(formData.password).hasUpperCase 
                      ? 'bg-green-50 text-green-700 border border-green-200' 
                      : 'bg-gray-50 text-gray-600 border border-gray-200'
                  }`}>
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      validatePassword(formData.password).hasUpperCase 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                    }`}>
                      {validatePassword(formData.password).hasUpperCase ? (
                        <Check size={12} />
                      ) : (
                        <X size={12} />
                      )}
                    </div>
                    <span className="text-xs font-medium">Uma letra maiúscula (A-Z)</span>
                  </div>
                  
                  <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                    validatePassword(formData.password).hasLowerCase 
                      ? 'bg-green-50 text-green-700 border border-green-200' 
                      : 'bg-gray-50 text-gray-600 border border-gray-200'
                  }`}>
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      validatePassword(formData.password).hasLowerCase 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                    }`}>
                      {validatePassword(formData.password).hasLowerCase ? (
                        <Check size={12} />
                      ) : (
                        <X size={12} />
                      )}
                    </div>
                    <span className="text-xs font-medium">Uma letra minúscula (a-z)</span>
                  </div>
                  
                  <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                    validatePassword(formData.password).hasNumbers 
                      ? 'bg-green-50 text-green-700 border border-green-200' 
                      : 'bg-gray-50 text-gray-600 border border-gray-200'
                  }`}>
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      validatePassword(formData.password).hasNumbers 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                    }`}>
                      {validatePassword(formData.password).hasNumbers ? (
                        <Check size={12} />
                      ) : (
                        <X size={12} />
                      )}
                    </div>
                    <span className="text-xs font-medium">Um número (0-9)</span>
                  </div>
                  
                  <div className={`flex items-center gap-3 p-2 rounded-lg transition-all duration-200 ${
                    validatePassword(formData.password).hasSpecialChar 
                      ? 'bg-green-50 text-green-700 border border-green-200' 
                      : 'bg-gray-50 text-gray-600 border border-gray-200'
                  }`}>
                    <div className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${
                      validatePassword(formData.password).hasSpecialChar 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gray-300 text-gray-500'
                    }`}>
                      {validatePassword(formData.password).hasSpecialChar ? (
                        <Check size={12} />
                      ) : (
                        <X size={12} />
                      )}
                    </div>
                    <span className="text-xs font-medium">Um caractere especial</span>
                  </div>
                </div>
                
                {/* Indicador de força da senha */}
                <div className="mt-4 pt-3 border-t border-gray-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-gray-600">Força da senha:</span>
                    <span className={`text-xs font-semibold ${
                      validatePassword(formData.password).isValid 
                        ? 'text-green-600' 
                        : Object.values(validatePassword(formData.password)).filter(Boolean).length >= 3
                        ? 'text-yellow-600'
                        : 'text-red-500'
                    }`}>
                      {validatePassword(formData.password).isValid 
                        ? 'Forte' 
                        : Object.values(validatePassword(formData.password)).filter(Boolean).length >= 3
                        ? 'Média'
                        : 'Fraca'}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className={`h-2 rounded-full transition-all duration-300 ${
                        validatePassword(formData.password).isValid 
                          ? 'bg-green-500 w-full' 
                          : Object.values(validatePassword(formData.password)).filter(Boolean).length >= 3
                          ? 'bg-yellow-500 w-2/3'
                          : 'bg-red-500 w-1/3'
                      }`}
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Confirmar Senha */}
        <div className="space-y-2">
          <Label htmlFor="confirmPassword" className="pl-1 flex items-center gap-2">
            <Lock size={16} className="text-gray-500" />
            Confirmar Senha *
          </Label>
          <div className="relative">
            <Input
              id="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              value={formData.confirmPassword}
              onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
              required
              autoComplete="new-password"
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-1/4 text-gray-400 hover:text-gray-600"
            >
              {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>
          {formData.confirmPassword && formData.password !== formData.confirmPassword && (
            <p className="text-xs text-red-500">As senhas não coincidem</p>
          )}
        </div>

        {/* Nome da Empresa */}
        <div className="space-y-2">
          <Label htmlFor="companyName" className="pl-1 flex items-center gap-2">
            <Building size={16} className="text-gray-500" />
            Nome da Empresa *
          </Label>
          <Input
            id="companyName"
            type="text"
            value={formData.companyName}
            onChange={(e) => handleInputChange('companyName', e.target.value)}
            required
            autoComplete="organization"
          />
        </div>

        {/* Nome do Responsável */}
        <div className="space-y-2">
          <Label htmlFor="responsibleName" className="pl-1 flex items-center gap-2">
            <User size={16} className="text-gray-500" />
            Nome do Responsável *
          </Label>
          <Input
            id="responsibleName"
            type="text"
            value={formData.responsibleName}
            onChange={(e) => handleInputChange('responsibleName', e.target.value)}
            required
            autoComplete="name"
          />
        </div>

        {/* Telefone */}
        <div className="space-y-2">
          <Label htmlFor="phone" className="pl-1 flex items-center gap-2">
            <Phone size={16} className="text-gray-500" />
            Telefone *
          </Label>
          <Input
            id="phone"
            type="tel"
            value={formData.phone}
            onChange={(e) => {
              const formatted = formatPhone(e.target.value);
              handleInputChange('phone', formatted);
            }}
            placeholder="(11) 99999-9999"
            required
            autoComplete="tel"
          />
        </div>

        {/* CNPJ (opcional) */}
        <div className="space-y-2">
          <Label htmlFor="cnpj" className="pl-1 flex items-center gap-2">
            <FileText size={16} className="text-gray-500" />
            CNPJ
          </Label>
          <Input
            id="cnpj"
            type="text"
            value={formData.cnpj}
            onChange={(e) => {
              const formatted = formatCNPJ(e.target.value);
              handleInputChange('cnpj', formatted);
            }}
            placeholder="00.000.000/0000-00"
            maxLength={18}
          />
        </div>

        {/* Termos e Condições */}
        <div className="flex items-start gap-2 mt-4 pl-1">
          <Checkbox 
            id="accept-terms" 
            checked={acceptedTerms} 
            onCheckedChange={(checked) => setAcceptedTerms(checked === true)} 
          />
          <label htmlFor="accept-terms" className="text-xs text-gray-500 select-none cursor-pointer">
            Eu li e aceito os
            <button 
              type="button" 
              className="underline ml-1 hover:text-gray-700 transition-colors" 
              onClick={() => setOpenModal("terms")}
            >
              Termos de Uso
            </button>
            {' '}e a
            <button 
              type="button" 
              className="underline ml-1 hover:text-gray-700 transition-colors" 
              onClick={() => setOpenModal("privacy")}
            >
              Política de Privacidade
            </button>
          </label>
        </div>

        {/* Botão de Submit */}
        <Button
          type="submit"
          disabled={loading || !isFormValid()}
          className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-medium py-2 px-4 rounded-md transition-colors mt-6"
        >
          {loading ? "Criando conta..." : "Criar Conta"}
        </Button>
      </form>

      {/* Modal de Termos e Privacidade */}
      <Dialog open={openModal !== null} onOpenChange={(open) => setOpenModal(open ? openModal : null)}>
        <DialogContent className="w-[600px] max-w-full h-[60vh] max-h-[60vh] overflow-y-auto animate-slide-in bg-white">
          <DialogHeader>
            <DialogTitle className="text-base text-gray-700">
              {openModal === "terms" ? "Termos de Uso" : "Política de Privacidade"}
            </DialogTitle>
          </DialogHeader>
          <div
            className="prose max-w-none"
            style={{ maxHeight: '45vh', overflowY: 'auto' }}
            dangerouslySetInnerHTML={{
              __html: `
                <style>
                  .popup-legal p { font-size: 11px !important; color: #4b5563 !important; margin-bottom: 0.7em !important; }
                  .popup-legal span, .popup-legal div { font-size: 11px !important; color: #4b5563 !important; }
                  .popup-legal ul, .popup-legal ol { font-size: 0.875rem !important; color: #4b5563 !important; margin-left: 1.25em; list-style-position: inside !important; list-style-type: initial !important; margin-bottom: 0 !important; }
                  .popup-legal li { font-size: 0.875rem !important; color: #4b5563 !important; list-style-type: initial !important; margin-bottom: 0.2em !important; line-height: 1.2 !important; }
                </style>
                <div class='popup-legal'>${openModal === "terms" ? termsHtml : privacyHtml}</div>
              `
            }}
          />
          <div className="flex justify-end mt-4">
            <DialogClose asChild>
              <Button variant="outline" size="sm">Fechar</Button>
            </DialogClose>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
