/*
 * COMPONENTE SECURITY ENHANCED AUTH - TEMPORARIAMENTE DESABILITADO
 * 
 * Este componente implementa autenticação com segurança avançada.
 * Está preservado para implementação futura quando o sistema avançado for ativado.
 */

import { withAuthFeature } from './auth-config';
import { apiFetch } from '@/lib/apiFetch';

interface SecurityEnhancedAuthProps {
  email: string;
  onAuthComplete: () => void;
  requireEmailVerification?: boolean;
  require2FA?: boolean;
}

// Placeholder component para quando estiver desabilitado
function SecurityEnhancedAuthPlaceholder(_props: SecurityEnhancedAuthProps) {
  return null;
}

// Exporta a versão envolvida que pode ser desabilitada
export default withAuthFeature('SECURITY_ENHANCED_AUTH', SecurityEnhancedAuthPlaceholder);

// Exporta interface para uso futuro
export type { SecurityEnhancedAuthProps };

/*
CÓDIGO ORIGINAL PRESERVADO PARA IMPLEMENTAÇÃO FUTURA:
---------------------------------------------------------

import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { TwoFactorAuth } from './TwoFactorAuth';
import { EmailVerification } from './EmailVerification';
import { useToast } from "@/hooks/use-toast";

export function SecurityEnhancedAuthOriginal({ 
  email, 
  onAuthComplete, 
  requireEmailVerification = true,
  require2FA = true 
}: SecurityEnhancedAuthProps) {
  const [searchParams] = useSearchParams();
  const [currentStep, setCurrentStep] = useState<'email-verification' | '2fa' | 'complete'>('email-verification');
  const { toast } = useToast();

  useEffect(() => {
    // Check if user came from email verification link
    const verified = searchParams.get('verified');
    if (verified === 'true') {
      if (require2FA) {
        setCurrentStep('2fa');
        // Send 2FA code automatically
        send2FACode();
      } else {
        setCurrentStep('complete');
        onAuthComplete();
      }
    }
  }, [searchParams, require2FA, onAuthComplete]);

  const send2FACode = async () => {
    try {
      // TODO: Implementar com novo backend
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/auth/send-2fa`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email })
      });

      if (!response.ok) {
        throw new Error('Falha ao enviar código 2FA');
      }
      
      toast({
        title: "Código de segurança enviado",
        description: "Verifique seu e-mail para o código de verificação.",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Não foi possível enviar o código de segurança.",
        variant: "destructive",
      });
    }
  };

  // Resto do componente preservado...
}
*/