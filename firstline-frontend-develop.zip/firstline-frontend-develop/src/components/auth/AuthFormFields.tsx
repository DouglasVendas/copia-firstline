
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Building, User, Phone, Mail, Lock, Eye, EyeOff, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface AuthFormFieldsProps {
  isSignUp: boolean;
  formData: {
    email: string;
    password: string;
    confirmPassword: string;
    companyName: string;
    responsibleName: string;
    phone: string;
    cnpj: string;
  };
  showPassword: boolean;
  showConfirmPassword: boolean;
  onInputChange: (field: string, value: string) => void;
  onTogglePassword: () => void;
  onToggleConfirmPassword: () => void;
  toast: (args: { title: string; description: string }) => void;
}

export function AuthFormFields({
  isSignUp,
  formData,
  showPassword,
  showConfirmPassword,
  onInputChange,
  onTogglePassword,
  onToggleConfirmPassword,
  toast
}: AuthFormFieldsProps) {
  const navigate = useNavigate();
  return (
    <>
      {isSignUp && (
        <>
          <div>
            <Label htmlFor="companyName" className="text-gray-700 font-medium flex items-center">
              <Building className="w-4 h-4 mr-2" />
              Nome da Empresa
            </Label>
            <Input
              id="companyName"
              name="companyName"
              type="text"
              value={formData.companyName}
              onChange={(e) => onInputChange('companyName', e.target.value)}
              required
              autoComplete="organization"
              className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900"
              placeholder="Digite o nome da empresa"
            />
          </div>

          <div>
            <Label htmlFor="responsibleName" className="text-gray-700 font-medium flex items-center">
              <User className="w-4 h-4 mr-2" />
              Nome do Responsável
            </Label>
            <Input
              id="responsibleName"
              name="responsibleName"
              type="text"
              value={formData.responsibleName}
              onChange={(e) => onInputChange('responsibleName', e.target.value)}
              required
              autoComplete="name"
              className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900"
              placeholder="Digite o nome do responsável"
            />
          </div>

          <div>
            <Label htmlFor="phone" className="text-gray-700 font-medium flex items-center">
              <Phone className="w-4 h-4 mr-2" />
              Telefone
            </Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => onInputChange('phone', e.target.value)}
              autoComplete="tel"
              className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900"
              placeholder="(11) 99999-9999"
            />
          </div>

          <div>
            <Label htmlFor="cnpj" className="text-gray-700 font-medium flex items-center">
              <FileText className="w-4 h-4 mr-2" />
              CNPJ
            </Label>
            <Input
              id="cnpj"
              name="cnpj"
              type="text"
              value={formData.cnpj}
              onChange={(e) => onInputChange('cnpj', e.target.value)}
              required
              autoComplete="off"
              className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900"
              placeholder="00.000.000/0000-00"
            />
          </div>
        </>
      )}

      <div>
        <Label htmlFor="email" className="text-gray-700 font-medium flex items-center pl-1">
          <Mail className="w-4 h-4 mr-2" />
          E-mail
        </Label>
        <Input
          id="email"
          name="email"
          type="email"
          value={formData.email}
          onChange={(e) => onInputChange('email', e.target.value)}
          required
          autoComplete="email"
          className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900"
          placeholder="Digite seu e-mail"
        />
      </div>

      <div>
        <Label htmlFor="password" className="text-gray-700 font-medium flex items-center pl-1">
          <Lock className="w-4 h-4 mr-2" />
          Senha
        </Label>
        <div className="relative">
          <Input
            id="password"
            name="password"
            type={showPassword ? "text" : "password"}
            value={formData.password}
            onChange={(e) => onInputChange('password', e.target.value)}
            required
            autoComplete={isSignUp ? "new-password" : "current-password"}
            className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900 pr-10"
            placeholder="Digite sua senha"
          />
          <button
            type="button"
            onClick={onTogglePassword}
            className="absolute right-3 top-3.5 text-gray-500 hover:text-gray-700"
          >
            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
        {!isSignUp && (
          <div className="flex justify-end mt-1 pr-1.5">
            <button
              type="button"
              className="text-xs text-blue-500 hover:text-blue-600 font-medium transition-colors p-0 h-auto"
              onClick={() => navigate('/redefinir-senha')}
            >
              Esqueceu sua senha?
            </button>
          </div>
        )}
      </div>

      {isSignUp && (
        <div>
          <Label htmlFor="confirmPassword" className="text-gray-700 font-medium flex items-center">
            <Lock className="w-4 h-4 mr-2" />
            Confirmar Senha
          </Label>
          <div className="relative">
            <Input
              id="confirmPassword"
              name="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              value={formData.confirmPassword}
              onChange={(e) => onInputChange('confirmPassword', e.target.value)}
              required
              autoComplete="new-password"
              className="mt-2 bg-white border-gray-300 focus:border-emerald-400 text-gray-900 pr-10"
              placeholder="Confirme sua senha"
            />
            <button
              type="button"
              onClick={onToggleConfirmPassword}
              className="absolute right-3.5 top-4 text-gray-500 hover:text-gray-700"
            >
              {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
