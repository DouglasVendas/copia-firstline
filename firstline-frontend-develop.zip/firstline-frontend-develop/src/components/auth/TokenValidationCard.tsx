
/*
 * COMPONENTE TOKEN VALIDATION CARD - TEMPORARIAMENTE DESABILITADO
 * 
 * Este componente implementa validação de token.
 * Está preservado para implementação futura quando o sistema de tokens for ativado.
 */

import { withAuthFeature } from './auth-config';

interface TokenValidationCardProps {
  tokenValid: boolean;
  tokenData: any;
  onReturnHome: () => void;
}

// Placeholder component para quando estiver desabilitado
function TokenValidationCardPlaceholder(_props: TokenValidationCardProps) {
  return null;
}

// Exporta a versão envolvida que pode ser desabilitada
const TokenValidationCard = withAuthFeature('TOKEN_VALIDATION', TokenValidationCardPlaceholder);

export default TokenValidationCard;
export { TokenValidationCard };

// Exporta interface para uso futuro
export type { TokenValidationCardProps };

/*
CÓDIGO ORIGINAL PRESERVADO PARA IMPLEMENTAÇÃO FUTURA:
---------------------------------------------------------

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, CheckCircle } from "lucide-react";

export function TokenValidationCardOriginal({ tokenValid, tokenData, onReturnHome }: TokenValidationCardProps) {
  if (tokenValid) {
    return (
      <div className="flex items-center justify-center mb-2">
        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center mr-2">
          <CheckCircle className="w-5 h-5 text-green-600" />
        </div>
        <span className="text-sm text-green-600 font-medium">Acesso Autorizado</span>
      </div>
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader className="text-center">
        <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
          <Shield className="w-8 h-8 text-red-600" />
        </div>
        <CardTitle className="text-red-600">Acesso Negado</CardTitle>
      </CardHeader>
      <CardContent className="text-center">
        <p className="text-gray-600 mb-4">
          Este link de cadastro não é válido ou expirou.
        </p>
        <Button onClick={onReturnHome}>
          Voltar ao Início
        </Button>
      </CardContent>
    </Card>
  );
}

*/