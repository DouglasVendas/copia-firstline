
import { useEffect, useState } from 'react';
import { useAccountStatus } from '@/hooks/useAccountStatus';
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, XCircle, Clock } from "lucide-react";

interface AccountApprovalStatusProps {
  onStatusChange?: (status: string) => void;
}

export function AccountApprovalStatus({ onStatusChange }: AccountApprovalStatusProps) {
  const { profileData, loading, refreshProfile } = useAccountStatus();
  const [lastStatus, setLastStatus] = useState<string | null>(null);

  useEffect(() => {
    if (profileData?.account_status && profileData.account_status !== lastStatus) {
      setLastStatus(profileData.account_status);
      onStatusChange?.(profileData.account_status);
    }
  }, [profileData?.account_status, lastStatus, onStatusChange]);

  if (loading) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="p-6 text-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Verificando status...</p>
        </CardContent>
      </Card>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-6 h-6 text-green-600" />;
      case 'rejected':
        return <XCircle className="w-6 h-6 text-red-600" />;
      default:
        return <Clock className="w-6 h-6 text-yellow-600" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'approved':
        return 'Conta Aprovada';
      case 'rejected':
        return 'Conta Rejeitada';
      default:
        return 'Aguardando Aprovação';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'text-green-600';
      case 'rejected':
        return 'text-red-600';
      default:
        return 'text-yellow-600';
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardContent className="p-6 text-center">
        <div className="flex flex-col items-center space-y-3">
          {getStatusIcon(profileData?.account_status || 'pending')}
          <h3 className={`font-semibold ${getStatusColor(profileData?.account_status || 'pending')}`}>
            {getStatusText(profileData?.account_status || 'pending')}
          </h3>
          {profileData?.account_status === 'pending' && (
            <p className="text-sm text-gray-600">
              Sua conta está sendo analisada. Aguarde nossa resposta.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
