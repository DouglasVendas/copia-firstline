"use client"

import { Home, Settings, FileText, Upload, Target, User, LogOut, Bot } from "lucide-react"
import { NavLink, useLocation } from "react-router-dom"
import { useAuth } from "@/hooks/useAuth"
import { useToast } from "@/hooks/use-toast"
import { AuthRedirectError } from "@/lib/apiFetch"
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar"

const menuItems = [
  { title: "Dashboard", url: "/", icon: Home },
  { title: "Configurar Contexto", url: "/contexto", icon: Target },
  { title: "Cadastrar Vendedor", url: "/vendedores", icon: User },
  { title: "Meeting Bot", url: "/meeting-bot", icon: Bot },
  { title: "Minhas Interações", url: "/interacoes", icon: Upload },
  { title: "Meus Relatórios", url: "/relatorios", icon: FileText },
  { title: "Configurações", url: "/configuracoes", icon: Settings },
]

export function AppSidebar() {
  const { state } = useSidebar()
  const location = useLocation()
  const { signOut } = useAuth()
  const { toast } = useToast()
  const currentPath = location.pathname
  const isCollapsed = state === "collapsed"

  const isActive = (path: string) => currentPath === path
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    `transition-all duration-200 ${
      isActive
        ? "bg-blue-50 text-blue-700 border-r-4 border-blue-500 font-medium"
        : "hover:bg-gray-50 text-gray-700 hover:text-gray-900"
    }`

  const handleSignOut = async () => {
    try {
      await signOut()
      toast({
        title: "Logout realizado com sucesso",
        description: "Você foi desconectado da aplicação.",
      })
    } catch (error) {
      if (error instanceof AuthRedirectError) return
      toast({
        title: "Erro ao fazer logout",
        description: "Ocorreu um erro ao tentar desconectar.",
        variant: "destructive",
      })
    }
  }

  return (
    <Sidebar
      className={`${isCollapsed ? "w-16" : "w-64"} bg-[#F9FAFB] border-r border-gray-200 transition-all duration-300`}
      collapsible="icon"
    >
      {/* Só renderiza o topo se NÃO estiver colapsada */}
      {!isCollapsed && (
        <div className="py-20 px-8 border-b border-gray-200 bg-[#F9FAFB]">
          <div className="flex items-center space-x-3">
            <img src="LogoHorizontal01.png" alt="FirstLineAI" className="w-auto" />
          </div>
        </div>
      )}

      {/* Só renderiza o conteúdo se NÃO estiver colapsada */}
      {!isCollapsed && (
        <SidebarContent className="p-4 pt-6 bg-[#F9FAFB]">
          <SidebarGroup>
            <SidebarGroupLabel className="text-[#4B5563] font-semibold text-sm uppercase tracking-wider mb-3">
              {"Menu Principal"}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu className="space-y-1">
                {menuItems.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild className="h-12">
                      <NavLink to={item.url} end className={getNavCls}>
                        <item.icon className="w-5 h-5 flex-shrink-0" />
                        <span className="font-medium">{item.title}</span>
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>

          <div className="mt-auto pt-4 border-t border-gray-200">
            <div className="relative">
              <button
                onClick={handleSignOut}
                className="flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left outline-none transition-all duration-200 focus-visible:ring-2 focus-visible:ring-blue-500 hover:bg-red-50 text-red-600 hover:text-red-700 h-12"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Sair</span>
              </button>
            </div>
          </div>
        </SidebarContent>
      )}
    </Sidebar>
  )
}
