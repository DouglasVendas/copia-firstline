
import { useRef, useEffect } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { MotivationalQuote } from "../ui/MotivationalQuote";
import { useCloseAllOverlaysOnRouteChange } from "@/hooks/useCloseAllOverlaysOnRouteChange";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const isMountedRef = useRef(true);

  useCloseAllOverlaysOnRouteChange();

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-50">
        <AppSidebar />
        
        <main className="flex-1 flex flex-col">
          <header className="h-16 flex items-center justify-between px-6 border-b border-slate-200 bg-white/80 backdrop-blur-sm">
            <div className="flex items-center space-x-4">
              <SidebarTrigger className="text-blue-600 hover:text-blue-700" />
              <MotivationalQuote />
            </div>
          </header>
          
          <div className="flex-1 p-6 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
