import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Upload, FileAudio, FileText, Loader2, Plus, Minus, Users, Info } from "lucide-react";
import { useState, useRef } from "react";

// WhatsApp Icon Component
const WhatsAppIcon = ({ className, isSelected }: { className?: string; isSelected?: boolean }) => (
  <img 
    src="/whatsapp.png" 
    alt="WhatsApp" 
    className={className}
    style={{
      filter: isSelected 
        ? 'brightness(0) saturate(100%) invert(1)' 
        : 'brightness(0.4) saturate(100%)'
    }}
  />
);

type UploadType = 'audio' | 'text' | 'whatsapp';

interface Vendedor {
  id: string;
  name: string;
}

interface Context {
  id: string;
  name: string;
  description: string;
  vendedores: Vendedor[];
  vendedor_ativo: string | null;
}

interface FileUploadCardProps {
  uploadType: UploadType;
  selectedFile: File | null;
  selectedContext: string;
  selectedVendedor: string;
  selectedAnalysisName: string;
  textContent: string;
  isUploading: boolean;
  activeContexts: Context[];
  selectedContextData?: Context;
  autoDetectSpeakers: boolean;
  speakersCount: number;
  onUploadTypeChange: (type: UploadType) => void;
  onFileSelect: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onContextChange: (contextId: string) => void;
  onVendedorChange: (vendedor: string) => void;
  onAnalysisNameChange: (name: string) => void;
  onUpload: () => void;
  onTextContentChange: (content: string) => void;
  onAutoDetectSpeakersChange: (checked: boolean) => void;
  onSpeakersCountChange: (count: number) => void;
  hasActiveContexts: boolean;
  sellers: Array<{ id: string; name: string }>;
  // WhatsApp ZIP props
  whatsAppZip?: {
    isExtracting: boolean;
    zipAnalysis: any;
    includeAudios: boolean;
    includeImages: boolean;
    setIncludeAudios: (include: boolean) => void;
    setIncludeImages: (include: boolean) => void;
  };
}

export function FileUploadCard({
  uploadType,
  selectedFile,
  selectedContext,
  selectedVendedor,
  selectedAnalysisName,
  textContent,
  isUploading,
  activeContexts,
  selectedContextData,
  autoDetectSpeakers,
  speakersCount,
  onUploadTypeChange,
  onFileSelect,
  onContextChange,
  onVendedorChange,
  onAnalysisNameChange,
  onUpload,
  onTextContentChange,
  onAutoDetectSpeakersChange,
  onSpeakersCountChange,
  hasActiveContexts,
  sellers,
  whatsAppZip
}: FileUploadCardProps & { selectedAnalysisName: string; onAnalysisNameChange: (name: string) => void }) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [dragError, setDragError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Lista completa de MIME types aceitos para áudio
  const acceptedAudioMimeTypes = [
    // Formatos de áudio principais
    'audio/mpeg', 'audio/mp3', 'audio/mpga', 'audio/mp2',
    'audio/wav', 'audio/wave',
    'audio/ogg', 'audio/oga', 'audio/mogg',
    'audio/opus',
    'audio/aac',
    'audio/ac3',
    'audio/aiff', 'audio/aif',
    'audio/alac',
    'audio/amr',
    'audio/ape',
    'audio/au', 'audio/basic',
    'audio/dss',
    'audio/flac',
    'audio/tta',
    'audio/voc',
    'audio/wma',
    'audio/x-m4a', 'audio/x-m4b', 'audio/x-m4p', 'audio/x-m4r',
    'audio/x-3ga',
    'audio/x-8svx',
    'audio/x-flv',
    'audio/x-qcp',
    // Formatos de vídeo (que contêm áudio)
    'video/mp4', 'video/x-m4v',
    'video/webm',
    'video/ogg',
    'video/quicktime', 'video/x-quicktime',
    'video/mp2t', 'video/mp2ts', 'video/mts',
    'video/mxf',
    'video/flv',
    // Formatos específicos
    'application/ogg'
  ];

  const isValidAudioFile = (file: File) => {
    const acceptedTypes = getAcceptedTypes().split(',');
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    return acceptedTypes.includes(fileExtension) || acceptedAudioMimeTypes.includes(file.type);
  };
  
  const getFileTypeIcon = () => {
    if (uploadType === 'audio') return FileAudio;
    if (uploadType === 'whatsapp') return WhatsAppIcon;
    return FileText;
  };
  
  const getAcceptedTypes = () => {
    if (uploadType === 'audio') {
      return '.mp3,.wav,.m4a,.mp4,.webm,.ogg,.opus,.aac,.ac3,.aiff,.aif,.alac,.amr,.ape,.au,.dss,.flac,.tta,.voc,.wma,.3ga,.8svx,.flv,.qcp,.m4b,.m4p,.m4r,.m4v,.mts,.mxf,.mov,.qt,.ts,.m2t,.m2ts';
    }
    if (uploadType === 'whatsapp') {
      return '.zip';
    }
    return '.txt';
  };
  const FileIcon = getFileTypeIcon();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
    setDragError(null);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    setDragError(null);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      const file = files[0];
      
      // Validate file type
      const acceptedTypes = getAcceptedTypes().split(',');
      const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
      
      let isValidFile = false;
      if (uploadType === 'audio') {
        isValidFile = isValidAudioFile(file);
      } else if (uploadType === 'whatsapp') {
        isValidFile = fileExtension === '.zip';
      } else {
        isValidFile = acceptedTypes.includes(fileExtension);
      }
      
      if (isValidFile) {
        // Create a synthetic event to pass to onFileSelect
        const syntheticEvent = {
          target: {
            files: [file]
          }
        } as unknown as React.ChangeEvent<HTMLInputElement>;
        
        onFileSelect(syntheticEvent);
        setDragError(null);
      } else {
        setDragError(`Tipo de arquivo não suportado. Tipos aceitos: ${acceptedTypes.join(', ')}`);
        setTimeout(() => setDragError(null), 3000);
      }
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card className="border-slate-200 bg-white shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center text-slate-900">
          <Upload className="w-5 h-5 mr-2 text-emerald-600" />
          Upload de Arquivo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* File Type Selection */}
        <div className="space-y-3">
          <label className="text-sm font-semibold text-slate-800">Tipo de arquivo</label>
          <div className="grid grid-cols-3 gap-3">
            <Button
              variant={uploadType === 'audio' ? 'default' : 'outline'}
              onClick={() => onUploadTypeChange('audio')}
              className={`h-20 py-3 flex flex-col items-center justify-center space-y border-2 transition-all ${
                uploadType === 'audio' 
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600' 
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300 hover:border-emerald-300'
              }`}
            >
              <FileAudio className="w-5 h-5" />
              <span className="text-sm font-semibold">Áudio</span>
              <span className="text-xs opacity-90">MP3, WAV, M4A, AAC, OGG, OPUS</span>
            </Button>
            <Button
              variant={uploadType === 'text' ? 'default' : 'outline'}
              onClick={() => onUploadTypeChange('text')}
              className={`h-20 py-3 flex flex-col items-center justify-center space-y border-2 transition-all ${
                uploadType === 'text' 
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600' 
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300 hover:border-emerald-300'
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="text-sm font-semibold">Texto</span>
              <span className="text-xs opacity-90">TXT ou Colar Texto</span>
            </Button>
            <Button
              variant={uploadType === 'whatsapp' ? 'default' : 'outline'}
              onClick={() => onUploadTypeChange('whatsapp')}
              className={`h-20 py-3 flex flex-col items-center justify-center space-y border-2 transition-all ${
                uploadType === 'whatsapp' 
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-600' 
                  : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300 hover:border-emerald-300'
              }`}
            >
              <WhatsAppIcon className="w-5 h-5" isSelected={uploadType === 'whatsapp'} />
              <span className="text-sm font-semibold">WhatsApp</span>
              <span className="text-xs opacity-90">ZIP Exportado</span>
            </Button>
          </div>
        </div>

        {/* Context Selection */}
        {activeContexts.length > 1 && (
          <div className="space-y-3">
            <label className="text-sm font-semibold text-slate-800">Contexto para análise</label>
            <Select value={selectedContext} onValueChange={onContextChange}>
              <SelectTrigger className="bg-white border-slate-300">
                <SelectValue placeholder="Selecione um contexto" />
              </SelectTrigger>
              <SelectContent>
                {activeContexts.map((context) => (
                  <SelectItem key={context.id} value={context.id}>
                    <div className="flex items-center justify-between w-full">
                      <span className="text-slate-900">{context.name}</span>
                      <Badge variant="secondary" className="ml-2 text-xs bg-emerald-100 text-emerald-700">
                        Ativo
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Campo obrigatório para nome da análise */}
        <div className="space-y-1">
          <label className="text-sm font-semibold text-slate-800">Nome da análise <span className="text-red-500">*</span></label>
          <input
            type="text"
            value={selectedAnalysisName}
            onChange={e => onAnalysisNameChange(e.target.value)}
            required
            className={`w-full border rounded px-3 py-2 focus:outline-none ${!selectedAnalysisName.trim() ? 'border-red-500 focus:border-red-500' : 'border-slate-300 focus:border-emerald-500'}`}
            placeholder="Digite o nome da análise"
            disabled={isUploading}
          />
        </div>

        {/* Seller Selection */}
        <div className="space-y-3">
          <label className="text-sm font-semibold text-slate-800">Vendedor responsável</label>
          <Select 
            value={selectedVendedor} 
            onValueChange={onVendedorChange}
            disabled={!sellers || sellers.length === 0}
          >
            <SelectTrigger className={`bg-white border-slate-300 ${(!sellers || sellers.length === 0) ? 'opacity-50 cursor-not-allowed' : ''}`}>
              <SelectValue placeholder={
                !sellers || sellers.length === 0 
                  ? "Nenhum vendedor cadastrado" 
                  : "Selecione o vendedor"
              } />
            </SelectTrigger>
            <SelectContent>
              {sellers && sellers.length > 0 ? (
                sellers.map((vendedor) => (
                  <SelectItem key={vendedor.id} value={vendedor.id}>
                    <span className="text-slate-900">{vendedor.name}</span>
                  </SelectItem>
                ))
              ) : (
                <div className="px-2 py-1 text-sm text-slate-500">
                  Nenhum vendedor disponível
                </div>
              )}
            </SelectContent>
          </Select>
          {(!sellers || sellers.length === 0) && (
            <p className="text-sm text-amber-600 flex items-center gap-2">
              <span className="w-4 h-4 bg-amber-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-amber-600 font-bold text-xs">!</span>
              </span>
              Cadastre pelo menos um vendedor para fazer análises
            </p>
          )}
        </div>

        {/* Speakers Detection - Only for audio uploads */}
        {uploadType === 'audio' && (
          <div className="space-y-3">
            <label className="text-sm font-semibold text-slate-800">Número de participantes</label>
            <div className="flex items-center justify-start gap-12">
              {/* Manual count selector */}
              <div className="flex items-center space-x-3">
                <Users className="w-4 h-4 text-slate-600" />
                <span className="text-sm text-slate-700">Participantes:</span>
                <div className="flex items-center space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => onSpeakersCountChange(Math.max(2, speakersCount - 1))}
                    disabled={speakersCount <= 2 || autoDetectSpeakers}
                    className="h-8 w-8 p-0"
                  >
                    <Minus className="w-4 h-4" />
                  </Button>
                  <span className="w-8 text-center font-medium text-slate-800">
                    {autoDetectSpeakers ? 'Auto' : speakersCount}
                  </span>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => onSpeakersCountChange(Math.min(6, speakersCount + 1))}
                    disabled={speakersCount >= 6 || autoDetectSpeakers}
                    className="h-8 w-8 p-0"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Auto-detect checkbox */}
              <div className="flex items-start space-x-2 mt-1">
                <Checkbox 
                  id="auto-detect"
                  checked={autoDetectSpeakers}
                  onCheckedChange={onAutoDetectSpeakersChange}
                  className="mt-1"
                />
                <label 
                  htmlFor="auto-detect" 
                  className="text-sm text-slate-700 cursor-pointer select-none mt-1 leading-none"
                >
                  Detectar automaticamente (não recomendado)
                </label>
              </div>
            </div>
          </div>
        )}

        {/* File Upload or Text Input */}
        {uploadType === 'text' ? (
          <div className="space-y-3">
            <label className="text-sm font-semibold text-slate-800">
              Conteúdo da conversa
            </label>
            <Textarea
              value={textContent}
              onChange={(e) => onTextContentChange(e.target.value)}
              placeholder="Cole aqui o conteúdo da conversa que deseja analisar..."
              className="min-h-[200px] resize-none border-slate-300 bg-white text-slate-900 placeholder:text-slate-500 focus:border-emerald-500 focus:ring-emerald-500"
            />
            <p className="text-xs text-slate-600">
              Ou faça upload de um arquivo de texto usando o botão abaixo
            </p>
            <div className="space-y-2">
              <div className="flex items-center justify-center w-full">
                <div
                  onClick={handleClick}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-lg cursor-pointer transition-all duration-200 ${
                    isDragOver 
                      ? 'border-emerald-400 bg-emerald-50 scale-105' 
                      : 'border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-slate-400'
                  }`}
                >
                  <div className="flex flex-col items-center justify-center">
                    <FileText className={`w-6 h-6 mb-2 ${isDragOver ? 'text-emerald-600' : 'text-slate-500'}`} />
                    <p className={`text-sm ${isDragOver ? 'text-emerald-700 font-semibold' : 'text-slate-600'}`}>
                      {isDragOver ? (
                        <span className="font-semibold">Solte o arquivo aqui</span>
                      ) : (
                        <span className="font-semibold">Clique para selecionar o arquivo</span>
                      )} ou arraste-o aqui
                    </p>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    accept=".txt"
                    onChange={onFileSelect}
                    disabled={isUploading}
                  />
                </div>
              </div>
              {dragError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-700">{dragError}</p>
                </div>
              )}
            </div>
          </div>
        ) : uploadType === 'whatsapp' ? (
          <div className="space-y-3">
            <label className="text-sm font-semibold text-slate-800">
              Arquivo ZIP do WhatsApp
            </label>
            
            {/* ZIP Upload Area */}
            <div className="space-y-2">
              <div className="flex items-center justify-center w-full">
                <div
                  onClick={handleClick}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer transition-all duration-200 ${
                    isDragOver 
                      ? 'border-emerald-400 bg-emerald-50 scale-105' 
                      : 'border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-slate-400'
                  }`}
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    {whatsAppZip?.isExtracting ? (
                      <>
                        <Loader2 className="w-8 h-8 mb-3 text-emerald-600 animate-spin" />
                        <p className="text-sm text-emerald-700 font-semibold">Extraindo...</p>
                        <p className="text-xs text-emerald-600">Analisando arquivos do ZIP</p>
                      </>
                    ) : (
                      <>
                        <WhatsAppIcon 
                          className="w-8 h-8 mb-3" 
                          isSelected={false}
                        />
                        <p className={`mb-2 text-sm ${isDragOver ? 'text-emerald-700 font-semibold' : 'text-slate-600'}`}>
                          {isDragOver ? (
                            <span className="font-semibold">Solte o arquivo ZIP aqui</span>
                          ) : (
                            <span className="font-semibold">Clique para selecionar o arquivo ZIP</span>
                          )} ou arraste-o aqui
                        </p>
                        <p className="text-xs text-slate-500">
                          Suporte apenas para arquivos .zip exportados do WhatsApp
                        </p>
                      </>
                    )}
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    accept=".zip"
                    onChange={onFileSelect}
                    disabled={isUploading || whatsAppZip?.isExtracting}
                  />
                </div>
              </div>
              {dragError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-700">{dragError}</p>
                </div>
              )}
            </div>

            {/* ZIP Analysis Results */}
            {whatsAppZip?.zipAnalysis?.isValid && (
              <div className="space-y-4">
                {/* Include Options */}
                {(whatsAppZip.zipAnalysis.hasAudioFiles || whatsAppZip.zipAnalysis.hasImageFiles) && (
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                    <h4 className="font-semibold text-slate-800 mb-3">Incluir na análise:</h4>
                    <div className="space-y-3">
                      {whatsAppZip.zipAnalysis.hasAudioFiles && (
                        <div className="flex items-start space-x-3">
                          <Checkbox
                            id="include-audios"
                            checked={whatsAppZip.includeAudios}
                            onCheckedChange={whatsAppZip.setIncludeAudios}
                            className="mt-0.5"
                          />
                          <label htmlFor="include-audios" className="text-sm text-slate-700 cursor-pointer leading-5">
                            Incluir áudios <span className="text-emerald-600 font-semibold">(+{whatsAppZip.zipAnalysis.audioCount} {whatsAppZip.zipAnalysis.audioCount === 1 ? 'crédito' : 'créditos'})</span>
                          </label>
                        </div>
                      )}
                      {whatsAppZip.zipAnalysis.hasImageFiles && (
                        <div className="flex items-start space-x-3">
                          <Checkbox
                            id="include-images"
                            checked={whatsAppZip.includeImages}
                            onCheckedChange={whatsAppZip.setIncludeImages}
                            className="mt-0.5"
                          />
                          <label htmlFor="include-images" className="text-sm text-slate-700 cursor-pointer leading-5">
                            Incluir imagens <span className="text-emerald-600 font-semibold">(+{whatsAppZip.zipAnalysis.imageCount} {whatsAppZip.zipAnalysis.imageCount === 1 ? 'crédito' : 'créditos'})</span>
                          </label>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            <label className="text-sm font-semibold text-slate-800">
              Arquivo de áudio
            </label>
            <div className="space-y-2">
              <div className="flex items-center justify-center w-full">
                <div
                  onClick={handleClick}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer transition-all duration-200 ${
                    isDragOver 
                      ? 'border-emerald-400 bg-emerald-50 scale-105' 
                      : 'border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-slate-400'
                  }`}
                >
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <FileIcon className={`w-8 h-8 mb-3 ${isDragOver ? 'text-emerald-600' : 'text-slate-500'}`} />
                    <p className={`mb-2 text-sm ${isDragOver ? 'text-emerald-700 font-semibold' : 'text-slate-600'}`}>
                      {isDragOver ? (
                        <span className="font-semibold">Solte o arquivo aqui</span>
                      ) : (
                        <span className="font-semibold">Clique para selecionar o arquivo</span>
                      )} ou arraste-o aqui
                    </p>
                     <div className="flex items-center gap-1 text-xs text-slate-500">
                       <span>Verifique os tipos suportados e os limites de tamanho de arquivo</span>
                       <TooltipProvider>
                         <Tooltip>
                           <TooltipTrigger asChild>
                             <Info className="w-3 h-3 text-slate-400 hover:text-slate-600 cursor-help" />
                           </TooltipTrigger>
                           <TooltipContent className="max-w-xs p-2">
                             <div className="space-y-1.5">
                               <p className="font-semibold text-xs text-slate-900">Formatos suportados:</p>
                               <div className="text-xs space-y-0.5 text-slate-700">
                                 <p className="text-xs"><span className="font-semibold">Principais:</span> MP3, WAV, M4A, FLAC, AAC, OGG, OPUS, AC3, AIFF, ALAC, AMR, APE, AU, DSS, TTA, VOC, WMA</p>
                                 <p className="text-xs"><span className="font-semibold">Vídeo:</span> MP4, WebM, OGG, MOV, MTS, MXF, FLV</p>
                                 <p className="text-xs"><span className="font-semibold">Outros:</span> 3GA, 8SVX, QCP, M4B, M4P, M4R, M4V, TS, M2T, M2TS</p>
                               </div>
                               <div className="pt-1 border-t border-slate-200">
                                 <p className="font-semibold text-xs text-slate-900">Limite: <span className="text-emerald-600">200 MB</span></p>
                               </div>
                             </div>
                           </TooltipContent>
                         </Tooltip>
                       </TooltipProvider>
                     </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="hidden"
                    accept={getAcceptedTypes()}
                    onChange={onFileSelect}
                    disabled={isUploading}
                  />
                </div>
              </div>
              {dragError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-700">{dragError}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Selected File Info */}
        {selectedFile && (
          (uploadType === 'audio' && isValidAudioFile(selectedFile)) || 
          (uploadType === 'text' && selectedFile.type === 'text/plain') ||
          (uploadType === 'whatsapp' && selectedFile.name.toLowerCase().endsWith('.zip'))
        ) && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
            <div className="flex items-center space-x-3">
              <FileIcon className="w-5 h-5 text-emerald-600" />
              <div className="flex-1">
                <p className="font-medium text-emerald-800">{selectedFile.name}</p>
                <p className="text-sm text-emerald-600">
                  {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                {uploadType === 'audio' ? 'Áudio' : uploadType === 'whatsapp' ? 'WhatsApp' : 'Texto'}
              </Badge>
            </div>
          </div>
        )}

        {/* Warning for no active contexts */}
        {!hasActiveContexts && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="w-5 h-5 bg-amber-400 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white font-bold text-xs">!</span>
              </div>
              <div>
                <p className="font-medium text-amber-800">Nenhum contexto ativo</p>
                <p className="text-amber-700 text-sm">Configure pelo menos um contexto ativo antes de fazer análises.</p>
              </div>
            </div>
          </div>
        )}

        {/* Upload Button */}
        <Button
          onClick={onUpload}
          disabled={
            !hasActiveContexts || 
            isUploading || 
            (activeContexts.length > 1 && !selectedContext) ||
            (uploadType === 'audio' && !selectedFile) ||
            (uploadType === 'text' && !textContent.trim() && !selectedFile) ||
            (uploadType === 'text' && selectedFile && selectedFile.type !== 'text/plain' && !textContent.trim()) ||
            (uploadType === 'audio' && selectedFile && !isValidAudioFile(selectedFile)) ||
            (uploadType === 'whatsapp' && (!selectedFile || !whatsAppZip?.zipAnalysis?.isValid)) ||
            (!sellers || sellers.length === 0) ||
            (sellers && sellers.length > 0 && !selectedVendedor) ||
            !selectedAnalysisName.trim() ||
            whatsAppZip?.isExtracting
          }
          className="w-full h-12 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-base disabled:bg-slate-400 disabled:cursor-not-allowed transition-colors"
        >
          {isUploading || whatsAppZip?.isExtracting ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              {whatsAppZip?.isExtracting ? 'Extraindo...' : 'Processando...'}
            </>
          ) : (
            <>
              <Upload className="w-4 h-4 mr-2" />
              Analisar {uploadType === 'audio' ? 'Áudio' : uploadType === 'whatsapp' ? 'Conversa' : 'Texto'}
            </>
          )}
        </Button>
        
        {/* Warning when no sellers */}
        {(!sellers || sellers.length === 0) && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-start space-x-3">
              <div className="w-5 h-5 bg-amber-400 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                <span className="text-white font-bold text-xs">!</span>
              </div>
              <div>
                <p className="font-medium text-amber-800">Nenhum vendedor cadastrado</p>
                <p className="text-amber-700 text-sm">
                  Para fazer análises, você precisa cadastrar pelo menos um vendedor na página de Vendedores.
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
