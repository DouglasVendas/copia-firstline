
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react";

interface Vendedor {
  id: string;
  name: string;
}

interface Context {
  id: string;
  name: string;
  description: string;
  vendedores: Vendedor[];
  vendedor_ativo: string | null;
}

interface ContextStatusCardProps {
  contextsLoading: boolean;
  hasActiveContexts: boolean;
  activeContexts: Context[];
}

export function ContextStatusCard({ contextsLoading, hasActiveContexts, activeContexts }: ContextStatusCardProps) {
  if (contextsLoading) {
    return (
      <Card className="border-slate-200 bg-slate-50">
        <CardContent className="p-6">
          <div className="flex items-center space-x-3">
            <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
            <span className="text-lg font-medium text-slate-800">Carregando contextos...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!hasActiveContexts) {
    return (
      <Card className="border-amber-300 bg-amber-50">
        <CardContent className="p-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-6 h-6 text-amber-700 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-lg text-amber-900 mb-2">Nenhum contexto ativo</h3>
              <p className="text-amber-800 text-base mb-4 leading-relaxed">
                Configure um contexto de vendas antes de fazer upload de suas calls para obter análises personalizadas.
              </p>
              <Button
                variant="outline"
                size="lg"
                className="border-amber-400 text-amber-800 hover:bg-amber-100 font-semibold text-base px-6 py-3"
                onClick={() => window.location.href = '/contexto'}
              >
                Configurar Contexto
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-emerald-300 bg-emerald-50">
      <CardContent className="p-6">
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-6 h-6 text-emerald-700" />
          <div>
            <span className="font-bold text-lg text-emerald-900">
              {activeContexts.length} contexto{activeContexts.length > 1 ? 's' : ''} ativo{activeContexts.length > 1 ? 's' : ''}
            </span>
            <p className="text-emerald-800 text-base mt-1 leading-relaxed">
              {activeContexts.length === 1 
                ? `Usando automaticamente: ${activeContexts[0].name}`
                : 'Selecione o contexto desejado abaixo para análise personalizada'
              }
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
