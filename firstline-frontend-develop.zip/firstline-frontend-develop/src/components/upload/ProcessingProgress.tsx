import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Clock, Zap, Users } from "lucide-react";
import React, { useEffect, useRef, useState } from "react";

interface ProcessingProgressProps {
  isUploading: boolean;
  uploadProgress: number;
  estimatedTime: number | null;
  isCompressing: boolean;
  compressionProgress: number;
  queueLength: number;
  audioDuration?: number; // duração do áudio em segundos
  textLength?: number;    // número de caracteres do texto
}

export function ProcessingProgress({
  isUploading,
  uploadProgress,
  estimatedTime,
  isCompressing,
  compressionProgress,
  queueLength,
  audioDuration,
  textLength
}: ProcessingProgressProps) {
  const formatTime = (seconds: number): string => {
    if (seconds < 60) return `${seconds} segundos`;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.round(seconds % 60);
    if (remainingSeconds === 0) return `${minutes} ${minutes === 1 ? 'minuto' : 'minutos'}`;
    return `${minutes} ${minutes === 1 ? 'minuto' : 'minutos'} e ${remainingSeconds} segundos`;
  };

  // Simulação de progresso
  const [simulatedProgress, setSimulatedProgress] = useState(0);
  const [showFinalizing, setShowFinalizing] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  // Fixar valores de início da simulação
  const simStartRef = useRef<number | null>(null);
  const simEndRef = useRef<number>(99);
  const simDurationRef = useRef<number>(0);

  // Calcula o tempo estimado de simulação (fixo no início)
  useEffect(() => {
    if (isUploading && uploadProgress < 99 && intervalRef.current == null) {
      // Fixar valores no início da simulação
      simStartRef.current = uploadProgress;
      simEndRef.current = 99;
      // Usar o tempo estimado se disponível, senão, fazer uma estimativa
      const simulationDuration = estimatedTime 
        ? Math.max(estimatedTime, 1) // Garante que não seja 0
        : (() => {
            const audioEstimate = audioDuration ? audioDuration * 0.2 : 0;
            const textEstimate = textLength ? textLength * 0.005 : 0;
            return Math.max(audioEstimate, textEstimate, 5); // Pelo menos 5s
        })();

      // Proporcional ao progresso restante
      const percentToGo = Math.max(0, (simEndRef.current - uploadProgress) / simEndRef.current);
      simDurationRef.current = simulationDuration * percentToGo;

      setShowFinalizing(false);
      setSimulatedProgress(uploadProgress);
      const totalSteps = Math.max((simEndRef.current - uploadProgress), 1);
      const step = totalSteps > 50 ? 1 : 0.5;
      const stepsCount = Math.ceil((simEndRef.current - uploadProgress) / step);
      const intervalMs = stepsCount > 0 ? (simDurationRef.current * 1000) / stepsCount : simDurationRef.current * 1000;
      intervalRef.current = setInterval(() => {
        setSimulatedProgress(prev => {
          if (prev + step < simEndRef.current!) {
            return prev + step;
          } else {
            clearInterval(intervalRef.current!);
            intervalRef.current = null;
            setShowFinalizing(true);
            return simEndRef.current!;
          }
        });
      }, intervalMs);
    }
    // Limpeza e reset se upload parar
    if (!isUploading || uploadProgress >= 99) {
      setSimulatedProgress(uploadProgress);
      setShowFinalizing(false);
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      simStartRef.current = null;
    }
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isUploading, uploadProgress, audioDuration, textLength, estimatedTime]);

  // O valor mostrado na barra
  const progressValue = isUploading ? Math.max(simulatedProgress, uploadProgress) : (isCompressing ? compressionProgress : 0);

  // Só depois dos hooks, faça o retorno condicional:
  if (!isUploading && !isCompressing && queueLength === 0) {
    return null;
  }

  return (
    <Card className="border-slate-200 bg-white shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center text-slate-900 text-lg">
          <Zap className="w-5 h-5 mr-2 text-emerald-600" />
          Status do Processamento
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Compression Progress */}
        {isCompressing && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-700">Comprimindo áudio</span>
              <span className="text-sm text-slate-600">{compressionProgress}%</span>
            </div>
            <Progress value={compressionProgress} className="h-2" />
          </div>
        )}

        {/* Upload Progress */}
        {isUploading && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-slate-700">Processando</span>
              <span className="text-sm text-slate-600">{progressValue}%</span>
            </div>
            <Progress value={progressValue} className="h-2" />
            {showFinalizing && (
              <div className="mt-2 text-xs text-slate-600">Fazendo ajustes finais, aguarde um momento...</div>
            )}
          </div>
        )}

        {/* Queue Status */}
        {queueLength > 0 && (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-medium text-slate-700">Na fila</span>
            </div>
            <Badge variant="outline" className="text-slate-600">
              {queueLength} {queueLength === 1 ? 'arquivo' : 'arquivos'}
            </Badge>
          </div>
        )}

        {/* Estimated Time */}
        {estimatedTime && (
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-slate-500" />
              <span className="text-sm font-medium text-slate-700">Tempo estimado</span>
            </div>
            <span className="text-sm text-slate-600">{formatTime(estimatedTime)}</span>
          </div>
        )}

        {/* Performance Tips */}
        {estimatedTime && estimatedTime > 120 && (
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              <strong>Dica:</strong> Arquivos grandes podem levar mais tempo. 
              O sistema otimiza automaticamente o processamento para melhor performance.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}