
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function InstructionsCard() {
  return (
    <Card className="border-slate-200" style={{ backgroundColor: '#F9FAFB' }}>
      <CardHeader>
        <CardTitle className="text-lg text-slate-900">Como usar</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 text-sm">
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-emerald-600 font-semibold text-xs">1</span>
            </div>
            <div>
              <p className="font-medium text-slate-900">Escolha o tipo de arquivo</p>
              <p className="text-slate-700">Selecione o formato do arquivo a ser processado: áudio ou documento de texto, por exemplo</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-emerald-600 font-semibold text-xs">2</span>
            </div>
            <div>
              <p className="font-medium text-slate-900">Selecione o contexto</p>
              <p className="text-slate-700">Caso existam múltiplos contextos, selecione o mais apropriado para a análise</p>
            </div>
          </div>
          
          <div className="flex items-start space-x-3">
            <div className="w-6 h-6 bg-emerald-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <span className="text-emerald-600 font-semibold text-xs">3</span>
            </div>
            <div>
              <p className="font-medium text-slate-900">Faça o upload</p>
              <p className="text-slate-700">Importe o arquivo através do campo de upload ou arraste-o para a área designada, em seguida, clique em "Analisar"</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
