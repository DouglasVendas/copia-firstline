import React, { useCallback, useState } from 'react';
import { Upload, File, X, FileText, FileType, FileImage } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FileUploadAreaProps {
  onFileSelect: (file: File) => void;
  acceptedTypes: string;
  maxFileSize: number;
  disabled?: boolean;
}

export function FileUploadArea({ onFileSelect, acceptedTypes, maxFileSize, disabled = false }: FileUploadAreaProps) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!disabled) {
      setIsDragOver(true);
    }
  }, [disabled]);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    if (disabled) return;

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      onFileSelect(files[0]);
    }
  }, [onFileSelect, disabled]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      onFileSelect(files[0]);
    }
    // Reset input value to allow selecting the same file again
    e.target.value = '';
  }, [onFileSelect]);

  const formatMaxSize = (bytes: number) => {
    return `${bytes / (1024 * 1024)}MB`;
  };

  return (
    <div
      className={`
        relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200
        ${isDragOver && !disabled 
          ? 'border-blue-400 bg-blue-50' 
          : 'border-gray-300 hover:border-gray-400'
        }
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
      `}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <input
        type="file"
        accept={acceptedTypes}
        onChange={handleFileInput}
        disabled={disabled}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
      />
      
      <div className="space-y-4">
        <div className="mx-auto w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
          <Upload className="w-6 h-6 text-gray-600" />
        </div>
        
        <div>
          <p className="text-lg font-medium text-gray-700">
            Arraste um arquivo aqui ou clique para selecionar
          </p>
          <p className="text-sm text-gray-500 mt-2">
            Tipos aceitos: PDF, Word, TXT, RTF, ODT (máx. {formatMaxSize(maxFileSize)})
          </p>
        </div>
        
        <Button
          type="button"
          variant="outline"
          disabled={disabled}
          className="mt-4"
          onClick={(e) => e.stopPropagation()}
        >
          <File className="w-4 h-4 mr-2" />
          Selecionar Arquivo
        </Button>
      </div>
    </div>
  );
}

interface FilePreviewProps {
  fileName: string;
  fileSize: string;
  fileType: string;
  onRemove: () => void;
  isUploading?: boolean;
  isExtracting?: boolean;
  uploadProgress?: number;
  extractionInfo?: {
    originalSize: string;
    extractedSize: string;
    wasExtracted: boolean;
  };
}

export function FilePreview({ 
  fileName, 
  fileSize, 
  fileType, 
  onRemove, 
  isUploading = false, 
  isExtracting = false,
  uploadProgress = 0,
  extractionInfo 
}: FilePreviewProps) {
  const getFileIcon = () => {
    if (fileType.includes('pdf')) return <FileType className="w-6 h-6 text-red-500" />;
    if (fileType.includes('word') || fileType.includes('document')) return <FileText className="w-6 h-6 text-blue-500" />;
    if (fileType.includes('text')) return <FileText className="w-6 h-6 text-gray-500" />;
    return <File className="w-6 h-6 text-gray-500" />;
  };

  return (
    <div className="bg-gray-50 border border-gray-200 rounded-lg p-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 ml-1">
          <div className="flex items-center justify-center">{getFileIcon()}</div>
          <div>
            <p className="font-medium text-gray-900">{fileName}</p>
            <p className="text-sm text-gray-500">{fileSize}</p>
          </div>
        </div>
        
        {!isUploading && !isExtracting && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onRemove}
            className="text-gray-400 hover:text-red-500"
          >
            <X className="w-4 h-4" />
          </Button>
        )}
      </div>
      
      {/* Progresso de extração (silencioso) */}
      {isExtracting && (
        <div className="mt-3">
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div className="bg-blue-600 h-3 rounded-full animate-pulse" style={{ width: '50%' }}></div>
          </div>
          <p className="text-sm text-gray-600 mt-2">Processando arquivo...</p>
        </div>
      )}
      
      {/* Progresso de upload */}
      {isUploading && (
        <div className="mt-3">
          <div className="w-full bg-gray-200 rounded-full h-3">
            <div 
              className="bg-blue-600 h-3 rounded-full transition-all duration-1000 ease-out" 
              style={{ width: `${uploadProgress}%` }}
            ></div>
          </div>
          <div className="flex justify-between items-center mt-2">
            <p className="text-sm text-gray-600">
              {uploadProgress >= 99 ? 'Fazendo ajustes finais...' : 'Processando arquivo...'}
            </p>
            <span className="text-sm font-medium text-blue-600">
              {Math.round(uploadProgress)}%
            </span>
          </div>
        </div>
      )}
    </div>
  );
}