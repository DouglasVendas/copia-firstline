
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Trash2, CheckCircle, Eye, EyeOff, AlertCircle, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { Context, Vendedor } from '@/types/context';

interface ContextCardProps {
  context: Context;
  onEdit: (context: Context) => void;
  onDelete: (id: string) => void;
  onSetActive: (id: string) => void;
  onVendedoresUpdate: (contextId: string, vendedores: Vendedor[]) => void;
  onVendedorAtivoUpdate: (contextId: string, vendedorAtivoId: string | null) => void;
}

// Função para renderizar texto como markdown simples
const renderMarkdown = (text: string) => {
  return text.split('\n').map((line, idx) => {
    const trimmed = line.trim();
    
    // Linha horizontal (---)
    if (trimmed === '---' || trimmed === '***' || trimmed === '___') {
      return <hr key={idx} className="my-3 border-t-2 border-slate-300" />;
    }
    
    // H1 (# Título) - Subtítulo menor que nossos títulos principais
    if (trimmed.match(/^#\s+/)) {
      return (
        <div key={idx} className="font-bold text-base text-slate-800 mt-4 mb-2">
          {trimmed.replace(/^#\s+/, '')}
        </div>
      );
    }
    
    // H2 (## Título) - Ainda menor
    if (trimmed.match(/^##\s+/)) {
      return (
        <div key={idx} className="font-semibold text-sm text-slate-700 mt-3 mb-1">
          {trimmed.replace(/^##\s+/, '')}
        </div>
      );
    }
    
    // H3 (### Título) - Menor ainda
    if (trimmed.match(/^###\s+/)) {
      return (
        <div key={idx} className="font-medium text-sm text-slate-600 mt-2 mb-1">
          {trimmed.replace(/^###\s+/, '')}
        </div>
      );
    }
    
    // H4 (#### Título)
    if (trimmed.match(/^####\s+/)) {
      return (
        <div key={idx} className="font-medium text-sm text-slate-600 mt-2 mb-1">
          {trimmed.replace(/^####\s+/, '')}
        </div>
      );
    }
    
    // H5 (##### Título)
    if (trimmed.match(/^#####\s+/)) {
      return (
        <div key={idx} className="font-normal text-sm text-slate-600 mt-1 mb-1">
          {trimmed.replace(/^#####\s+/, '')}
        </div>
      );
    }
    
    // H6 (###### Título)
    if (trimmed.match(/^######\s+/)) {
      return (
        <div key={idx} className="font-normal text-xs text-slate-500 mt-1 mb-1">
          {trimmed.replace(/^######\s+/, '')}
        </div>
      );
    }
    
    // Lista com marcadores
    if (trimmed.match(/^[-*•]\s/)) {
      return (
        <div key={idx} className="flex items-start gap-2 ml-4 mb-1">
          <span className="text-blue-500 mt-1">•</span>
          <span className="flex-1">{trimmed.replace(/^[-*•]\s/, '')}</span>
        </div>
      );
    }
    
    // Títulos em negrito (ex: **TÍTULO:**) - Menor que nossos títulos
    if (trimmed.match(/^\*\*.*\*\*:?$/)) {
      return (
        <div key={idx} className="font-semibold text-sm text-slate-700 mt-3 mb-1">
          {trimmed.replace(/\*\*/g, '')}
        </div>
      );
    }
    
    // Texto com negrito inline (ex: **palavra** no meio do texto)
    if (trimmed.includes('**')) {
      const parts = line.split(/(\*\*[^*]+\*\*)/g);
      return (
        <div key={idx} className="mb-1">
          {parts.map((part, partIdx) => {
            if (part.match(/^\*\*.*\*\*$/)) {
              return <strong key={partIdx} className="font-semibold">{part.replace(/\*\*/g, '')}</strong>;
            }
            return <span key={partIdx}>{part}</span>;
          })}
        </div>
      );
    }
    
    // Linha vazia
    if (!trimmed) {
      return <div key={idx} className="h-2" />;
    }
    
    // Texto normal
    return <div key={idx} className="mb-1">{line}</div>;
  });
};

// Função auxiliar para renderizar campos estruturados
const renderContextFields = (context: Context) => {
  return (
    <div className="space-y-6">
      {/* Produto/Serviço */}
      {context.productInfo && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Produto/Serviço
          </h3>
          <div className="text-sm text-slate-700 leading-relaxed">
            {renderMarkdown(context.productInfo)}
          </div>
        </div>
      )}

      {/* Público-Alvo */}
      {context.targetAudience && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Público-Alvo
          </h3>
          <div className="text-sm text-slate-700 leading-relaxed">
            {renderMarkdown(context.targetAudience)}
          </div>
        </div>
      )}

      {/* Objeções Comuns */}
      {context.commonObjections && context.commonObjections.length > 0 && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Objeções Comuns
          </h3>
          <div className="space-y-3">
            {context.commonObjections.map((obj, idx) => (
              <div key={idx} className="bg-slate-50 rounded-md p-3 border border-slate-200">
                <div className="flex items-start gap-2 mb-2">
                  <AlertCircle className="w-3 h-3 text-red-500 mt-1.5 flex-shrink-0" />
                  <div className="flex-1">
                    <span className="font-semibold text-sm text-red-600">Objeção:</span>
                    <p className="text-sm text-slate-700 mt-0.5">{obj.objection}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-3 h-3 text-green-500 mt-1.5 flex-shrink-0" />
                  <div className="flex-1">
                    <span className="font-semibold text-sm text-green-600">Resposta:</span>
                    <p className="text-sm text-slate-700 mt-0.5">{obj.response}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Estrutura de Preços */}
      {context.pricingStructure && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Estrutura de Preços
          </h3>
          <div className="text-sm text-slate-700 leading-relaxed">
            {renderMarkdown(context.pricingStructure)}
          </div>
        </div>
      )}

      {/* Playbook */}
      {context.playbook && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Playbook de Vendas
          </h3>
          <div className="text-sm text-slate-700 leading-relaxed">
            {renderMarkdown(context.playbook)}
          </div>
        </div>
      )}

      {/* Gatilhos Mentais */}
      {context.mentalTriggers && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Gatilhos Mentais
          </h3>
          <div className="text-sm text-slate-700 leading-relaxed">
            {renderMarkdown(context.mentalTriggers)}
          </div>
        </div>
      )}

      {/* Concorrentes */}
      {context.competitors && context.competitors.length > 0 && (
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-2 pb-2 border-b-2 border-blue-400">
            Concorrentes
          </h3>
          <div className="flex flex-wrap gap-2">
            {context.competitors.map((competitor, idx) => (
              <span 
                key={idx}
                className="px-3 py-1.5 bg-blue-50 text-blue-800 rounded-full text-sm font-medium border border-blue-300"
              >
                {competitor}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export function ContextCard({ context, onEdit, onDelete, onSetActive, onVendedoresUpdate, onVendedorAtivoUpdate }: ContextCardProps) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <Card className="bg-white border-2 border-slate-200 shadow-md hover:shadow-lg transition-all duration-200">
      <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-3">
            <CardTitle className="text-xl font-bold text-slate-900">{context.name}</CardTitle>
            {context.is_active && (
              <div className="flex items-center space-x-2 bg-green-100 text-green-800 px-3 py-1.5 rounded-full text-sm font-semibold">
                <CheckCircle className="w-4 h-4" />
                <span>Ativo</span>
              </div>
            )}
          </div>
          {context.description && (
            <p className="text-sm text-slate-600 leading-relaxed max-w-2xl">{context.description}</p>
          )}
        </div>
        <div className="flex space-x-2 flex-shrink-0">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => setShowDetails(!showDetails)}
            className="border-blue-300 text-blue-700 hover:bg-blue-50 font-semibold text-sm px-3 py-2"
            title={showDetails ? "Ocultar detalhes" : "Visualizar detalhes"}
          >
            {showDetails ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </Button>
          {!context.is_active && (
            <Button 
              size="sm" 
              onClick={() => onSetActive(context.id)}
              className="bg-green-500 text-white hover:bg-green-600 font-semibold text-sm px-4 py-2"
            >
              Ativar
            </Button>
          )}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onEdit(context)}
            className="border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-sm px-3 py-2"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onDelete(context.id)}
            className="border-red-500 text-red-700 hover:bg-red-500 hover:text-white font-semibold text-sm px-3 py-2"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      {showDetails && (
        <CardContent>
          <div className="bg-slate-50 p-6 rounded-lg border-2 border-slate-200">
            {renderContextFields(context)}
          </div>
          <p className="text-sm text-slate-600 mt-4 font-medium">
            Criado em {new Date(context.created_at).toLocaleDateString('pt-BR')}
          </p>
        </CardContent>
      )}
    </Card>
  );
}
