
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, User, Star } from "lucide-react";

interface SellerManagementProps {
  vendedores: string[];
  vendedorAtivo: string | null;
  onVendedoresChange: (vendedores: string[]) => void;
  onVendedorAtivoChange: (vendedor: string | null) => void;
}

export function SellerManagement({
  vendedores,
  vendedorAtivo,
  onVendedoresChange,
  onVendedorAtivoChange
}: SellerManagementProps) {
  const [newSeller, setNewSeller] = useState('');

  const handleAddSeller = () => {
    if (!newSeller.trim()) return;
    
    if (vendedores.includes(newSeller.trim())) return;
    
    const updatedVendedores = [...vendedores, newSeller.trim()];
    onVendedoresChange(updatedVendedores);
    setNewSeller('');
  };

  const handleRemoveSeller = (seller: string) => {
    const updatedVendedores = vendedores.filter(v => v !== seller);
    onVendedoresChange(updatedVendedores);
    
    if (vendedorAtivo === seller) {
      onVendedorAtivoChange(null);
    }
  };

  const handleSetActiveSeller = (seller: string) => {
    onVendedorAtivoChange(seller);
  };

  const handleSelectChange = (value: string) => {
    if (value === "none") {
      onVendedorAtivoChange(null);
    } else {
      onVendedorAtivoChange(value);
    }
  };

  return (
    <Card className="bg-white border border-[#E5E7EB] shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-[#111827]">
          <User className="w-5 h-5" />
          <span>Gestão de Vendedores</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Adicionar novo vendedor */}
        <div className="space-y-3">
          <Label className="text-[#111827] font-medium">Adicionar Vendedor</Label>
          <div className="flex space-x-2">
            <Input
              value={newSeller}
              onChange={(e) => setNewSeller(e.target.value)}
              placeholder="Nome do vendedor"
              className="flex-1 bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827]"
              onKeyPress={(e) => e.key === 'Enter' && handleAddSeller()}
            />
            <Button 
              onClick={handleAddSeller}
              disabled={!newSeller.trim()}
              className="bg-[#34D399] hover:bg-[#059669] text-white"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Lista de vendedores */}
        {vendedores.length > 0 && (
          <div className="space-y-3">
            <Label className="text-[#111827] font-medium">Vendedores Cadastrados</Label>
            <div className="space-y-2">
              {vendedores.map((vendedor) => (
                <div 
                  key={vendedor}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border"
                >
                  <div className="flex items-center space-x-3">
                    <User className="w-4 h-4 text-gray-500" />
                    <span className="font-medium text-[#111827]">{vendedor}</span>
                    {vendedorAtivo === vendedor && (
                      <Badge className="bg-green-100 text-green-800">
                        <Star className="w-3 h-3 mr-1" />
                        Ativo
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center space-x-2">
                    {vendedorAtivo !== vendedor && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSetActiveSeller(vendedor)}
                        className="border-green-200 text-green-600 hover:bg-green-50"
                      >
                        Ativar
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRemoveSeller(vendedor)}
                      className="border-red-200 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Selecionar vendedor ativo */}
        {vendedores.length > 0 && (
          <div className="space-y-2">
            <Label className="text-[#111827] font-medium">Vendedor Ativo Padrão</Label>
            <Select 
              value={vendedorAtivo || "none"} 
              onValueChange={handleSelectChange}
            >
              <SelectTrigger className="bg-white border-[#E5E7EB] focus:border-[#3B82F6]">
                <SelectValue placeholder="Selecione o vendedor padrão" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Nenhum vendedor padrão</SelectItem>
                {vendedores.map((vendedor) => (
                  <SelectItem key={vendedor} value={vendedor}>
                    {vendedor}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
