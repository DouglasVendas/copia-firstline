
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2 } from "lucide-react";

interface CompetitorsListProps {
  competitors: string[];
  onAdd: () => void;
  onRemove: (index: number) => void;
  onUpdate: (index: number, value: string) => void;
}

export function CompetitorsList({ competitors, onAdd, onRemove, onUpdate }: CompetitorsListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <Label className="text-[#111827] font-medium">Lista de Concorrentes</Label>
        <Button
          type="button"
          onClick={onAdd}
          variant="outline"
          size="sm"
          className="border-[#E5E7EB] text-[#4B5563] hover:bg-gray-50"
        >
          <Plus className="w-4 h-4 mr-1" />
          Adicionar
        </Button>
      </div>
      <div className="space-y-2">
        {competitors.map((competitor, index) => (
          <div key={index} className="flex items-center space-x-2">
            <Input
              value={competitor}
              onChange={(e) => onUpdate(index, e.target.value)}
              placeholder="Nome do concorrente"
              className="bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827]"
            />
            {competitors.length > 1 && (
              <Button
                type="button"
                onClick={() => onRemove(index)}
                variant="outline"
                size="sm"
                className="border-red-200 text-red-600 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
