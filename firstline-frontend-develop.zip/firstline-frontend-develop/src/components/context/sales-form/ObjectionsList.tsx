
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";

interface ObjectionResponse {
  objection: string;
  response: string;
}

interface ObjectionsListProps {
  objections: ObjectionResponse[];
  onAdd: () => void;
  onRemove: (index: number) => void;
  onUpdate: (index: number, field: 'objection' | 'response', value: string) => void;
}

export function ObjectionsList({ objections, onAdd, onRemove, onUpdate }: ObjectionsListProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <Label className="text-[#111827] font-medium">Objeções Comuns</Label>
        <Button
          type="button"
          onClick={onAdd}
          variant="outline"
          size="sm"
          className="border-[#E5E7EB] text-[#4B5563] hover:bg-gray-50"
        >
          <Plus className="w-4 h-4 mr-1" />
          Adicionar
        </Button>
      </div>
      <div className="space-y-3">
        {objections.map((item, index) => (
          <div key={index} className="p-4 border border-[#E5E7EB] rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-[#111827]">Objeção {index + 1}</span>
              {objections.length > 1 && (
                <Button
                  type="button"
                  onClick={() => onRemove(index)}
                  variant="outline"
                  size="sm"
                  className="border-red-200 text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              )}
            </div>
            <Input
              value={item.objection}
              onChange={(e) => onUpdate(index, 'objection', e.target.value)}
              placeholder="Ex: É muito caro"
              className="bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827]"
            />
            <Textarea
              value={item.response}
              onChange={(e) => onUpdate(index, 'response', e.target.value)}
              placeholder="Resposta recomendada para esta objeção..."
              className="min-h-[80px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none"
            />
          </div>
        ))}
      </div>
    </div>
  );
}
