
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SellerManagement } from "./SellerManagement";

interface Vendedor {
  id: string;
  name: string;
}

interface Context {
  id: string;
  name: string;
  description: string;
  prompt: string;
  is_active: boolean;
  created_at: string;
  vendedores: Vendedor[];
  vendedor_ativo: string | null;
}

interface ContextFormProps {
  context?: Context;
  isEditing: boolean;
  onSave: (context: Partial<Context>) => void;
  onCancel: () => void;
}

export function ContextForm({ context, isEditing, onSave, onCancel }: ContextFormProps) {
  const [formData, setFormData] = useState({
    name: context?.name || '',
    description: context?.description || '',
    prompt: context?.prompt || '',
    vendedores: context?.vendedores || [],
    vendedor_ativo: context?.vendedor_ativo || null,
  });

  const handleSubmit = () => {
    onSave(formData);
  };

  const handleVendedoresChange = async (vendedores: Vendedor[]) => {
    setFormData(prev => ({ ...prev, vendedores }));
  };

  const handleVendedorAtivoChange = async (vendedorAtivo: string | null) => {
    setFormData(prev => ({ ...prev, vendedor_ativo: vendedorAtivo }));
  };

  return (
    <Card className="bg-white border border-[#E5E7EB] shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl text-[#111827]">
          {isEditing ? 'Editar Contexto' : 'Novo Contexto Simples'}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-1">
            <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
            {/* <TabsTrigger value="sellers">Vendedores</TabsTrigger> */}
          </TabsList>

          <TabsContent value="basic" className="space-y-6 mt-6">
            <div>
              <Label htmlFor="name" className="text-[#111827] font-medium">Nome do Contexto</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ex: Suporte Técnico"
                className="mt-2 bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827]"
              />
            </div>

            <div>
              <Label htmlFor="description" className="text-[#111827] font-medium">Descrição (opcional)</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Breve descrição do contexto"
                className="mt-2 bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827]"
              />
            </div>

            <div>
              <Label htmlFor="prompt" className="text-[#111827] font-medium">Prompt do Contexto</Label>
              <Textarea
                id="prompt"
                value={formData.prompt}
                onChange={(e) => setFormData(prev => ({ ...prev, prompt: e.target.value }))}
                placeholder="Descreva o contexto específico para análise das chamadas..."
                className="mt-2 min-h-[120px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none"
              />
            </div>
          </TabsContent>

          {/*
          <TabsContent value="sellers" className="space-y-6 mt-6">
            <SellerManagement
              vendedores={formData.vendedores}
              vendedorAtivo={formData.vendedor_ativo}
              onVendedoresChange={handleVendedoresChange}
              onVendedorAtivoChange={handleVendedorAtivoChange}
            />
          </TabsContent>
          */}
        </Tabs>

        <div className="flex justify-end space-x-3 mt-6 pt-4 border-t border-[#E5E7EB]">
          <Button 
            variant="outline" 
            onClick={onCancel}
            className="border-[#E5E7EB] text-[#4B5563] hover:bg-gray-50"
          >
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit}
            className="bg-[#34D399] hover:bg-[#059669] text-white font-medium"
          >
            {isEditing ? 'Salvar Alterações' : 'Criar Contexto'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
