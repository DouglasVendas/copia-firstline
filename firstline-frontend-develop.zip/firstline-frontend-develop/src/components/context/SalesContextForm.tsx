
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, Upload, Trash2 } from "lucide-react";
import { ObjectionsList } from "./sales-form/ObjectionsList";
import { CompetitorsList } from "./sales-form/CompetitorsList";
import { FileUploadArea, FilePreview } from "./FileUploadArea";
import { useSalesContextForm } from "@/hooks/useSalesContextForm";
import { useFileContextUpload } from "@/hooks/useFileContextUpload";
import { useEffect, useState } from "react";

interface SalesContextFormProps {
  onSave: () => void;
  onCancel: () => void;
  context?: any; // Adiciona prop opcional para edição
}

// Classe de animação de borda verde piscando (ajustada)
const greenGlow = `
@keyframes greenGlow {
  0%   { box-shadow: 0 0 0 0 #34d39933, 0 0 0 1.5px #34d399; }

  10%  { box-shadow: 0 0 6px 3px #34d39988, 0 0 0 1.5px #34d399; }
  20%  { box-shadow: 0 0 0 0 #34d39933, 0 0 0 1.5px #34d399; }

  40%  { box-shadow: 0 0 6px 3px #34d39988, 0 0 0 1.5px #34d399; }
  50%  { box-shadow: 0 0 0 0 #34d39933, 0 0 0 1.5px #34d399; }

  70%  { box-shadow: 0 0 6px 3px #34d39988, 0 0 0 1.5px #34d399; }
  80%  { box-shadow: 0 0 0 0 #34d39933, 0 0 0 1.5px #34d399; }

  100% { box-shadow: 0 0 0 0 #34d39933, 0 0 0 1.5px #34d399; }
}

.animate-green-glow {
  animation: greenGlow 3.2s ease-in-out 1;
  border-color: #34d399 !important;
}
`;


if (typeof window !== 'undefined' && !document.getElementById('green-glow-style')) {
  const style = document.createElement('style');
  style.id = 'green-glow-style';
  style.innerHTML = greenGlow;
  document.head.appendChild(style);
}

export function SalesContextForm({ onSave, onCancel, context }: SalesContextFormProps) {
  const [showAnimation, setShowAnimation] = useState(!!context);
  const [isDragOver, setIsDragOver] = useState(false);
  
  useEffect(() => {
    if (context) {
      setShowAnimation(true);
      const timeout = setTimeout(() => setShowAnimation(false), 3200);
      return () => clearTimeout(timeout);
    } else {
      setShowAnimation(false);
    }
  }, [context]);
  const [activeTab, setActiveTab] = useState("product");
  useEffect(() => {
    setActiveTab("product");
  }, [context]);
  
  // Prevenir comportamento padrão de drag em toda a janela
  useEffect(() => {
    const preventDefaults = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
    };

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      document.addEventListener(eventName, preventDefaults, false);
    });

    return () => {
      ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        document.removeEventListener(eventName, preventDefaults, false);
      });
    };
  }, []);
  
  const {
    formData,
    setFormData,
    loading,
    handleSave,
    addObjection,
    removeObjection,
    updateObjection,
    addCompetitor,
    removeCompetitor,
    updateCompetitor
  } = useSalesContextForm(context); // Passa context para hook

  const {
    fileState,
    handleFileSelect,
    handleFileRemove,
    uploadContext,
    acceptedTypes,
    maxFileSize
  } = useFileContextUpload();

  // Se está editando, aplica animação
  const editingClass = showAnimation ? 'animate-green-glow' : '';

  // Determina se deve mostrar o formulário de arquivo ou as tabs
  const showFileMode = fileState.file !== null;

  // Handlers para drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!showFileMode) {
      setIsDragOver(true);
    }
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // Só remove o overlay se realmente saiu da área principal
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX;
    const y = e.clientY;
    
    if (x < rect.left || x > rect.right || y < rect.top || y > rect.bottom) {
      setIsDragOver(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    
    if (!showFileMode) {
      const files = Array.from(e.dataTransfer.files);
      if (files.length > 0) {
        handleFileSelect(files[0]);
      }
    }
  };

  const handleSaveContext = async () => {
    if (showFileMode) {
      // Modo arquivo: usar hook de upload
      const success = await uploadContext(formData.name, formData.description);
      if (success) {
        onSave();
      }
    } else {
      // Modo manual: usar hook existente
      await handleSave(onSave);
    }
  };

  return (
    <Card className="bg-white border border-[#E5E7EB] shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl text-[#111827]">
            {context ? 'Editar Contexto de Vendas' : 'Novo Contexto de Vendas'}
          </CardTitle>
          {!context && !showFileMode && (
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => document.getElementById('file-input-button')?.click()}
              className="flex items-center space-x-2 text-[#10B981] border-[#10B981] hover:bg-[#10B981] hover:text-white"
            >
              <Upload className="w-4 h-4" />
              <span>Importar Arquivo</span>
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="text-[#111827] font-medium">Nome do Contexto *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Ex: Vendas de Software B2B"
                className={`mt-2 bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] ${editingClass}`}
              />
            </div>
            <div>
              <Label htmlFor="description" className="text-[#111827] font-medium">Descrição</Label>
              <Input
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Breve descrição do contexto"
                className={`mt-2 bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] ${editingClass}`}
              />
            </div>
          </div>

          {/* Tabbed Content or File Upload */}
          {!showFileMode ? (
            <>
              {/* Hidden file input for button trigger */}
              <input
                type="file"
                accept={acceptedTypes}
                onChange={(e) => {
                  const files = e.target.files;
                  if (files && files.length > 0) {
                    handleFileSelect(files[0]);
                  }
                  e.target.value = '';
                }}
                style={{ display: 'none' }}
                id="file-input-button"
              />

              <div
                className="w-full relative"
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                {/* Overlay de drag and drop */}
                {isDragOver && (
                  <div className="absolute inset-0 z-50 bg-black bg-opacity-50 rounded-lg flex items-center justify-center">
                    <div className="text-center text-white">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white bg-opacity-20 flex items-center justify-center backdrop-blur-sm">
                        <Upload className="w-8 h-8 text-white" />
                      </div>
                      <p className="text-xl text-white font-medium mb-2">Solte o arquivo aqui</p>
                      <p className="text-sm text-white opacity-80">PDF, Word, TXT, RTF, ODT</p>
                    </div>
                  </div>
                )}
                
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-4 md:grid-cols-6">
                  <TabsTrigger value="product">Produto</TabsTrigger>
                  <TabsTrigger value="audience">Público</TabsTrigger>
                  <TabsTrigger value="objections">Objeções</TabsTrigger>
                  <TabsTrigger value="pricing">Preços</TabsTrigger>
                  <TabsTrigger value="playbook">Playbook</TabsTrigger>
                  <TabsTrigger value="competitors">Outros</TabsTrigger>
                </TabsList>

                <TabsContent value="product" className="space-y-4">
                  <div>
                    <Label htmlFor="productInfo" className="text-[#111827] font-medium">
                      Informações do Produto/Serviço
                    </Label>
                    <Textarea
                      id="productInfo"
                      value={formData.productInfo}
                      onChange={(e) => setFormData(prev => ({ ...prev, productInfo: e.target.value }))}
                      placeholder="Descreva seu produto/serviço, principais características e diferenciais únicos..."
                      className={`mt-2 min-h-[120px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none ${editingClass}`}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="audience" className="space-y-4">
                  <div>
                    <Label htmlFor="targetAudience" className="text-[#111827] font-medium">
                      Público-Alvo/Personas
                    </Label>
                    <Textarea
                      id="targetAudience"
                      value={formData.targetAudience}
                      onChange={(e) => setFormData(prev => ({ ...prev, targetAudience: e.target.value }))}
                      placeholder="Descreva as dores, necessidades, cargos e segmentos do seu público-alvo..."
                      className={`mt-2 min-h-[120px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none ${editingClass}`}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="objections" className="space-y-4">
                  <ObjectionsList
                    objections={formData.commonObjections}
                    onAdd={addObjection}
                    onRemove={removeObjection}
                    onUpdate={updateObjection}
                  />
                </TabsContent>

                <TabsContent value="pricing" className="space-y-4">
                  <div>
                    <Label htmlFor="pricingStructure" className="text-[#111827] font-medium">
                      Estrutura de Preços/Ofertas
                    </Label>
                    <Textarea
                      id="pricingStructure"
                      value={formData.pricingStructure}
                      onChange={(e) => setFormData(prev => ({ ...prev, pricingStructure: e.target.value }))}
                      placeholder="Descreva os planos, preços, condições de pagamento e ofertas especiais..."
                      className={`mt-2 min-h-[120px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none ${editingClass}`}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="playbook" className="space-y-4">
                  <div>
                    <Label htmlFor="playbook" className="text-[#111827] font-medium">
                      Playbook/Elementos de Script
                    </Label>
                    <Textarea
                      id="playbook"
                      value={formData.playbook}
                      onChange={(e) => setFormData(prev => ({ ...prev, playbook: e.target.value }))}
                      placeholder="Perguntas-chave (BANT, SPIN), etapas do processo, argumentos essenciais de valor..."
                      className={`mt-2 min-h-[120px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none ${editingClass}`}
                    />
                  </div>
                  <div>
                    <Label htmlFor="mentalTriggers" className="text-[#111827] font-medium">
                      Gatilhos Mentais Aprovados
                    </Label>
                    <Textarea
                      id="mentalTriggers"
                      value={formData.mentalTriggers}
                      onChange={(e) => setFormData(prev => ({ ...prev, mentalTriggers: e.target.value }))}
                      placeholder="Liste os gatilhos persuasivos que a equipe de vendas deve usar..."
                      className={`mt-2 min-h-[100px] bg-white border-[#E5E7EB] focus:border-[#3B82F6] text-[#111827] resize-none ${editingClass}`}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="competitors" className="space-y-4">
                  <CompetitorsList
                    competitors={formData.competitors}
                    onAdd={addCompetitor}
                    onRemove={removeCompetitor}
                    onUpdate={updateCompetitor}
                  />
                </TabsContent>
              </Tabs>
              </div>
            </>
          ) : (
            /* File Mode */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium text-gray-900">Arquivo Anexado</h3>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleFileRemove}
                  disabled={fileState.isUploading}
                  className="border-red-500 text-red-700 hover:bg-red-500 hover:text-white font-semibold text-sm px-3 py-2"
                >
                <Trash2 className="w-4 h-4" />
                </Button>
              </div>
              
              <FilePreview
                fileName={fileState.preview?.name || ''}
                fileSize={fileState.preview?.size || ''}
                fileType={fileState.preview?.type || ''}
                onRemove={handleFileRemove}
                isUploading={fileState.isUploading}
                isExtracting={fileState.isExtracting}
                uploadProgress={fileState.uploadProgress}
                extractionInfo={fileState.extractionInfo}
              />
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  O contexto será criado automaticamente a partir do conteúdo do arquivo anexado. 
                  O nome do contexto ainda é obrigatório.
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t border-[#E5E7EB]">
            <Button 
              variant="outline" 
              onClick={onCancel}
              className="border-[#E5E7EB] text-[#4B5563] hover:bg-gray-50"
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleSaveContext}
              disabled={loading || fileState.isUploading || fileState.isExtracting}
              className="bg-[#34D399] hover:bg-[#059669] text-white font-medium"
            >
              <Save className="w-4 h-4 mr-2" />
              {loading || fileState.isUploading || fileState.isExtracting ? 'Salvando...' : 'Salvar Contexto'}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
