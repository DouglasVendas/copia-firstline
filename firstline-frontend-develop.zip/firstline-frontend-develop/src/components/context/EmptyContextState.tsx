
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Target, Plus, Briefcase } from "lucide-react";

interface EmptyContextStateProps {
  onCreateSimple: () => void;
  onCreateSales: () => void;
}

export function EmptyContextState({ onCreateSimple, onCreateSales }: EmptyContextStateProps) {
  return (
    <Card className="bg-white border border-[#E5E7EB] shadow-sm">
      <CardContent className="p-12 text-center">
        <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <Target className="w-8 h-8 text-[#3B82F6]" />
        </div>
        <h3 className="text-xl font-semibold text-[#111827] mb-3">
          Nenhum contexto configurado
        </h3>
        <p className="text-[#4B5563] mb-6 max-w-md mx-auto">
          Configure seu primeiro contexto para começar a personalizar as análises de acordo com suas necessidades específicas.
        </p>
        <div className="flex justify-center space-x-3">
          <Button 
            onClick={onCreateSales}
            className="bg-[#3B82F6] hover:bg-[#2563EB] text-white font-medium"
          >
            <Briefcase className="w-4 h-4 mr-2" />
            Contexto de Vendas
          </Button>
          {/*
          <Button 
            onClick={onCreateSimple}
            className="bg-[#34D399] hover:bg-[#059669] text-white font-medium"
          >
            <Plus className="w-4 h-4 mr-2" />
            Contexto Simples
          </Button>
          */}
        </div>
      </CardContent>
    </Card>
  );
}
