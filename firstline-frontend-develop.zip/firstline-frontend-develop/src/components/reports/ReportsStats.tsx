
import { Card, CardContent } from "@/components/ui/card";
import { FileText, TrendingUp, Calendar, Users } from "lucide-react";

interface Analysis {
  id: string;
  created_at: string;
  score_geral: number;
  vendedor: string;
}

interface ReportsStatsProps {
  analyses: Analysis[];
  vendedores: string[];
}

export function ReportsStats({ analyses, vendedores }: ReportsStatsProps) {
  const averageScore = analyses.length > 0 ? analyses.reduce((sum, analysis) => sum + analysis.score_geral, 0) / analyses.length : 0;
  const totalAnalyses = analyses.length;
  const recentAnalyses = analyses.filter(analysis => {
    const analysisDate = new Date(analysis.created_at);
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return analysisDate >= weekAgo;
  }).length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
      <Card className="card-white-bg">
        <CardContent className="p-7">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-black-900 mb-1">TOTAL DE ANÁLISES</p>
              <p className="text-3xl font-bold text-black">{totalAnalyses}</p>
            </div>
            <div className="w-12 h-12 bg-emerald-400/30 rounded-lg flex items-center justify-center">
              <FileText className="w-6 h-6 text-emerald-700" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="card-white-bg">
        <CardContent className="p-7">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-black-900 mb-1">SCORE MÉDIO</p>
              <p className="text-3xl font-bold text-black">{averageScore.toFixed(1)}</p>
            </div>
            <div className="w-12 h-12 bg-emerald-400/30 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-emerald-700" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="card-white-bg">
        <CardContent className="p-7">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-black-900 mb-1">TENDÊNCIA</p>
              <p className="text-3xl font-bold text-black">{recentAnalyses}</p>
            </div>
            <div className="w-12 h-12 bg-emerald-400/30 rounded-lg flex items-center justify-center">
              <Calendar className="w-6 h-6 text-emerald-700" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="card-white-bg">
        <CardContent className="p-7">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-black-900 mb-1">VENDEDORES ATIVOS</p>
              <p className="text-3xl font-bold text-black">{vendedores.length}</p>
            </div>
            <div className="w-12 h-12 bg-emerald-400/30 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-emerald-700" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
