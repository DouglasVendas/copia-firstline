import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Eye, Download, Share2, User, Check, X } from "lucide-react";
import { ContextSelector } from "@/components/analysis/ContextSelector";
import { useReportActions } from "@/hooks/useReportActions";
import { useAnalysisNameEdit } from "@/hooks/useAnalysisNameEdit";

interface Analysis {
  id: string;
  created_at: string;
  analysis_name: string;
  client_name: string;
  score_geral: number;
  upload_type: string;
  resumo: string;
  context_uuid: string;
  transcription: string;
  vendedor: string;
  pontos_positivos: string[];
  pontos_atencao: string[];
  objecoes_identificadas: string[];
  sugestoes_melhoria: string[];
  proximos_passos: string[];
}

interface Context {
  id: string;
  name: string;
  description: string;
}

interface AnalysisListItemProps {
  analysis: Analysis;
  contextUsed?: Context;
  onViewReport: (analysis: Analysis) => void;
  onContextChanged: () => void;
  onAnalysisNameChanged?: (analysisId: string, newName: string) => void;
}

export function AnalysisListItem({ 
  analysis, 
  contextUsed, 
  onViewReport, 
  onContextChanged, 
  onAnalysisNameChanged
}: AnalysisListItemProps) {
  const { loadingAction, handleDownloadPDF, handleShareLink } = useReportActions();
  const { 
    editingId, 
    editingName, 
    saving, 
    setEditingName, 
    startEditing, 
    cancelEditing, 
    saveAnalysisName 
  } = useAnalysisNameEdit();

  const getScoreColor = (score: number) => {
    if (score >= 8) return "bg-green-100 text-green-800 border-green-200";
    if (score >= 6) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-red-100 text-red-800 border-red-200";
  };

  const getScoreBadge = (score: number) => {
    if (score >= 8) return "Excelente";
    if (score >= 6) return "Bom";
    return "Precisa Melhorar";
  };

  const onDownloadPDF = () => {
    handleDownloadPDF(analysis, contextUsed);
  };

  const onShareLink = () => {
    handleShareLink(analysis);
  };

  const handleDoubleClick = () => {
    startEditing(analysis.id, analysis.analysis_name);
  };

  const handleSave = async () => {
    const success = await saveAnalysisName(analysis.id, editingName, (updatedName) => {
      // Atualiza o nome localmente através do callback
      if (onAnalysisNameChanged) {
        onAnalysisNameChanged(analysis.id, updatedName);
      }
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      cancelEditing();
    }
  };

  return (
    <div className="p-6 rounded-lg border-2 border-blue-200 hover:border-blue-300 transition-colors bg-white hover:bg-blue-50">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-3">
            {editingId === analysis.id ? (
              <div className="flex items-center relative w-80">
                <Input
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="text-xl font-bold text-slate-800 border-blue-300 focus:border-blue-500 pr-16"
                  autoFocus
                />
                <div className="absolute right-2 flex items-center space-x-1">
                  <button
                    onClick={handleSave}
                    disabled={saving || !editingName.trim()}
                    className="text-green-600 hover:text-green-700 disabled:text-gray-400 transition-colors"
                  >
                    {saving ? (
                      <div className="w-4 h-4 border-2 border-green-600 border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                  </button>
                  <button
                    onClick={cancelEditing}
                    disabled={saving}
                    className="text-red-600 hover:text-red-700 disabled:text-gray-400 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <h3 
                className="text-xl font-bold text-slate-800 cursor-text hover:text-slate-800 transition-colors"
                onDoubleClick={handleDoubleClick}
                title="Clique duas vezes para editar"
              >
                {analysis.analysis_name}
              </h3>
            )}
            {contextUsed && (
              <Badge variant="outline" className="text-xs font-semibold bg-gray-400">
                {contextUsed.name}
              </Badge>
            )}
            {analysis.vendedor && (
              <Badge variant="outline" className="text-xs font-semibold bg-blue-100 text-blue-800">
                <User className="w-3 h-3 mr-1" />
                {analysis.vendedor}
              </Badge>
            )}
          </div>
          <p className="text-slate-700 text-sm mb-3 leading-relaxed">
            {analysis.resumo}
          </p>
        </div>
        <div className="flex flex-col items-end space-y-3">
          <div className={`px-4 py-2 rounded-full text-sm font-bold border ${getScoreColor(analysis.score_geral)}`}>
            {analysis.score_geral}/10 - {getScoreBadge(analysis.score_geral)}
          </div>
          <Badge variant="outline" className="text-xs font-semibold bg-slate-400">
            {analysis.upload_type === 'audio' ? 'Áudio' : 'Texto'}
          </Badge>
        </div>
      </div>

      <div className="flex items-center justify-between text-sm text-slate-600">
        <span className="font-medium">
          {new Date(analysis.created_at).toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </span>
        <div className="flex space-x-3">
          <Button 
            onClick={() => onViewReport(analysis)} 
            variant="outline" 
            size="sm" 
            className="border-green-600 text-green-600 hover:bg-green-50 font-semibold"
          >
            <Eye className="w-4 h-4 mr-1" />
            Ver Relatório Completo
          </Button>
          {contextUsed && (
            <ContextSelector 
              currentContextId={analysis.context_uuid} 
              analysisId={analysis.id} 
              transcription={analysis.transcription} 
              onContextChanged={onContextChanged}
            />
          )}
          <Button 
            onClick={onDownloadPDF}
            disabled={loadingAction === "download"}
            variant="outline" 
            size="sm" 
            className="border-blue-600 text-blue-600 hover:bg-blue-50 font-semibold"
          >
            {loadingAction === "download" ? (
              <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mr-1" />
            ) : (
              <Download className="w-4 h-4 mr-1" />
            )}
            {loadingAction === "download" ? "Gerando..." : "Exportar PDF"}
          </Button>
          <Button 
            onClick={onShareLink}
            disabled={loadingAction === "share"}
            variant="outline" 
            size="sm" 
            className="border-purple-600 text-purple-600 hover:bg-purple-50 font-semibold"
          >
            {loadingAction === "share" ? (
              <div className="w-4 h-4 border-2 border-purple-600 border-t-transparent rounded-full animate-spin mr-1" />
            ) : (
              <Share2 className="w-4 h-4 mr-1" />
            )}
            {loadingAction === "share" ? "Compartilhando..." : "Compartilhar"}
          </Button>
        </div>
      </div>
    </div>
  );
}
