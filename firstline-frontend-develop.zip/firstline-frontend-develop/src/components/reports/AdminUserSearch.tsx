import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, X, User, Shield } from "lucide-react";

interface AdminUserSearchProps {
  adminUserEmail: string;
  setAdminUserEmail: (email: string) => void;
  adminSearchLoading: boolean;
  searchUserAnalyses: (email: string) => Promise<void>;
  clearAdminSearch: () => void;
  isAdmin: boolean;
}

export function AdminUserSearch({
  adminUserEmail,
  setAdminUserEmail,
  adminSearchLoading,
  searchUserAnalyses,
  clearAdminSearch,
  isAdmin
}: AdminUserSearchProps) {
  const [localEmail, setLocalEmail] = useState(adminUserEmail);

  const handleSearch = async () => {
    if (localEmail.trim()) {
      await searchUserAnalyses(localEmail);
    }
  };

  const handleClear = () => {
    setLocalEmail('');
    clearAdminSearch();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  if (!isAdmin) {
    return null;
  }

  return (
    <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center space-x-2 text-lg">
          <Shield className="w-5 h-5 text-purple-600" />
          <span className="text-slate-800">Busca por Usuário (Admin)</span>
          <Badge variant="secondary" className="bg-purple-100 text-purple-700">
            Administrador
          </Badge>
        </CardTitle>
        <p className="text-sm text-slate-600">
          Digite o email do usuário para visualizar todas as suas análises (somente administradores podem ver isso).
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex space-x-2">
          <div className="relative flex-1">
            <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              type="email"
              placeholder="Digite o email do usuário..."
              value={localEmail}
              onChange={(e) => setLocalEmail(e.target.value)}
              onKeyPress={handleKeyPress}
              className="pl-10"
              disabled={adminSearchLoading}
            />
          </div>
          <Button
            onClick={handleSearch}
            disabled={!localEmail.trim() || adminSearchLoading}
            className="bg-purple-600 hover:bg-purple-700 text-white"
          >
            {adminSearchLoading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            <span className="ml-2">Buscar</span>
          </Button>
          {adminUserEmail && (
            <Button
              onClick={handleClear}
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50"
            >
              <X className="w-4 h-4" />
              <span className="ml-2">Limpar</span>
            </Button>
          )}
        </div>
        
        {adminUserEmail && (
          <div className="flex items-center space-x-2 p-3 bg-purple-100 rounded-lg">
            <User className="w-4 h-4 text-purple-600" />
            <span className="text-sm text-purple-700">
              Mostrando análises de: <strong>{adminUserEmail}</strong>
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
} 