import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, Calendar as CalendarIcon, X, SlidersHorizontal } from "lucide-react";

interface ReportsFiltersProps {
  searchTerm: string;
  selectedVendedor: string;
  vendedores: string[];
  onSearchChange: (value: string) => void;
  onVendedorChange: (value: string) => void;
  // Novos props para filtros avançados
  dateRange?: { from: Date | undefined; to: Date | undefined };
  onDateRangeChange?: (range: { from: Date | undefined; to: Date | undefined }) => void;
  minScore?: number;
  maxScore?: number;
  onScoreRangeChange?: (min: number | undefined, max: number | undefined) => void;
  selectedContext?: string;
  contexts?: Array<{ id: string; name: string }>;
  onContextChange?: (contextId: string) => void;
}

export function ReportsFilters({ 
  searchTerm, 
  selectedVendedor, 
  vendedores, 
  onSearchChange, 
  onVendedorChange,
  dateRange,
  onDateRangeChange,
  minScore,
  maxScore,
  onScoreRangeChange,
  selectedContext,
  contexts = [],
  onContextChange
}: ReportsFiltersProps) {
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [localMinScore, setLocalMinScore] = useState(minScore?.toString() || "");
  const [localMaxScore, setLocalMaxScore] = useState(maxScore?.toString() || "");
  const [localDateRange, setLocalDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({ from: undefined, to: undefined });

  // Sincronizar estados locais com props
  useEffect(() => {
    setLocalMinScore(minScore?.toString() || "");
  }, [minScore]);

  useEffect(() => {
    setLocalMaxScore(maxScore?.toString() || "");
  }, [maxScore]);

  useEffect(() => {
    // Corrige o bug de fuso horário ao inicializar localDateRange
    setLocalDateRange(dateRange
      ? {
          from: dateRange.from ? new Date(dateRange.from.getFullYear(), dateRange.from.getMonth(), dateRange.from.getDate()) : undefined,
          to: dateRange.to ? new Date(dateRange.to.getFullYear(), dateRange.to.getMonth(), dateRange.to.getDate()) : undefined,
        }
      : { from: undefined, to: undefined }
    );
  }, [dateRange]);

  useEffect(() => {
    const handler = () => setIsAdvancedOpen(false);
    window.addEventListener('close-all-overlays', handler);
    return () => window.removeEventListener('close-all-overlays', handler);
  }, []);

  const handleApplyFilters = () => {
    // Aplicar filtro de score
    const min = localMinScore ? parseFloat(localMinScore) : undefined;
    const max = localMaxScore ? parseFloat(localMaxScore) : undefined;
    
    // Validar se min não é maior que max
    if (min !== undefined && max !== undefined && min > max) {
      alert("O valor mínimo não pode ser maior que o valor máximo");
      return;
    }

    // Ajustar as datas para o início e fim do dia
    const adjustedDateRange = {
      from: localDateRange.from ? new Date(localDateRange.from.getFullYear(), localDateRange.from.getMonth(), localDateRange.from.getDate(), 0, 0, 0, 0) : undefined,
      to: localDateRange.to ? new Date(localDateRange.to.getFullYear(), localDateRange.to.getMonth(), localDateRange.to.getDate(), 23, 59, 59, 999) : undefined
    };
    
    // Aplicar filtros
    onScoreRangeChange?.(min, max);
    onDateRangeChange?.(adjustedDateRange);
    
    // Fechar o popover após aplicar
    setIsAdvancedOpen(false);
  };

  const handleClearFilters = () => {
    onSearchChange("");
    onVendedorChange("");
    onDateRangeChange?.({ from: undefined, to: undefined });
    onScoreRangeChange?.(undefined, undefined);
    onContextChange?.("");
    setLocalMinScore("");
    setLocalMaxScore("");
    setLocalDateRange({ from: undefined, to: undefined });
    setIsAdvancedOpen(false);
  };

  const hasActiveFilters = searchTerm || selectedVendedor || dateRange?.from || dateRange?.to || minScore !== undefined || maxScore !== undefined || selectedContext;

  return (
    <Card className="bg-white border-blue-200 shadow-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-800">Filtros</CardTitle>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearFilters}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <X className="w-4 h-4 mr-1" />
              Limpar Filtros
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input 
                placeholder="Buscar por cliente, conteúdo ou vendedor..." 
                value={searchTerm} 
                onChange={e => onSearchChange(e.target.value)} 
                className="pl-10 bg-white border-blue-200" 
              />
            </div>
          </div>
          
          <div className="w-48">
            <Select value={selectedVendedor || "all"} onValueChange={(value) => onVendedorChange(value === "all" ? "" : value)}>
              <SelectTrigger className="w-full bg-white border-blue-200 text-slate-900">
                <SelectValue placeholder="Todos os vendedores" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="text-slate-900">Todos</SelectItem>
                {vendedores.map(vendedor => (
                  <SelectItem key={vendedor} value={vendedor} className="text-slate-900">
                    {vendedor}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Popover open={isAdvancedOpen} onOpenChange={setIsAdvancedOpen}>
            <PopoverTrigger asChild>
              <Button 
                variant="outline" 
                className={`border-blue-600 text-blue-600 hover:bg-blue-50 ${hasActiveFilters ? 'bg-blue-50' : ''}`}
              >
                <SlidersHorizontal className="w-4 h-4 mr-2" />
                Filtros Avançados
                {hasActiveFilters && (
                  <Badge variant="secondary" className="ml-2 bg-blue-100 text-blue-700">
                    Ativo
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent 
              className="w-80 p-4" 
              align="start" 
              side="bottom"
              sideOffset={4}
              collisionBoundary={document.body}
              onOpenAutoFocus={(e) => e.preventDefault()}
              onPointerDownOutside={(e) => {
                // Não fechar se clicar em elementos dentro do popover
                if (e.target instanceof Element && e.target.closest('[data-radix-popover-content]')) {
                  e.preventDefault();
                }
              }}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-slate-800">Filtros Avançados</h4>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClearFilters}
                    className="text-red-600 hover:text-red-700 h-8 px-2"
                  >
                    <X className="w-6 h-6" />
                  </Button>
                </div>

                                 {/* Filtro por Contexto */}
                 {contexts.length > 0 && (
                   <div className="space-y-2">
                     <Label className="text-sm font-medium text-slate-700">Contexto</Label>
                     <Select value={selectedContext || "all"} onValueChange={(value) => (onContextChange || (() => {}))(value === "all" ? "" : value)}>
                       <SelectTrigger className="w-full bg-white border-blue-200 text-slate-900">
                         <SelectValue placeholder="Todos os contextos" />
                       </SelectTrigger>
                       <SelectContent>
                         <SelectItem value="all" className="text-slate-900">Todos</SelectItem>
                         {contexts.map(context => (
                           <SelectItem key={context.id} value={context.id} className="text-slate-900">
                             {context.name}
                           </SelectItem>
                         ))}
                       </SelectContent>
                     </Select>
                   </div>
                 )}

                 {/* Filtro por Data */}
                 <div className="space-y-2">
                   <Label className="text-sm font-medium text-slate-700">Período</Label>
                   <div className="flex gap-2">
                     <Input
                       type="date"
                       placeholder="Data inicial"
                       className="bg-white border-blue-200 w-36 pr-1 pl-1"
                       value={localDateRange?.from ? localDateRange.from.toISOString().split('T')[0] : ""}
                       max={localDateRange?.to ? localDateRange.to.toISOString().split('T')[0] : undefined}
                       onChange={(e) => {
                         const date = e.target.value
                           ? (() => {
                               const [year, month, day] = e.target.value.split('-').map(Number);
                               return new Date(year, month - 1, day);
                             })()
                           : undefined;
                         setLocalDateRange({ from: date, to: localDateRange?.to });
                       }}
                     />
                     <Input
                       type="date"
                       placeholder="Data final"
                       className="bg-white border-blue-200 w-36 pr-1 pl-1"
                       value={localDateRange?.to ? localDateRange.to.toISOString().split('T')[0] : ""}
                       min={localDateRange?.from ? localDateRange.from.toISOString().split('T')[0] : undefined}
                       onChange={(e) => {
                         const date = e.target.value
                           ? (() => {
                               const [year, month, day] = e.target.value.split('-').map(Number);
                               return new Date(year, month - 1, day);
                             })()
                           : undefined;
                         setLocalDateRange({ from: localDateRange?.from, to: date });
                       }}
                     />
                   </div>
                 </div>

                {/* Filtro por Score */}
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-slate-700">Score (0-10)</Label>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <Input
                        placeholder="Mín"
                        value={localMinScore}
                        onChange={(e) => setLocalMinScore(e.target.value)}
                        className="bg-white border-blue-200"
                        type="number"
                        min="0"
                        max="10"
                        step="0.1"
                      />
                    </div>
                    <div className="flex-1">
                      <Input
                        placeholder="Máx"
                        value={localMaxScore}
                        onChange={(e) => setLocalMaxScore(e.target.value)}
                        className="bg-white border-blue-200"
                        type="number"
                        min="0"
                        max="10"
                        step="0.1"
                      />
                    </div>
                  </div>
                </div>

                {/* Botão Aplicar */}
                <div className="flex justify-end pt-2">
                  <Button
                    onClick={handleApplyFilters}
                    className="bg-blue-600 text-white hover:bg-blue-700"
                  >
                    Aplicar Filtros
                  </Button>
                </div>

                {/* Resumo dos filtros ativos */}
                {hasActiveFilters && (
                  <div className="pt-2 border-t border-slate-200">
                    <Label className="text-sm font-medium text-slate-700 mb-2 block">Filtros Ativos:</Label>
                    <div className="flex flex-wrap gap-1">
                      {searchTerm && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                          Busca: {searchTerm}
                        </Badge>
                      )}
                      {selectedVendedor && (
                        <Badge variant="secondary" className="bg-green-100 text-green-700">
                          Vendedor: {selectedVendedor}
                        </Badge>
                      )}
                      {selectedContext && (
                        <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                          Contexto: {contexts.find(c => c.id === selectedContext)?.name}
                        </Badge>
                      )}
                                             {dateRange?.from && (
                  <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                    Data: {dateRange.from ? `${dateRange.from.getDate().toString().padStart(2, '0')}/${(dateRange.from.getMonth()+1).toString().padStart(2, '0')}/${dateRange.from.getFullYear()}` : ""}
                    {dateRange.to &&
                      ` - ${dateRange.to.getDate().toString().padStart(2, '0')}/${(dateRange.to.getMonth()+1).toString().padStart(2, '0')}/${dateRange.to.getFullYear()}`}
                  </Badge>
                )}
                      {(minScore !== undefined || maxScore !== undefined) && (
                        <Badge variant="secondary" className="bg-red-100 text-red-700">
                          Score: {minScore || 0}-{maxScore || 10}
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </CardContent>
    </Card>
  );
}
