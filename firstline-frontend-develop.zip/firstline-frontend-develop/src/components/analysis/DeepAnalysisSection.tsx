import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Quote, Target } from "lucide-react";

export function DeepAnalysisSection({ performanceData }: { performanceData: any[] }) {
  const getScoreColor = (score: number) => {
    if (score >= 9) return "bg-green-100 text-green-800 border-green-200";
    if (score >= 7) return "bg-blue-100 text-blue-800 border-blue-200";
    if (score >= 5) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    if (score >= 3) return "bg-orange-100 text-orange-800 border-orange-200";
    return "bg-red-100 text-red-800 border-red-200";
  };
  return (
    <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-indigo-800 flex items-center">
          <Brain className="w-6 h-6 mr-3 text-indigo-600" />
          Deep Analysis – FirstLine
        </CardTitle>
        <p className="text-sm text-indigo-600 mt-2">
          <em>Sugestão especializada da FirstLine baseada na sua performance nesta etapa.</em>
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {performanceData.filter(item => item.score < 7).map((item, index) => (
          <div key={index} className="bg-white p-6 rounded-lg border border-indigo-200">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-bold text-slate-800 text-lg">{item.skill}</h4>
              <Badge className={`px-3 py-1 text-sm font-bold border ${getScoreColor(item.score)}`}>
                {item.score}/10
              </Badge>
            </div>
            <div className="space-y-4">
              <div className="bg-slate-50 p-4 rounded-lg border-l-4 border-slate-400">
                <div className="flex items-start space-x-3">
                  <Quote className="w-5 h-5 text-slate-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-slate-700 mb-2">Frase Real do Vendedor:</p>
                    <p className="text-slate-600 italic leading-relaxed">"{item.actualQuote}"</p>
                  </div>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Target className="w-5 h-5 text-indigo-600 mt-0.5" />
                <div>
                  <p className="font-medium text-slate-700 mb-2">Diagnóstico Comportamental:</p>
                  <p className="text-slate-600 leading-relaxed">{item.observation}</p>
                </div>
              </div>
              <div className="bg-indigo-50 p-4 rounded-lg border-l-4 border-indigo-400">
                <div className="flex items-start space-x-3">
                  <Brain className="w-5 h-5 text-indigo-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-indigo-700 mb-2">FirstLine Expert Suggestion:</p>
                    <p className="text-indigo-700 leading-relaxed font-medium">"{item.firstLineSuggestion}"</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
} 