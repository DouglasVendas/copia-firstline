import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState, useMemo } from "react";
import { 
  Download, 
  Share2, 
  CheckCircle, 
  Send,
  Lock,
  FileText,
  Phone,
  Brain,
  FlaskConical,
  ClipboardList,
  TrendingUp,
  AlertTriangle,
  Target,
  Lightbulb,
  Zap,
  Quote,
  XCircle,
  Copy,
  Check
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PredictiveInsights } from "@/components/analytics/PredictiveInsights";
import { PerformanceMetrics } from "@/components/analytics/PerformanceMetrics";
import { TalkTimeMetrics } from "@/components/analytics/TalkTimeMetrics";

// IMPORTS ADICIONAIS PARA AS SEÇÕES MODULARIZADAS
import { ResumoSection } from "./ResumoSection";
import { PontosPositivosSection } from "./PontosPositivosSection";
import { PontosAtencaoSection } from "./PontosAtencaoSection";
import { IAPreditivaSection } from "./IAPreditivaSection";
import { FrameworkSection } from "./FrameworkSection";
import { DeepAnalysisSection } from "./DeepAnalysisSection";
import { NLPSection } from "./NLPSection";
import { PerformanceSection } from "./PerformanceSection";
import { SugestoesMelhoriaSection } from "./SugestoesMelhoriaSection";
import { EvolucaoVendedorSection } from "./EvolucaoVendedorSection";
import { TreinamentoSection } from "./TreinamentoSection";
import { TranscricaoSection } from "./TranscricaoSection";
import { ReportSectionsFilter, SectionOption } from "./ReportSectionsFilter";
import { MentalTriggersSection } from "./MentalTriggersSection";
import { ProximosPassosSection } from "./ProximosPassosSection";
import { PlanoFechamentoSection } from "./PlanoFechamentoSection";

interface CallReportProps {
  transcription: string;
  analysis: {
    score_geral: number;
    pontos_positivos: string[];
    pontos_atencao: string[];
    objecoes_identificadas: string[];
    sugestoes_melhoria: string[];
    proximos_passos: string[];
    resumo: string;
    framework_analysis?: any;
    coaching_insights?: string[];
    performance_analysis?: any;
    mental_triggers?: any;
    reformulacoes_pnl?: any;
    plano_fechamento?: string[];
    ia_preditiva?: any;
    audio_duration_seconds?: number;
    desempenho_geral?: {
      abertura: number;
      descoberta: number;
      fechamento: number;
      qualificacao: number;
    };
    tempo_de_fala?: {
      tempo_geral: {
        vendedor: number;
        cliente: number;
      };
      tempo_por_fase: {
        abertura: number;
        descoberta: number;
        qualificacao: number;
        fechamento: number;
      };
    };
  };
  clientName: string;
  contextUsed?: { id: string; name: string; description: string };
  vendedor?: string;
  createdAt?: string;
}

export function CallReport({ transcription, analysis, clientName, contextUsed, vendedor, createdAt }: CallReportProps) {
  const [selectedFramework, setSelectedFramework] = useState<string>("SPIN");
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [copiedTranscription, setCopiedTranscription] = useState<boolean>(false);
  const { toast } = useToast();

  const getScoreColor = (score: number) => {
    if (score >= 9) return "bg-green-100 text-green-800 border-green-200";
    if (score >= 7) return "bg-blue-100 text-blue-800 border-blue-200";
    if (score >= 5) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    if (score >= 3) return "bg-orange-100 text-orange-800 border-orange-200";
    return "bg-red-100 text-red-800 border-red-200";
  };

  const getClassificationBadge = (score: number) => {
    if (score >= 9) return { text: "Excelente", color: "bg-green-100 text-green-800 border-green-200" };
    if (score >= 7) return { text: "Bom", color: "bg-blue-100 text-blue-800 border-blue-200" };
    if (score >= 5) return { text: "Razoável", color: "bg-yellow-100 text-yellow-800 border-yellow-200" };
    if (score >= 3) return { text: "Fraco", color: "bg-orange-100 text-orange-800 border-orange-200" };
    return { text: "Crítico", color: "bg-red-100 text-red-800 border-red-200" };
  };

  const handleDownloadPDF = async () => {
    setLoadingAction("download");
    try {
      const jsPDF = (await import('jspdf')).default;
      const doc = new jsPDF();
      
      let yPosition = 20;
      const pageHeight = doc.internal.pageSize.height;
      const margin = 20;
      const maxWidth = 170;
      
      // Helper function to add new page if needed
      const checkAndAddPage = (requiredSpace: number = 30) => {
        if (yPosition + requiredSpace >= pageHeight - margin) {
          doc.addPage();
          yPosition = 20;
        }
      };

      // Helper function to add text with word wrap
      const addText = (text: string, fontSize: number = 10, isBold: boolean = false) => {
        doc.setFontSize(fontSize);
        if (isBold) {
          doc.setFont(undefined, 'bold');
        } else {
          doc.setFont(undefined, 'normal');
        }
        const splitText = doc.splitTextToSize(text, maxWidth);
        checkAndAddPage(splitText.length * 5 + 5);
        doc.text(splitText, margin, yPosition);
        yPosition += splitText.length * 5 + 5;
      };

      // Header
      addText('RELATÓRIO COMPLETO DE CALL - FIRSTLINE AI', 20, true);
      yPosition += 10;
      
      // Basic Info
      addText(`Cliente: ${clientName}`, 12, true);
      addText(`Data: ${createdAt 
        ? new Date(createdAt).toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })
        : new Date().toLocaleDateString('pt-BR')
      }`, 12);
      addText(`Produto: ${contextUsed?.name || "Produto Geral"}`, 12);
      addText(`Vendedor: ${vendedor || "Não informado"}`, 12);
      addText(`Duração: ${analysis.audio_duration_seconds ? `${(analysis.audio_duration_seconds / 60).toFixed(1)}min` : "N/A"}`, 12);
      addText(`Score Final: ${analysis.score_geral}/10 - ${getClassificationBadge(analysis.score_geral).text}`, 12, true);
      yPosition += 10;

      // Resumo da Call
      checkAndAddPage(40);
      addText('RESUMO DA CALL', 16, true);
      addText(analysis.resumo || "Resumo não disponível", 10);
      yPosition += 10;

      // Pontos Positivos
      if (analysis.pontos_positivos && analysis.pontos_positivos.length > 0) {
        checkAndAddPage(40);
        addText('PONTOS POSITIVOS', 16, true);
        analysis.pontos_positivos.forEach((point: string, index: number) => {
          addText(`${index + 1}. ${point}`, 10);
        });
        yPosition += 10;
      }

      // Pontos de Atenção
      if (analysis.pontos_atencao && analysis.pontos_atencao.length > 0) {
        checkAndAddPage(40);
        addText('PONTOS DE ATENÇÃO', 16, true);
        analysis.pontos_atencao.forEach((point: string, index: number) => {
          addText(`${index + 1}. ${point}`, 10);
        });
        yPosition += 10;
      }

      // IA Preditiva
      if (analysis.ia_preditiva) {
        checkAndAddPage(60);
        addText('IA PREDITIVA - FIRSTLINE', 16, true);
        
        if (analysis.ia_preditiva.probabilidade_fechamento !== undefined) {
          addText(`Probabilidade de Fechamento: ${analysis.ia_preditiva.probabilidade_fechamento}%`, 12, true);
        }
        
        if (analysis.ia_preditiva.proximos_passos_ia && Array.isArray(analysis.ia_preditiva.proximos_passos_ia)) {
          addText('Próximos Passos Recomendados pela IA:', 12, true);
          analysis.ia_preditiva.proximos_passos_ia.forEach((passo: string, index: number) => {
            addText(`${index + 1}. ${passo}`, 10);
          });
        }
        
        if (analysis.ia_preditiva.insights_comportamentais && Array.isArray(analysis.ia_preditiva.insights_comportamentais)) {
          addText('Insights Comportamentais:', 12, true);
          analysis.ia_preditiva.insights_comportamentais.forEach((insight: string, index: number) => {
            addText(`• ${insight}`, 10);
          });
        }
        yPosition += 10;
      }

      // Framework Analysis
      if (analysis.framework_analysis) {
        checkAndAddPage(60);
        addText('ANÁLISE DOS FRAMEWORKS DE VENDAS', 16, true);
        
        ['spin', 'bant', 'gpct'].forEach(framework => {
          if (analysis.framework_analysis[framework]) {
            const frameworkData = analysis.framework_analysis[framework];
            addText(`${framework.toUpperCase()}:`, 14, true);
            
            Object.keys(frameworkData).forEach(key => {
              if (frameworkData[key] && typeof frameworkData[key] === 'object') {
                addText(`${key.charAt(0).toUpperCase() + key.slice(1)}:`, 12, true);
                addText(`Presente: ${frameworkData[key].presente ? 'Sim' : 'Não'}`, 10);
                if (frameworkData[key].trecho) {
                  addText(`Trecho: "${frameworkData[key].trecho}"`, 10);
                }
                if (frameworkData[key].avaliacao) {
                  addText(`Avaliação: ${frameworkData[key].avaliacao}`, 10);
                }
              }
            });
            yPosition += 5;
          }
        });
        yPosition += 10;
      }

      // Performance Analysis
      if (analysis.performance_analysis) {
        checkAndAddPage(60);
        addText('ANÁLISE DE PERFORMANCE', 16, true);
        
        Object.keys(analysis.performance_analysis).forEach(skill => {
          const skillData = analysis.performance_analysis[skill];
          if (skillData && typeof skillData === 'object') {
            addText(`${skill.charAt(0).toUpperCase() + skill.slice(1).replace(/_/g, ' ')}:`, 12, true);
            addText(`Score: ${skillData.score || 0}/10`, 10);
            if (skillData.observacao) {
              addText(`Observação: ${skillData.observacao}`, 10);
            }
            if (skillData.frase_real) {
              addText(`Frase Real: "${skillData.frase_real}"`, 10);
            }
            if (skillData.sugestao_firstline) {
              addText(`Sugestão FirstLine: "${skillData.sugestao_firstline}"`, 10);
            }
            yPosition += 3;
          }
        });
        yPosition += 10;
      }

      // Mental Triggers
      if (analysis.mental_triggers) {
        checkAndAddPage(40);
        addText('GATILHOS MENTAIS IDENTIFICADOS', 16, true);
        
        // Handle both array and object formats
        if (Array.isArray(analysis.mental_triggers)) {
          analysis.mental_triggers.forEach((trigger: any, index: number) => {
            if (typeof trigger === 'object') {
              addText(`${index + 1}. ${trigger.tipo || trigger.name || 'Gatilho'}`, 11, true);
              if (trigger.descricao || trigger.description) {
                addText(`Descrição: ${trigger.descricao || trigger.description}`, 10);
              }
              if (trigger.trecho || trigger.excerpt) {
                addText(`Trecho: "${trigger.trecho || trigger.excerpt}"`, 10);
              }
            } else {
              addText(`${index + 1}. ${trigger}`, 10);
            }
          });
        } else if (typeof analysis.mental_triggers === 'object') {
          // Handle object format where keys are trigger names
          let triggerIndex = 1;
          Object.keys(analysis.mental_triggers).forEach(triggerName => {
            const triggerData = analysis.mental_triggers[triggerName];
            addText(`${triggerIndex}. ${triggerName}`, 11, true);
            
            if (triggerData.detectado !== undefined) {
              addText(`Detectado: ${triggerData.detectado ? 'Sim' : 'Não'}`, 10);
            }
            
            if (triggerData.frase_real && triggerData.frase_real.trim()) {
              addText(`Frase Real: "${triggerData.frase_real}"`, 10);
            }
            
            if (triggerData.recomendacao_firstline) {
              addText(`Recomendação FirstLine: "${triggerData.recomendacao_firstline}"`, 10);
            }
            
            yPosition += 3;
            triggerIndex++;
          });
        }
        yPosition += 10;
      }

      // Reformulações PNL
      if (analysis.reformulacoes_pnl && Array.isArray(analysis.reformulacoes_pnl)) {
        checkAndAddPage(60);
        addText('REFORMULAÇÕES COM BASE EM PNL', 16, true);
        analysis.reformulacoes_pnl.forEach((reformulacao: any, index: number) => {
          addText(`${index + 1}. ${reformulacao.categoria || 'Reformulação'}`, 12, true);
          if (reformulacao.frase_real) {
            addText(`Frase Real: "${reformulacao.frase_real}"`, 10);
          }
          if (reformulacao.recomendacao_firstline) {
            addText(`Recomendação FirstLine: "${reformulacao.recomendacao_firstline}"`, 10);
          }
          yPosition += 5;
        });
        yPosition += 10;
      }

      // Plano de Fechamento
      if (analysis.plano_fechamento && Array.isArray(analysis.plano_fechamento)) {
        checkAndAddPage(40);
        addText('PLANO DE FECHAMENTO', 16, true);
        analysis.plano_fechamento.forEach((passo: string, index: number) => {
          addText(`${index + 1}. ${passo}`, 10);
        });
        yPosition += 10;
      }

      // Coaching Insights
      if (analysis.coaching_insights && Array.isArray(analysis.coaching_insights)) {
        checkAndAddPage(40);
        addText('INSIGHTS DE COACHING', 16, true);
        analysis.coaching_insights.forEach((insight: string, index: number) => {
          addText(`${index + 1}. ${insight}`, 10);
        });
        yPosition += 10;
      }

      // Objeções Identificadas
      if (analysis.objecoes_identificadas && analysis.objecoes_identificadas.length > 0) {
        checkAndAddPage(40);
        addText('OBJEÇÕES IDENTIFICADAS', 16, true);
        analysis.objecoes_identificadas.forEach((objecao: string, index: number) => {
          addText(`${index + 1}. ${objecao}`, 10);
        });
        yPosition += 10;
      }

      // Sugestões de Melhoria
      if (analysis.sugestoes_melhoria && analysis.sugestoes_melhoria.length > 0) {
        checkAndAddPage(40);
        addText('SUGESTÕES DE MELHORIA', 16, true);
        analysis.sugestoes_melhoria.forEach((sugestao: string, index: number) => {
          addText(`${index + 1}. ${sugestao}`, 10);
        });
        yPosition += 10;
      }

      // Próximos Passos
      if (analysis.proximos_passos && analysis.proximos_passos.length > 0) {
        checkAndAddPage(40);
        addText('PRÓXIMOS PASSOS', 16, true);
        analysis.proximos_passos.forEach((passo: string, index: number) => {
          addText(`${index + 1}. ${passo}`, 10);
        });
        yPosition += 10;
      }

      // Footer on each page
      const totalPages = doc.internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.setFont(undefined, 'normal');
        doc.text(`FirstLine AI - Relatório Completo | Página ${i} de ${totalPages}`, margin, pageHeight - 10);
        doc.text(`Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}`, margin, pageHeight - 5);
      }
      
      // Save the PDF
      doc.save(`relatorio-call-completo-${clientName}-${new Date().toISOString().split('T')[0]}.pdf`);
      
      toast({
        title: "Sucesso",
        description: "Relatório PDF completo gerado com sucesso!",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao gerar PDF completo. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoadingAction(null);
    }
  };

  const handleShareLink = async () => {
    setLoadingAction("share");
    try {
      // Create a proper shareable URL
      const shareUrl = `${window.location.origin}/relatorios?shared=${btoa(JSON.stringify({
        clientName,
        analysis,
        timestamp: Date.now()
      }))}`;
      
      if (navigator.share) {
        await navigator.share({
          title: `Relatório de Call - ${clientName}`,
          text: `Confira o relatório de análise da call com ${clientName}`,
          url: shareUrl,
        });
      } else {
        await navigator.clipboard.writeText(shareUrl);
        toast({
          title: "Sucesso",
          description: "Link copiado para a área de transferência!",
        });
      }
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        return;
      }
      toast({
        title: "Erro",
        description: "Falha ao compartilhar o link. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoadingAction(null);
    }
  };

  const handleCopyTranscription = async () => {
    try {
      await navigator.clipboard.writeText(transcription);
      setCopiedTranscription(true);
      toast({
        title: "Sucesso",
        description: "Transcrição copiada para a área de transferência!",
      });
      
      // Reset the copied state after 2 seconds
      setTimeout(() => {
        setCopiedTranscription(false);
      }, 2000);
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao copiar a transcrição. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  // Get real framework data from AI analysis
  const getFrameworkData = () => {
    if (!analysis.framework_analysis) {
      return {
        SPIN: { data: [], breakdown: { questions: 0, statements: 0, missing: 0 } },
        BANT: { data: [], breakdown: { questions: 0, statements: 0, missing: 0 } },
        GPCT: { data: [], breakdown: { questions: 0, statements: 0, missing: 0 } }
      };
    }

    const frameworks = analysis.framework_analysis;
    const result: any = {};

    ['SPIN', 'BANT', 'GPCT'].forEach(frameworkType => {
      const framework = frameworks[frameworkType.toLowerCase()];
      if (framework) {
        const data = Object.keys(framework).map(key => ({
          stage: key.charAt(0).toUpperCase() + key.slice(1),
          excerpt: framework[key].trecho || "Não identificado na conversa",
          evaluation: framework[key].avaliacao || "Não avaliado",
          identified: framework[key].presente || false,
          method: framework[key].presente ? "question" : "missing"
        }));

        const questions = data.filter(item => item.method === "question").length;
        const statements = data.filter(item => item.method === "statement").length;
        const missing = data.filter(item => item.method === "missing").length;

        result[frameworkType] = {
          data,
          breakdown: { questions, statements, missing }
        };
      } else {
        result[frameworkType] = {
          data: [],
          breakdown: { questions: 0, statements: 0, missing: 0 }
        };
      }
    });

    return result;
  };

  const salesFrameworkData = getFrameworkData();

  // Get real performance data from AI analysis
  const getPerformanceData = () => {
    if (!analysis.performance_analysis) {
      return [];
    }

    const performance = analysis.performance_analysis;
    return Object.keys(performance).map(key => ({
      skill: key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' '),
      score: performance[key].score || 0,
      observation: performance[key].observacao || "Não avaliado",
      actualQuote: performance[key].frase_real || "Não identificado",
      firstLineSuggestion: performance[key].sugestao_firstline || "Aguardando análise"
    }));
  };

  const performanceData = getPerformanceData();

  // Get coaching insights from AI analysis
  const getCoachingInsights = () => {
    if (!analysis.coaching_insights || !Array.isArray(analysis.coaching_insights) || analysis.coaching_insights.length === 0) {
      return ["Aguardando análise de coaching baseada na performance da call"];
    }
    return analysis.coaching_insights;
  };

  const coachingInsights = getCoachingInsights();

  // Get NLP suggestions from AI analysis
  const getNlpSuggestions = () => {
    if (!analysis.reformulacoes_pnl || !Array.isArray(analysis.reformulacoes_pnl) || analysis.reformulacoes_pnl.length === 0) {
      return [];
    }
    return analysis.reformulacoes_pnl.map((item: any) => ({
      category: item.categoria || "Reformulação",
      actualQuote: item.frase_real || "Não identificado",
      firstLineRecommendation: item.recomendacao_firstline || "Aguardando sugestão"
    }));
  };

  const nlpSuggestions = getNlpSuggestions();

  const currentFramework = salesFrameworkData[selectedFramework as keyof typeof salesFrameworkData];

  const sectionOptions: SectionOption[] = [
    { id: "resumo", label: "Resumo da Call", contentText: analysis.resumo || "" },
    { id: "pontos_positivos", label: "Pontos Positivos", contentText: (analysis.pontos_positivos || []).join(" ") },
    { id: "pontos_atencao", label: "Pontos de Atenção", contentText: (analysis.pontos_atencao || []).join(" ") },
    { id: "ia_preditiva", label: "IA Preditiva FirstLine", contentText: JSON.stringify(analysis.ia_preditiva || "") },
    { id: "framework", label: "Análise do Framework de Vendas", contentText: JSON.stringify(analysis.framework_analysis || "") + " " + (analysis.coaching_insights || []).join(" ") },
    { id: "performance", label: "Análise de Performance da Call", contentText: JSON.stringify(analysis.performance_analysis || "") },
    { id: "deep_analysis", label: "Deep Analysis – FirstLine", contentText: JSON.stringify(analysis.performance_analysis || "") },
    { id: "mental_triggers", label: "Gatilhos Mentais", contentText: JSON.stringify(analysis.mental_triggers || "") },
    { id: "nlp", label: "Reformulações com Base em PNL", contentText: JSON.stringify(analysis.reformulacoes_pnl || "") },
    { id: "plano_fechamento", label: "Plano de Fechamento", contentText: (analysis.plano_fechamento || []).join(" ") },
    { id: "proximos_passos", label: "Próximos Passos", contentText: (analysis.proximos_passos || []).join(" ") },
    { id: "sugestoes", label: "Sugestões de Melhoria", contentText: (analysis.sugestoes_melhoria || []).join(" ") },
    { id: "evolucao", label: "Evolução da Performance do Vendedor", contentText: (analysis.objecoes_identificadas || []).join(" ") },
    { id: "treinamento", label: "Treinamento Personalizado", contentText: "Treinamento Personalizado" },
    { id: "transcricao", label: "Transcrição Completa", contentText: transcription || "" },
  ];
  const [visibleSectionIds, setVisibleSectionIds] = useState(sectionOptions.map(s => s.id));
  const [searchTerm, setSearchTerm] = useState("");

  // Filtrar seções baseado no termo de busca
  const filteredSectionIds = useMemo(() => {
    if (!searchTerm.trim()) return visibleSectionIds;
    const lower = searchTerm.toLowerCase();
    return visibleSectionIds.filter(id => {
      const section = sectionOptions.find(s => s.id === id);
      return section && (
        section.label.toLowerCase().includes(lower) ||
        section.contentText.toLowerCase().includes(lower)
      );
    });
  }, [visibleSectionIds, searchTerm, sectionOptions]);

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-2xl font-bold text-slate-800 flex items-center">
            <FileText className="w-6 h-6 mr-3 text-blue-600" />
            Relatório de Call
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Nome do Vendedor</p>
                <p className="text-lg font-bold text-slate-900">{vendedor || "Não definido"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Cliente</p>
                <p className="text-lg font-bold text-slate-900">{clientName}</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Produto</p>
                <p className="text-lg font-bold text-slate-900">{contextUsed?.name || "Produto Geral"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Data da Call</p>
                <p className="text-lg font-bold text-slate-900">
                  {createdAt 
                    ? new Date(createdAt).toLocaleDateString('pt-BR', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })
                    : new Date().toLocaleDateString('pt-BR')
                  }
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Duração</p>
                <p className="text-lg font-bold text-slate-900">
                  {typeof analysis.audio_duration_seconds === "number"
                    ? `${(analysis.audio_duration_seconds / 60).toFixed(1)}min`
                    : "N/A"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-600 mb-1">Score Final</p>
                <div className="flex items-center space-x-2">
                  <Badge className={`px-4 py-2 text-xl font-bold border ${getScoreColor(analysis.score_geral)}`}>
                    {analysis.score_geral}/10
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* Filtro de seções */}
      <ReportSectionsFilter
        sections={sectionOptions}
        selectedSectionIds={visibleSectionIds}
        onSelectionChange={setVisibleSectionIds}
        onSearchChange={setSearchTerm}
      />
      {/* Renderização condicional das seções */}
      {filteredSectionIds.includes("resumo") && <ResumoSection resumo={analysis.resumo} />}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredSectionIds.includes("pontos_positivos") && <PontosPositivosSection pontos={analysis.pontos_positivos} />}
        {filteredSectionIds.includes("pontos_atencao") && <PontosAtencaoSection pontos={analysis.pontos_atencao} />}
      </div>
      {filteredSectionIds.includes("ia_preditiva") && <IAPreditivaSection iaPreditiva={analysis.ia_preditiva} />}
      
      {/* Performance Metrics - Desempenho Geral e Tempo de Fala */}
      {/* {(analysis.desempenho_geral || analysis.tempo_de_fala) && (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {analysis.desempenho_geral && (
            <div className="lg:col-span-3">
              <PerformanceMetrics desempenhoGeral={analysis.desempenho_geral} />
            </div>
          )}
          {analysis.tempo_de_fala && (
            <div className="lg:col-span-2">
              <TalkTimeMetrics tempoFala={analysis.tempo_de_fala} />
            </div>
          )}
        </div>
      )} */}
      
      {filteredSectionIds.includes("framework") && (
        <FrameworkSection
          framework_analysis={analysis.framework_analysis}
          coaching_insights={analysis.coaching_insights}
          selectedFramework={selectedFramework}
          setSelectedFramework={setSelectedFramework}
        />
      )}
      {filteredSectionIds.includes("performance") && <PerformanceSection performanceData={performanceData} />}
      {filteredSectionIds.includes("deep_analysis") && <DeepAnalysisSection performanceData={performanceData} />}
      {/* {filteredSectionIds.includes("mental_triggers") && <MentalTriggersSection mentalTriggers={analysis.mental_triggers} />} */}
      {filteredSectionIds.includes("nlp") && <NLPSection nlpSuggestions={nlpSuggestions} />}
      {/* {filteredSectionIds.includes("plano_fechamento") && <PlanoFechamentoSection planoFechamento={analysis.plano_fechamento} />} */}
      {/* {filteredSectionIds.includes("proximos_passos") && <ProximosPassosSection proximosPassos={analysis.proximos_passos} />} */}
      {filteredSectionIds.includes("sugestoes") && <SugestoesMelhoriaSection sugestoes={analysis.sugestoes_melhoria} />}
      {filteredSectionIds.includes("evolucao") && <EvolucaoVendedorSection objecoes={analysis.objecoes_identificadas} />}
      {filteredSectionIds.includes("treinamento") && <TreinamentoSection />}
      {filteredSectionIds.includes("transcricao") && <TranscricaoSection transcription={transcription} onCopy={handleCopyTranscription} copied={copiedTranscription} />}
    </div>
  );
}
