import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, Clock, Shield, Zap, Lightbulb } from "lucide-react";

interface PlanoFechamentoSectionProps {
  planoFechamento?: string[];
}

export function PlanoFechamentoSection({ planoFechamento }: PlanoFechamentoSectionProps) {
  if (!planoFechamento || planoFechamento.length === 0) {
    return (
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
            <Target className="w-5 h-5 mr-3 text-blue-500" />
            Plano de Fechamento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-500">
            <Target className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Nenhum plano de fechamento definido para esta call.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Função para determinar o ícone e estilo baseado no tipo de ação
  const getActionStyle = (text: string) => {
    const lowerText = text.toLowerCase();
    if (lowerText.includes('imediato') || lowerText.includes('urgente')) {
      return { 
        icon: Zap, 
        bgColor: 'bg-blue-50', 
        borderColor: 'border-blue-200', 
        iconColor: 'text-blue-600',
        badgeColor: 'bg-blue-100 text-blue-700 border-blue-300'
      };
    }
    if (lowerText.includes('validação') || lowerText.includes('confirmar')) {
      return { 
        icon: Shield, 
        bgColor: 'bg-slate-50', 
        borderColor: 'border-slate-200', 
        iconColor: 'text-slate-600',
        badgeColor: 'bg-slate-100 text-slate-700 border-slate-300'
      };
    }
    if (lowerText.includes('estruturação') || lowerText.includes('cronograma')) {
      return { 
        icon: Clock, 
        bgColor: 'bg-blue-50', 
        borderColor: 'border-blue-200', 
        iconColor: 'text-blue-600',
        badgeColor: 'bg-blue-100 text-blue-700 border-blue-300'
      };
    }
    return { 
      icon: Target, 
      bgColor: 'bg-slate-50', 
      borderColor: 'border-slate-200', 
      iconColor: 'text-slate-600',
      badgeColor: 'bg-slate-100 text-slate-700 border-slate-300'
    };
  };

  // Função para extrair o tipo da ação (ex: "IMEDIATO:", "VALIDAÇÃO:")
  const getActionType = (text: string) => {
    const match = text.match(/^([A-ZÁÇÃOÊÎ]+):/);
    return match ? match[1] : null;
  };

  // Função para obter o texto sem o prefixo
  const getActionText = (text: string) => {
    const match = text.match(/^[A-ZÁÇÃOÊÎ]+:\s*(.+)/);
    return match ? match[1] : text;
  };

  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <Target className="w-5 h-5 mr-3 text-blue-500" />
          Plano de Fechamento
        </CardTitle>
        <p className="text-sm text-slate-600 mt-2">
          Estratégia estruturada para maximizar as chances de fechamento da venda.
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {planoFechamento.map((acao, index) => {
            const actionType = getActionType(acao);
            const actionText = getActionText(acao);
            const { icon: Icon, bgColor, borderColor, iconColor, badgeColor } = getActionStyle(acao);
            
            return (
              <div 
                key={index}
                className={`flex items-start p-4 ${bgColor} rounded-lg border ${borderColor} hover:shadow-sm transition-all`}
              >
                <div className="flex-shrink-0 mr-3">
                  <Icon className={`w-5 h-5 ${iconColor} mt-1`} />
                </div>
                <div className="flex-1">
                  {actionType && (
                    <Badge 
                      variant="outline" 
                      className={`mb-2 ${badgeColor} font-semibold`}
                    >
                      {actionType}
                    </Badge>
                  )}
                  <p className="text-slate-800 font-medium leading-relaxed">
                    {actionText}
                  </p>
                </div>
                <div className="flex-shrink-0 ml-3">
                  <Badge variant="outline" className="bg-white text-slate-600 border-slate-300">
                    {index + 1}
                  </Badge>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
          <div className="flex items-start">
            <div className="flex-shrink-0 mr-3">
              <Lightbulb className="w-4 h-4 text-blue-500 mt-1" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-700 mb-1">
                Estratégia FirstLine
              </p>
              <p className="text-sm text-slate-600">
                Este plano de fechamento foi estruturado para criar urgência, validar o comprometimento e estabelecer um cronograma claro de entregas.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}