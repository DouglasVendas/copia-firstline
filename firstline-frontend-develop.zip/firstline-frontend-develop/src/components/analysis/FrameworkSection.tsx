import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Brain, CheckCircle, AlertTriangle, XCircle, Lightbulb } from "lucide-react";
import React from "react";

export function FrameworkSection({ framework_analysis, coaching_insights, selectedFramework, setSelectedFramework }: {
  framework_analysis: any,
  coaching_insights: string[],
  selectedFramework: string,
  setSelectedFramework: (fw: string) => void
}) {
  // Lógica para extrair dados do framework igual ao CallReport
  const getFrameworkData = () => {
    if (!framework_analysis) {
      return {
        SPIN: { data: [], breakdown: { questions: 0, statements: 0, missing: 0 } },
        BANT: { data: [], breakdown: { questions: 0, statements: 0, missing: 0 } },
        GPCT: { data: [], breakdown: { questions: 0, statements: 0, missing: 0 } }
      };
    }
    const frameworks = framework_analysis;
    const result: any = {};
    ['SPIN', 'BANT', 'GPCT'].forEach(frameworkType => {
      const framework = frameworks[frameworkType.toLowerCase()];
      if (framework) {
        const data = Object.keys(framework).map(key => ({
          stage: key.charAt(0).toUpperCase() + key.slice(1),
          excerpt: framework[key].trecho || "Não identificado na conversa",
          evaluation: framework[key].avaliacao || "Não avaliado",
          identified: framework[key].presente || false,
          method: framework[key].presente ? "question" : "missing"
        }));
        const questions = data.filter(item => item.method === "question").length;
        const statements = data.filter(item => item.method === "statement").length;
        const missing = data.filter(item => item.method === "missing").length;
        result[frameworkType] = {
          data,
          breakdown: { questions, statements, missing }
        };
      } else {
        result[frameworkType] = {
          data: [],
          breakdown: { questions: 0, statements: 0, missing: 0 }
        };
      }
    });
    return result;
  };
  const salesFrameworkData = getFrameworkData();
  const currentFramework = salesFrameworkData[selectedFramework as keyof typeof salesFrameworkData];
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
            <Brain className="w-6 h-6 mr-3 text-purple-600" />
            Análise do Framework de Vendas
          </CardTitle>
          <Tabs value={selectedFramework} onValueChange={setSelectedFramework} className="w-auto">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="SPIN">SPIN</TabsTrigger>
              <TabsTrigger value="BANT">BANT</TabsTrigger>
              <TabsTrigger value="GPCT">GPCT</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6 p-4 bg-slate-50 rounded-lg">
          <h4 className="font-bold text-slate-800 mb-3">Breakdown do {selectedFramework}:</h4>
          <div className="flex space-x-6">
            <div className="flex items-center space-x-2">
              <Badge className="bg-green-100 text-green-800 border-green-200"><CheckCircle className="w-4 h-4 text-green-800" /></Badge>
              <span className="text-sm font-medium">{currentFramework.breakdown.questions} perguntas feitas</span>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200"><AlertTriangle className="w-4 h-4 text-yellow-800" /></Badge>
              <span className="text-sm font-medium">{currentFramework.breakdown.statements} afirmações do lead</span>
            </div>
            <div className="flex items-center space-x-2">
              <Badge className="bg-red-100 text-red-800 border-red-200"><XCircle className="w-4 h-4 text-red-800" /></Badge>
              <span className="text-sm font-medium">{currentFramework.breakdown.missing} elementos ausentes</span>
            </div>
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-bold text-slate-700">Etapa de Vendas</TableHead>
              <TableHead className="font-bold text-slate-700">Trecho da Call</TableHead>
              <TableHead className="font-bold text-slate-700">Avaliação</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {currentFramework.data.map((item: any, index: number) => (
              <TableRow key={index} className="hover:bg-slate-50">
                <TableCell className="font-semibold text-slate-800">{item.stage}</TableCell>
                <TableCell className="italic text-slate-600 leading-relaxed">"{item.excerpt}"</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    {item.method === "question" && (
                      <>
                        <span className="text-xl"><CheckCircle className="w-5 h-5 text-green-800" /></span>
                        <span className="font-bold text-green-800 text-sm">{item.evaluation}</span>
                      </>
                    )}
                    {item.method === "statement" && (
                      <>
                        <span className="text-xl"><AlertTriangle className="w-5 h-5 text-yellow-800" /></span>
                        <span className="font-bold text-yellow-800 text-sm">{item.evaluation}</span>
                      </>
                    )}
                    {item.method === "missing" && (
                      <>
                        <span className="text-xl"><XCircle className="w-5 h-5 text-red-800" /></span>
                        <span className="font-bold text-red-800 text-sm">{item.evaluation}</span>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        {coaching_insights && coaching_insights.length > 0 && (
          <div className="mt-6 p-4 bg-blue-50 border-l-4 border-blue-400 rounded-r-lg">
            <div className="flex items-start space-x-3">
              <Lightbulb className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-bold text-blue-800 mb-2">Insights de Coaching</h4>
                <div className="space-y-2">
                  {coaching_insights.map((insight, index) => (
                    <p key={index} className="text-blue-700 leading-relaxed">
                      • {insight}
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
} 