
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { User } from "lucide-react";

interface SellerSelectorProps {
  vendedores: string[];
  vendedorAtivo: string | null;
  selectedVendedor: string;
  onVendedorChange: (vendedor: string) => void;
  disabled?: boolean;
}

export function SellerSelector({ 
  vendedores, 
  vendedorAtivo, 
  selectedVendedor, 
  onVendedorChange,
  disabled = false
}: SellerSelectorProps) {
  if (!vendedores || vendedores.length === 0) {
    return (
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
        <div className="flex items-center space-x-2">
          <User className="w-4 h-4 text-amber-600" />
          <span className="text-sm text-amber-800 font-medium">
            Nenhum vendedor cadastrado neste contexto
          </span>
        </div>
        <p className="text-xs text-amber-700 mt-1">
          Configure vendedores na seção Contexto antes de fazer análises
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium text-slate-700">
        Vendedor responsável pela call *
      </Label>
      <div className="flex items-center space-x-3">
        <Select 
          value={selectedVendedor} 
          onValueChange={onVendedorChange}
          disabled={disabled}
        >
          <SelectTrigger className="flex-1">
            <SelectValue placeholder="Selecione o vendedor" />
          </SelectTrigger>
          <SelectContent>
            {vendedores.map((vendedor) => (
              <SelectItem key={vendedor} value={vendedor}>
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4" />
                  <span>{vendedor}</span>
                  {vendedorAtivo === vendedor && (
                    <Badge variant="secondary" className="text-xs">Padrão</Badge>
                  )}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {vendedorAtivo && selectedVendedor === vendedorAtivo && (
          <Badge className="bg-green-100 text-green-800 text-xs">
            Vendedor Padrão
          </Badge>
        )}
      </div>
    </div>
  );
}
