import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Lock } from "lucide-react";

export function TreinamentoSection() {
  return (
    <Card className="bg-gradient-to-r from-gray-50 to-gray-100 border-gray-300 shadow-sm">
      <CardContent className="p-8">
        <div className="text-center">
          <Lock className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-700 mb-2">Treinamento Personalizado</h3>
          <p className="text-gray-600 mb-4">Em desenvolvimento - lançamento em breve</p>
          <Badge className="bg-gray-200 text-gray-700 border-gray-300">
            Funcionalidade em desenvolvimento
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
} 