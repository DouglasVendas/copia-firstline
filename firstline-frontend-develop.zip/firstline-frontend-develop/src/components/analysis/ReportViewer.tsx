import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calendar, User, Target, Download, Share2 } from "lucide-react";
import { CallReport } from "./CallReport";
interface Analysis {
  id: string;
  created_at: string;
  client_name: string;
  score_geral: number;
  upload_type: string;
  resumo: string;
  pontos_positivos: string[];
  pontos_atencao: string[];
  objecoes_identificadas: string[];
  sugestoes_melhoria: string[];
  proximos_passos: string[];
  context_uuid: string;
  transcription: string;
  vendedor: string;
  // Enhanced AI analysis fields
  framework_analysis?: any;
  coaching_insights?: string[];
  performance_analysis?: any;
  mental_triggers?: any;
  reformulacoes_pnl?: any;
  plano_fechamento?: string[];
  ia_preditiva?: any;
  audio_duration_seconds?: number;
  desempenho_geral?: {
    abertura: number;
    descoberta: number;
    fechamento: number;
    qualificacao: number;
  };
  tempo_de_fala?: {
    tempo_geral: {
      vendedor: number;
      cliente: number;
    };
    tempo_por_fase: {
      abertura: number;
      descoberta: number;
      qualificacao: number;
      fechamento: number;
    };
  };
}
interface ReportViewerProps {
  analysis: Analysis;
  contextUsed?: {
    id: string;
    name: string;
    description: string;
  };
  onBack: () => void;
  onDownloadPDF: () => void;
  onShareLink: () => void;
  loadingAction: string | null;
}
export function ReportViewer({
  analysis,
  contextUsed,
  onBack,
  onDownloadPDF,
  onShareLink,
  loadingAction
}: ReportViewerProps) {
  const getScoreColor = (score: number) => {
    if (score >= 8) return "bg-green-100 text-green-800 border-green-200";
    if (score >= 6) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-red-100 text-red-800 border-red-200";
  };
  const getScoreBadge = (score: number) => {
    if (score >= 8) return "Excelente";
    if (score >= 6) return "Bom";
    return "Precisa Melhorar";
  };
  const analysisData = {
    score_geral: analysis.score_geral,
    pontos_positivos: analysis.pontos_positivos || [],
    pontos_atencao: analysis.pontos_atencao || [],
    objecoes_identificadas: analysis.objecoes_identificadas || [],
    sugestoes_melhoria: analysis.sugestoes_melhoria || [],
    proximos_passos: analysis.proximos_passos || [],
    resumo: analysis.resumo || "Resumo não disponível",
    // Include all enhanced AI analysis fields
    framework_analysis: analysis.framework_analysis,
    coaching_insights: analysis.coaching_insights,
    performance_analysis: analysis.performance_analysis,
    mental_triggers: analysis.mental_triggers,
    reformulacoes_pnl: analysis.reformulacoes_pnl,
    plano_fechamento: analysis.plano_fechamento,
    ia_preditiva: analysis.ia_preditiva,
    audio_duration_seconds: analysis.audio_duration_seconds,
    desempenho_geral: analysis.desempenho_geral,
    tempo_de_fala: analysis.tempo_de_fala,
  };
  return <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-7xl mx-auto space-y-6 animate-fade-in">
        {/* Header with Back Button and Actions */}
        <Card className="bg-white border-blue-200 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Button onClick={onBack} variant="outline" size="sm" className="border-blue-600 text-blue-600 hover:bg-blue-50 flex items-center">
                  <ArrowLeft className="w-3.5 h-3.5 mr-1.5" />
                  Voltar aos Relatórios
                </Button>
                <Button 
                  onClick={onDownloadPDF}
                  disabled={loadingAction === "download"}
                  variant="outline"
                  size="sm"
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 flex items-center font-medium"
                >
                  <Download className="w-4 h-4 mr-1.5" />
                  {loadingAction === "download" ? "Gerando PDF..." : "Baixar PDF Completo"}
                </Button>
                <Button 
                  onClick={onShareLink}
                  disabled={loadingAction === "share"}
                  variant="outline" 
                  size="sm"
                  className="border-blue-600 text-blue-600 hover:bg-blue-50 flex items-center font-medium"
                >
                  <Share2 className="w-4 h-4 mr-1.5" />
                  {loadingAction === "share" ? "Compartilhando..." : "Compartilhar Link"}
                </Button>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1.5">
                  <Calendar className="w-3.5 h-3.5 text-slate-600" />
                  <span className="text-xs font-medium text-slate-700">
                    {new Date(analysis.created_at).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                  </span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <User className="w-3.5 h-3.5 text-slate-600" />
                  <span className="text-xs font-bold text-slate-800">{analysis.client_name}</span>
                </div>
                {contextUsed && <div className="flex items-center space-x-1.5">
                    <Target className="w-3.5 h-3.5 text-slate-600" />
                    <Badge variant="outline" className="font-semibold bg-slate-400 text-xs py-0.5 px-2">
                      {contextUsed.name}
                    </Badge>
                  </div>}
                <div className={`px-3 py-1.5 rounded-full text-xs font-bold border ${getScoreColor(analysis.score_geral)}`}>
                  {analysis.score_geral}/10 - {getScoreBadge(analysis.score_geral)}
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Full Report */}
        <CallReport
          transcription={analysis.transcription}
          analysis={analysisData}
          clientName={analysis.client_name}
          contextUsed={contextUsed}
          vendedor={analysis.vendedor}
          createdAt={analysis.created_at}
        />
      </div>
    </div>;
}