import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Quote } from "lucide-react";

export function NLPSection({ nlpSuggestions }: { nlpSuggestions: any[] }) {
  if (!nlpSuggestions || nlpSuggestions.length === 0) return null;
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <Quote className="w-6 h-6 mr-3 text-purple-600" />
          Reformulações com Base em PNL
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-bold text-slate-700">Categoria</TableHead>
              <TableHead className="font-bold text-slate-700">Frase Real do Vendedor</TableHead>
              <TableHead className="font-bold text-slate-700">FirstLine Expert Recommended Phrase</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {nlpSuggestions.map((suggestion, index) => (
              <TableRow key={index} className="hover:bg-slate-50">
                <TableCell className="font-semibold text-slate-800">{suggestion.category}</TableCell>
                <TableCell className="text-red-600 italic">"{suggestion.actualQuote}"</TableCell>
                <TableCell className="text-green-700 font-medium">"{suggestion.firstLineRecommendation}"</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
} 