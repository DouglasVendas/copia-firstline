import { useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Settings, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useContextsFromProvider } from "@/contexts/ContextsProvider";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';
import { AuthRedirectError } from '@/lib/apiFetch';

interface Context {
  id: string;
  name: string;
  description: string;
  is_active: boolean;
  user_id: string;
  created_at: string;
  updated_at: string;
  prompt: string;
  vendedores: any[];
  vendedor_ativo: string | null;
  vendedor_ativo_id: string | null;
}

interface ContextSelectorProps {
  currentContextId: string;
  analysisId: string;
  transcription: string;
  onContextChanged?: () => void;
  // Props opcionais para otimização
  providedContexts?: Context[];
  providedActiveContexts?: Context[];
}

export function ContextSelector({ 
  currentContextId, 
  analysisId, 
  transcription,
  onContextChanged,
  providedContexts,
  providedActiveContexts
}: ContextSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedContext, setSelectedContext] = useState<string>('');
  const { user } = useAuth();
  const [isReanalyzing, setIsReanalyzing] = useState(false);
  
  const { toast } = useToast();
  
  const contextProvider = useContextsFromProvider();
  const activeContexts = providedActiveContexts?.length ? providedActiveContexts : contextProvider.activeContexts;
  const contexts = providedContexts?.length ? providedContexts : contextProvider.contexts;

  // O contexto atual é o que está sendo usado na análise (pode estar inativo)
  const currentContext = contexts.find(ctx => ctx.id === currentContextId);

  useEffect(() => {
    const handler = () => setIsOpen(false);
    window.addEventListener('close-all-overlays', handler);
    return () => window.removeEventListener('close-all-overlays', handler);
  }, []);

  const handleReanalyze = async () => {
    if (!selectedContext) {
      toast({
        title: "Selecione um contexto",
        description: "Escolha um contexto para reprocessar a análise.",
        variant: "destructive",
      });
      return;
    }

    if (selectedContext === currentContextId) {
      toast({
        title: "Selecione um contexto diferente",
        description: "Escolha um contexto diferente do atual para reprocessar a análise.",
        variant: "destructive",
      });
      return;
    }

    setIsReanalyzing(true);

    try {
      // Re-run analysis with new context
      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyze-text`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: transcription,
          contextId: selectedContext
        })
      });

      if (!response.ok) {
        throw new Error('Falha ao reprocessar análise');
      }

      const data = await response.json();

      // Update analysis with new context and results - call backend endpoint
      const updateResponse = await apiFetch(`${import.meta.env.VITE_API_URL}/analyses/${analysisId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          context_uuid: selectedContext,
          resumo: data.resumo || null,
          pontos_positivos: data.pontos_positivos || null,
          pontos_atencao: data.pontos_atencao || null,
          objecoes_identificadas: data.objecoes_identificadas || null,
          sugestoes_melhoria: data.sugestoes_melhoria || null,
          proximos_passos: data.proximos_passos || null,
          score_geral: data.score_geral || null,
        })
      });

      if (!updateResponse.ok) {
        throw new Error('Falha ao atualizar análise');
      }

      toast({
        title: "Contexto alterado com sucesso!",
        description: "A análise foi reprocessada com o novo contexto selecionado.",
      });

      setIsOpen(false);
      setSelectedContext('');
      onContextChanged?.();

    } catch (error) {
      if (error instanceof AuthRedirectError) return; // Não mostra toast
      toast({
        title: "Erro ao alterar contexto",
        description: error instanceof Error ? error.message : "Erro desconhecido",
        variant: "destructive",
      });
    } finally {
      setIsReanalyzing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center space-x-2">
          <Settings className="w-4 h-4" />
          <span>Alterar Contexto</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Alterar Contexto de Análise</DialogTitle>
          <DialogDescription>
            Selecione um novo contexto para reprocessar esta análise com diferentes configurações.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Current Context */}
          <div className="p-3 bg-gray-50 rounded-lg border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-900">Contexto da Análise</p>
                <p className="text-sm text-gray-600">
                  {currentContext?.name || 'Contexto não encontrado'}
                </p>
                {currentContext?.description && (
                  <p className="text-xs text-gray-500 mt-1">{currentContext.description}</p>
                )}
              </div>
              <Badge variant="secondary">Atual</Badge>
            </div>
          </div>

          {/* New Context Selection */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Novo Contexto</label>
            {contexts.filter(ctx => ctx.id !== currentContextId).length > 0 ? (
              <Select value={selectedContext} onValueChange={setSelectedContext}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um novo contexto" />
                </SelectTrigger>
                <SelectContent>
                  {contexts
                    .filter(ctx => ctx.id !== currentContextId)
                    .map((context) => (
                      <SelectItem key={context.id} value={context.id}>
                        <div className="flex items-center justify-between w-full">
                          <div>
                            <span className="font-medium">{context.name}</span>
                            {context.description && (
                              <p className="text-xs text-gray-500">{context.description}</p>
                            )}
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            ) : (
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  Não há outros contextos disponíveis para alterar.
                </p>
              </div>
            )}
          </div>

          {/* Warning */}
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-800">
              <strong>Atenção:</strong> Alterar o contexto irá reprocessar toda a análise usando as configurações do novo contexto selecionado.
            </p>
          </div>

          {/* Actions */}
          <div className="flex space-x-2 justify-end">
            <Button 
              variant="outline" 
              onClick={() => setIsOpen(false)}
              disabled={isReanalyzing}
            >
              Cancelar
            </Button>
            <Button 
              onClick={handleReanalyze}
              disabled={!selectedContext || isReanalyzing || contexts.filter(ctx => ctx.id !== currentContextId).length === 0}
              className="bg-emerald-500 hover:bg-emerald-600"
            >
              {isReanalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Reprocessando...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reprocessar Análise
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
