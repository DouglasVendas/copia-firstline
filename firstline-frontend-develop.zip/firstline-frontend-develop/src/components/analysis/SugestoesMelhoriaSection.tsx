import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Lightbulb } from "lucide-react";

export function SugestoesMelhoriaSection({ sugestoes }: { sugestoes: string[] }) {
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <Lightbulb className="w-6 h-6 mr-3 text-blue-600" />
          Sugestões de Melhoria
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {(Array.isArray(sugestoes) ? sugestoes : []).map((item, index) => (
          <div key={index} className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
            <span className="text-xl text-blue-600 mt-0.5"><Lightbulb className="w-5 h-5 text-blue-600" /></span>
            <span className="text-slate-700 leading-relaxed">{item}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
} 