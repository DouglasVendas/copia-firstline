import { Button } from "@/components/ui/button";
import { Zap } from "lucide-react";
import { CallReport } from "./CallReport";

interface AnalysisData {
  score_geral: number;
  pontos_positivos: string[];
  pontos_atencao: string[];
  objecoes_identificadas: string[];
  sugestoes_melhoria: string[];
  proximos_passos: string[];
  resumo: string;
}

interface AnalysisResultsProps {
  transcription: string;
  analysis: AnalysisData;
  clientName: string;
  analysisId: string;
  contextUsed?: { id: string; name: string; description: string };
  vendedor?: string;
  createdAt?: string;
  onNewAnalysis: () => void;
  onContextChanged?: () => void;
}

export function AnalysisResults({ 
  transcription, 
  analysis, 
  clientName, 
  analysisId,
  contextUsed,
  vendedor,
  createdAt,
  onNewAnalysis,
  onContextChanged 
}: AnalysisResultsProps) {
  return (
    <div className="space-y-6">
      <CallReport
        transcription={transcription}
        analysis={analysis}
        clientName={clientName}
        contextUsed={contextUsed}
        vendedor={vendedor}
        createdAt={createdAt}
      />

      {/* New Analysis Button */}
      <div className="flex justify-center">
        <Button 
          onClick={onNewAnalysis}
          className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3"
        >
          <Zap className="w-5 h-5 mr-2" />
          Nova Análise
        </Button>
      </div>
    </div>
  );
}
