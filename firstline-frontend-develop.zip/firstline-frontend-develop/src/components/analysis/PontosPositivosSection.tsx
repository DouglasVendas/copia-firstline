import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle } from "lucide-react";

export function PontosPositivosSection({ pontos }: { pontos: string[] }) {
  return (
    <Card className="bg-green-50 border-green-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-bold text-green-800 flex items-center">
          <CheckCircle className="w-5 h-5 mr-2" />
          Pontos Positivos
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {(Array.isArray(pontos) ? pontos : []).map((point, index) => (
            <div key={index} className="flex items-start space-x-3">
              <Badge className="bg-green-100 text-green-800 border-green-200 px-2 py-1 text-xs"><CheckCircle className="w-4 h-4 text-green-800" /></Badge>
              <span className="text-green-800 font-medium leading-relaxed">{point}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
} 