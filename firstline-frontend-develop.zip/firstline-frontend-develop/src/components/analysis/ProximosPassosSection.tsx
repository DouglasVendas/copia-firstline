import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle, Calendar, Lightbulb } from "lucide-react";

interface ProximosPassosSectionProps {
  proximosPassos?: string[];
}

export function ProximosPassosSection({ proximosPassos }: ProximosPassosSectionProps) {
  if (!proximosPassos || proximosPassos.length === 0) {
    return (
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
            <ArrowRight className="w-5 h-5 mr-3 text-blue-500" />
            Próximos Passos
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-500">
            <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Nenhum próximo passo definido para esta call.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <ArrowRight className="w-5 h-5 mr-3 text-blue-500" />
          Próximos Passos
        </CardTitle>
        <p className="text-sm text-slate-600 mt-2">
          Ações estratégicas recomendadas para dar continuidade ao processo de vendas.
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {proximosPassos.map((passo, index) => (
            <div 
              key={index}
              className="flex items-start p-4 bg-blue-50 rounded-lg border border-blue-200 hover:bg-blue-100 transition-colors"
            >
              <div className="flex-shrink-0 mr-3">
                <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-300 font-semibold">
                  {index + 1}
                </Badge>
              </div>
              <div className="flex-1">
                <p className="text-slate-800 font-medium leading-relaxed">
                  {passo}
                </p>
              </div>
              <div className="flex-shrink-0 ml-3">
                <CheckCircle className="w-5 h-5 text-blue-500 opacity-50" />
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-200">
          <div className="flex items-start">
            <div className="flex-shrink-0 mr-3">
              <Lightbulb className="w-4 h-4 text-blue-500 mt-1" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-700 mb-1">
                Dica FirstLine
              </p>
              <p className="text-sm text-slate-600">
                Execute estes passos em ordem de prioridade e acompanhe o progresso de cada um para maximizar as chances de conversão.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}