import { PredictiveInsights } from "@/components/analytics/PredictiveInsights";

export function IAPreditivaSection({ iaPreditiva }: { iaPreditiva: any }) {
  return <PredictiveInsights iaPreditiva={iaPreditiva} />;
} 