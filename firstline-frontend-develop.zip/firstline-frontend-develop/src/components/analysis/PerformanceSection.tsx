import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FlaskConical } from "lucide-react";

export function PerformanceSection({ performanceData }: { performanceData: any[] }) {
  const getScoreColor = (score: number) => {
    if (score >= 9) return "bg-green-100 text-green-800 border-green-200";
    if (score >= 7) return "bg-blue-100 text-blue-800 border-blue-200";
    if (score >= 5) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    if (score >= 3) return "bg-orange-100 text-orange-800 border-orange-200";
    return "bg-red-100 text-red-800 border-red-200";
  };
  const getClassificationBadge = (score: number) => {
    if (score >= 9) return { text: "Excelente", color: "bg-green-100 text-green-800 border-green-200" };
    if (score >= 7) return { text: "Bom", color: "bg-blue-100 text-blue-800 border-blue-200" };
    if (score >= 5) return { text: "Razoável", color: "bg-yellow-100 text-yellow-800 border-yellow-200" };
    if (score >= 3) return { text: "Fraco", color: "bg-orange-100 text-orange-800 border-orange-200" };
    return { text: "Crítico", color: "bg-red-100 text-red-800 border-red-200" };
  };
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <FlaskConical className="w-6 h-6 mr-3 text-green-600" />
          Análise de Performance da Call
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-bold text-slate-700">Habilidade Avaliada</TableHead>
              <TableHead className="font-bold text-slate-700">Score (0-10)</TableHead>
              <TableHead className="font-bold text-slate-700">Classificação</TableHead>
              <TableHead className="font-bold text-slate-700">Observação Técnica</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {performanceData.map((item, index) => {
              const badge = getClassificationBadge(item.score);
              return (
                <TableRow key={index} className="hover:bg-slate-50">
                  <TableCell className="font-bold text-slate-800">{item.skill}</TableCell>
                  <TableCell>
                    <Badge className={`px-3 py-1 text-sm font-bold border ${getScoreColor(item.score)}`}>
                      {item.score}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={`px-3 py-1 text-sm font-semibold border ${badge.color}`}>
                      {badge.text}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-slate-600 leading-relaxed">{item.observation}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
} 