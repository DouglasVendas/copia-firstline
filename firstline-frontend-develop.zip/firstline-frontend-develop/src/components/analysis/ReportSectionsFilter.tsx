import React, { useState, useMemo } from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, X, Filter } from "lucide-react";
import { Popover, PopoverTrigger, PopoverContent } from "@/components/ui/popover";

export interface SectionOption {
  id: string;
  label: string;
  contentText: string;
}

interface ReportSectionsFilterProps {
  sections: SectionOption[];
  selectedSectionIds: string[];
  onSelectionChange: (ids: string[]) => void;
  onSearchChange?: (searchTerm: string) => void;
}

export function ReportSectionsFilter({ sections, selectedSectionIds, onSelectionChange, onSearchChange }: ReportSectionsFilterProps) {
  const [search, setSearch] = useState("");
  const [popoverOpen, setPopoverOpen] = useState(false);

  const filteredSections = useMemo(() => {
    if (!search.trim()) return sections;
    const lower = search.toLowerCase();
    return sections.filter(
      s =>
        s.label.toLowerCase().includes(lower) ||
        (s.contentText && s.contentText.toLowerCase().includes(lower))
    );
  }, [search, sections]);

  const handleToggle = (id: string) => {
    if (selectedSectionIds.includes(id)) {
      onSelectionChange(selectedSectionIds.filter(sid => sid !== id));
    } else {
      onSelectionChange([...selectedSectionIds, id]);
    }
  };

  const handleClear = () => {
    setSearch("");
    onSearchChange?.("");
    onSelectionChange(sections.map(s => s.id));
  };

  const handleSearchChange = (value: string) => {
    setSearch(value);
    onSearchChange?.(value);
  };

  const hasActiveFilters = search.trim() || selectedSectionIds.length !== sections.length;

  return (
    <Card className="bg-white border-blue-200 shadow-sm mb-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-800">Filtrar Seções do Relatório</CardTitle>
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClear}
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <X className="w-4 h-4 mr-1" />
              Limpar Filtros
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="flex-1 w-full">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
              <Input
                placeholder="Buscar seção por título ou conteúdo..."
                value={search}
                onChange={e => handleSearchChange(e.target.value)}
                className="pl-10 bg-white border-blue-200"
              />
            </div>
          </div>
          <div className={`w-full ${selectedSectionIds.length === sections.length ? 'md:w-44' : 'md:w-64'}`}>
            <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={`w-full ${selectedSectionIds.length === sections.length ? 'md:w-44' : 'md:w-64'} max-w-xs border-blue-200 text-slate-900 flex justify-between items-center bg-white hover:bg-white focus:bg-white active:bg-white`}
                >
                  <Filter className="w-4 h-4 mr-2 text-blue-600" />
                  <span className="text-blue-600">
                    {selectedSectionIds.length === 0
                      ? "Nenhuma seção selecionada"
                      : selectedSectionIds.length === sections.length
                      ? "Todas as seções"
                      : `${selectedSectionIds.length} seção(ões) selecionada(s)`}
                  </span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className={`${selectedSectionIds.length === sections.length ? 'w-44' : 'w-64'} p-2`} align="start" side="bottom" sideOffset={4}>
                <div className="max-h-64 overflow-y-auto overflow-x-auto flex flex-col gap-1 whitespace-nowrap scrollbar-thin scrollbar-thumb-blue-200 scrollbar-track-blue-50" style={{paddingBottom: 8}}>
                  {filteredSections.map(section => (
                    <label key={section.id} className="flex items-center gap-2 cursor-pointer px-2 py-1 rounded hover:bg-blue-50">
                      <input
                        type="checkbox"
                        checked={selectedSectionIds.includes(section.id)}
                        onChange={() => handleToggle(section.id)}
                        className="accent-blue-600"
                      />
                      <span className="text-slate-700 font-medium">{section.label}</span>
                    </label>
                  ))}
                  {filteredSections.length === 0 && (
                    <span className="text-slate-500 px-2 py-1">Nenhuma seção encontrada</span>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 