import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, CheckCircle, XCircle, Lightbulb } from "lucide-react";

interface MentalTriggersSectionProps {
  mentalTriggers?: any;
}

export function MentalTriggersSection({ mentalTriggers }: MentalTriggersSectionProps) {
  if (!mentalTriggers) {
    return null;
  }

  // Handle both array and object formats
  const renderTriggers = () => {
    if (Array.isArray(mentalTriggers)) {
      return mentalTriggers.map((trigger: any, index: number) => (
        <div key={index} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
          <div className="flex items-start justify-between mb-3">
            <h4 className="font-semibold text-slate-900 flex items-center">
              <Zap className="w-4 h-4 mr-2 text-orange-500" />
              {trigger.tipo || trigger.name || `Gatilho ${index + 1}`}
            </h4>
          </div>
          
          {(trigger.descricao || trigger.description) && (
            <p className="text-sm text-slate-600 mb-3">
              {trigger.descricao || trigger.description}
            </p>
          )}
          
          {(trigger.trecho || trigger.excerpt) && (
            <div className="mb-3">
              <p className="text-xs font-medium text-slate-500 mb-1">Trecho identificado:</p>
              <p className="text-sm text-slate-700 italic bg-white p-2 rounded border-l-4 border-blue-400">
                "{trigger.trecho || trigger.excerpt}"
              </p>
            </div>
          )}
        </div>
      ));
    } 
    
    if (typeof mentalTriggers === 'object') {
      return Object.keys(mentalTriggers).map((triggerName, index) => {
        const triggerData = mentalTriggers[triggerName];
        
        return (
          <div key={index} className="bg-slate-50 rounded-lg p-4 border border-slate-200">
            <div className="flex items-start justify-between mb-3">
              <h4 className="font-semibold text-slate-900 flex items-center">
                <Zap className="w-4 h-4 mr-2 text-orange-500" />
                {triggerName}
              </h4>
              <Badge 
                variant={triggerData.detectado ? "default" : "secondary"}
                className={`flex items-center ${
                  triggerData.detectado 
                    ? "bg-green-100 text-green-800 border-green-200" 
                    : "bg-red-100 text-red-800 border-red-200"
                }`}
              >
                {triggerData.detectado ? (
                  <CheckCircle className="w-3 h-3 mr-1" />
                ) : (
                  <XCircle className="w-3 h-3 mr-1" />
                )}
                {triggerData.detectado ? "Detectado" : "Não Detectado"}
              </Badge>
            </div>
            
            {triggerData.frase_real && triggerData.frase_real.trim() && (
              <div className="mb-3">
                <p className="text-xs font-medium text-slate-500 mb-1">Frase identificada:</p>
                <p className="text-sm text-slate-700 italic bg-white p-2 rounded border-l-4 border-blue-400">
                  "{triggerData.frase_real}"
                </p>
              </div>
            )}
            
            {triggerData.recomendacao_firstline && (
              <div className="mt-3">
                <p className="text-xs font-medium text-slate-500 mb-1 flex items-center">
                  <Lightbulb className="w-3 h-3 mr-1 text-yellow-500" />
                  Recomendação FirstLine:
                </p>
                <p className="text-sm text-slate-700 bg-blue-50 p-3 rounded border-l-4 border-blue-500">
                  "{triggerData.recomendacao_firstline}"
                </p>
              </div>
            )}
          </div>
        );
      });
    }
    
    return (
      <div className="text-center py-8 text-slate-500">
        <Zap className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>Nenhum gatilho mental identificado nesta análise.</p>
      </div>
    );
  };

  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <Zap className="w-5 h-5 mr-3 text-orange-500" />
          Gatilhos Mentais Identificados
        </CardTitle>
        <p className="text-sm text-slate-600 mt-2">
          Análise dos gatilhos mentais presentes na conversa e recomendações para otimização.
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {renderTriggers()}
        </div>
      </CardContent>
    </Card>
  );
}