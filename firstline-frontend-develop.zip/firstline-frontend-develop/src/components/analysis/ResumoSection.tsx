import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Phone } from "lucide-react";

export function ResumoSection({ resumo }: { resumo: string }) {
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <Phone className="w-6 h-6 mr-3 text-blue-600" />
          Resumo da Call
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-slate-700 leading-relaxed text-base">{resumo}</p>
      </CardContent>
    </Card>
  );
} 