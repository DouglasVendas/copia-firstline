import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Lock, Brain } from "lucide-react";

export function EvolucaoVendedorSection({ objecoes }: { objecoes: string[] }) {
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
          <TrendingUp className="w-6 h-6 mr-3 text-indigo-600" />
          Evolução da Performance do Vendedor
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-slate-50 p-8 rounded-lg">
            <h4 className="text-lg font-bold text-slate-800 mb-6">Progressão de Scores</h4>
            <div className="flex items-center justify-center h-32 text-slate-500">
              <div className="text-center">
                <TrendingUp className="w-12 h-12 mx-auto mb-3" />
                <p className="text-sm flex items-center justify-center gap-2">
                  <Lock className="w-4 h-4 inline-block text-gray-500" />
                  Em desenvolvimento - em breve
                </p>
              </div>
            </div>
          </div>
          <div className="bg-slate-50 p-8 rounded-lg">
            <h4 className="text-lg font-bold text-slate-800 mb-6">Radar de Habilidades</h4>
            <div className="flex items-center justify-center h-32 text-slate-500">
              <div className="text-center">
                <Brain className="w-12 h-12 mx-auto mb-3" />
                <p className="text-sm flex items-center justify-center gap-2">
                  <Lock className="w-4 h-4 inline-block text-gray-500" />
                  Em desenvolvimento - em breve
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-8">
          <h4 className="text-lg font-bold text-slate-800 mb-4">Objeções Mais Frequentes</h4>
          <div className="space-y-3">
            {(Array.isArray(objecoes) ? objecoes : []).map((objection, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                <span className="text-slate-700 font-medium">{objection}</span>
                <Badge variant="outline" className="font-semibold">{Math.floor(Math.random() * 5) + 1}x</Badge>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
} 