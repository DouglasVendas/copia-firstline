import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Copy, Check } from "lucide-react";

export function TranscricaoSection({ transcription, onCopy, copied }: { transcription: string, onCopy: () => void, copied: boolean }) {
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold text-slate-800 flex items-center">
            <FileText className="w-6 h-6 mr-3 text-slate-600" />
            Transcrição Completa
          </CardTitle>
          <Button
            onClick={onCopy}
            variant="outline"
            size="sm"
            className="flex items-center space-x-2 border-slate-300 text-slate-700 hover:bg-slate-50"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-green-600 font-medium">Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copiar</span>
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200 max-h-96 overflow-y-auto">
          <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap">
            {transcription}
          </p>
        </div>
      </CardContent>
    </Card>
  );
} 