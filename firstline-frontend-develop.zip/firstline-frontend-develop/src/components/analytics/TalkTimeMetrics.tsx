import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, User, UserCircle, Construction } from "lucide-react";

interface TalkTimeMetricsProps {
  tempoFala: {
    tempo_geral: {
      vendedor: number;
      cliente: number;
    };
    tempo_por_fase: {
      abertura: number;
      descoberta: number;
      qualificacao: number;
      fechamento: number;
    };
  } | null;
}

export function TalkTimeMetrics({ tempoFala }: TalkTimeMetricsProps) {
  const [activeTab, setActiveTab] = useState<"DISC" | "TDF">("TDF"); // TDF = Tempo de Fala, DISC = Análise DISC (em desenvolvimento)

  if (!tempoFala) {
    return null;
  }

  const { tempo_geral, tempo_por_fase } = tempoFala;

  // Percentuais de tempo geral (já vêm em porcentagem)
  const percentCliente = tempo_geral.cliente;
  const percentVendedor = tempo_geral.vendedor;

  // Dados para o gráfico donut (Tempo por Fase) - já vêm em porcentagem
  const faseColors = [
    { name: "Abertura", percent: tempo_por_fase.abertura, color: "#0099f1ff" },
    { name: "Descoberta", percent: tempo_por_fase.descoberta, color: "#6B3BFF" },
    { name: "Proposta", percent: tempo_por_fase.qualificacao, color: "#FF2D95" },
    { name: "Fechamento", percent: tempo_por_fase.fechamento, color: "#00D08A" },
  ];

  // Calcular ângulos para o donut chart
  let currentAngle = 0;
  const segments = faseColors.map((fase) => {
    const angle = (fase.percent / 100) * 360;
    const segment = {
      ...fase,
      startAngle: currentAngle,
      endAngle: currentAngle + angle,
    };
    currentAngle += angle;
    return segment;
  });

  // Função para criar o path do segmento do donut
  const createArcPath = (startAngle: number, endAngle: number, innerRadius: number, outerRadius: number) => {
    const start = polarToCartesian(50, 50, outerRadius, endAngle);
    const end = polarToCartesian(50, 50, outerRadius, startAngle);
    const innerStart = polarToCartesian(50, 50, innerRadius, endAngle);
    const innerEnd = polarToCartesian(50, 50, innerRadius, startAngle);
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

    return [
      "M", start.x, start.y,
      "A", outerRadius, outerRadius, 0, largeArcFlag, 0, end.x, end.y,
      "L", innerEnd.x, innerEnd.y,
      "A", innerRadius, innerRadius, 0, largeArcFlag, 1, innerStart.x, innerStart.y,
      "Z"
    ].join(" ");
  };

  const polarToCartesian = (centerX: number, centerY: number, radius: number, angleInDegrees: number) => {
    const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180;
    return {
      x: centerX + radius * Math.cos(angleInRadians),
      y: centerY + radius * Math.sin(angleInRadians),
    };
  };

  return (
    <Card className="bg-white border-slate-200 shadow-lg h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-bold text-slate-800 tracking-wide uppercase">
            Tempo de Fala
          </CardTitle>
          <div className="flex gap-1.5">
            <Button
              variant={activeTab === "TDF" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("TDF")}
              className={`px-2.5 py-1 text-xs font-semibold ${
                activeTab === "TDF"
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "border-slate-300 text-slate-600 hover:bg-slate-100"
              }`}
            >
              TDF
            </Button>
            <Button
              variant={activeTab === "DISC" ? "default" : "outline"}
              size="sm"
              onClick={() => setActiveTab("DISC")}
              className={`px-2.5 py-1 text-xs font-semibold ${
                activeTab === "DISC"
                  ? "bg-blue-600 text-white hover:bg-blue-700"
                  : "border-slate-300 text-slate-600 hover:bg-slate-100"
              }`}
            >
              DISC
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="py-3">
        {activeTab === "TDF" ? (
          // Tempo de Fala - Mostra tudo: barras + rosquinha
          <div className="space-y-4">
            {/* Barras de Tempo de Fala por Participante */}
            <div className="space-y-2.5">
              {/* Vendedor - primeiro */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" style={{ color: "#7C3AED" }} />
                    <span className="text-xs font-medium text-slate-700">Vendedor</span>
                  </div>
                  <span className="text-xs font-bold text-slate-800">{percentVendedor}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${percentVendedor}%`, backgroundColor: "#7C3AED" }}
                  />
                </div>
              </div>

              {/* Cliente - segundo */}
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <UserCircle className="w-3.5 h-3.5" style={{ color: "#32D58D" }} />
                    <span className="text-xs font-medium text-slate-700">Cliente</span>
                  </div>
                  <span className="text-xs font-bold text-slate-800">{percentCliente}%</span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${percentCliente}%`, backgroundColor: "#32D58D" }}
                  />
                </div>
              </div>
            </div>

            {/* Divisor */}
            <div className="border-t border-slate-200"></div>

            {/* Tempo por Fase (Donut Chart) */}
            <div>
              <h4 className="text-xs font-semibold text-slate-700 mb-2">Tempo por Fase</h4>
              <div className="flex items-center gap-4">
                {/* Gráfico Donut */}
                <div className="flex-shrink-0 w-24 h-24 relative">
                  <svg viewBox="0 0 100 100" className="w-full h-full">
                    {segments.map((segment, index) => (
                      <path
                        key={index}
                        d={createArcPath(segment.startAngle, segment.endAngle, 28, 40)}
                        fill={segment.color}
                        className="transition-all duration-500 hover:opacity-80"
                      />
                    ))}
                  </svg>
                </div>

                {/* Legenda */}
                <div className="flex-1 space-y-1.5">
                  {segments.map((segment, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <div
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: segment.color }}
                        />
                        <span className="text-xs font-medium text-slate-700">{segment.name}</span>
                      </div>
                      <span className="text-xs font-bold text-slate-800">{segment.percent}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          // DISC - Em Desenvolvimento
          <div className="flex flex-col items-center justify-center py-12 space-y-4">
            <Construction className="w-16 h-16 text-slate-400" />
            <div className="text-center">
              <p className="text-slate-700 font-semibold text-lg mb-1">
                Análise DISC
              </p>
              <p className="text-slate-500 text-sm">
                Em desenvolvimento
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
