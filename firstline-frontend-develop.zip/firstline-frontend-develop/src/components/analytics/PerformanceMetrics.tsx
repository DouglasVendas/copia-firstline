import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { TrendingUp } from "lucide-react";

interface PerformanceMetricsProps {
  desempenhoGeral: {
    abertura: number;
    descoberta: number;
    fechamento: number;
    qualificacao: number;
  } | null;
}

export function PerformanceMetrics({ desempenhoGeral }: PerformanceMetricsProps) {
  if (!desempenhoGeral) {
    return null;
  }

  const { abertura, descoberta, fechamento, qualificacao } = desempenhoGeral;

  // Calcular a média geral
  const mediaGeral = Math.round((abertura + descoberta + fechamento + qualificacao) / 4);

  const phases = [
    { label: "Abertura", value: abertura },
    { label: "Qualificação", value: qualificacao },
    { label: "Descoberta", value: descoberta },
    { label: "Fechamento", value: fechamento },
  ];

  return (
    <Card className="bg-white border-slate-200 shadow-lg h-full">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg font-bold text-slate-800 tracking-wide uppercase">
          Desempenho Geral
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-6">
          {/* Gráfico Donut (Score Geral) */}
          <div className="flex-shrink-0 w-32 h-32 relative">
            <svg viewBox="0 0 100 100" className="transform -rotate-90">
              {/* Background circle */}
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="#e5e7eb"
                strokeWidth="12"
              />
              {/* Progress circle */}
              <circle
                cx="50"
                cy="50"
                r="40"
                fill="none"
                stroke="url(#scoreGradient)"
                strokeWidth="12"
                strokeDasharray={`${(mediaGeral / 100) * 251.2} 251.2`}
                strokeLinecap="round"
                className="transition-all duration-1000 ease-out"
              />
              <defs>
                <linearGradient id="scoreGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#7C3AED" />
                  <stop offset="100%" stopColor="#32D58D" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-slate-800 leading-none">{mediaGeral}</span>
              <span className="text-xs text-slate-400 font-medium leading-none">/100</span>
            </div>
          </div>

          {/* Barras de Progresso por Fase */}
          <div className="flex-1 space-y-4">
            {phases.map((phase, index) => (
              <div key={index} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-slate-700">{phase.label}</span>
                  <span className="text-sm font-bold text-slate-800">{phase.value}%</span>
                </div>
                <div className="relative h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0 rounded-full transition-all duration-1000 ease-out"
                    style={{ 
                      width: `${phase.value}%`,
                      background: 'linear-gradient(90deg, #7C3AED 0%, #32D58D 100%)'
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
