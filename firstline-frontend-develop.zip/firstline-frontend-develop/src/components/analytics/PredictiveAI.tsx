import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Brain, Zap, Target, TrendingUp, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from '@/lib/apiFetch';

interface PredictiveInsight {
  type: 'conversion' | 'recommendation' | 'alert';
  title: string;
  description: string;
  confidence: number;
  priority: 'high' | 'medium' | 'low';
  vendedor?: string;
  actionable: boolean;
}

interface PredictiveAIProps {
  contextId?: string;
  vendedorId?: string;
}

export function PredictiveAI({ contextId, vendedorId }: PredictiveAIProps) {
  const { user } = useAuth();
  const [insights, setInsights] = useState<PredictiveInsight[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      generatePredictiveInsights();
    } else {
      setLoading(false);
    }
  }, [contextId, vendedorId, user]);

  const generatePredictiveInsights = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // Fetch recent analyses for AI predictions
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      let queryParams = new URLSearchParams({
        limit: '100',
        offset: '0'
      });

      if (contextId) {
        queryParams.append('context_id', contextId);
      }

      if (vendedorId) {
        queryParams.append('vendedor', vendedorId);
      }

      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyses?${queryParams}`);

      if (!response.ok) {
        throw new Error('Falha ao buscar análises');
      }

      const { data: analyses } = await response.json();

      // Filter analyses from the last 30 days and with valid scores
      const filteredAnalyses = analyses.filter((analysis: any) => {
        const analysisDate = new Date(analysis.created_at);
        return analysisDate >= thirtyDaysAgo && analysis.score_geral != null;
      });

      // Generate AI-powered insights based on patterns
      const generatedInsights: PredictiveInsight[] = [];

      if (filteredAnalyses && filteredAnalyses.length > 0) {
        // Conversion probability analysis
        const avgScore = filteredAnalyses.reduce((sum: number, a: any) => sum + (a.score_geral || 0), 0) / filteredAnalyses.length;
        const highScoreCount = filteredAnalyses.filter((a: any) => (a.score_geral || 0) >= 8).length;
        const conversionRate = (highScoreCount / filteredAnalyses.length) * 100;

        generatedInsights.push({
          type: 'conversion',
          title: `Probabilidade de Conversão: ${conversionRate.toFixed(0)}%`,
          description: `Com base nas últimas ${filteredAnalyses.length} análises, a taxa de calls de alta qualidade é de ${conversionRate.toFixed(0)}%. Score médio: ${avgScore.toFixed(1)}/10.`,
          confidence: conversionRate > 70 ? 90 : conversionRate > 50 ? 75 : 60,
          priority: conversionRate > 70 ? 'high' : conversionRate > 50 ? 'medium' : 'low',
          vendedor: vendedorId,
          actionable: true
        });

        // Pattern recognition for recommendations
        const commonIssues = new Map<string, number>();
        filteredAnalyses.forEach((analysis: any) => {
          analysis.pontos_atencao?.forEach((ponto: string) => {
            commonIssues.set(ponto, (commonIssues.get(ponto) || 0) + 1);
          });
        });

        if (commonIssues.size > 0) {
          const mostCommonIssue = Array.from(commonIssues.entries())
            .sort((a, b) => b[1] - a[1])[0];

          if (mostCommonIssue[1] > filteredAnalyses.length * 0.3) {
            generatedInsights.push({
              type: 'recommendation',
              title: 'Recomendação de Treinamento',
              description: `Detectado padrão recorrente: "${mostCommonIssue[0]}" aparece em ${((mostCommonIssue[1] / filteredAnalyses.length) * 100).toFixed(0)}% das calls. Recomendamos treinamento específico.`,
              confidence: 85,
              priority: 'medium',
              vendedor: vendedorId,
              actionable: true
            });
          }
        }

        // Performance trend alerts
        const recentAnalyses = filteredAnalyses.slice(-5);
        const olderAnalyses = filteredAnalyses.slice(0, -5);
        
        if (recentAnalyses.length >= 3 && olderAnalyses.length >= 3) {
          const recentAvg = recentAnalyses.reduce((sum: number, a: any) => sum + (a.score_geral || 0), 0) / recentAnalyses.length;
          const olderAvg = olderAnalyses.reduce((sum: number, a: any) => sum + (a.score_geral || 0), 0) / olderAnalyses.length;
          
          if (recentAvg < olderAvg - 1) {
            generatedInsights.push({
              type: 'alert',
              title: 'Alerta: Queda na Performance',
              description: `Performance recente (${recentAvg.toFixed(1)}) está abaixo da média histórica (${olderAvg.toFixed(1)}). Recomenda-se revisão do processo.`,
              confidence: 80,
              priority: 'high',
              vendedor: vendedorId,
              actionable: true
            });
          } else if (recentAvg > olderAvg + 1) {
            generatedInsights.push({
              type: 'conversion',
              title: 'Tendência Positiva Detectada',
              description: `Performance melhorou significativamente! Score atual (${recentAvg.toFixed(1)}) vs anterior (${olderAvg.toFixed(1)}). Continue com a estratégia atual.`,
              confidence: 85,
              priority: 'high',
              vendedor: vendedorId,
              actionable: false
            });
          }
        }

        // Smart timing recommendations
        const analysesWithTiming = filteredAnalyses.filter((a: any) => a.created_at);
        if (analysesWithTiming.length > 10) {
          const hourDistribution = new Map<number, number>();
          analysesWithTiming.forEach((analysis: any) => {
            const hour = new Date(analysis.created_at).getHours();
            hourDistribution.set(hour, (hourDistribution.get(hour) || 0) + 1);
          });

          const bestHour = Array.from(hourDistribution.entries())
            .sort((a, b) => b[1] - a[1])[0];

          if (bestHour[1] > analysesWithTiming.length * 0.2) {
            generatedInsights.push({
              type: 'recommendation',
              title: 'Timing Ideal para Calls',
              description: `Análise de padrões mostra que ${bestHour[1]} calls (${((bestHour[1] / analysesWithTiming.length) * 100).toFixed(0)}%) foram feitas às ${bestHour[0]}h. Considere focar neste horário.`,
              confidence: 70,
              priority: 'medium',
              vendedor: vendedorId,
              actionable: true
            });
          }
        }
      } else {
        // No data insights for new users
        generatedInsights.push({
          type: 'alert',
          title: 'Comece Sua Jornada Analytics',
          description: 'Você ainda não possui análises para gerar insights preditivos. Faça sua primeira análise de call para desbloquear recomendações personalizadas da IA.',
          confidence: 100,
          priority: 'medium',
          actionable: false
        });
      }

      setInsights(generatedInsights);

    } catch (error) {
      toast({
        title: "Erro na IA Preditiva",
        description: "Não foi possível gerar insights preditivos.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'conversion': return <Target className="w-5 h-5" />;
      case 'recommendation': return <Brain className="w-5 h-5" />;
      case 'alert': return <AlertTriangle className="w-5 h-5" />;
      default: return <Zap className="w-5 h-5" />;
    }
  };

  if (!user) {
    return (
      <Card className="bg-white border-blue-200 shadow-sm">
        <CardContent className="p-8 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h3 className="font-semibold text-slate-800 mb-2">Acesso Restrito</h3>
          <p className="text-slate-600">
            Faça login para acessar os insights preditivos da IA.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="bg-white border-blue-200 shadow-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-white border-blue-200 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-slate-800">
            <Brain className="w-5 h-5 text-blue-600" />
            <span>IA Preditiva FirstLine</span>
            <Badge className="bg-blue-100 text-blue-800 border-blue-200">BETA</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-600">
            Nossa IA analisa padrões em suas calls para fornecer insights preditivos e recomendações acionáveis.
          </p>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {insights.map((insight, index) => (
          <Card key={index} className={`bg-white border-blue-200 shadow-sm border-l-4 ${
            insight.type === 'conversion' ? 'border-l-green-500' :
            insight.type === 'recommendation' ? 'border-l-blue-500' :
            'border-l-orange-500'
          }`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3 flex-1">
                  <div className={`p-2 rounded-lg ${
                    insight.type === 'conversion' ? 'bg-green-100 text-green-600' :
                    insight.type === 'recommendation' ? 'bg-blue-100 text-blue-600' :
                    'bg-orange-100 text-orange-600'
                  }`}>
                    {getInsightIcon(insight.type)}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-slate-800 mb-2">{insight.title}</h3>
                    <p className="text-slate-600 mb-3">{insight.description}</p>
                    
                    <div className="flex items-center space-x-3">
                      <Badge className={`${
                        insight.priority === 'high' ? 'bg-red-100 text-red-800 border-red-200' :
                        insight.priority === 'medium' ? 'bg-yellow-100 text-yellow-800 border-yellow-200' :
                        'bg-blue-100 text-blue-800 border-blue-200'
                      }`}>
                        {insight.priority === 'high' ? 'Alta Prioridade' :
                         insight.priority === 'medium' ? 'Média Prioridade' :
                         'Baixa Prioridade'}
                      </Badge>
                      
                      <div className="flex items-center space-x-1">
                        <CheckCircle className="w-4 h-4 text-slate-500" />
                        <span className="text-sm font-medium text-slate-600">
                          Confiança: {insight.confidence}%
                        </span>
                      </div>

                      {insight.vendedor && (
                        <Badge variant="outline" className="text-xs border-slate-300 text-slate-600">
                          {insight.vendedor}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {/* {insight.actionable && (
                  <Button variant="outline" size="sm" className="ml-4 border-blue-600 text-blue-600 hover:bg-blue-50">
                    <Zap className="w-4 h-4 mr-1" />
                    Ação
                  </Button>
                )} TODO: implementar ação*/}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {insights.length === 0 && (
        <Card className="bg-white border-blue-200 shadow-sm">
          <CardContent className="p-8 text-center">
            <Brain className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="font-semibold text-slate-800 mb-2">IA Aprendendo</h3>
            <p className="text-slate-600">
              A IA FirstLine está coletando dados para gerar insights preditivos. 
              Faça mais análises para desbloquear recomendações personalizadas.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
