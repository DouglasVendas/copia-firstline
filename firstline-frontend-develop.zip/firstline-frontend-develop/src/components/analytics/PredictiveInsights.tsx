
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, TrendingUp, AlertTriangle, CheckCircle, Clock, DollarSign } from "lucide-react";

interface PredictiveInsightsProps {
  iaPreditiva: {
    probabilidade_fechamento: number;
    principais_riscos: string[];
    fatores_positivos: string[];
    timeline_provavel: string;
    acao_recomendada: string;
    valor_negocio_estimado: string;
  } | null;
}

export function PredictiveInsights({ iaPreditiva }: PredictiveInsightsProps) {
  if (!iaPreditiva) {
    return (
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-xl font-bold text-purple-800 flex items-center">
            <Brain className="w-6 h-6 mr-3 text-purple-600" />
            IA Preditiva FirstLine
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Brain className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600">Análise preditiva não disponível para esta conversa.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const getProbabilityColor = (probability: number) => {
    if (probability >= 70) return "text-green-600";
    if (probability >= 40) return "text-yellow-600";
    return "text-red-600";
  };

  // Substituir getProbabilityBg para retornar as classes do getScoreColor do AnalysisListItem
  const getProbabilityBg = (probability: number) => {
    if (probability >= 70) return "bg-green-100 text-green-800 border-green-200";
    if (probability >= 40) return "bg-yellow-100 text-yellow-800 border-yellow-200";
    return "bg-red-100 text-red-800 border-red-200";
  };

  // Safe array access with fallbacks
  const fatoresPositivos = Array.isArray(iaPreditiva.fatores_positivos) ? iaPreditiva.fatores_positivos : [];
  const principaisRiscos = Array.isArray(iaPreditiva.principais_riscos) ? iaPreditiva.principais_riscos : [];

  // Formatar valor do negócio se for número
  const formatarValorNegocio = (valor: string | undefined): string => {
    if (!valor) return "Não informado";
    
    const numeroValor = Number(valor);
    if (!isNaN(numeroValor)) {
      return numeroValor.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
      });
    }
    
    return valor;
  };

  return (
    <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-purple-800 flex items-center">
          <Brain className="w-6 h-6 mr-3 text-purple-600" />
          IA Preditiva FirstLine
        </CardTitle>
        <p className="text-sm text-purple-600 mt-2">
          <em>Análise preditiva baseada em padrões de milhares de conversas de vendas</em>
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Probabilidade de Fechamento */}
        <div className="bg-white p-6 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-bold text-slate-800 text-lg flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
              Probabilidade de Fechamento
            </h4>
            <Badge className={`px-4 py-2 text-lg font-bold border ${getProbabilityBg(iaPreditiva.probabilidade_fechamento || 0)}`}>
              {iaPreditiva.probabilidade_fechamento || 0}%
            </Badge>
          </div>
          <Progress 
            value={iaPreditiva.probabilidade_fechamento || 0} 
            className="h-3 mb-2"
          />
          <p className={`text-sm font-medium ${getProbabilityColor(iaPreditiva.probabilidade_fechamento || 0)}`}>
            {(iaPreditiva.probabilidade_fechamento || 0) >= 70 && "Alta probabilidade de conversão"}
            {(iaPreditiva.probabilidade_fechamento || 0) >= 40 && (iaPreditiva.probabilidade_fechamento || 0) < 70 && "Probabilidade moderada - necessário follow-up estratégico"}
            {(iaPreditiva.probabilidade_fechamento || 0) < 40 && "Baixa probabilidade - requer abordagem diferente"}
          </p>
        </div>

        {/* Timeline e Valor Estimado */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg border border-purple-200">
            <div className="flex items-center mb-3">
              <Clock className="w-5 h-5 mr-2 text-blue-600" />
              <h4 className="font-bold text-slate-800">Timeline Provável</h4>
            </div>
            <p className="text-slate-700 font-medium">{iaPreditiva.timeline_provavel || "Não informado"}</p>
          </div>

          <div className="bg-white p-6 rounded-lg border border-purple-200">
            <div className="flex items-center mb-3">
              <DollarSign className="w-5 h-5 mr-2 text-green-600" />
              <h4 className="font-bold text-slate-800">Valor Estimado</h4>
            </div>
            <p className="text-slate-700 font-medium">{formatarValorNegocio(iaPreditiva.valor_negocio_estimado)}</p>
          </div>
        </div>

        {/* Fatores Positivos */}
        {fatoresPositivos.length > 0 && (
          <div className="bg-white p-6 rounded-lg border border-purple-200">
            <div className="flex items-center mb-4">
              <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
              <h4 className="font-bold text-slate-800">Fatores Positivos Identificados</h4>
            </div>
            <div className="space-y-3">
              {fatoresPositivos.map((fator, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <Badge className="bg-green-100 text-green-800 border-green-200 px-2 py-1 text-xs"><CheckCircle className="w-4 h-4 text-green-800" /></Badge>
                  <span className="text-green-800 font-medium leading-relaxed">{fator}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Principais Riscos */}
        {principaisRiscos.length > 0 && (
          <div className="bg-white p-6 rounded-lg border border-purple-200">
            <div className="flex items-center mb-4">
              <AlertTriangle className="w-5 h-5 mr-2 text-red-600" />
              <h4 className="font-bold text-slate-800">Principais Riscos Identificados</h4>
            </div>
            <div className="space-y-3">
              {principaisRiscos.map((risco, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <Badge className="bg-red-100 text-red-800 border-red-200 px-2 py-1 text-xs"><AlertTriangle className="w-4 h-4 text-red-800" /></Badge>
                  <span className="text-red-800 font-medium leading-relaxed">{risco}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Ação Recomendada */}
        {iaPreditiva.acao_recomendada && (
          <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-6 rounded-lg border-l-4 border-purple-400">
            <div className="flex items-start space-x-3">
              <Brain className="w-6 h-6 text-purple-600 mt-0.5" />
              <div>
                <h4 className="font-bold text-purple-800 mb-2">Próxima Ação Prioritária (IA FirstLine)</h4>
                <p className="text-purple-700 leading-relaxed font-medium">{iaPreditiva.acao_recomendada}</p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
