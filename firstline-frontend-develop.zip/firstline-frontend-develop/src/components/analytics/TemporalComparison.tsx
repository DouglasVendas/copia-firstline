import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Calendar, User, BarChart3, Target, AlertTriangle, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { apiFetch } from '@/lib/apiFetch';
import { Listbox } from '@headlessui/react';
import { ChevronUpDownIcon, CheckIcon } from '@heroicons/react/20/solid';

interface ScoreEntry {
  [timestamp: string]: number;
}

interface VendedorScore {
  id: string;
  nome: string;
  scores: ScoreEntry[];
}

interface AnalysisMetrics {
  date: string;
  score: number;
  vendedor: string;
  count: number;
  vendedor_id: string;
}

interface TemporalComparisonProps {
  contextId?: string;
}

export function TemporalComparison({ contextId }: TemporalComparisonProps) {
  const { user } = useAuth();
  const [period, setPeriod] = useState<'30' | '60' | '90'>('30');
  const [selectedVendedores, setSelectedVendedores] = useState<string[]>([]);
  const [allMetrics, setAllMetrics] = useState<AnalysisMetrics[]>([]); // Armazenar todos os dados
  const [filteredMetrics, setFilteredMetrics] = useState<AnalysisMetrics[]>([]); // Dados filtrados
  const [vendedores, setVendedores] = useState<{ id: string, nome: string }[]>([]); // Agora armazena id e nome
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  // Remover o estado showVendedoresDropdown pois o Listbox já gerencia isso
  // const [showVendedoresDropdown, setShowVendedoresDropdown] = useState(false);

  // Remover selectedVendedores das dependências do useEffect
  useEffect(() => {
    if (user) {
      fetchMetrics();
    } else {
      setLoading(false);
    }
  }, [period, contextId, user]);

  // Adicionar useEffect para filtrar dados localmente quando selectedVendedores mudar
  useEffect(() => {
    if (selectedVendedores.length === 0) {
      setFilteredMetrics([]);
    } else {
      setFilteredMetrics(allMetrics.filter(m => selectedVendedores.includes(m.vendedor_id)));
    }
  }, [selectedVendedores, allMetrics]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.relative.w-64')) {
        // setShowVendedoresDropdown(false); // Não precisa mais
      }
    };
    // if (showVendedoresDropdown) { // Não precisa mais
    //   document.addEventListener('mousedown', handleClick);
    // } else { // Não precisa mais
    //   document.removeEventListener('mousedown', handleClick);
    // } // Não precisa mais
    return () => document.removeEventListener('mousedown', handleClick);
  }, []); // Não precisa mais

  const fetchMetrics = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(period));

      let queryParams = new URLSearchParams();

      if (contextId) {
        queryParams.append('context_id', contextId);
      }

      const response = await apiFetch(`${import.meta.env.VITE_API_URL}/analyses/scores?${queryParams}`);

      if (!response.ok) {
        throw new Error('Falha ao buscar métricas');
      }

      const data: VendedorScore[] = await response.json();

      // Process data for charts
      const processedData: AnalysisMetrics[] = [];
      const vendedoresSet = new Set<string>();
      const vendedoresMap = new Map<string, string>();
      const vendedorLastAverage = new Map<string, number>(); // Para armazenar a última média de cada vendedor

      data.forEach((vendedor: VendedorScore) => {
        vendedoresSet.add(vendedor.id);
        vendedoresMap.set(vendedor.id, vendedor.nome);

        const scoresInPeriod: number[] = [];
        const scoresBeforePeriod: number[] = [];

        vendedor.scores.forEach((scoreEntry: ScoreEntry) => {
          const timestamp = Object.keys(scoreEntry)[0];
          const score = scoreEntry[timestamp];
          const analysisDate = new Date(timestamp);

          if (analysisDate >= startDate) {
            scoresInPeriod.push(score);
            const date = analysisDate.toLocaleDateString('pt-BR');
            const existingEntry = processedData.find(d => 
              d.date === date && d.vendedor_id === vendedor.id
            );

            if (existingEntry) {
              existingEntry.score = (existingEntry.score * existingEntry.count + score) / (existingEntry.count + 1);
              existingEntry.count += 1;
            } else {
              processedData.push({
                date,
                score,
                vendedor: vendedor.nome,
                vendedor_id: vendedor.id,
                count: 1
              });
            }
          } else {
            scoresBeforePeriod.push(score);
          }
        });

        // Se o vendedor não tem scores no período mas tem scores anteriores, calcular a média
        if (scoresInPeriod.length === 0 && scoresBeforePeriod.length > 0) {
          const average = scoresBeforePeriod.reduce((sum, score) => sum + score, 0) / scoresBeforePeriod.length;
          vendedorLastAverage.set(vendedor.id, average);
        }
      });

      // Para vendedores que não têm dados no período, adicionar a média anterior
      // Mas só adicionar em uma data fictícia para que apareçam na lista de vendedores
      vendedorLastAverage.forEach((average, vendedorId) => {
        const vendedorNome = vendedoresMap.get(vendedorId) || vendedorId;
        // Adicionar apenas uma entrada fictícia para que o vendedor apareça na lista
        processedData.push({
          date: startDate.toLocaleDateString('pt-BR'),
          score: average,
          vendedor: vendedorNome,
          vendedor_id: vendedorId,
          count: 1
        });
      });

      // Ordenar por data crescente
      processedData.sort((a, b) => {
        const [d1, m1, y1] = a.date.split('/').map(Number);
        const [d2, m2, y2] = b.date.split('/').map(Number);
        const dateA = new Date(y1, m1 - 1, d1);
        const dateB = new Date(y2, m2 - 1, d2);
        return dateA.getTime() - dateB.getTime();
      });

      setAllMetrics(processedData);
      setVendedores(Array.from(vendedoresSet).map(id => ({
        id,
        nome: vendedoresMap.get(id) || id
      })));

      // Se nada selecionado, selecionar todos por padrão
      if (selectedVendedores.length === 0 && vendedoresSet.size > 0) {
        setSelectedVendedores(Array.from(vendedoresSet));
      }
    } catch (error) {
      toast({
        title: "Erro ao carregar métricas",
        description: "Não foi possível carregar os dados de comparação temporal.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Ajustar função handleSelectAll para garantir que desmarca tudo
  const handleSelectAll = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const allSelected = selectedVendedores.length === vendedores.length;
    setSelectedVendedores(allSelected ? [] : vendedores.map(v => v.id));
  };

  // Adicionar função para gerenciar a seleção individual
  const handleSelectVendedor = (vendedorId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedVendedores(prev => {
      if (prev.includes(vendedorId)) {
        return prev.filter(id => id !== vendedorId);
      } else {
        return [...prev, vendedorId];
      }
    });
  };

  // Ajustar chartData para usar filteredMetrics em vez de metrics
  const chartData = (() => {
    if (selectedVendedores.length === 0 || filteredMetrics.length === 0) return [];

    // Encontrar a data mais antiga e mais recente do período
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));
    const today = new Date();

    // Criar um mapa com todas as pontuações dos vendedores selecionados
    const vendedorScores: Record<string, Record<string, number>> = {};
    const vendedorFirstDate: Record<string, Date> = {};

    selectedVendedores.forEach(vId => {
      vendedorScores[vId] = {};
    });

    // Registrar todas as pontuações e encontrar a primeira data de cada vendedor
    filteredMetrics.forEach(m => {
      if (selectedVendedores.includes(m.vendedor_id)) {
        vendedorScores[m.vendedor_id][m.date] = m.score;
        
        const [d, mon, y] = m.date.split('/').map(Number);
        const metricDate = new Date(y, mon - 1, d);
        
        if (!vendedorFirstDate[m.vendedor_id] || metricDate < vendedorFirstDate[m.vendedor_id]) {
          vendedorFirstDate[m.vendedor_id] = metricDate;
        }
      }
    });

    // Gerar todas as datas do período (do início até hoje)
    const allDates: string[] = [];
    const currentDate = new Date(startDate);
    
    while (currentDate <= today) {
      allDates.push(currentDate.toLocaleDateString('pt-BR'));
      currentDate.setDate(currentDate.getDate() + 1);
    }

    // Processar os dados para o gráfico
    const chartRows = allDates.map(date => {
      const row: any = { date };
      const [d, m, y] = date.split('/').map(Number);
      const currentDateObj = new Date(y, m - 1, d);
      
      selectedVendedores.forEach(vId => {
        // Só mostrar dados se a data atual for igual ou posterior à primeira análise do vendedor
        if (vendedorFirstDate[vId] && currentDateObj >= vendedorFirstDate[vId]) {
          if (vendedorScores[vId][date] !== undefined) {
            // Se temos um valor para esta data, usar ele
            row[vId] = vendedorScores[vId][date];
          } else {
            // Se não temos um valor para esta data, procurar a última média conhecida
            const lastKnownScore = allDates
              .filter(d => {
                const [dd, mm, yy] = d.split('/').map(Number);
                const dDate = new Date(yy, mm - 1, dd);
                return dDate < currentDateObj && 
                       dDate >= vendedorFirstDate[vId] &&
                       vendedorScores[vId][d] !== undefined;
              })
              .sort((a, b) => {
                const [d1, m1, y1] = a.split('/').map(Number);
                const [d2, m2, y2] = b.split('/').map(Number);
                const dateA = new Date(y1, m1 - 1, d1);
                const dateB = new Date(y2, m2 - 1, d2);
                return dateB.getTime() - dateA.getTime();
              })[0];

            if (lastKnownScore) {
              row[vId] = vendedorScores[vId][lastKnownScore];
            }
          }
        }
      });
      
      return row;
    });

    return chartRows;
  })();

  // Ajustar getAverageScore para usar filteredMetrics
  const getAverageScore = () => {
    if (filteredMetrics.length === 0) return 0;
    const total = filteredMetrics.reduce((sum, metric) => sum + metric.score, 0);
    return (total / filteredMetrics.length).toFixed(1);
  };

  const getTrend = () => {
    if (filteredMetrics.length < 2) return 'stable';

    // Ordenar por data para garantir a ordem cronológica
    const sortedMetrics = [...filteredMetrics].sort((a, b) => {
      const [d1, m1, y1] = a.date.split('/').map(Number);
      const [d2, m2, y2] = b.date.split('/').map(Number);
      const dateA = new Date(y1, m1 - 1, d1);
      const dateB = new Date(y2, m2 - 1, d2);
      return dateA.getTime() - dateB.getTime();
    });

    // Pegar o último valor de cada vendedor
    const lastValueByVendedor: Record<string, { date: Date, score: number }> = {};
    const secondLastValueByVendedor: Record<string, { date: Date, score: number }> = {};

    sortedMetrics.forEach(metric => {
      const [d, m, y] = metric.date.split('/').map(Number);
      const date = new Date(y, m - 1, d);

      if (!lastValueByVendedor[metric.vendedor_id] || 
          date > lastValueByVendedor[metric.vendedor_id].date) {
        // Mover o último valor para o penúltimo
        if (lastValueByVendedor[metric.vendedor_id]) {
          secondLastValueByVendedor[metric.vendedor_id] = lastValueByVendedor[metric.vendedor_id];
        }
        // Atualizar o último valor
        lastValueByVendedor[metric.vendedor_id] = { date, score: metric.score };
      } else if (!secondLastValueByVendedor[metric.vendedor_id] || 
                 date > secondLastValueByVendedor[metric.vendedor_id].date) {
        secondLastValueByVendedor[metric.vendedor_id] = { date, score: metric.score };
      }
    });

    // Calcular a tendência geral baseada na diferença entre o último e o penúltimo valor
    let totalDiff = 0;
    let countComparisons = 0;

    selectedVendedores.forEach(vendedorId => {
      const last = lastValueByVendedor[vendedorId];
      const secondLast = secondLastValueByVendedor[vendedorId];

      if (last && secondLast) {
        totalDiff += last.score - secondLast.score;
        countComparisons++;
      }
    });

    if (countComparisons === 0) return 'stable';
    
    const averageDiff = totalDiff / countComparisons;
    
    if (averageDiff > 0.2) return 'up';
    if (averageDiff < -0.2) return 'down';
    return 'stable';
  };

  const chartColors = ['#3B82F6', '#F97316', '#10B981', '#EF4444', '#8B5CF6', '#F59E0B'];

  if (!user) {
    return (
      <Card className="bg-white border-blue-200 shadow-sm">
        <CardContent className="p-8 text-center">
          <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h3 className="font-semibold text-slate-800 mb-2">Acesso Restrito</h3>
          <p className="text-slate-600">
            Faça login para acessar a comparação temporal.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-32">
            <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <Card className="bg-white border-blue-200 shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-slate-800">
            <BarChart3 className="w-5 h-5" />
            <span>Comparação Temporal</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Período</label>
              <Select value={period} onValueChange={(value: '30' | '60' | '90') => setPeriod(value)}>
                <SelectTrigger className="w-32 bg-white border-blue-200 text-slate-900">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white border-blue-200">
                  <SelectItem value="30" className="text-slate-900 hover:bg-blue-50">30 dias</SelectItem>
                  <SelectItem value="60" className="text-slate-900 hover:bg-blue-50">60 dias</SelectItem>
                  <SelectItem value="90" className="text-slate-900 hover:bg-blue-50">90 dias</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">Vendedores</label>
              <Listbox value={selectedVendedores} onChange={setSelectedVendedores} multiple>
                <div className="relative w-64">
                  <Listbox.Button className="w-full border border-blue-200 bg-white rounded-lg px-3 py-[0.5625rem] text-left text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-200 flex items-center justify-between transition-all shadow-sm text-sm h-10">
                    <span className="truncate">
                      {selectedVendedores.length === 0
                        ? 'Selecione vendedores'
                        : selectedVendedores.length === vendedores.length
                          ? 'Todos os vendedores'
                          : `${selectedVendedores.length} selecionado(s)`}
                    </span>
                    <ChevronUpDownIcon className="w-4 h-4 text-slate-400" />
                  </Listbox.Button>
                  <Listbox.Options className="absolute z-10 mt-1 w-full bg-white border border-blue-200 rounded-lg shadow-lg max-h-60 overflow-auto py-1 text-sm">
                    <div
                      className="flex items-center px-3 py-2 cursor-pointer rounded hover:bg-blue-50"
                      onClick={handleSelectAll}
                    >
                      <input
                        type="checkbox"
                        className="mr-2 rounded"
                        checked={selectedVendedores.length === vendedores.length && vendedores.length > 0}
                        readOnly
                      />
                      <span>Selecionar todos</span>
                    </div>
                    <div className="border-t border-blue-100 my-1" />
                    {vendedores.map(vendedor => (
                      <div
                        key={vendedor.id}
                        className="flex items-center px-3 py-2 cursor-pointer rounded hover:bg-blue-50"
                        onClick={(e) => handleSelectVendedor(vendedor.id, e)}
                      >
                        <input
                          type="checkbox"
                          className="mr-2 rounded"
                          checked={selectedVendedores.includes(vendedor.id)}
                          readOnly
                        />
                        <span>{vendedor.nome}</span>
                        {selectedVendedores.includes(vendedor.id) && (
                          <CheckIcon className="w-4 h-4 text-blue-600 ml-auto" />
                        )}
                      </div>
                    ))}
                  </Listbox.Options>
                </div>
              </Listbox>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chart */}
      <Card className="bg-white border-blue-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-slate-800">Evolução dos Scores</CardTitle>
        </CardHeader>
        <CardContent>
          {selectedVendedores.length === 0 || chartData.length === 0 ? (
            <div className="text-center py-12">
              <BarChart3 className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500 text-lg font-semibold">
                Nenhum dado disponível
              </p>
              <p className="text-slate-400 mt-2">
                Selecione pelo menos um vendedor para visualizar o gráfico
              </p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" stroke="#e2e8f0" fontSize={12} />
                <YAxis domain={[0, 10]} stroke="#e2e8f0" fontSize={12} tickFormatter={(value) => value.toFixed(1)} />
                <Tooltip 
                  content={({ active, payload, label }) => {
                    if (active && payload && payload.length) {
                      // Ordenar os vendedores por score (maior para menor)
                      const sortedPayload = [...payload]
                        .filter(entry => entry.value !== null && entry.value !== undefined)
                        .sort((a, b) => {
                          const scoreA = typeof a.value === 'number' ? a.value : 0;
                          const scoreB = typeof b.value === 'number' ? b.value : 0;
                          return scoreB - scoreA;
                        });

                      return (
                        <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-3">
                          <p className="font-medium text-gray-900 mb-2">{`Data: ${label}`}</p>
                          {sortedPayload.map((entry, index) => {
                            const vendedorNome = vendedores.find(v => v.id === entry.dataKey)?.nome || entry.dataKey;
                            return (
                              <div key={index} className="flex items-center gap-2 text-sm">
                                <div 
                                  className="w-3 h-3 rounded-full" 
                                  style={{ backgroundColor: entry.color }}
                                />
                                <span className="text-gray-700">{vendedorNome}:</span>
                                <span className="font-medium text-gray-900">
                                  {typeof entry.value === 'number' ? entry.value.toFixed(1) : entry.value}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                {selectedVendedores.map((vendedorId, index) => {
                  const vendedor = vendedores.find(v => v.id === vendedorId);
                  
                  // Encontrar a primeira análise deste vendedor
                  const vendedorMetrics = filteredMetrics.filter(m => m.vendedor_id === vendedorId);
                  const firstAnalysis = vendedorMetrics.sort((a, b) => {
                    const [d1, m1, y1] = a.date.split('/').map(Number);
                    const [d2, m2, y2] = b.date.split('/').map(Number);
                    const dateA = new Date(y1, m1 - 1, d1);
                    const dateB = new Date(y2, m2 - 1, d2);
                    return dateA.getTime() - dateB.getTime();
                  })[0];
                  
                  return (
                    <Line
                      key={vendedorId}
                      connectNulls
                      type="linear"
                      dataKey={vendedorId}
                      stroke={chartColors[index % chartColors.length]}
                      strokeWidth={2}
                      dot={(props: any) => {
                        // Só mostrar ponto na primeira análise do vendedor
                        if (firstAnalysis && props.payload.date === firstAnalysis.date) {
                          return (
                            <circle
                              cx={props.cx}
                              cy={props.cy}
                              r={5}
                              fill={chartColors[index % chartColors.length]}
                              stroke="white"
                              strokeWidth={2}
                            />
                          );
                        }
                        return null;
                      }}
                      name={vendedor ? vendedor.nome : vendedorId}
                    />
                  );
                })}
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-white border-blue-200 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between h-full">
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-600">Score Médio (Vendedores Selecionados)</p>
                <p className="text-2xl font-bold text-slate-900">{getAverageScore()}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-blue-200 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between h-full">
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-600">Total de Análises</p>
                <p className="text-2xl font-bold text-slate-900">{filteredMetrics.length}</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                <BarChart3 className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-blue-200 shadow-sm">
          <CardContent className="p-6">
            <div className="flex items-center justify-between h-full">
              <div className="space-y-2">
                <p className="text-sm font-medium text-slate-600">Tendência</p>
                <div className="flex items-center space-x-2 mt-1">
                  {getTrend() === 'up' && (
                    <Badge className="bg-green-100 text-green-800 border-green-200 text-base px-3 py-0.95 font-medium">Subindo</Badge>
                  )}
                  {getTrend() === 'down' && (
                    <Badge className="bg-red-100 text-red-800 border-red-200 text-base px-3 py-0.95 font-medium">Descendo</Badge>
                  )}
                  {getTrend() === 'stable' && (
                    <Badge className="bg-gray-100 text-gray-800 border-gray-200 text-base px-3 py-0.95 font-medium">Estável</Badge>
                  )}
                </div>
              </div>
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${
                getTrend() === 'up' 
                  ? 'bg-green-100' 
                  : getTrend() === 'down' 
                    ? 'bg-red-100' 
                    : 'bg-gray-100'
              }`}>
                {getTrend() === 'down' ? (
                  <TrendingDown className={`w-6 h-6 ${
                    getTrend() === 'up' 
                      ? 'text-green-600' 
                      : getTrend() === 'down' 
                        ? 'text-red-600' 
                        : 'text-gray-600'
                  }`} />
                ) : (
                  <TrendingUp className={`w-6 h-6 ${
                    getTrend() === 'up' 
                      ? 'text-green-600' 
                      : getTrend() === 'down' 
                        ? 'text-red-600' 
                        : 'text-gray-600'
                  }`} />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
